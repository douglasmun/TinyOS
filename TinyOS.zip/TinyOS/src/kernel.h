/*=============================================================================
 *  Shogun-OS — Public Kernel Interface (kernel.h)
 *============================================================================*/
#ifndef SHOGUN_KERNEL_H
#define SHOGUN_KERNEL_H

#include <stdint.h>
#include <stddef.h>

#if defined(__GNUC__) || defined(__clang__)
#  define PACKED     __attribute__((packed))
#  define NORETURN   __attribute__((noreturn))
#else
#  define PACKED
#  define NORETURN
#endif

/* VGA text-mode */
enum { VGA_WIDTH = 80, VGA_HEIGHT = 25, VGA_BUFFER_ADDR = 0xB8000 };
#define VGA_DEFAULT_ATTR 0x0F

/* Multiboot magic values (EAX on entry) */
#define MB1_MAGIC_BOOT  0x2BADB002u
#define MB2_MAGIC_BOOT  0x36D76289u

/* ------------------------- Multiboot v1 ------------------------- */
struct PACKED multiboot_info {
    uint32_t flags;
    uint32_t mem_lower, mem_upper;
    uint32_t boot_device;            /* optional */
    uint32_t cmdline;                /* char* */
    uint32_t mods_count, mods_addr;  /* optional */
    uint32_t num, size, addr, shndx; /* ELF */
    uint32_t mmap_length, mmap_addr; /* memory map */
    uint32_t drives_length, drives_addr;
    uint32_t config_table;
    uint32_t boot_loader_name;       /* char* */
    uint32_t apm_table;
    uint32_t vbe_ctrl_info, vbe_mode_info, vbe_mode;
    uint32_t vbe_interface_seg, vbe_interface_off, vbe_interface_len;
};

struct PACKED mb1_mmap_entry {
    uint32_t size;       /* size of the remaining fields (20) */
    uint32_t base_lo, base_hi;
    uint32_t len_lo,  len_hi;
    uint32_t type;       /* 1 = usable RAM */
};

/* ------------------------- Multiboot v2 ------------------------- */
struct PACKED mb2_tag { uint32_t type, size; };

enum { MB2_TAG_END = 0, MB2_TAG_CMDLINE = 1, MB2_TAG_BOOTLOADER = 2, MB2_TAG_MMAP = 6 };

struct PACKED mb2_tag_string { uint32_t type, size; char str[]; };

struct PACKED mb2_tag_mmap {
    uint32_t type, size;
    uint32_t entry_size;
    uint32_t entry_version;
    /* entries follow */
};

struct PACKED mb2_mmap_entry {
    uint64_t addr;
    uint64_t len;
    uint32_t type;
    uint32_t zero;
};

/* Entry point from boot.s */
void kernel_main(uint32_t magic, uint32_t info_ptr);

/* Panic & tiny libc */
NORETURN void panic(const char* msg);
void* memset(void* dst, int val, size_t n);
void* memcpy(void* dst, const void* src, size_t n);

/* Console (vga.c) */
void  console_clear(void);
void  console_putc(char c);
void  console_puts(const char* s);
void  console_put_hex32(uint32_t v);
void  console_put_hex64(uint64_t v);
void  console_put_dec_u32(uint32_t v);
void  console_put_dec_i32(int32_t v);

/* Multiboot dumpers (multiboot.c) */
void  mb_dump_mb1(const struct multiboot_info* mb);
void  mb_dump_mb2(const void* info_ptr);

#endif /* SHOGUN_KERNEL_H */
