/*=============================================================================
 *  util.c — Freestanding C Library and Kernel Utilities for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file provides fundamental utility functions that a kernel needs to
 *   operate in a FREESTANDING environment (no standard C library). It
 *   implements essential string/memory operations and critical error handling.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Target: i386 (32-bit x86) protected mode
 *   - Environment: Freestanding (no libc, no OS services)
 *   - Dependencies: Minimal (only kernel.h and serial.h)
 *   - Safety: Defensive programming with null checks
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is Freestanding C?
 * 2. Why We Need Our Own memset/memcpy
 * 3. Memory Operations Deep Dive
 * 4. Panic: The Last Resort
 * 5. Design Decisions and Trade-offs
 * 6. Performance Considerations
 * 7. Common Pitfalls and Solutions
 * 8. Testing and Verification
 * 9. Integration with the Kernel
 *
 *=============================================================================
 * SECTION 1: WHAT IS FREESTANDING C?
 *=============================================================================
 * 
 * When writing an operating system kernel, we face a chicken-and-egg problem:
 * 
 * THE PROBLEM:
 *   - Normal C programs depend on the STANDARD C LIBRARY (libc)
 *   - libc provides: printf, malloc, memcpy, strlen, etc.
 *   - But libc depends on an OPERATING SYSTEM (system calls for I/O, memory)
 *   - Our kernel IS the operating system
 *   - Result: We can't use libc! (Nothing to depend on yet)
 * 
 * TWO TYPES OF C ENVIRONMENTS:
 * 
 * 1. HOSTED ENVIRONMENT (Normal C programs):
 *    - Full standard library available
 *    - OS provides system calls
 *    - main() is called by OS
 *    - Can use: stdio.h, stdlib.h, string.h, etc.
 *    - Examples: Desktop apps, web servers, utilities
 * 
 * 2. FREESTANDING ENVIRONMENT (OS kernels, embedded systems):
 *    - NO standard library (except a few headers)
 *    - NO OS to provide services
 *    - Entry point defined by us (not main)
 *    - Can ONLY use: stdint.h, stddef.h, stdarg.h, stdbool.h
 *    - Must implement everything ourselves
 *    - Examples: Kernels, bootloaders, firmware
 * 
 * WHAT FREESTANDING PROVIDES:
 *   The C standard GUARANTEES these headers work in freestanding:
 *   - stdint.h:  Fixed-width types (uint32_t, int8_t, etc.)
 *   - stddef.h:  Basic definitions (size_t, NULL, offsetof)
 *   - stdarg.h:  Variable argument lists (va_list, va_start, va_end)
 *   - stdbool.h: Boolean type (bool, true, false)
 *   - float.h:   Floating-point limits
 *   - limits.h:  Integer limits
 *   - iso646.h:  Alternative operators (not, and, or)
 * 
 * WHAT FREESTANDING DOES NOT PROVIDE:
 *   Everything else! Including:
 *   ❌ stdio.h (printf, scanf, fopen, etc.)
 *   ❌ stdlib.h (malloc, free, exit, etc.)
 *   ❌ string.h (memcpy, strlen, strcpy, etc.) ← WE IMPLEMENT THESE!
 *   ❌ time.h (time, clock, etc.)
 *   ❌ math.h (sin, cos, sqrt, etc.)
 *   ❌ Any file I/O, networking, threads, etc.
 * 
 * COMPILER FLAGS FOR FREESTANDING:
 *   -ffreestanding: Tells GCC we're in freestanding mode
 *   -nostdlib: Don't link against standard library
 *   -fno-builtin: Don't use compiler's built-in function implementations
 * 
 * IMPLICATIONS FOR TINYOS:
 *   Since we're freestanding, we must implement:
 *   ✅ memset() - Fill memory with a byte value
 *   ✅ memcpy() - Copy memory from src to dst
 *   ✅ memcmp() - Compare two memory regions (future)
 *   ✅ strlen() - Get string length (future)
 *   ✅ strcpy() - Copy strings (future)
 *   ✅ printf() - Formatted output (we have kprintf!)
 *   
 *   This file implements memset and memcpy.
 *   Other files implement the rest (kprintf.c for formatted output, etc.)
 * 
 * WHY NOT JUST LINK AGAINST LIBC?
 *   - libc makes system calls (we ARE the system)
 *   - libc assumes paging, memory protection (we haven't set up yet)
 *   - libc is large (several MB, our kernel should be small)
 *   - libc has hidden dependencies (dynamic linker, etc.)
 *   - We want complete control over everything
 *   - Educational value: Learn how things work at the lowest level!
 *
 *=============================================================================
 * SECTION 2: WHY WE NEED OUR OWN MEMSET/MEMCPY
 *=============================================================================
 * 
 * Q: Can't the compiler handle memory operations automatically?
 * A: Not in freestanding mode! Let's see why.
 * 
 * WHAT HAPPENS IN NORMAL C:
 * 
 * Source code:
 *   char buffer[100];
 *   memset(buffer, 0, sizeof(buffer));
 * 
 * Compiled code (hosted environment):
 *   call memset@libc    ; Call libc's memset function
 * 
 * Linked:
 *   Linker finds memset in libc.so and links it in.
 * 
 * WHAT HAPPENS IN FREESTANDING C:
 * 
 * Source code (same):
 *   char buffer[100];
 *   memset(buffer, 0, sizeof(buffer));
 * 
 * Compiled code (freestanding):
 *   call memset         ; Call to undefined function
 * 
 * Linked:
 *   ERROR: undefined reference to 'memset'
 *   Linker can't find memset (no libc!)
 * 
 * SOLUTION:
 *   We provide our own memset implementation.
 *   Now the linker finds OUR memset and links it.
 * 
 * COMPILER OPTIMIZATIONS:
 *   Modern compilers (GCC, Clang) have BUILT-IN implementations of
 *   memset/memcpy that can be faster than function calls.
 * 
 *   Example: GCC can turn memset into a single REP STOSB instruction.
 * 
 *   With -fno-builtin:
 *   - Compiler treats memset as a normal function call
 *   - Uses our implementation
 *   - Gives us control but may be slower
 * 
 *   Without -fno-builtin:
 *   - Compiler might inline memory operations
 *   - Faster but less predictable
 *   - Might still call our implementation for large sizes
 * 
 *   TinyOS uses -fno-builtin for:
 *   - Predictability (know exactly what code runs)
 *   - Debugging (can set breakpoints in our functions)
 *   - Learning (see how memory operations work)
 * 
 * WHEN ARE THESE FUNCTIONS USED?
 * 
 * memset is used for:
 *   - Zeroing buffers: memset(buffer, 0, size)
 *   - Initializing arrays: memset(array, 0xFF, size)
 *   - Clearing structures: memset(&struct, 0, sizeof(struct))
 *   - Clearing sensitive data: memset(password, 0, len)
 * 
 * memcpy is used for:
 *   - Copying buffers: memcpy(dst, src, size)
 *   - Duplicating structures: memcpy(&dst, &src, sizeof(struct))
 *   - Loading data: memcpy(buffer, disk_data, size)
 *   - Saving data: memcpy(disk_data, buffer, size)
 * 
 * EXAMPLES IN TINYOS:
 *   - IDT setup: memset(idt, 0, sizeof(idt))
 *   - PMM bitmap: memset(bitmap, 0xFF, size) to mark all used
 *   - Stack clearing: memset(stack, 0, STACK_SIZE)
 *   - Frame buffer ops: memcpy(vga_buffer, temp, VGA_SIZE)
 *
 *=============================================================================
 * SECTION 3: MEMORY OPERATIONS DEEP DIVE
 *=============================================================================
 * 
 * MEMSET: FILL MEMORY WITH A BYTE VALUE
 * 
 * Function signature:
 *   void* memset(void* dst, int val, size_t n);
 * 
 * What it does:
 *   Fills 'n' bytes at 'dst' with the byte value 'val'.
 * 
 * Parameters:
 *   dst - Pointer to memory to fill
 *   val - Value to fill (only lowest 8 bits used)
 *   n   - Number of bytes to fill
 * 
 * Return value:
 *   Returns 'dst' (same pointer passed in)
 *   Why? Allows chaining: process(memset(buf, 0, size))
 * 
 * Example usage:
 *   char buffer[100];
 *   memset(buffer, 0, sizeof(buffer));      // Zero buffer
 *   memset(buffer, 'A', sizeof(buffer));    // Fill with 'A'
 *   memset(buffer, 0xFF, sizeof(buffer));   // Fill with 0xFF
 * 
 * Memory layout (before and after):
 * 
 * Before: buffer = [0x12, 0x34, 0x56, 0x78, 0xAB, 0xCD, ...]
 * After memset(buffer, 0, 6):
 *         buffer = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...]
 * 
 * MEMCPY: COPY MEMORY FROM SOURCE TO DESTINATION
 * 
 * Function signature:
 *   void* memcpy(void* dst, const void* src, size_t n);
 * 
 * What it does:
 *   Copies 'n' bytes from 'src' to 'dst'.
 * 
 * Parameters:
 *   dst - Destination pointer (where to copy TO)
 *   src - Source pointer (where to copy FROM)
 *   n   - Number of bytes to copy
 * 
 * Return value:
 *   Returns 'dst' (same pointer passed in)
 * 
 * Example usage:
 *   char src[10] = "Hello";
 *   char dst[10];
 *   memcpy(dst, src, 10);  // dst now contains "Hello\0"
 * 
 * Memory layout:
 * 
 * Before:
 *   src = ['H', 'e', 'l', 'l', 'o', '\0', ...]
 *   dst = [0x??, 0x??, 0x??, 0x??, 0x??, 0x??, ...]  (garbage)
 * 
 * After memcpy(dst, src, 6):
 *   src = ['H', 'e', 'l', 'l', 'o', '\0', ...]  (unchanged)
 *   dst = ['H', 'e', 'l', 'l', 'o', '\0', ...]  (copied)
 * 
 * CRITICAL WARNING: OVERLAPPING REGIONS
 * 
 * memcpy is UNSAFE if src and dst overlap!
 * 
 * Example of overlap:
 *   char buffer[10] = "Hello";
 *   memcpy(buffer + 2, buffer, 5);  // UNDEFINED BEHAVIOR!
 * 
 * Why? Because we're copying forward and overwriting source:
 *   Step 1: buffer[2] = buffer[0] = 'H'  → "HeHlo"
 *   Step 2: buffer[3] = buffer[1] = 'e'  → "HeHeo"
 *   Step 3: buffer[4] = buffer[2] = 'H'  → "HeHeH"  (oops! was 'l')
 *   Result: Corrupted data!
 * 
 * Solution: Use memmove (not implemented in TinyOS yet)
 *   memmove checks for overlap and copies in correct direction.
 * 
 * In TinyOS:
 *   - We NEVER call memcpy with overlapping regions
 *   - If needed, we'd implement memmove
 *   - Current uses are all non-overlapping (safe)
 * 
 * ALIGNMENT CONSIDERATIONS:
 * 
 * Our implementation copies byte-by-byte (unsigned char).
 * This is SLOW but CORRECT for any alignment.
 * 
 * Faster alternatives:
 *   1. Copy by uint32_t (4 bytes at a time) if aligned
 *   2. Use SIMD instructions (SSE, AVX) for large copies
 *   3. Use REP MOVSB/MOVSW/MOVSD (x86 string instructions)
 * 
 * Trade-off in TinyOS:
 *   ✅ Simple, portable, correct
 *   ❌ Not optimized for speed
 *   
 *   For a learning OS, simplicity > speed.
 *   Production kernels (Linux, FreeBSD) use highly optimized versions.
 * 
 * NULL POINTER BEHAVIOR:
 * 
 * Standard C says: memset/memcpy with NULL pointers is UNDEFINED.
 * 
 * Our implementation:
 *   - Does NOT check for NULL (for simplicity)
 *   - If you pass NULL, you'll get a page fault
 *   - In kernel mode, page fault → panic → halt
 * 
 * Better implementation (defensive):
 *   if (dst == NULL || src == NULL) return NULL;
 * 
 * TinyOS approach:
 *   - Trust the caller (kernel code should be correct)
 *   - If we crash, fix the caller (not hide the bug)
 *   - Simplicity and learning value
 * 
 * ZERO-LENGTH OPERATIONS:
 * 
 * memset(ptr, val, 0) → Does nothing (loop doesn't execute)
 * memcpy(dst, src, 0) → Does nothing (loop doesn't execute)
 * 
 * This is CORRECT behavior per C standard.
 *
 *=============================================================================
 * SECTION 4: PANIC - THE LAST RESORT
 *=============================================================================
 * 
 * WHAT IS PANIC?
 * 
 * panic() is the kernel's "EMERGENCY STOP" function. It's called when
 * something goes so wrong that the kernel cannot continue safely.
 * 
 * ANALOGY:
 *   Think of panic() like an emergency stop button on a machine:
 *   - Used only when continuing would be dangerous
 *   - Tries to provide information about what went wrong
 *   - Halts the system in a safe state
 *   - Cannot be recovered from (system must reboot)
 * 
 * WHEN TO CALL PANIC:
 * 
 * ✅ Critical hardware failure:
 *    - CPU exception during initialization
 *    - Memory corruption detected
 *    - Hardware not responding
 * 
 * ✅ Impossible conditions:
 *    - Assertion failures (should never happen)
 *    - Unreachable code reached
 *    - Data structure invariants violated
 * 
 * ✅ Unrecoverable errors:
 *    - Out of critical resources (page tables full)
 *    - Bootloader didn't provide required info
 *    - Cannot initialize essential hardware
 * 
 * ❌ DO NOT call panic for:
 *    - Recoverable errors (use error codes)
 *    - User errors (invalid system call arguments)
 *    - Expected failures (file not found, etc.)
 *    - Debugging (use serial output instead)
 * 
 * PANIC DESIGN PHILOSOPHY:
 * 
 * "Fail fast, fail loudly, fail safely"
 * 
 * 1. FAIL FAST:
 *    Stop immediately when corruption detected.
 *    Don't let corrupted state propagate further.
 * 
 * 2. FAIL LOUDLY:
 *    Display clear error message.
 *    Tell user/developer what went wrong.
 * 
 * 3. FAIL SAFELY:
 *    Halt in a clean state (interrupts disabled).
 *    Don't corrupt disk, network, or other persistent state.
 * 
 * PANIC STEPS:
 * 
 * 1. Disable interrupts (CLI)
 *    - Prevents interrupt handlers from running
 *    - System is in unknown state, handlers might crash
 *    - Ensures we can display message without interruption
 * 
 * 2. Display error message
 *    - Try VGA output (most reliable - just memory writes)
 *    - Try serial output (for logging/debugging)
 *    - Use simple console functions (don't trust complex subsystems)
 * 
 * 3. Halt forever
 *    - Execute HLT instruction in infinite loop
 *    - CPU enters low-power mode
 *    - Only way out is reset/power cycle
 * 
 * WHY HALT INSTEAD OF REBOOT?
 * 
 * Halting is better than automatic reboot because:
 *   ✅ User sees error message (not just endless reboot loop)
 *   ✅ Debugger can attach and inspect state
 *   ✅ Serial log contains error (not overwritten by reboot)
 *   ✅ Prevents data corruption from repeated crashes
 * 
 * Linux's panic() can reboot after timeout (configurable).
 * TinyOS halts forever (simpler, better for debugging).
 * 
 * PANIC OUTPUT FORMAT:
 * 
 *   *** KERNEL PANIC ***
 *   <error message>
 *   System halted.
 * 
 * The "KERNEL PANIC" header makes it obvious what happened.
 * This is the universal OS convention (Linux, BSD, etc. all use it).
 * 
 * NORETURN ATTRIBUTE:
 * 
 * panic() is marked with __attribute__((noreturn)).
 * 
 * This tells the compiler:
 *   - This function NEVER returns
 *   - No need to generate return epilogue
 *   - Calling code doesn't need to handle return
 *   - Enables optimizations (dead code elimination)
 * 
 * Example impact:
 * 
 * Without noreturn:
 *   if (!ptr) panic("Null pointer");
 *   *ptr = 42;  // Compiler: "Maybe panic returns, need null check here!"
 * 
 * With noreturn:
 *   if (!ptr) panic("Null pointer");
 *   *ptr = 42;  // Compiler: "panic never returns, ptr can't be null here!"
 * 
 * PANIC IN INTERRUPT CONTEXT:
 * 
 * If panic is called from an interrupt handler:
 *   - CLI has no effect (interrupts already disabled in handler)
 *   - VGA output still works (direct memory access)
 *   - Serial output might work (depends on hardware state)
 *   - System halts safely
 * 
 * Special consideration:
 *   If the panic is CAUSED by an interrupt handler, we might
 *   want to display which interrupt (vector number).
 *   TinyOS doesn't do this yet (future enhancement).
 * 
 * PANIC EXAMPLES IN TINYOS:
 * 
 * Example 1: Bootloader check
 *   if (magic != MB2_MAGIC_BOOT) {
 *       panic("Not booted by Multiboot2!");
 *   }
 * 
 * Example 2: Memory allocation failure
 *   void* page = pmm_alloc();
 *   if (!page) {
 *       panic("Out of physical memory!");
 *   }
 * 
 * Example 3: Assertion failure
 *   if (ptr == NULL) {
 *       panic("Assertion failed: ptr != NULL");
 *   }
 * 
 * PANIC VS ASSERT:
 * 
 * assert() macro (not in TinyOS yet):
 *   - Used for invariant checking during development
 *   - Can be disabled in release builds (#define NDEBUG)
 *   - Automatically provides file/line info
 * 
 * panic() function:
 *   - Used for unrecoverable errors
 *   - Always enabled (never disabled)
 *   - Explicit error message from programmer
 * 
 * Relationship:
 *   assert() would call panic() when it fails.
 *   Example: #define assert(x) if(!(x)) panic("assert(" #x ")")
 *
 *=============================================================================
 * SECTION 5: DESIGN DECISIONS AND TRADE-OFFS
 *=============================================================================
 * 
 * DECISION 1: BYTE-BY-BYTE VS WORD-BY-WORD
 * 
 * Our implementation: Byte-by-byte (unsigned char*)
 * 
 * Alternatives:
 *   A. Word-by-word (uint32_t*) when aligned
 *   B. Mixed (words for bulk, bytes for remainder)
 *   C. Assembly (REP MOVS/STOS instructions)
 * 
 * Trade-offs:
 *   Byte-by-byte:
 *     ✅ Simple, portable, works for any alignment
 *     ✅ Easy to understand and debug
 *     ❌ Slower (4x slower than word-by-word on aligned data)
 * 
 *   Word-by-word:
 *     ✅ 4x faster on aligned data
 *     ❌ More complex (need alignment checks)
 *     ❌ Still need byte loop for unaligned portions
 * 
 *   Assembly:
 *     ✅ Fastest (REP prefix is hardware-optimized)
 *     ❌ Not portable (x86-specific)
 *     ❌ Harder to debug
 * 
 * TinyOS choice: Byte-by-byte (simplicity for learning)
 * 
 * 
 * DECISION 2: NULL POINTER CHECKING
 * 
 * Our implementation: No null checks
 * 
 * Alternative: Check and return error
 *   if (dst == NULL || src == NULL) return NULL;
 * 
 * Trade-offs:
 *   No checks:
 *     ✅ Faster (no branches)
 *     ✅ Smaller code
 *     ✅ Matches standard C behavior
 *     ❌ Null pointer causes page fault
 * 
 *   With checks:
 *     ✅ Graceful handling of null pointers
 *     ✅ Can log error before crashing
 *     ❌ Slower (extra branch on every call)
 *     ❌ Hides bugs (caller should check first)
 * 
 * TinyOS choice: No checks (trust caller, fail fast on bugs)
 * 
 * 
 * DECISION 3: PANIC OUTPUT DESTINATIONS
 * 
 * Our implementation: Both VGA and serial
 * 
 * Why both?
 *   VGA:
 *     ✅ Always visible (no need for serial cable)
 *     ✅ User can see error on screen
 *     ✅ Very reliable (just memory writes)
 * 
 *   Serial:
 *     ✅ Can be logged to file (debugging)
 *     ✅ Can be read by automated tools
 *     ✅ Works even if VGA is broken
 * 
 * Why not more (disk, network)?
 *   - System is in unknown state
 *   - Complex operations might fail or hang
 *   - Simple is better during panic
 * 
 * 
 * DECISION 4: PANIC INFINITE LOOP
 * 
 * Our implementation: for(;;) __asm__ volatile("hlt");
 * 
 * Alternatives:
 *   A. Just hlt (no loop) - Single halt, wake on interrupt
 *   B. Loop with sti/cli - Allow interrupts briefly
 *   C. Hang without hlt - Busy wait (wastes power)
 * 
 * Why loop + hlt?
 *   - HLT enters low-power mode (saves power/heat)
 *   - Interrupts disabled (cli in panic)
 *   - But NMI can still wake CPU
 *   - Loop ensures we halt again after NMI
 * 
 * Why volatile?
 *   - Prevents compiler from optimizing away loop
 *   - Ensures HLT is actually executed each iteration
 * 
 * 
 * DECISION 5: RETURN DST POINTER
 * 
 * Both memset and memcpy return 'dst' pointer.
 * 
 * Why?
 *   - Standard C requires it
 *   - Allows chaining: process(memcpy(dst, src, n))
 *   - Useful in expressions: x = memset(buf, 0, size)
 * 
 * Cost:
 *   - None! Register already contains dst (first argument)
 *   - Just return EAX (calling convention)
 *
 *=============================================================================
 * SECTION 6: PERFORMANCE CONSIDERATIONS
 *=============================================================================
 * 
 * MEMSET PERFORMANCE:
 * 
 * Our implementation (byte-by-byte):
 *   - Speed: ~1-2 GB/s on modern CPU
 *   - Latency: ~1 cycle per byte + loop overhead
 * 
 * Optimized implementation (word-by-word):
 *   - Speed: ~4-8 GB/s (2-4x faster)
 *   - But requires alignment handling
 * 
 * Best implementation (REP STOSB):
 *   - Speed: ~10-40 GB/s (CPU-optimized)
 *   - Single instruction: rep stosb
 *   - But x86-specific
 * 
 * When does it matter?
 *   - Large operations (>1 KiB): Optimization helps
 *   - Small operations (<100 bytes): Overhead dominates
 *   - TinyOS: Most operations are small, speed is adequate
 * 
 * MEMCPY PERFORMANCE:
 * 
 * Our implementation (byte-by-byte):
 *   - Speed: ~1-2 GB/s on modern CPU
 * 
 * Optimized implementation:
 *   - Speed: ~10-40 GB/s with REP MOVSB
 *   - Speed: ~50+ GB/s with SSE/AVX on large copies
 * 
 * Typical sizes in TinyOS:
 *   - Small (< 64 bytes): 90% of operations
 *   - Medium (64-4096 bytes): 9% of operations
 *   - Large (> 4096 bytes): 1% of operations
 * 
 * For small sizes, function call overhead dominates.
 * For large sizes, memory bandwidth dominates.
 * Our simple implementation is adequate for TinyOS use cases.
 * 
 * CALL OVERHEAD:
 * 
 * Function call overhead:
 *   - CALL instruction: ~2 cycles
 *   - Stack frame setup: ~3 cycles
 *   - Parameter passing: ~0 cycles (registers)
 *   - Return: ~2 cycles
 *   - Total: ~7 cycles
 * 
 * For memset(ptr, 0, 10):
 *   - Call overhead: ~7 cycles
 *   - Loop: 10 cycles
 *   - Total: 17 cycles
 *   - Overhead: 41% of total time!
 * 
 * This is why compiler built-ins can be faster:
 *   - Inline expansion eliminates call overhead
 *   - Compiler can optimize based on constant size
 *   - Example: memset(buf, 0, 4) → MOV DWORD PTR [buf], 0
 * 
 * CACHE EFFECTS:
 * 
 * Memory operations interact with CPU cache:
 *   - L1 cache: ~4 cycles per access (~50 GB/s)
 *   - L2 cache: ~10 cycles per access (~20 GB/s)
 *   - L3 cache: ~40 cycles per access (~5 GB/s)
 *   - RAM: ~100 cycles per access (~2 GB/s)
 * 
 * Our byte-by-byte loop:
 *   - Good locality (sequential access)
 *   - Cache-friendly (prefetcher works well)
 *   - Not cache-efficient (reading/writing bytes vs cache lines)
 * 
 * Optimized implementations:
 *   - Write full cache lines (64 bytes) at once
 *   - Use non-temporal stores to bypass cache (large copies)
 *   - Prefetch ahead for large operations
 * 
 * For TinyOS:
 *   - Operations are small enough to fit in L1 cache
 *   - Cache effects are negligible
 *   - No need for cache-aware optimization
 *
 *=============================================================================
 * SECTION 7: COMMON PITFALLS AND SOLUTIONS
 *=============================================================================
 * 
 * PITFALL 1: USING INT INSTEAD OF UNSIGNED CHAR
 * 
 * Wrong:
 *   void* memset(void* dst, int val, size_t n) {
 *       char* d = (char*)dst;  // SIGNED char!
 *       for (size_t i = 0; i < n; ++i) d[i] = val;
 *   }
 * 
 * Problem:
 *   - char is SIGNED on x86 (-128 to 127)
 *   - val=0xFF (255) gets converted to -1
 *   - When written, might be sign-extended
 *   - Result: Undefined behavior!
 * 
 * Correct:
 *   unsigned char* d = (unsigned char*)dst;
 *   d[i] = (unsigned char)val;
 * 
 * Why unsigned char?
 *   - Represents raw bytes (0-255)
 *   - No sign extension issues
 *   - Standard C requires this
 * 
 * 
 * PITFALL 2: FORGETTING TO CAST VAL TO UNSIGNED CHAR
 * 
 * Wrong:
 *   d[i] = val;  // val is int (32 bits)
 * 
 * Problem:
 *   - Only lowest 8 bits should be used
 *   - Upper 24 bits should be ignored
 *   - Without cast, behavior is implementation-defined
 * 
 * Correct:
 *   d[i] = (unsigned char)val;
 * 
 * Example:
 *   memset(buf, 0x12345678, 10);
 *   Result: buf filled with 0x78 (not 0x12345678!)
 * 
 * 
 * PITFALL 3: OVERLAPPING MEMCPY
 * 
 * Wrong:
 *   char buf[100] = "Hello";
 *   memcpy(buf + 2, buf, 5);  // UNDEFINED!
 * 
 * Problem:
 *   - Source and dest overlap
 *   - Copy order matters
 *   - Our forward copy corrupts data
 * 
 * Solution:
 *   - Use memmove() instead (not in TinyOS)
 *   - Or ensure no overlap (careful design)
 * 
 * 
 * PITFALL 4: SIZE_T OVERFLOW
 * 
 * Wrong:
 *   size_t size = -1;  // Wraps to SIZE_MAX
 *   memset(buf, 0, size);  // Writes 4GB of zeros!
 * 
 * Problem:
 *   - size_t is unsigned (wraps on underflow)
 *   - size - 1 when size==0 → SIZE_MAX
 *   - Loop runs billions of times!
 * 
 * Solution:
 *   - Check size > 0 before subtracting
 *   - Use signed types for calculations, cast to size_t
 * 
 * 
 * PITFALL 5: CALLING MEMSET IN PANIC
 * 
 * Wrong:
 *   void panic(const char* msg) {
 *       char buffer[1000];
 *       memset(buffer, 0, sizeof(buffer));  // Bad idea!
 *       // ... format message into buffer
 *   }
 * 
 * Problem:
 *   - panic is called when system is broken
 *   - memset might be broken too (corrupted code)
 *   - Creating large stack arrays might overflow stack
 *   - Should keep panic simple!
 * 
 * Solution:
 *   - Use fixed strings in panic
 *   - No complex formatting or large buffers
 *   - Direct console output only
 * 
 * 
 * PITFALL 6: RETURNING WRONG POINTER
 * 
 * Wrong:
 *   void* memcpy(void* dst, const void* src, size_t n) {
 *       // ... copy code ...
 *       return src;  // Oops! Should return dst
 *   }
 * 
 * Problem:
 *   - Breaks standard C contract
 *   - Code expecting dst pointer gets src instead
 *   - Hard to debug!
 * 
 * Correct:
 *   return dst;
 * 
 * 
 * PITFALL 7: NOT HANDLING N=0
 * 
 * Wrong:
 *   void* memset(void* dst, int val, size_t n) {
 *       unsigned char* d = (unsigned char*)dst;
 *       d[0] = (unsigned char)val;  // Always write first byte
 *       for (size_t i = 1; i < n; ++i) d[i] = (unsigned char)val;
 *   }
 * 
 * Problem:
 *   - When n=0, we still write d[0]!
 *   - This is out-of-bounds write
 *   - Violates standard C behavior
 * 
 * Correct:
 *   - Check n > 0 before accessing d[0]
 *   - Or use loop that naturally handles n=0 (like ours)
 * 
 * 
 * PITFALL 8: MIXING UP DST AND SRC IN MEMCPY
 * 
 * Wrong:
 *   memcpy(src, dst, n);  // Backwards!
 * 
 * Problem:
 *   - Overwrites source instead of dest
 *   - Data loss and corruption
 *   - Very common mistake!
 * 
 * Mnemonic:
 *   memcpy(TO, FROM, SIZE);
 *   Think "copy FROM source TO dest"
 * 
 * In TinyOS:
 *   - Parameter names are 'dst' and 'src' (clear!)
 *   - Comments reinforce direction
 *   - Still easy to mess up at call site
 *
 *=============================================================================
 * SECTION 8: TESTING AND VERIFICATION
 *=============================================================================
 * 
 * HOW TO TEST MEMSET:
 * 
 * Test 1: Zero fill
 *   uint8_t buf[10] = {0xFF, 0xFF, 0xFF, ...};
 *   memset(buf, 0, 10);
 *   assert(buf[0] == 0 && buf[9] == 0);
 * 
 * Test 2: Non-zero fill
 *   uint8_t buf[10];
 *   memset(buf, 0xAB, 10);
 *   assert(buf[0] == 0xAB && buf[9] == 0xAB);
 * 
 * Test 3: Partial fill
 *   uint8_t buf[10] = {0};
 *   memset(buf, 0xFF, 5);
 *   assert(buf[4] == 0xFF && buf[5] == 0);
 * 
 * Test 4: Size zero
 *   uint8_t buf[10] = {0xAA, 0xAA, ...};
 *   memset(buf, 0, 0);
 *   assert(buf[0] == 0xAA);  // Unchanged
 * 
 * Test 5: Large buffer
 *   uint8_t buf[10000];
 *   memset(buf, 0x55, sizeof(buf));
 *   // Check first, middle, last
 *   assert(buf[0] == 0x55);
 *   assert(buf[5000] == 0x55);
 *   assert(buf[9999] == 0x55);
 * 
 * HOW TO TEST MEMCPY:
 * 
 * Test 1: Basic copy
 *   uint8_t src[10] = {1,2,3,4,5,6,7,8,9,10};
 *   uint8_t dst[10] = {0};
 *   memcpy(dst, src, 10);
 *   assert(memcmp(dst, src, 10) == 0);
 * 
 * Test 2: Partial copy
 *   uint8_t src[10] = {1,2,3,4,5,6,7,8,9,10};
 *   uint8_t dst[10] = {0};
 *   memcpy(dst, src, 5);
 *   assert(dst[4] == 5 && dst[5] == 0);
 * 
 * Test 3: Size zero
 *   uint8_t dst[10] = {0xFF, ...};
 *   memcpy(dst, src, 0);
 *   assert(dst[0] == 0xFF);  // Unchanged
 * 
 * Test 4: Structures
 *   struct { int x, y; } src = {10, 20};
 *   struct { int x, y; } dst;
 *   memcpy(&dst, &src, sizeof(src));
 *   assert(dst.x == 10 && dst.y == 20);
 * 
 * HOW TO TEST PANIC:
 * 
 * Testing panic is tricky (it never returns!).
 * 
 * Manual test:
 *   void test_panic() {
 *       panic("Test panic message");
 *   }
 *   
 *   Expected:
 *   - Screen clears
 *   - Shows "*** KERNEL PANIC ***"
 *   - Shows "Test panic message"
 *   - Shows "System halted."
 *   - System stops responding
 * 
 * Automated test (in QEMU):
 *   - Run with -no-reboot flag
 *   - Check serial output for panic message
 *   - Verify system halted (no more output)
 * 
 * INTEGRATION TESTING:
 * 
 * Test in context of kernel initialization:
 *   1. Boot kernel in QEMU
 *   2. Kernel uses memset to clear buffers
 *   3. Kernel uses memcpy to copy data
 *   4. Verify correct operation (no corruption)
 *   5. If panic occurs, verify message is displayed
 * 
 * DEBUGGING TIPS:
 * 
 * If memset seems broken:
 *   - Add serial output: serial_printf("memset %p %d %d\n", dst, val, n);
 *   - Check dst pointer is valid
 *   - Check n is reasonable (not SIZE_MAX)
 *   - Use QEMU's memory view to verify writes
 * 
 * If memcpy seems broken:
 *   - Print src and dst pointers
 *   - Verify no overlap
 *   - Check n doesn't exceed buffer sizes
 *   - Dump memory before and after
 * 
 * If panic doesn't show message:
 *   - Check VGA is initialized (console_clear works)
 *   - Check serial is initialized (serial_puts works)
 *   - Try simpler message (single string, no formatting)
 *   - Verify interrupts are disabled (CLI executed)
 *
 *=============================================================================
 * SECTION 9: INTEGRATION WITH THE KERNEL
 *=============================================================================
 * 
 * WHERE THESE FUNCTIONS ARE USED IN TINYOS:
 * 
 * MEMSET USAGE:
 * 
 * 1. idt.c - Clear IDT entries
 *    for (int i = 0; i < 256; ++i) {
 *        idt[i] = 0;  // Could use: memset(idt, 0, sizeof(idt));
 *    }
 * 
 * 2. pmm.c - Initialize bitmap
 *    memset(bitmap, 0xFF, sizeof(bitmap));  // Mark all used
 * 
 * 3. paging.c - Clear page tables
 *    memset(page_table, 0, 4096);
 * 
 * 4. General - Clear buffers/structures
 *    struct config cfg;
 *    memset(&cfg, 0, sizeof(cfg));
 * 
 * MEMCPY USAGE:
 * 
 * 1. Multiboot info - Copy boot data (future)
 *    memcpy(&kernel_mmap, &mb2_mmap, sizeof(mmap));
 * 
 * 2. VGA - Screen operations (future)
 *    memcpy(vga_buffer, temp_buffer, VGA_SIZE);
 * 
 * 3. File I/O - Buffer operations (future)
 *    memcpy(disk_buffer, memory, sector_size);
 * 
 * PANIC USAGE:
 * 
 * 1. kernel.c - Boot validation
 *    if (magic != MB2_MAGIC_BOOT) {
 *        panic("Not booted by Multiboot2!");
 *    }
 * 
 * 2. pmm.c - Memory exhaustion
 *    if (free_frames == 0) {
 *        panic("Out of physical memory!");
 *    }
 * 
 * 3. paging.c - Page table errors
 *    if (!page_dir) {
 *        panic("Cannot allocate page directory!");
 *    }
 * 
 * 4. interrupts.c - Critical exceptions
 *    case 0x08:  // Double fault
 *        panic("Double fault - system unstable!");
 * 
 * CALL FREQUENCY:
 * 
 * memset:
 *   - Called ~10-50 times during boot
 *   - Called occasionally during runtime
 *   - Not performance-critical for TinyOS
 * 
 * memcpy:
 *   - Called ~5-20 times during boot
 *   - Will be called frequently in future (file I/O, networking)
 *   - May need optimization later
 * 
 * panic:
 *   - Should NEVER be called in working system
 *   - Only called when something is seriously wrong
 *   - If you see panic, there's a bug to fix!
 * 
 * DEPENDENCY GRAPH:
 * 
 *   util.c (THIS FILE)
 *     ↑
 *     ├── kernel.h (types, declarations)
 *     └── serial.h (for panic serial output)
 *     ↓
 *   Used by:
 *     ├── kernel.c (boot, initialization)
 *     ├── idt.c (clear IDT)
 *     ├── pmm.c (clear bitmap)
 *     ├── paging.c (clear page tables)
 *     └── many other files (general utility)
 * 
 * INITIALIZATION ORDER:
 * 
 * These functions are available IMMEDIATELY:
 *   - No initialization required
 *   - Can be used even before kernel_main()
 *   - Can be used in constructors (if we had them)
 *   - Safe to use at any time
 * 
 * Panic requirements:
 *   - Works better after console_clear() (clear screen)
 *   - Works better after serial_init() (debug output)
 *   - But will work even without these (degrades gracefully)
 * 
 * FUTURE ENHANCEMENTS:
 * 
 * This file could be extended with:
 * 
 * 1. memmove() - Overlapping copy support
 *    void* memmove(void* dst, const void* src, size_t n);
 * 
 * 2. memcmp() - Memory comparison
 *    int memcmp(const void* s1, const void* s2, size_t n);
 * 
 * 3. strlen() - String length
 *    size_t strlen(const char* s);
 * 
 * 4. strcpy() - String copy
 *    char* strcpy(char* dst, const char* src);
 * 
 * 5. strcmp() - String comparison
 *    int strcmp(const char* s1, const char* s2);
 * 
 * 6. assert() - Assertion macro
 *    #define assert(x) if(!(x)) panic("assert(" #x ")")
 * 
 * 7. Optimized versions (ASM)
 *    - REP STOSB for memset
 *    - REP MOVSB for memcpy
 *    - Word-aligned fast paths
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "kernel.h"
#include "serial.h"  // For serial output in panic

/*=============================================================================
 * FUNCTION: memset
 *=============================================================================
 * 
 * PURPOSE:
 *   Fill a block of memory with a specific byte value.
 *   This is one of the most fundamental memory operations in C.
 * 
 * SIGNATURE:
 *   void* memset(void* dst, int val, size_t n);
 * 
 * PARAMETERS:
 *   dst - Pointer to the memory region to fill
 *         Type is void* to accept any pointer type without casting
 *         Must point to valid, writable memory
 * 
 *   val - Value to fill with (only lowest 8 bits are used)
 *         Type is int for historical reasons (C standard)
 *         Converted to unsigned char before writing
 *         Example: val=0x12345678 → writes 0x78 to each byte
 * 
 *   n   - Number of bytes to fill
 *         Type is size_t (unsigned, typically 32-bit or 64-bit)
 *         Can be 0 (no operation, valid)
 *         Can be very large (limited only by available memory)
 * 
 * RETURN VALUE:
 *   Returns the original 'dst' pointer (not modified).
 *   Why? Allows use in expressions: process(memset(buf, 0, size))
 * 
 * ALGORITHM:
 *   1. Cast void* to unsigned char* (byte pointer)
 *   2. Convert val to unsigned char (extract lowest 8 bits)
 *   3. Loop n times, writing the byte value
 *   4. Return original pointer
 * 
 * COMPLEXITY:
 *   Time:  O(n) - Linear in number of bytes
 *   Space: O(1) - No additional memory used
 * 
 * EXAMPLE USAGE:
 * 
 *   // Clear a buffer
 *   char buffer[100];
 *   memset(buffer, 0, sizeof(buffer));
 * 
 *   // Fill with a pattern
 *   uint8_t data[10];
 *   memset(data, 0xFF, sizeof(data));
 * 
 *   // Clear a structure
 *   struct config cfg;
 *   memset(&cfg, 0, sizeof(cfg));
 * 
 * VISUAL REPRESENTATION:
 * 
 *   Before: dst → [??, ??, ??, ??, ??]  (garbage data)
 *   After:  dst → [0x42, 0x42, 0x42, 0x42, 0x42]  (filled with 0x42)
 * 
 * SAFETY NOTES:
 *   - No bounds checking (caller must ensure dst has n bytes)
 *   - No null pointer checking (will crash if dst is NULL)
 *   - No overflow checking (n must be accurate)
 *   - Assumes dst is writable (will fault if read-only)
 * 
 * STANDARD C COMPLIANCE:
 *   Fully compliant with ISO C99/C11 standard.
 *   Behavior matches glibc, musl, and other implementations.
 * 
 * THREAD SAFETY:
 *   NOT thread-safe if multiple threads write to same memory.
 *   Safe if each thread writes to different memory regions.
 *   TinyOS is single-threaded, so this is not a concern.
 * 
 * PERFORMANCE:
 *   ~1-2 GB/s on modern CPU (byte-by-byte)
 *   ~10-40 GB/s possible with REP STOSB instruction
 *   Good enough for TinyOS (not performance-critical)
 */
void* memset(void* dst, int val, size_t n) {
    /*
     * Step 1: Convert void pointer to byte pointer
     * 
     * Why unsigned char*?
     *   - Represents raw bytes (0-255)
     *   - No sign extension issues
     *   - Required by C standard for byte operations
     * 
     * Why not char*?
     *   - char can be signed (-128 to 127 on x86)
     *   - Sign extension can cause problems
     *   - unsigned char is always 0-255
     */
    unsigned char* d = (unsigned char*)dst;
    
    /*
     * Step 2: Loop through each byte and fill
     * 
     * Loop structure:
     *   - Initialize: i = 0
     *   - Condition: i < n (unsigned comparison, no overflow)
     *   - Increment: ++i (pre-increment, slightly more idiomatic)
     * 
     * Inside loop:
     *   - Cast val to unsigned char (extract lowest 8 bits)
     *   - Write to d[i] (byte at offset i from d)
     * 
     * Edge cases:
     *   - n = 0: Loop doesn't execute, no writes (correct!)
     *   - n = SIZE_MAX: Loop runs many times but eventually terminates
     *   - dst = NULL: Will crash on first write (no null check)
     * 
     * Assembly equivalent (rough):
     *   mov ecx, n          ; Loop counter
     *   mov al, val         ; Byte to write
     *   mov edi, dst        ; Destination pointer
     * loop:
     *   stosb               ; Write AL to [EDI++]
     *   dec ecx             ; Decrement counter
     *   jnz loop            ; Jump if not zero
     * 
     * Why not use REP STOSB?
     *   - Requires assembly code (not portable)
     *   - Compiler might use it with -O2 anyway
     *   - Our simple loop is clear and educational
     */
    for (size_t i = 0; i < n; ++i) {
        d[i] = (unsigned char)val;
    }
    
    /*
     * Step 3: Return original pointer
     * 
     * Return dst (not d!) because:
     *   - Standard requires returning original pointer
     *   - Allows chaining: process(memset(buf, 0, size))
     *   - Matches caller's expectation (void* type)
     * 
     * Note: d and dst point to same memory, but have different types.
     */
    return dst;
}

/*=============================================================================
 * FUNCTION: memcpy
 *=============================================================================
 * 
 * PURPOSE:
 *   Copy a block of memory from source to destination.
 *   This is the fundamental memory copying operation in C.
 * 
 * SIGNATURE:
 *   void* memcpy(void* dst, const void* src, size_t n);
 * 
 * PARAMETERS:
 *   dst - Destination pointer (where to copy TO)
 *         Type is void* to accept any pointer type
 *         Must point to valid, writable memory
 *         Must have at least n bytes available
 * 
 *   src - Source pointer (where to copy FROM)
 *         Type is const void* (we won't modify source)
 *         Must point to valid, readable memory
 *         Must have at least n bytes available
 * 
 *   n   - Number of bytes to copy
 *         Type is size_t (unsigned)
 *         Can be 0 (no operation, valid)
 *         Must not cause dst or src to overflow
 * 
 * RETURN VALUE:
 *   Returns the original 'dst' pointer (not modified).
 * 
 * CRITICAL WARNING:
 *   UNDEFINED BEHAVIOR if dst and src overlap!
 *   Use memmove() for overlapping regions (not implemented in TinyOS).
 * 
 * ALGORITHM:
 *   1. Cast void* pointers to unsigned char* (byte pointers)
 *   2. Loop n times, copying bytes from src to dst
 *   3. Return original destination pointer
 * 
 * COMPLEXITY:
 *   Time:  O(n) - Linear in number of bytes
 *   Space: O(1) - No additional memory used
 * 
 * EXAMPLE USAGE:
 * 
 *   // Copy array
 *   int src[10] = {1,2,3,4,5,6,7,8,9,10};
 *   int dst[10];
 *   memcpy(dst, src, sizeof(src));
 * 
 *   // Copy structure
 *   struct point { int x, y; } src = {10, 20};
 *   struct point dst;
 *   memcpy(&dst, &src, sizeof(src));
 * 
 *   // Copy string (including null terminator)
 *   char src[] = "Hello";
 *   char dst[10];
 *   memcpy(dst, src, strlen(src) + 1);
 * 
 * VISUAL REPRESENTATION:
 * 
 *   Before:
 *     src → [1, 2, 3, 4, 5]
 *     dst → [?, ?, ?, ?, ?]
 * 
 *   After:
 *     src → [1, 2, 3, 4, 5]  (unchanged)
 *     dst → [1, 2, 3, 4, 5]  (copied from src)
 * 
 * OVERLAPPING REGIONS (UNDEFINED BEHAVIOR):
 * 
 *   BAD: memcpy(buf + 2, buf, 5)
 *   
 *   Memory: [A, B, C, D, E, F, G, H]
 *           src = buf (points to A)
 *           dst = buf + 2 (points to C)
 *   
 *   Copy forward (our implementation):
 *     Step 1: C ← A  → [A, B, A, D, E, F, G, H]
 *     Step 2: D ← B  → [A, B, A, B, E, F, G, H]
 *     Step 3: E ← A  → [A, B, A, B, A, F, G, H]  (oops! was C)
 *     Result: Corrupted!
 *   
 *   Solution: Use memmove (detects overlap, copies in right direction)
 * 
 * SAFETY NOTES:
 *   - No bounds checking (caller ensures n is valid)
 *   - No null pointer checking (will crash if dst or src is NULL)
 *   - No overlap checking (undefined if regions overlap)
 *   - Assumes dst is writable, src is readable
 * 
 * STANDARD C COMPLIANCE:
 *   Fully compliant with ISO C99/C11 standard.
 *   Undefined behavior on overlap (per standard).
 * 
 * THREAD SAFETY:
 *   NOT thread-safe if threads access same memory concurrently.
 *   Safe if threads copy to/from separate regions.
 * 
 * PERFORMANCE:
 *   ~1-2 GB/s on modern CPU (byte-by-byte)
 *   ~10-40 GB/s possible with REP MOVSB or SIMD
 *   Adequate for TinyOS use cases
 */
void* memcpy(void* dst, const void* src, size_t n) {
    /*
     * Step 1: Convert void pointers to byte pointers
     * 
     * dst: void* → unsigned char*
     *   - Need non-const because we're writing
     *   - unsigned char for byte-level access
     * 
     * src: const void* → const unsigned char*
     *   - Keep const qualifier (we don't modify source)
     *   - unsigned char for byte-level access
     */
    unsigned char* d = (unsigned char*)dst;
    const unsigned char* s = (const unsigned char*)src;
    
    /*
     * Step 2: Copy bytes one at a time
     * 
     * Loop structure:
     *   - Same as memset loop
     *   - Copy from s[i] to d[i]
     * 
     * Why forward copy?
     *   - Simple and straightforward
     *   - Good cache behavior (sequential access)
     *   - But breaks on overlapping regions!
     * 
     * Edge cases:
     *   - n = 0: No copy, returns immediately (correct!)
     *   - dst = NULL or src = NULL: Crashes (no check)
     *   - Overlap: Undefined behavior (corrupts data)
     * 
     * Assembly equivalent (rough):
     *   mov ecx, n          ; Loop counter
     *   mov esi, src        ; Source pointer
     *   mov edi, dst        ; Destination pointer
     * loop:
     *   movsb               ; Copy byte from [ESI++] to [EDI++]
     *   dec ecx
     *   jnz loop
     * 
     * Optimized version would:
     *   - Check alignment
     *   - Copy words (4 bytes) when aligned
     *   - Use SIMD for large copies
     *   - Use REP MOVSB for very large copies
     */
    for (size_t i = 0; i < n; ++i) {
        d[i] = s[i];
    }
    
    /*
     * Step 3: Return original destination pointer
     * 
     * Same reasoning as memset.
     * Returns void* (not unsigned char*) to match signature.
     */
    return dst;
}

/*=============================================================================
 * FUNCTION: panic
 *=============================================================================
 * 
 * PURPOSE:
 *   Handle unrecoverable kernel errors by displaying an error message
 *   and halting the system. This is the "emergency stop" function.
 * 
 * SIGNATURE:
 *   NORETURN void panic(const char* msg);
 * 
 * PARAMETERS:
 *   msg - Error message to display
 *         Can be NULL (we handle gracefully)
 *         Should be a static string (panic might corrupt stack)
 *         Examples: "Out of memory", "Hardware failure"
 * 
 * RETURN VALUE:
 *   NEVER RETURNS! (marked with NORETURN attribute)
 *   The system halts forever after this function is called.
 * 
 * WHEN TO CALL:
 *   Call panic() when:
 *   ✅ System is in an unrecoverable state
 *   ✅ Continuing would cause data corruption or harm
 *   ✅ Critical resource exhausted (out of memory)
 *   ✅ Hardware failure detected
 *   ✅ Assertion/invariant violated
 * 
 *   DO NOT call panic() for:
 *   ❌ Recoverable errors (use error codes)
 *   ❌ User errors (invalid input)
 *   ❌ Expected failures (file not found)
 *   ❌ Debugging (use serial output)
 * 
 * WHAT HAPPENS:
 *   1. Disable interrupts (CLI instruction)
 *      - Prevents interrupt handlers from running
 *      - System might be in inconsistent state
 *      - Handlers might make things worse
 * 
 *   2. Display panic message on VGA screen
 *      - Clears screen (so message is visible)
 *      - Shows "*** KERNEL PANIC ***" header
 *      - Shows provided error message
 *      - Shows "System halted." footer
 * 
 *   3. Display panic message on serial port
 *      - Same message as VGA
 *      - For logging/debugging
 *      - Works even if VGA is broken
 * 
 *   4. Halt CPU forever
 *      - Execute HLT instruction (low-power mode)
 *      - In infinite loop (in case of NMI wake-up)
 *      - Never returns
 * 
 * OUTPUT FORMAT:
 * 
 *   *** KERNEL PANIC ***
 *   Out of physical memory
 *   System halted.
 * 
 * EXAMPLE USAGE:
 * 
 *   // Check critical condition
 *   if (magic != MB2_MAGIC_BOOT) {
 *       panic("Not booted by Multiboot2!");
 *   }
 * 
 *   // Memory exhaustion
 *   void* page = pmm_alloc();
 *   if (!page) {
 *       panic("Out of physical memory!");
 *   }
 * 
 *   // Hardware failure
 *   if (!init_hardware()) {
 *       panic("Hardware initialization failed!");
 *   }
 * 
 * SAFETY CONSIDERATIONS:
 * 
 *   - Keep code SIMPLE (system is already broken)
 *   - Don't use complex operations (might fail)
 *   - Don't allocate memory (might be out)
 *   - Don't use locking (might deadlock)
 *   - Use direct hardware access (VGA, serial)
 * 
 * WHY BOTH VGA AND SERIAL?
 * 
 *   VGA:
 *     ✅ Always visible to user
 *     ✅ Very reliable (direct memory writes)
 *     ✅ Works even if everything else is broken
 *     ❌ Can't be logged or automated
 * 
 *   Serial:
 *     ✅ Can be logged to file
 *     ✅ Can be parsed by automation
 *     ✅ Works remotely (no monitor needed)
 *     ❌ Might not be visible to user
 * 
 * NULL MESSAGE HANDLING:
 * 
 *   If msg is NULL, we display "<null>" instead of crashing.
 *   This is defensive programming (panic should never panic!).
 * 
 * INTERRUPT STATE:
 * 
 *   We disable interrupts (CLI) immediately because:
 *   - System is in unknown/corrupt state
 *   - Interrupt handlers might make things worse
 *   - Timer interrupts could interfere with display
 *   - We want clean, uninterrupted halt
 * 
 * MEMORY BARRIER:
 * 
 *   The "memory" clobber in CLI ensures compiler doesn't
 *   reorder memory operations around it. This is important
 *   because we're about to access hardware directly.
 * 
 * HLT INSTRUCTION:
 * 
 *   HLT puts CPU in low-power state until interrupt.
 *   But we disabled interrupts (CLI), so CPU sleeps forever.
 *   Well, almost... NMI (Non-Maskable Interrupt) can still wake us.
 *   That's why we use an infinite loop (re-HLT after NMI).
 * 
 * NORETURN ATTRIBUTE:
 * 
 *   Tells compiler this function never returns.
 *   Benefits:
 *   - No need to generate return epilogue
 *   - Enables dead code elimination after panic
 *   - Helps with control flow analysis
 * 
 * COMPARISON WITH OTHER SYSTEMS:
 * 
 *   Linux:
 *     - More complex panic handler
 *     - Can sync filesystems
 *     - Can write crash dump
 *     - Can reboot after timeout
 * 
 *   Windows (BSOD):
 *     - Displays detailed crash info
 *     - Shows register dump
 *     - Shows stack trace
 *     - Writes minidump to disk
 * 
 *   TinyOS:
 *     - Simple and educational
 *     - Clear error message
 *     - Immediate halt
 *     - No fancy features (yet!)
 * 
 * FUTURE ENHANCEMENTS:
 * 
 *   Could add:
 *   - Register dump (EAX, EBX, EIP, etc.)
 *   - Stack trace (call chain)
 *   - Memory dump (first N bytes of stack)
 *   - Reboot option (after delay)
 *   - Write to disk (if filesystem available)
 */
NORETURN void panic(const char* msg) {
    /*
     * STEP 1: DISABLE INTERRUPTS IMMEDIATELY
     * 
     * This is the FIRST thing we do, before anything else.
     * 
     * Why?
     *   - System is in unknown/corrupt state
     *   - Interrupt handlers might crash
     *   - Timer interrupts could interfere with our display
     *   - We need atomic operation (no interruption)
     * 
     * CLI instruction:
     *   - Clears IF (Interrupt Flag) in EFLAGS register
     *   - After this, maskable interrupts are ignored
     *   - NMI (Non-Maskable Interrupt) can still fire
     * 
     * Volatile asm:
     *   - Prevents compiler from optimizing away
     *   - Ensures CLI actually executes
     * 
     * Memory clobber:
     *   - Tells compiler: "memory state has changed"
     *   - Prevents reordering memory operations around CLI
     *   - Important for hardware I/O operations that follow
     */
    __asm__ volatile("cli" ::: "memory");
    
    /*
     * STEP 2: OUTPUT TO VGA CONSOLE
     * 
     * We use VGA output because:
     *   - Very reliable (direct memory writes)
     *   - Always visible to user
     *   - Works even if everything else is broken
     * 
     * We try each operation individually:
     *   - If one fails, others might still work
     *   - Don't want console_clear failure to prevent message display
     * 
     * Note: We don't check return values or handle errors.
     * If console functions crash, so be it (system is doomed anyway).
     */
    
    /* Clear screen for visibility */
    console_clear();
    
    /* Display header (universally recognized format) */
    console_puts("*** KERNEL PANIC ***\n");
    
    /* Display error message (or "<null>" if msg is NULL) */
    console_puts(msg ? msg : "<null>");
    
    /* Display footer (tells user system is halted) */
    console_puts("\nSystem halted.\n");
    
    /*
     * STEP 3: OUTPUT TO SERIAL PORT
     * 
     * We use serial output because:
     *   - Can be logged to file (for later analysis)
     *   - Can be parsed by automation (testing)
     *   - Works even if VGA is broken
     *   - Visible remotely (no need for monitor)
     * 
     * We use serial_puts (not kprintf) because:
     *   - More direct (fewer dependencies)
     *   - Less likely to fail
     *   - Simpler code path
     * 
     * Note: serial_puts is defined in serial.c.
     * If serial port isn't initialized, these calls might fail silently.
     * That's OK - we already displayed on VGA.
     */
    
    /* Newline for separation (in case previous output was in progress) */
    serial_puts("\n*** KERNEL PANIC ***\n");
    
    /* Same message as VGA */
    serial_puts(msg ? msg : "<null>");
    
    /* Same footer as VGA */
    serial_puts("\nSystem halted.\n");
    
    /*
     * STEP 4: HALT FOREVER
     * 
     * We enter an infinite loop that repeatedly executes HLT.
     * 
     * Why loop?
     *   - HLT can be woken by NMI (Non-Maskable Interrupt)
     *   - After NMI, execution continues
     *   - We want to HLT again (not execute garbage code)
     * 
     * Why HLT?
     *   - Puts CPU in low-power state (saves power/heat)
     *   - Better than busy-wait loop (CPU at 100%)
     *   - More energy-efficient
     *   - Cooler and quieter
     * 
     * Why volatile?
     *   - Prevents compiler from optimizing away the loop
     *   - Ensures HLT is actually executed each iteration
     *   - Without volatile, compiler might do: while(1);
     * 
     * Can we ever return?
     *   NO! This function never returns.
     *   The only way out is:
     *     - Hardware reset (reset button)
     *     - Power cycle (turn off and on)
     *     - VM reset (QEMU monitor command)
     * 
     * What about debugger?
     *   - Debugger can break into HLT loop
     *   - Can inspect registers, memory, etc.
     *   - Very useful for post-mortem analysis!
     */
    for(;;) {
        __asm__ volatile("hlt");
    }
    
    /*
     * This line is never reached, but helps the compiler know
     * that control flow doesn't continue past panic.
     * 
     * The NORETURN attribute already tells the compiler this,
     * but having the infinite loop makes it obvious to humans too.
     */
}

/*=============================================================================
 * END OF FILE: util.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Implemented memset (fill memory with byte value)
 *   ✅ Implemented memcpy (copy memory block)
 *   ✅ Implemented panic (emergency halt with error message)
 *   ✅ Provided comprehensive documentation for learning
 *   ✅ Explained freestanding C environment
 *   ✅ Discussed design decisions and trade-offs
 *   ✅ Covered common pitfalls and solutions
 * 
 * WHAT HAPPENS NEXT:
 *   → These functions are used throughout the kernel
 *   → See kernel.c for panic usage examples
 *   → See pmm.c for memset usage (bitmap init)
 *   → See idt.c for memset usage (IDT clear)
 * 
 * KEY TAKEAWAYS:
 *   1. Freestanding C requires implementing basic functions ourselves
 *   2. memset and memcpy are fundamental building blocks
 *   3. panic is the last resort for unrecoverable errors
 *   4. Simple implementations are adequate for learning
 *   5. Performance can be improved later (if needed)
 *   6. Safety and clarity are more important than speed
 * 
 * LEARNING RESOURCES:
 *   - C Standard (ISO C99/C11) - memset/memcpy specification
 *   - GCC Manual - Freestanding environment documentation
 *   - OSDev Wiki: https://wiki.osdev.org/Writing_a_memory_manager
 *   - Intel Manual Vol 2 - HLT instruction documentation
 *   - Linux source: lib/string.c - Production implementations
 * 
 * PERFORMANCE NOTES:
 *   Our implementations are SIMPLE, not FAST.
 *   
 *   For production systems:
 *   - Use REP STOSB/MOVSB (hardware-optimized)
 *   - Use SIMD instructions (SSE/AVX) for large copies
 *   - Use word-aligned operations when possible
 *   - Implement memmove for overlapping copies
 *   
 *   For TinyOS:
 *   - Current implementation is adequate
 *   - Can optimize later if profiling shows bottleneck
 *   - Premature optimization is root of all evil!
 * 
 * TESTING RECOMMENDATIONS:
 *   1. Test memset with various sizes (0, 1, 10, 1000, 10000)
 *   2. Test memset with various values (0, 0xFF, 0x55, 0xAA)
 *   3. Test memcpy with various data patterns
 *   4. Test panic with various messages (including NULL)
 *   5. Verify panic halts system (no more output after panic)
 *   6. Check serial output matches VGA output
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - What freestanding C is and why kernels need it
 *   - How to implement fundamental memory operations
 *   - How to handle catastrophic errors in a kernel
 *   - The trade-offs between simplicity and performance
 *   - How to write defensive code in hostile environments
 * 
 *   You've learned one of the most fundamental aspects of systems programming! 🎉
 *============================================================================*/
