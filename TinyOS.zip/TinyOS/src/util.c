/*=============================================================================
* util.c — Freestanding libc shims and panic
*============================================================================*/
#include "kernel.h"


void* memset(void* dst, int val, size_t n) {
unsigned char* d = (unsigned char*)dst;
for (size_t i = 0; i < n; ++i) d[i] = (unsigned char)val;
return dst;
}


void* memcpy(void* dst, const void* src, size_t n) {
unsigned char* d = (unsigned char*)dst;
const unsigned char* s = (const unsigned char*)src;
for (size_t i = 0; i < n; ++i) d[i] = s[i];
return dst;
}


NORETURN void panic(const char* msg) {
console_clear();
console_puts("KERNEL PANIC: ");
console_puts(msg ? msg : "<null>");
console_puts("\nSystem halted.\n");
__asm__ volatile("cli; hlt");
for(;;) __asm__ volatile("hlt");
}
