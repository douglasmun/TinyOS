/*=============================================================================
 *  multiboot.c — Multiboot2 tag dump (bootloader, cmdline, memory map)
 *============================================================================*/
#include "kernel.h"

static void dump_mmap_mb2(const struct mb2_tag_mmap* mm) {
    const uint8_t* p = (const uint8_t*)(mm + 1);
    const uint8_t* e = ((const uint8_t*)mm) + mm->size;

    console_puts("Memory map entries:\n");
    while (p + mm->entry_size <= e) {
        const struct mb2_mmap_entry* me = (const struct mb2_mmap_entry*)p;
        console_puts("  addr="); console_put_hex64(me->addr);
        console_puts(" len=");   console_put_hex64(me->len);
        console_puts(" type=");  console_put_dec_u32(me->type);
        console_putc('\n');
        p += mm->entry_size;
    }
}

void mb_dump_mb1(const struct multiboot_info* mb) {
    /* kept minimal; your focus is MB2 */
    console_puts("Bootloader: ");
    if (mb->boot_loader_name) console_puts((const char*)(uintptr_t)mb->boot_loader_name);
    else                      console_puts("<unknown>");
    console_putc('\n');
    /* You can add MB1 mmap dump later if you want parity. */
}

void mb_dump_mb2(const void* info_ptr) {
    const uint8_t* base = (const uint8_t*)info_ptr;
    const uint32_t total_size = *(const uint32_t*)(base + 0);
    /* const uint32_t reserved = *(const uint32_t*)(base + 4); // must be 0 */

    const uint8_t* p = base + 8;                   // first tag
    const uint8_t* end = base + total_size;        // hard upper bound

    while (p + sizeof(struct mb2_tag) <= end) {
        const struct mb2_tag* tag = (const struct mb2_tag*)p;
        if (tag->type == MB2_TAG_END) break;       // graceful stop
        if (p + tag->size > end) break;            // malformed guard

        switch (tag->type) {
            case MB2_TAG_BOOTLOADER: {
                const struct mb2_tag_string* s = (const struct mb2_tag_string*)tag;
                console_puts("Bootloader: "); console_puts(s->str); console_putc('\n');
            } break;

            case MB2_TAG_CMDLINE: {
                const struct mb2_tag_string* s = (const struct mb2_tag_string*)tag;
                console_puts("Cmdline   : "); console_puts(s->str); console_putc('\n');
            } break;

            case MB2_TAG_MMAP: {
                const struct mb2_tag_mmap* mm = (const struct mb2_tag_mmap*)tag;
                const uint8_t* q = (const uint8_t*)(mm + 1);
                const uint8_t* qe = p + mm->size;
                console_puts("Memory map entries:\n");
                while (q + mm->entry_size <= qe) {
                    const struct mb2_mmap_entry* me = (const struct mb2_mmap_entry*)q;
                    console_puts("  addr="); console_put_hex64(me->addr);
                    console_puts(" len=");   console_put_hex64(me->len);
                    console_puts(" type=");  console_put_dec_u32(me->type);
                    console_putc('\n');
                    q += mm->entry_size;
                }
            } break;

            default: /* ignore others for now */ break;
        }

        /* advance to next tag (8-byte aligned) */
        uintptr_t next = ((uintptr_t)p + tag->size + 7u) & ~((uintptr_t)7u);
        p = (const uint8_t*)next;
    }
}
