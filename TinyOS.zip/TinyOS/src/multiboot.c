/*=============================================================================
 *  multiboot.c — Multiboot2 Boot Information Parser for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file implements the parsing and display of boot information provided
 *   by a Multiboot2-compliant bootloader (typically GRUB 2.x). It extracts
 *   critical system information like the bootloader name, command-line
 *   arguments, and most importantly, the physical memory map.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Target: i386 (32-bit x86) protected mode
 *   - Bootloader: GRUB 2.x (Multiboot2 protocol)
 *   - Memory: Accesses bootloader-provided data structures
 *   - Safety: Defensive parsing with bounds checking
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is Multiboot?
 * 2. Multiboot1 vs Multiboot2
 * 3. Boot Information Structure
 * 4. Tag-Based Architecture
 * 5. Memory Map (E820) Explained
 * 6. Parsing Strategy and Safety
 * 7. Implementation Details
 * 8. Common Pitfalls and Solutions
 * 9. Integration with Other Subsystems
 *
 *=============================================================================
 * SECTION 1: WHAT IS MULTIBOOT?
 *=============================================================================
 * 
 * Multiboot is a SPECIFICATION (not software) that defines a standard way
 * for bootloaders and operating systems to communicate during the boot
 * process. Think of it as a "contract" between bootloader and OS kernel.
 * 
 * THE BOOT PROBLEM:
 *   Before Multiboot, every bootloader had its own way of loading kernels:
 *   - LILO used one format
 *   - GRUB used another
 *   - SYSLINUX used yet another
 *   - Result: Each OS needed custom boot code for each bootloader!
 * 
 * THE MULTIBOOT SOLUTION:
 *   Multiboot standardizes:
 *   1. How the kernel identifies itself (magic header in kernel binary)
 *   2. What state the bootloader leaves the CPU in (protected mode, etc.)
 *   3. How the bootloader passes information to the kernel (boot info struct)
 *   4. What information is available (memory map, modules, framebuffer, etc.)
 * 
 * ANALOGY:
 *   Multiboot is like a USB standard:
 *   - USB defines how devices and hosts communicate
 *   - Multiboot defines how bootloaders and kernels communicate
 *   - Any Multiboot-compliant kernel works with any Multiboot bootloader
 *   - You write the kernel once, it works with GRUB, GRUB2, QEMU, etc.
 * 
 * WHO USES MULTIBOOT?
 *   - GRUB (Grand Unified Bootloader) - most popular
 *   - QEMU's -kernel option - for testing
 *   - Custom bootloaders
 *   - Many hobby OS projects (TinyOS, ToaruOS, etc.)
 * 
 * KEY BENEFIT FOR OS DEVELOPERS:
 *   We don't need to write bootloader code! GRUB handles:
 *   - Loading kernel from disk
 *   - Setting up protected mode
 *   - Providing memory map
 *   - Loading modules (initrd, etc.)
 *   - Detecting hardware (framebuffer, etc.)
 *   
 *   We just need to:
 *   - Put a Multiboot header in our kernel
 *   - Parse the boot information structure
 *   - Start our kernel logic
 *
 *=============================================================================
 * SECTION 2: MULTIBOOT1 vs MULTIBOOT2
 *=============================================================================
 * 
 * There are two versions of the Multiboot specification:
 * 
 * MULTIBOOT1 (2005):
 *   - Magic number: 0x2BADB002 (in kernel header)
 *   - Magic value at boot: 0x2BADB002 (in EAX register)
 *   - Fixed-size information structure
 *   - Flags-based: Each bit indicates presence of optional fields
 *   - Limited to 32-bit addresses
 *   - Simpler but less flexible
 *   - Used by: GRUB Legacy (0.x)
 * 
 * MULTIBOOT2 (2016):
 *   - Magic number: 0xE85250D6 (in kernel header)
 *   - Magic value at boot: 0x36D76289 (in EAX register)
 *   - Variable-size, tag-based structure
 *   - More extensible (new tags can be added)
 *   - Supports 64-bit addresses
 *   - Better alignment and padding
 *   - Used by: GRUB2 (2.x), QEMU
 * 
 * WHICH ONE DOES TINYOS USE?
 *   TinyOS uses Multiboot2 (the modern version).
 *   
 *   Our kernel header (in boot.s) declares:
 *     - Magic: 0xE85250D6
 *     - GRUB sees this and knows we're Multiboot2
 *   
 *   At boot, GRUB loads us and sets:
 *     - EAX = 0x36D76289 (Multiboot2 magic value)
 *     - EBX = Physical address of boot information structure
 *   
 *   Our kernel checks EAX to verify we were booted correctly.
 * 
 * WHY SUPPORT BOTH IN CODE?
 *   TinyOS includes minimal Multiboot1 support (mb_dump_mb1) for:
 *   - Testing with legacy bootloaders
 *   - Educational completeness
 *   - Future compatibility
 *   
 *   But the focus is on Multiboot2 (mb_dump_mb2).
 * 
 * MAGIC NUMBER ORIGINS:
 *   - 0x2BADB002 = "2 BAD BOOT" (Multiboot1 - a bit of humor!)
 *   - 0x36D76289 = No known meaning, just a unique identifier
 *   - These are carefully chosen to be unlikely to appear by accident
 *
 *=============================================================================
 * SECTION 3: BOOT INFORMATION STRUCTURE
 *=============================================================================
 * 
 * When GRUB boots our kernel, it prepares a data structure in RAM containing
 * information about the system. This structure is at the address in EBX.
 * 
 * MULTIBOOT2 INFORMATION STRUCTURE LAYOUT:
 * 
 * Offset  Size  Field         Description
 * ------  ----  ------------  -----------------------------------------------
 * 0       4     total_size    Total size of entire structure in bytes
 * 4       4     reserved      Must be 0 (reserved for future use)
 * 8       ?     tags          Variable-length array of tags
 * 
 * TOTAL_SIZE:
 *   - Includes the 8-byte header (total_size + reserved)
 *   - Includes all tags
 *   - Typical values: 500-2000 bytes (depends on memory map size)
 *   - Used for bounds checking (don't read past this!)
 * 
 * RESERVED:
 *   - Currently unused, must be 0
 *   - May be used in future versions of the spec
 *   - Good practice to check it's 0 (paranoid validation)
 * 
 * TAGS:
 *   - Start immediately after the 8-byte header
 *   - Variable number of tags
 *   - Each tag has its own format
 *   - Last tag is always "end tag" (type 0)
 * 
 * PHYSICAL LOCATION:
 *   - GRUB places this structure somewhere in RAM
 *   - Typically in low memory (below 1 MiB) or just above kernel
 *   - Exact location varies (that's why GRUB tells us the address!)
 *   - Structure is READ-ONLY (we parse, not modify)
 *   - Valid until we overwrite it (should copy critical data)
 * 
 * LIFETIME:
 *   The boot info structure is only guaranteed to be valid during early
 *   kernel initialization. Once we set up our own memory management, we
 *   might allocate memory that overwrites it. Therefore:
 *   
 *   ✅ Safe: Read during kernel_main() initialization
 *   ✅ Safe: Copy critical data (memory map) to kernel structures
 *   ❌ Unsafe: Access after memory manager is running
 *   ❌ Unsafe: Store pointer for later use without copying data
 * 
 * ALIGNMENT:
 *   - The entire structure is 8-byte aligned
 *   - Each tag is 8-byte aligned
 *   - This allows efficient access on 64-bit systems
 *   - Important for our pointer arithmetic!
 *
 *=============================================================================
 * SECTION 4: TAG-BASED ARCHITECTURE
 *=============================================================================
 * 
 * Multiboot2 uses a TAG-BASED DESIGN for extensibility. Instead of a fixed
 * structure, it's a linked list of variable-size "tags."
 * 
 * WHY TAGS?
 *   - Extensibility: New tag types can be added without breaking old kernels
 *   - Flexibility: Bootloader provides only tags it knows about
 *   - Efficiency: Kernel ignores tags it doesn't care about
 *   - Future-proof: Old kernels can boot with new bootloaders
 * 
 * GENERIC TAG STRUCTURE:
 *   Every tag starts with a common header:
 * 
 *   Offset  Size  Field   Description
 *   ------  ----  ------  ------------------------------------------------
 *   0       4     type    Tag type identifier (0=end, 1=cmdline, 6=mmap, etc.)
 *   4       4     size    Size of THIS TAG in bytes (including header)
 *   8       ?     data    Tag-specific data (varies by type)
 * 
 * TAG TYPES (Common ones):
 *   Type  Name                  Description
 *   ----  --------------------  -------------------------------------------
 *   0     End Tag               Marks end of tag list (MANDATORY)
 *   1     Command Line          Kernel command-line string
 *   2     Bootloader Name       Name and version of bootloader (e.g., "GRUB 2.06")
 *   3     Modules               Loaded modules (initrd, drivers, etc.)
 *   4     Basic Memory Info     Lower and upper memory (legacy, use mmap instead)
 *   5     BIOS Boot Device      Boot device identifier
 *   6     Memory Map (MMAP)     E820 memory map (CRITICAL!)
 *   7     VBE Info              VESA BIOS Extensions graphics info
 *   8     Framebuffer Info      Framebuffer dimensions and pixel format
 *   9     ELF Symbols           ELF section headers (for debugging)
 *   10    APM Table             Advanced Power Management info
 *   11    EFI 32-bit System     EFI system table pointer (32-bit)
 *   12    EFI 64-bit System     EFI system table pointer (64-bit)
 *   13    SMBIOS Tables         System Management BIOS tables
 *   14    ACPI Old RSDP         ACPI 1.0 Root System Descriptor Pointer
 *   15    ACPI New RSDP         ACPI 2.0+ RSDP
 *   16    Networking Info       Network boot information
 *   17    EFI Memory Map        EFI memory map
 *   18    EFI Boot Services     Whether EFI boot services are active
 *   19    EFI 32-bit Image      EFI image handle (32-bit)
 *   20    EFI 64-bit Image      EFI image handle (64-bit)
 *   21    Image Load Base       Physical address where kernel was loaded
 * 
 * TAG ALIGNMENT:
 *   Each tag starts at an 8-byte aligned address.
 *   
 *   To advance to next tag:
 *   1. Read current tag's size
 *   2. Add size to current tag address
 *   3. Round UP to next 8-byte boundary
 *   
 *   Formula: next = (current + size + 7) & ~7
 *   
 *   Example:
 *     Tag at 0x1000, size=26 bytes
 *     Next = (0x1000 + 26 + 7) & ~7
 *          = 0x1021 & 0xFFFFFFF8
 *          = 0x1020
 *     (Rounded from 0x101A to 0x1020)
 * 
 * PARSING STRATEGY:
 *   while (not at end of structure) {
 *       Read tag header (type, size)
 *       If type == 0 (end tag): break
 *       Switch on type:
 *           case 1: Parse command line
 *           case 2: Parse bootloader name
 *           case 6: Parse memory map
 *           default: Ignore (future/unknown tag)
 *       Advance to next tag (8-byte aligned)
 *   }
 * 
 * SAFETY:
 *   Always check: current_position + tag_size <= end_of_structure
 *   If this fails, the structure is CORRUPTED (stop parsing!)
 *
 *=============================================================================
 * SECTION 5: MEMORY MAP (E820) EXPLAINED
 *=============================================================================
 * 
 * The MEMORY MAP tag (type 6) is THE MOST IMPORTANT tag for an OS kernel.
 * It tells us which regions of RAM are usable and which are reserved.
 * 
 * WHY IS THIS CRITICAL?
 *   Without a memory map:
 *   ❌ We don't know how much RAM is installed
 *   ❌ We don't know where BIOS/firmware data is
 *   ❌ We don't know where hardware is memory-mapped
 *   ❌ We could overwrite critical system data
 *   ❌ We could try to use non-existent memory (crash!)
 * 
 *   With a memory map:
 *   ✅ We know exactly which RAM is safe to use
 *   ✅ We can set up a memory allocator
 *   ✅ We can protect critical regions
 *   ✅ We can support any amount of RAM (up to our limit)
 * 
 * E820 HISTORY:
 *   "E820" refers to BIOS interrupt 0x15, function 0xE820, which queries
 *   the memory map in real mode. GRUB calls this interrupt before switching
 *   to protected mode and passes the results to us.
 * 
 * MEMORY MAP TAG STRUCTURE:
 * 
 *   Offset  Size  Field           Description
 *   ------  ----  --------------  -----------------------------------------
 *   0       4     type            6 (memory map tag)
 *   4       4     size            Total size of tag including entries
 *   8       4     entry_size      Size of each mmap entry (usually 24)
 *   12      4     entry_version   Version of entry format (usually 0)
 *   16      ?     entries         Array of memory map entries
 * 
 * MEMORY MAP ENTRY STRUCTURE:
 * 
 *   Offset  Size  Field   Description
 *   ------  ----  ------  ---------------------------------------------------
 *   0       8     addr    Physical base address of memory region (64-bit)
 *   8       8     len     Length of memory region in bytes (64-bit)
 *   16      4     type    Region type (1=usable, 2=reserved, etc.)
 *   20      4     zero    Reserved, must be 0
 * 
 * MEMORY REGION TYPES:
 *   Type  Name                Description
 *   ----  ------------------  -----------------------------------------------
 *   1     Usable RAM          Normal, usable system RAM
 *   2     Reserved            Reserved by hardware, DO NOT USE
 *   3     ACPI Reclaimable    ACPI tables, can be reclaimed after parsing
 *   4     ACPI NVS            ACPI Non-Volatile Storage, DO NOT USE
 *   5     Bad Memory          Defective RAM chips, DO NOT USE
 *   6     Disabled            Disabled by firmware, DO NOT USE
 *   7+    Vendor-specific     Various vendor-specific meanings
 * 
 * TYPICAL MEMORY MAP (QEMU with 128 MiB RAM):
 * 
 *   Region  Address Range           Length      Type  Description
 *   ------  ----------------------  ----------  ----  ----------------------
 *   1       0x0000_0000-0x0009_FFFF 640 KiB     1     Low RAM (usable)
 *   2       0x000A_0000-0x000F_FFFF 384 KiB     2     VGA, BIOS (reserved)
 *   3       0x0010_0000-0x07FF_FFFF 127 MiB     1     Extended RAM (usable)
 *   4       0xFEC0_0000-0xFED0_3FFF ~1 MiB      2     I/O APIC (reserved)
 *   5       0xFEE0_0000-0xFEE0_0FFF 4 KiB       2     Local APIC (reserved)
 *   6       0xFFFC_0000-0xFFFF_FFFF 256 KiB     2     BIOS ROM (reserved)
 * 
 * KEY OBSERVATIONS:
 *   - Not all RAM is usable! (VGA buffer at 0xA0000-0xFFFFF is reserved)
 *   - There are "holes" in the address space (reserved regions)
 *   - High memory (above 4 GiB) is possible on 64-bit systems
 *   - We must respect reserved regions or risk corrupting firmware data
 * 
 * HOW TINYOS USES THIS:
 *   1. Parse memory map in multiboot.c (this file)
 *   2. Display regions to screen (for debugging)
 *   3. Pass memory map to PMM (Physical Memory Manager)
 *   4. PMM marks usable regions as "free" in bitmap
 *   5. PMM marks reserved regions as "used" in bitmap
 *   6. Kernel allocates memory only from "free" regions
 * 
 * EXAMPLE CALCULATION:
 *   System has two usable regions:
 *   - Region 1: 0x0000-0x9FFFF (640 KiB)
 *   - Region 2: 0x100000-0x7FFFFFF (127 MiB)
 *   
 *   Total usable RAM = 640 KiB + 127 MiB = 127.625 MiB
 *   
 *   In 4 KiB pages:
 *   - Region 1: 640 KiB / 4 KiB = 160 pages
 *   - Region 2: 127 MiB / 4 KiB = 32,512 pages
 *   - Total: 32,672 usable pages
 * 
 * 64-BIT ADDRESSES:
 *   The memory map uses 64-bit addresses (uint64_t) even on 32-bit systems.
 *   This is for future compatibility with systems that have >4 GiB RAM.
 *   
 *   On TinyOS (32-bit):
 *   - We only care about addresses below 4 GiB (0xFFFFFFFF)
 *   - We check the upper 32 bits are 0 (paranoid validation)
 *   - We cast to uint32_t for our 32-bit memory manager
 * 
 * PARSING SAFETY:
 *   We must validate:
 *   ✅ entry_size is reasonable (16-32 bytes typical)
 *   ✅ entries don't extend past tag size
 *   ✅ entry count is reasonable (<1000 typical)
 *   ❌ Don't trust any values blindly (bootloader could be buggy!)
 *
 *=============================================================================
 * SECTION 6: PARSING STRATEGY AND SAFETY
 *=============================================================================
 * 
 * Parsing boot information is RISKY because:
 * - We're reading data from an external source (bootloader)
 * - Data could be corrupted (RAM errors, buggy bootloader)
 * - Bad data could cause kernel to crash IMMEDIATELY
 * - We have no OS services yet (no memory protection, no exception recovery)
 * 
 * DEFENSIVE PROGRAMMING PRINCIPLES:
 * 
 * 1. BOUNDS CHECKING:
 *    Always verify: current_pointer + read_size <= end_of_structure
 *    
 *    Example:
 *    if (p + sizeof(struct mb2_tag) <= end) {
 *        // Safe to read tag header
 *    } else {
 *        // Corrupted, stop parsing
 *    }
 * 
 * 2. SIZE VALIDATION:
 *    Check that sizes are reasonable and consistent.
 *    
 *    Example:
 *    if (tag->size < sizeof(struct mb2_tag)) {
 *        // Corrupted (size can't be smaller than header)
 *    }
 *    if (p + tag->size > end) {
 *        // Corrupted (extends past end)
 *    }
 * 
 * 3. TYPE VALIDATION:
 *    Unknown tag types are OK (skip them), but be wary of impossible values.
 *    
 *    Example:
 *    if (tag->type == 0) {
 *        // End tag, stop parsing
 *    } else if (tag->type < 100) {
 *        // Known or reserved type range (process or skip)
 *    } else {
 *        // Very high type number (suspicious, but skip gracefully)
 *    }
 * 
 * 4. ALIGNMENT CHECKING:
 *    Tags should be 8-byte aligned. If not, data is corrupt.
 *    
 *    Example:
 *    if ((uintptr_t)p % 8 != 0) {
 *        // Misaligned, stop parsing
 *    }
 * 
 * 5. EARLY EXIT ON CORRUPTION:
 *    Don't try to "fix" corrupt data. Stop parsing immediately.
 *    
 *    Better to:
 *    - Lose some information (skip corrupt tags)
 *    - Halt with error message (if critical data is corrupt)
 *    
 *    Than to:
 *    - Continue with corrupt data (undefined behavior)
 *    - Crash mysteriously later (hard to debug)
 * 
 * 6. NULL POINTER CHECKS:
 *    Check that pointers are non-zero before dereferencing.
 *    
 *    Example (Multiboot1):
 *    if (mb->boot_loader_name != 0) {
 *        console_puts((const char*)(uintptr_t)mb->boot_loader_name);
 *    } else {
 *        console_puts("<unknown>");
 *    }
 * 
 * 7. STRING SAFETY:
 *    Strings in Multiboot structures should be null-terminated, but
 *    we can't trust this. Use strnlen() or similar if available.
 *    
 *    TinyOS approach:
 *    - Strings are typically short (<100 chars)
 *    - We don't implement full string validation (simplicity)
 *    - If a string causes a crash, it's a bootloader bug
 * 
 * OUR IMPLEMENTATION SAFETY FEATURES:
 *   ✅ Compute end pointer from total_size
 *   ✅ Check each tag doesn't extend past end
 *   ✅ Stop at end tag (type 0)
 *   ✅ Stop if malformed (tag->size extends past end)
 *   ✅ Use const pointers (can't accidentally modify boot info)
 *   ✅ 8-byte alignment in pointer arithmetic
 *   ❌ Don't validate string null-termination (simplicity trade-off)
 *   ❌ Don't check reserved fields (not critical)
 * 
 * WHAT COULD STILL GO WRONG?
 *   - Bootloader provides garbage total_size → We read garbage or crash
 *   - Bootloader provides non-null-terminated strings → We print garbage
 *   - Hardware RAM error corrupts structure → Unpredictable behavior
 *   
 *   These are RARE (bootloader bugs are unusual, RAM errors are rare).
 *   More validation could be added, but there's a trade-off between
 *   robustness and code complexity.
 *
 *=============================================================================
 * SECTION 7: DISPLAY VS PARSING
 *=============================================================================
 * 
 * This file has TWO responsibilities:
 * 
 * 1. DISPLAY (mb_dump_mb1, mb_dump_mb2):
 *    - Print boot information to screen (VGA console)
 *    - For human debugging and verification
 *    - Shows: bootloader name, command line, memory map
 *    - Non-critical (if it fails, kernel can still run)
 * 
 * 2. DATA EXTRACTION (used by pmm_init_from_mb2):
 *    - Extract memory map for use by memory manager
 *    - Critical (without this, we don't know what RAM is usable)
 *    - pmm.c calls same parsing logic to extract memory regions
 * 
 * CODE REUSE:
 *   pmm.c duplicates the memory map parsing logic because:
 *   - Avoids function call overhead (inline is faster)
 *   - Allows PMM-specific error handling
 *   - Keeps PMM independent (could work without multiboot.c)
 *   
 *   Alternatively, we could have:
 *   - A shared function: mb2_get_mmap_tag()
 *   - Or an iterator: mb2_foreach_mmap_entry()
 *   
 *   Trade-off: Code reuse vs simplicity/independence.
 *   TinyOS chooses simplicity (duplicate parsing in pmm.c).
 * 
 * WHY DISPLAY AT ALL?
 *   During development, seeing the boot information is INVALUABLE:
 *   - Verify we're being booted by correct bootloader
 *   - Check memory map is reasonable (no huge gaps, correct sizes)
 *   - Debug "why is my kernel only seeing 16 MiB RAM?" issues
 *   - Confirm command-line arguments are being passed correctly
 *   
 *   In production, this could be disabled (compile-time option).
 *
 *=============================================================================
 * SECTION 8: COMMON PITFALLS AND SOLUTIONS
 *=============================================================================
 * 
 * PITFALL 1: Forgetting to Check Magic Number
 * 
 * Problem:
 *   Kernel assumes it's always booted by Multiboot2.
 *   If booted another way, info_ptr is garbage.
 *   Parsing garbage causes crash or corrupt data.
 * 
 * Solution:
 *   In kernel_main(), check EAX == 0x36D76289 FIRST.
 *   If not, print error and halt (see kernel.c).
 * 
 * 
 * PITFALL 2: Casting Pointers Incorrectly
 * 
 * Problem:
 *   Multiboot1 uses uint32_t for pointers (32-bit addresses).
 *   Example: mb->boot_loader_name is uint32_t, not char*.
 *   Directly using it as char* causes warnings or errors.
 * 
 * Solution:
 *   Cast through uintptr_t:
 *   (const char*)(uintptr_t)mb->boot_loader_name
 *   
 *   Why uintptr_t?
 *   - Defined to be large enough to hold a pointer
 *   - Avoids "integer to pointer" warnings
 *   - Portable (works on 32-bit and 64-bit)
 * 
 * 
 * PITFALL 3: Not Handling Missing Tags
 * 
 * Problem:
 *   Kernel assumes memory map tag always exists.
 *   If bootloader doesn't provide it, kernel crashes.
 * 
 * Solution:
 *   Check if critical tags are present.
 *   If not, print error and halt or use defaults.
 *   
 *   Example:
 *   bool found_mmap = false;
 *   // ... parse loop ...
 *   if (!found_mmap) {
 *       panic("No memory map provided by bootloader!");
 *   }
 * 
 * 
 * PITFALL 4: Arithmetic Overflow in Alignment
 * 
 * Problem:
 *   Calculating next tag address can overflow if size is huge.
 *   next = (p + tag->size + 7) & ~7;
 *   If tag->size is 0xFFFFFFFF, this overflows!
 * 
 * Solution:
 *   Check tag->size is reasonable BEFORE using it.
 *   
 *   if (tag->size < sizeof(struct mb2_tag) || tag->size > 1000000) {
 *       // Suspicious size, stop parsing
 *   }
 * 
 * 
 * PITFALL 5: Assuming Entries Fit Exactly
 * 
 * Problem:
 *   Memory map parsing assumes:
 *   while (q + entry_size <= end) { ... }
 *   
 *   But if entry_size is wrong, we might read partial entries or
 *   skip entries.
 * 
 * Solution:
 *   Use the entry_size provided by bootloader (it knows best).
 *   Don't assume entry_size == sizeof(struct mb2_mmap_entry).
 *   
 *   Why? Future versions might add fields.
 * 
 * 
 * PITFALL 6: Reading Beyond total_size
 * 
 * Problem:
 *   If we don't track end pointer, we might read past the structure
 *   into garbage memory.
 * 
 * Solution:
 *   Calculate end = base + total_size ONCE at start.
 *   Check all reads against this end pointer.
 * 
 * 
 * PITFALL 7: Infinite Loop on Corrupt Data
 * 
 * Problem:
 *   If a tag has size=0, advancing to next tag doesn't progress.
 *   Result: Infinite loop, kernel hangs.
 * 
 * Solution:
 *   Check tag->size > 0 and tag->size >= sizeof(header).
 *   If not, treat as corrupt and stop parsing.
 * 
 * 
 * PITFALL 8: Not Handling 64-bit Addresses on 32-bit System
 * 
 * Problem:
 *   Memory map uses uint64_t addresses.
 *   On 32-bit system, we can't use addresses above 4 GiB.
 *   But we must still handle them (check high bits are 0).
 * 
 * Solution:
 *   if (me->addr < 0x100000000ULL) {
 *       // Safe to use on 32-bit system
 *       uint32_t phys = (uint32_t)me->addr;
 *   } else {
 *       // Above 4 GiB, skip on 32-bit system
 *   }
 *
 *=============================================================================
 * SECTION 9: INTEGRATION WITH OTHER SUBSYSTEMS
 *=============================================================================
 * 
 * This file interacts with several other kernel components:
 * 
 * CALLED BY:
 *   - kernel_main() in kernel.c
 *   - Early in initialization (right after I/O setup)
 *   - Before memory manager initialization
 * 
 * CALLS:
 *   - console_puts() - Print strings to VGA console
 *   - console_putc() - Print single characters
 *   - console_put_hex32() - Print 32-bit hex values
 *   - console_put_hex64() - Print 64-bit hex values
 *   - console_put_dec_u32() - Print 32-bit decimal values
 * 
 * PROVIDES DATA TO:
 *   - pmm.c (Physical Memory Manager)
 *   - pmm_init_from_mb2() reads memory map to build allocator
 *   - pmm.c duplicates tag parsing (for independence)
 * 
 * DEPENDS ON:
 *   - kernel.h (Multiboot structure definitions)
 *   - console output functions (vga.c)
 *   - Nothing else (very minimal dependencies)
 * 
 * INITIALIZATION ORDER:
 *   1. serial_init() - COM1 for debugging
 *   2. console_clear() - Clear VGA screen
 *   3. mb_dump_mb2() - Display boot info ← WE ARE HERE
 *   4. idt_init() - Install interrupt handlers
 *   5. pmm_init_from_mb2() - Parse memory map again for PMM
 *   6. paging_init() - Set up virtual memory
 *   7. ... rest of kernel initialization
 * 
 * WHY THIS ORDER?
 *   - mb_dump_mb2() must be early (boot info might be overwritten later)
 *   - Must be after console init (need output to display info)
 *   - Must be before memory manager (PMM needs memory map data)
 *   - Could be before or after IDT (doesn't matter, we won't fault)
 * 
 * FUTURE ENHANCEMENTS:
 *   This file could be extended to:
 *   - Parse framebuffer tag (for graphics mode)
 *   - Parse module tags (for initrd/drivers)
 *   - Parse ACPI tables (for power management)
 *   - Parse EFI system table (for UEFI systems)
 *   - Provide iterator functions for other subsystems
 *   - Cache parsed data in kernel structures
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "kernel.h"

/*=============================================================================
 * FUNCTION: dump_mmap_mb2 (UNUSED HELPER)
 *=============================================================================
 * 
 * PURPOSE:
 *   Helper function to display memory map entries.
 *   Currently unused (marked with __attribute__((unused))).
 *   Kept for future use or debugging.
 * 
 * WHY UNUSED?
 *   The memory map display logic is inlined in mb_dump_mb2() for simplicity.
 *   This function was originally separate but is no longer called.
 *   We keep it because:
 *   - Could be useful for debugging (call manually)
 *   - Shows alternative implementation approach
 *   - May be used in future refactoring
 * 
 * PARAMETERS:
 *   mm - Pointer to Multiboot2 memory map tag
 * 
 * WHAT IT DOES:
 *   1. Calculate start and end of entries array
 *   2. Loop through entries (using entry_size for stride)
 *   3. Print each entry's address, length, and type
 * 
 * ENTRY_SIZE:
 *   We use mm->entry_size (provided by bootloader) instead of
 *   sizeof(struct mb2_mmap_entry) because:
 *   - Future Multiboot versions might add fields
 *   - Bootloader knows the actual size being used
 *   - This makes our code forward-compatible
 * 
 * OUTPUT FORMAT:
 *   Memory map entries:
 *     addr=0x0000000000000000 len=0x000000000009FC00 type=1
 *     addr=0x0000000000100000 len=0x0000000007F00000 type=1
 *     ...
 * 
 * POINTER ARITHMETIC:
 *   We use uint8_t* (byte pointers) because:
 *   - entry_size is in bytes (not in units of struct size)
 *   - Allows precise control of address calculations
 *   - p += entry_size advances by exact byte count
 */
__attribute__((unused))
static void dump_mmap_mb2(const struct mb2_tag_mmap* mm) {
    /*
     * Calculate entry array bounds:
     * - p: Start of first entry (right after tag header)
     * - e: End of tag (one byte past last valid entry)
     */
    const uint8_t* p = (const uint8_t*)(mm + 1);  /* First entry */
    const uint8_t* e = ((const uint8_t*)mm) + mm->size;  /* End of tag */

    console_puts("Memory map entries:\n");
    
    /*
     * Loop through all entries:
     * - Check we have space for full entry (p + entry_size <= e)
     * - Cast byte pointer to entry structure
     * - Print entry fields
     * - Advance by entry_size bytes (not sizeof!)
     */
    while (p + mm->entry_size <= e) {
        const struct mb2_mmap_entry* me = (const struct mb2_mmap_entry*)p;
        
        /* Print base address (64-bit, in hex) */
        console_puts("  addr=");
        console_put_hex64(me->addr);
        
        /* Print length (64-bit, in hex) */
        console_puts(" len=");
        console_put_hex64(me->len);
        
        /* Print type (32-bit, in decimal) */
        console_puts(" type=");
        console_put_dec_u32(me->type);
        
        console_putc('\n');
        
        /* Advance to next entry */
        p += mm->entry_size;
    }
}

/*=============================================================================
 * FUNCTION: mb_dump_mb1 (MULTIBOOT1 SUPPORT)
 *=============================================================================
 * 
 * PURPOSE:
 *   Display boot information from Multiboot1 bootloader.
 *   
 * MULTIBOOT1 CONTEXT:
 *   If EAX == 0x2BADB002 at boot (instead of 0x36D76289),
 *   we were booted by Multiboot1 (GRUB Legacy).
 *   
 *   EBX points to a "struct multiboot_info" (not tag-based).
 * 
 * PARAMETERS:
 *   mb - Pointer to Multiboot1 information structure
 * 
 * WHAT IT DISPLAYS:
 *   Currently: Only bootloader name
 *   Could be extended to show:
 *   - Memory lower/upper
 *   - Command line
 *   - Memory map (mb1_mmap_entry format)
 *   - Loaded modules
 * 
 * MINIMAL IMPLEMENTATION:
 *   TinyOS focuses on Multiboot2, so this function is kept minimal.
 *   It's here for:
 *   - Completeness (educational value)
 *   - Testing with legacy bootloaders
 *   - Future compatibility
 * 
 * NULL POINTER HANDLING:
 *   Multiboot1 uses 0 to indicate "field not provided."
 *   We check boot_loader_name != 0 before dereferencing.
 * 
 * CASTING:
 *   boot_loader_name is uint32_t (physical address of string).
 *   We cast to pointer via uintptr_t (proper C99 practice).
 * 
 * OUTPUT FORMAT:
 *   Bootloader: GRUB 0.97
 *   OR
 *   Bootloader: <unknown>
 */
void mb_dump_mb1(const struct multiboot_info* mb) {
    console_puts("Bootloader: ");
    
    /*
     * Check if bootloader name field is provided (non-zero).
     * If provided, cast to char* and print.
     * If not provided, print placeholder.
     */
    if (mb->boot_loader_name) {
        /* Cast: uint32_t → uintptr_t → const char* */
        console_puts((const char*)(uintptr_t)mb->boot_loader_name);
    } else {
        console_puts("<unknown>");
    }
    
    console_putc('\n');
    
    /*
     * FUTURE EXPANSION:
     * You could add here:
     * 
     * if (mb->flags & (1 << 0)) {
     *     // mem_lower and mem_upper are valid
     *     console_puts("Memory: ");
     *     console_put_dec_u32(mb->mem_lower);
     *     console_puts(" KiB / ");
     *     console_put_dec_u32(mb->mem_upper);
     *     console_puts(" KiB\n");
     * }
     * 
     * if (mb->flags & (1 << 2)) {
     *     // Command line is valid
     *     console_puts("Cmdline: ");
     *     console_puts((const char*)(uintptr_t)mb->cmdline);
     *     console_putc('\n');
     * }
     * 
     * if (mb->flags & (1 << 6)) {
     *     // Memory map is valid
     *     // Parse mb1_mmap_entry structures
     * }
     */
}

/*=============================================================================
 * FUNCTION: mb_dump_mb2 (MULTIBOOT2 PARSER AND DISPLAY)
 *=============================================================================
 * 
 * PURPOSE:
 *   Parse and display boot information from Multiboot2 bootloader.
 *   This is the MAIN FUNCTION of this file.
 * 
 * PARAMETERS:
 *   info_ptr - Physical address of Multiboot2 information structure
 *              (provided by GRUB in EBX register)
 * 
 * WHAT IT DISPLAYS:
 *   - Bootloader name and version (e.g., "GRUB 2.06")
 *   - Command line arguments (e.g., "root=/dev/sda1 quiet")
 *   - Memory map (all usable and reserved regions)
 * 
 * PARSING APPROACH:
 *   1. Read total_size from structure header
 *   2. Calculate end pointer (for bounds checking)
 *   3. Start at first tag (base + 8 bytes)
 *   4. Loop through tags until end tag or structure end
 *   5. For each tag:
 *      - Read type and size
 *      - Process known types (bootloader, cmdline, mmap)
 *      - Ignore unknown types (forward compatibility)
 *      - Advance to next tag (8-byte aligned)
 *   6. Stop at end tag or if structure is malformed
 * 
 * SAFETY FEATURES:
 *   ✅ Bounds checking: p + sizeof(tag) <= end
 *   ✅ Size validation: p + tag->size <= end
 *   ✅ Graceful exit on end tag
 *   ✅ Graceful exit on malformed data
 *   ✅ 8-byte alignment in pointer arithmetic
 *   ✅ Const correctness (can't modify boot info)
 * 
 * TAG HANDLING:
 *   We process three tag types:
 *   - Type 2 (Bootloader Name): Print bootloader string
 *   - Type 1 (Command Line): Print kernel cmdline
 *   - Type 6 (Memory Map): Print all memory regions
 *   
 *   All other types are silently ignored (default case does nothing).
 *   This is correct behavior for forward compatibility!
 * 
 * ALIGNMENT:
 *   Tags are 8-byte aligned. To advance to next tag:
 *   next = ((p + tag->size + 7) & ~7)
 *   
 *   This formula:
 *   1. Adds current position + tag size
 *   2. Adds 7 (to round up)
 *   3. Clears lower 3 bits (forces alignment to 8)
 *   
 *   Example: size=26 → (p+26+7) & ~7 → p+33 & ~7 → p+32
 * 
 * WHY SWITCH ON TYPE?
 *   - Clear structure (one case per tag type)
 *   - Easy to add new tags (just add a case)
 *   - Default case handles unknown tags (ignore gracefully)
 *   - Compiler can optimize (jump table or binary search)
 * 
 * MEMORY MAP PARSING:
 *   The memory map tag contains an array of entries.
 *   We parse it inline (not using dump_mmap_mb2 helper).
 *   
 *   Steps:
 *   1. Cast tag to mb2_tag_mmap structure
 *   2. Calculate entries array (starts after tag header)
 *   3. Calculate end of entries (tag base + tag size)
 *   4. Loop through entries (stride = entry_size)
 *   5. Print each entry (addr, len, type)
 * 
 * OUTPUT FORMAT:
 *   Bootloader: GRUB 2.06
 *   Cmdline   : root=/dev/sda1 quiet
 *   Memory map entries:
 *     addr=0x0000000000000000 len=0x000000000009FC00 type=1
 *     addr=0x0000000000100000 len=0x0000000007F00000 type=1
 * 
 * WHAT IF NO TAGS FOUND?
 *   If bootloader provides no bootloader/cmdline/mmap tags:
 *   - We simply don't print those sections
 *   - Kernel can still run (these are informational)
 *   - Memory manager will need memory map though (critical!)
 * 
 * RETURN VALUE:
 *   None (void function). Side effect is console output.
 * 
 * THREAD SAFETY:
 *   Not applicable (single-threaded early initialization).
 * 
 * REENTRANCY:
 *   Not reentrant (uses console output, which is not reentrant).
 *   Should only be called once during boot.
 * 
 * ERROR HANDLING:
 *   If structure is malformed:
 *   - Loop exits early (when p + tag->size > end)
 *   - Partial information is displayed (what we parsed so far)
 *   - No error message (could add one if desired)
 */
void mb_dump_mb2(const void* info_ptr) {
    /*-------------------------------------------------------------------------
     * STEP 1: SET UP POINTERS AND BOUNDS
     *-----------------------------------------------------------------------*/
    
    /* Cast to byte pointer for arithmetic */
    const uint8_t* base = (const uint8_t*)info_ptr;
    
    /*
     * Read total_size from structure header (first 4 bytes).
     * This tells us the size of the entire structure in bytes.
     * 
     * Structure layout:
     *   Offset 0: uint32_t total_size
     *   Offset 4: uint32_t reserved (must be 0)
     *   Offset 8: First tag
     */
    const uint32_t total_size = *(const uint32_t*)(base + 0);
    
    /*
     * We could read 'reserved' field and check it's 0:
     * const uint32_t reserved = *(const uint32_t*)(base + 4);
     * if (reserved != 0) { console_puts("WARNING: Reserved field is non-zero!\n"); }
     * 
     * But we skip this check for simplicity (it's always 0 in practice).
     */
    
    /* First tag starts at offset 8 (after total_size and reserved) */
    const uint8_t* p = base + 8;
    
    /* End of structure (one byte past last valid data) */
    const uint8_t* end = base + total_size;
    
    /*
     * SANITY CHECK (optional):
     * if (total_size < 8) {
     *     console_puts("ERROR: Multiboot2 structure too small!\n");
     *     return;
     * }
     * if (total_size > 1000000) {
     *     console_puts("ERROR: Multiboot2 structure suspiciously large!\n");
     *     return;
     * }
     */

    /*-------------------------------------------------------------------------
     * STEP 2: LOOP THROUGH TAGS
     *-----------------------------------------------------------------------*/
    
    /*
     * Parse tags until we hit end tag or run out of data.
     * 
     * Loop invariant:
     *   p points to start of current tag (or past end if done)
     *   p is 8-byte aligned
     *   We've validated all tags before p
     */
    while (p + sizeof(struct mb2_tag) <= end) {
        /*
         * Read tag header (type and size).
         * We know p + sizeof(struct mb2_tag) <= end, so this is safe.
         */
        const struct mb2_tag* tag = (const struct mb2_tag*)p;
        
        /*
         * Check for end tag (type 0).
         * This MUST be the last tag in the structure.
         * When we see it, we're done parsing.
         */
        if (tag->type == MB2_TAG_END) {
            break;  /* Normal exit from loop */
        }
        
        /*
         * Validate that the entire tag fits in the structure.
         * If tag->size extends past end, the structure is CORRUPTED.
         * Stop parsing immediately to avoid reading garbage.
         */
        if (p + tag->size > end) {
            /*
             * MALFORMED STRUCTURE!
             * Options:
             *   1. Print warning and break (our choice)
             *   2. Panic and halt
             *   3. Continue with next tag (risky!)
             */
            break;  /* Stop parsing on corruption */
        }

        /*---------------------------------------------------------------------
         * STEP 3: PROCESS TAG BASED ON TYPE
         *-------------------------------------------------------------------*/
        
        switch (tag->type) {
            
            /*-----------------------------------------------------------------
             * TAG TYPE 2: BOOTLOADER NAME
             *-----------------------------------------------------------------
             * Contains name and version of bootloader as a null-terminated
             * ASCII string.
             * 
             * Example: "GRUB 2.06" or "GRUB 2.12"
             * 
             * Structure:
             *   Offset 0: uint32_t type (2)
             *   Offset 4: uint32_t size (including header and string)
             *   Offset 8: char[] string (null-terminated)
             */
            case MB2_TAG_BOOTLOADER: {
                /* Cast to string tag structure */
                const struct mb2_tag_string* s = (const struct mb2_tag_string*)tag;
                
                /* Print label and string */
                console_puts("Bootloader: ");
                console_puts(s->str);  /* str is char[] at offset 8 */
                console_putc('\n');
                
                /*
                 * SAFETY NOTE:
                 * We assume s->str is null-terminated. If it's not,
                 * console_puts will read beyond the tag (bad!).
                 * 
                 * Better implementation would use strnlen:
                 *   size_t max_len = tag->size - sizeof(struct mb2_tag_string);
                 *   console_putsn(s->str, max_len);
                 * 
                 * But TinyOS trusts the bootloader (simplicity trade-off).
                 */
            } break;

            /*-----------------------------------------------------------------
             * TAG TYPE 1: COMMAND LINE
             *-----------------------------------------------------------------
             * Contains kernel command-line arguments as a null-terminated
             * ASCII string.
             * 
             * Example: "root=/dev/sda1 quiet splash"
             * 
             * This string is typically set in GRUB configuration:
             *   linux /boot/kernel.elf root=/dev/sda1 quiet
             * 
             * Structure: Same as bootloader tag (type + size + string)
             */
            case MB2_TAG_CMDLINE: {
                const struct mb2_tag_string* s = (const struct mb2_tag_string*)tag;
                console_puts("Cmdline   : ");
                console_puts(s->str);
                console_putc('\n');
                
                /*
                 * WHAT CAN WE DO WITH CMDLINE?
                 * - Parse options (e.g., "quiet" → reduce logging)
                 * - Extract root device (e.g., "root=/dev/sda1")
                 * - Set kernel parameters (e.g., "mem=128M")
                 * - Enable debug mode (e.g., "debug")
                 * 
                 * TinyOS currently ignores cmdline (just displays it).
                 * Future enhancement: Implement cmdline parsing.
                 */
            } break;

            /*-----------------------------------------------------------------
             * TAG TYPE 6: MEMORY MAP (THE MOST IMPORTANT TAG!)
             *-----------------------------------------------------------------
             * Contains the E820 memory map: a list of physical memory regions
             * with their types (usable, reserved, ACPI, etc.).
             * 
             * This tag is CRITICAL. Without it:
             * - We don't know how much RAM is installed
             * - We don't know where hardware is mapped
             * - We can't set up memory management
             * - Kernel cannot function properly
             * 
             * Structure:
             *   Offset 0:  uint32_t type (6)
             *   Offset 4:  uint32_t size (total tag size)
             *   Offset 8:  uint32_t entry_size (bytes per entry, usually 24)
             *   Offset 12: uint32_t entry_version (usually 0)
             *   Offset 16: Entry array (variable count)
             * 
             * Each entry is 24 bytes:
             *   Offset 0:  uint64_t addr (base address)
             *   Offset 8:  uint64_t len (length in bytes)
             *   Offset 16: uint32_t type (1=usable, 2=reserved, etc.)
             *   Offset 20: uint32_t zero (reserved, must be 0)
             */
            case MB2_TAG_MMAP: {
                /* Cast to memory map tag structure */
                const struct mb2_tag_mmap* mm = (const struct mb2_tag_mmap*)tag;
                
                /*
                 * Calculate entry array bounds:
                 * - q: First entry (right after tag header)
                 * - qe: End of tag (one byte past last entry)
                 */
                const uint8_t* q = (const uint8_t*)(mm + 1);
                const uint8_t* qe = p + mm->size;
                
                console_puts("Memory map entries:\n");
                
                /*
                 * Loop through all entries:
                 * - Use entry_size from tag (not sizeof!)
                 * - Check full entry fits before accessing it
                 * - Print address, length, type for each entry
                 */
                while (q + mm->entry_size <= qe) {
                    /* Cast current position to entry structure */
                    const struct mb2_mmap_entry* me = (const struct mb2_mmap_entry*)q;
                    
                    /*
                     * Print entry fields:
                     * - addr: 64-bit physical base address
                     * - len: 64-bit length in bytes
                     * - type: 32-bit region type (1=usable, 2=reserved, etc.)
                     */
                    console_puts("  addr=");
                    console_put_hex64(me->addr);
                    
                    console_puts(" len=");
                    console_put_hex64(me->len);
                    
                    console_puts(" type=");
                    console_put_dec_u32(me->type);
                    
                    console_putc('\n');
                    
                    /*
                     * Advance to next entry.
                     * Use entry_size (not sizeof) for forward compatibility.
                     */
                    q += mm->entry_size;
                }
                
                /*
                 * MEMORY TYPE INTERPRETATION:
                 * 
                 * Type 1 (Usable):
                 *   Normal RAM that the OS can use for anything.
                 *   This is what we allocate from for kernel/user programs.
                 * 
                 * Type 2 (Reserved):
                 *   Hardware-reserved regions (BIOS, firmware, device memory).
                 *   DO NOT USE! Writing here can corrupt firmware or hang system.
                 * 
                 * Type 3 (ACPI Reclaimable):
                 *   ACPI tables. Can be reclaimed after parsing tables.
                 *   Most OSes treat as reserved until ACPI is fully parsed.
                 * 
                 * Type 4 (ACPI NVS):
                 *   ACPI Non-Volatile Storage. Used by firmware across reboots.
                 *   NEVER USE! Can cause resume-from-sleep to fail.
                 * 
                 * Type 5 (Bad):
                 *   Defective RAM detected by firmware.
                 *   DO NOT USE! Reading/writing can cause ECC errors.
                 * 
                 * TYPICAL ENTRIES ON QEMU (128 MiB):
                 *   addr=0x0000000000000000 len=0x000000000009FC00 type=1   (639 KiB usable)
                 *   addr=0x000000000009FC00 len=0x0000000000000400 type=2   (1 KiB reserved)
                 *   addr=0x00000000000E0000 len=0x0000000000020000 type=2   (128 KiB reserved, BIOS)
                 *   addr=0x0000000000100000 len=0x0000000007F00000 type=1   (127 MiB usable)
                 */
            } break;

            /*-----------------------------------------------------------------
             * DEFAULT: IGNORE UNKNOWN TAGS
             *-----------------------------------------------------------------
             * If we encounter a tag type we don't recognize, we simply
             * skip it. This is CORRECT BEHAVIOR for forward compatibility!
             * 
             * Why ignore instead of error?
             * - Future Multiboot2 versions may add new tags
             * - Old kernels should work with new bootloaders
             * - Bootloader may provide extra vendor-specific tags
             * - Unknown tags are not errors, just information we don't need
             * 
             * Examples of tags we ignore:
             * - Type 3: Modules (we don't support modules yet)
             * - Type 4: Basic memory info (legacy, use mmap instead)
             * - Type 5: Boot device (we don't care which device we booted from)
             * - Type 7: VBE info (we don't use VESA graphics)
             * - Type 8: Framebuffer info (we use text mode)
             * - Type 9: ELF symbols (we don't use kernel symbols yet)
             * - Types 10-21: Various ACPI, EFI, network tags
             * 
             * If you want to handle more tags, add cases above!
             */
            default:
                /* Silently ignore unknown/unimplemented tags */
                break;
        }

        /*---------------------------------------------------------------------
         * STEP 4: ADVANCE TO NEXT TAG (8-BYTE ALIGNED)
         *-------------------------------------------------------------------*/
        
        /*
         * Calculate address of next tag.
         * Tags are 8-byte aligned, so we must round up.
         * 
         * Formula: next = ((current + size + 7) & ~7)
         * 
         * Step-by-step:
         *   1. current + size = address right after current tag
         *   2. + 7 = round up to next 8-byte boundary
         *   3. & ~7 = clear lower 3 bits (force 8-byte alignment)
         * 
         * Example: tag at 0x1000, size=26
         *   next = (0x1000 + 26 + 7) & ~7
         *        = 0x1021 & 0xFFFFFFF8
         *        = 0x1020
         * 
         * Why uintptr_t?
         *   - Pointer arithmetic in C can be tricky with alignment
         *   - Cast to integer, do math, cast back to pointer
         *   - uintptr_t is guaranteed to hold any pointer value
         */
        uintptr_t next = ((uintptr_t)p + tag->size + 7u) & ~((uintptr_t)7u);
        p = (const uint8_t*)next;
        
        /*
         * SAFETY CHECK (optional, commented out for performance):
         * if (next <= (uintptr_t)p) {
         *     // Overflow or zero-size tag (corrupted)
         *     break;
         * }
         * if (p > end) {
         *     // Advanced past end (shouldn't happen if checks above are correct)
         *     break;
         * }
         */
    }
    
    /*-------------------------------------------------------------------------
     * STEP 5: PARSING COMPLETE
     *-----------------------------------------------------------------------*/
    
    /*
     * We've successfully parsed the entire boot information structure.
     * 
     * At this point:
     * ✅ We've displayed bootloader name (if present)
     * ✅ We've displayed command line (if present)
     * ✅ We've displayed memory map (if present)
     * ✅ We've ignored any unknown tags (forward compatible)
     * ✅ We've handled malformed structures (early exit if corrupted)
     * 
     * Next steps in kernel initialization:
     * 1. Set up IDT (interrupt handlers)
     * 2. Initialize PMM (parse memory map AGAIN for allocator)
     * 3. Enable paging (virtual memory)
     * 4. Set up hardware interrupts (PIC, PIT)
     * 5. Enable interrupts (STI)
     * 6. Enter idle loop
     */
}

/*=============================================================================
 * END OF FILE: multiboot.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Explained Multiboot specification (history and purpose)
 *   ✅ Documented Multiboot1 vs Multiboot2 differences
 *   ✅ Implemented safe tag-based parser for Multiboot2
 *   ✅ Displayed bootloader name, command line, and memory map
 *   ✅ Provided extensive comments for educational value
 *   ✅ Implemented defensive parsing (bounds checking, validation)
 *   ✅ Handled unknown tags gracefully (forward compatibility)
 * 
 * WHAT HAPPENS NEXT:
 *   → See kernel.c for overall boot sequence
 *   → See pmm.c for memory map usage (marks usable RAM)
 *   → See boot.s for Multiboot2 header definition
 *   → See linker.ld for kernel memory layout
 * 
 * LEARNING RESOURCES:
 *   - Multiboot2 Specification:
 *     https://www.gnu.org/software/grub/manual/multiboot2/multiboot.html
 *   - OSDev Wiki Multiboot:
 *     https://wiki.osdev.org/Multiboot
 *   - GRUB Manual:
 *     https://www.gnu.org/software/grub/manual/
 *   - E820 Memory Map:
 *     https://wiki.osdev.org/Detecting_Memory_(x86)
 * 
 * TESTING TIPS:
 *   - Boot with QEMU's -m option to test different RAM sizes
 *   - Use GRUB's command line to pass kernel parameters
 *   - Check memory map matches expected physical RAM layout
 *   - Verify bootloader name shows correct GRUB version
 *   - Test with different bootloaders (GRUB Legacy, GRUB2, QEMU)
 * 
 * FUTURE ENHANCEMENTS:
 *   - Parse command line into key=value pairs
 *   - Cache parsed data in kernel structures (don't re-parse)
 *   - Handle framebuffer tag (graphics mode support)
 *   - Handle module tags (initrd/driver loading)
 *   - Handle ACPI/EFI tags (advanced power management)
 *   - Provide iterator API for other subsystems
 *   - Add more validation (check reserved fields, alignment)
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - How bootloaders communicate with OS kernels
 *   - How to parse complex, tag-based data structures
 *   - The importance of memory maps in OS development
 *   - How to write safe parsing code (bounds checking, validation)
 *   - Why forward compatibility matters in specifications
 * 
 *   You're well on your way to understanding low-level systems programming! 🎉
 *============================================================================*/
