/*=============================================================================
 *  serial.c — Serial Port (UART) Driver for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file implements a driver for the 16550 UART (Universal Asynchronous
 *   Receiver/Transmitter) serial port. It provides debug output capabilities
 *   through COM1, allowing kernel messages to be logged to a host machine.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Target: 16550 UART (or compatible)
 *   - Port: COM1 (I/O base address 0x3F8)
 *   - Protocol: RS-232 serial communication
 *   - Mode: 8N1 (8 data bits, no parity, 1 stop bit)
 *   - Speed: 115200 baud (bits per second)
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is Serial Communication?
 * 2. The UART Hardware
 * 3. RS-232 Protocol
 * 4. COM Ports and I/O Addresses
 * 5. UART Registers
 * 6. Baud Rate Configuration
 * 7. Initialization Sequence
 * 8. Transmission Process
 * 9. Line Endings (CR/LF)
 * 10. Design Decisions and Trade-offs
 * 11. Common Pitfalls and Solutions
 * 12. Integration with the Kernel
 *
 *=============================================================================
 * SECTION 1: WHAT IS SERIAL COMMUNICATION?
 *=============================================================================
 * 
 * Serial communication is a method of transmitting data ONE BIT AT A TIME
 * over a single wire (or pair of wires). This contrasts with parallel
 * communication, which sends multiple bits simultaneously over multiple wires.
 * 
 * ANALOGY:
 *   Imagine sending a message letter by letter vs word by word:
 *   
 *   Serial:   H → e → l → l → o  (one character at a time)
 *   Parallel: Hello               (all characters at once)
 *   
 *   Serial is slower but uses fewer wires!
 * 
 * WHY SERIAL COMMUNICATION?
 * 
 * Advantages:
 *   ✅ Simple hardware (fewer wires, cheaper cables)
 *   ✅ Long distances (up to 50 feet for RS-232)
 *   ✅ Reliable (well-established standard)
 *   ✅ Universal (works across different systems)
 *   ✅ Debugging-friendly (easy to capture with oscilloscope)
 * 
 * Disadvantages:
 *   ❌ Slower than parallel (sends one bit at a time)
 *   ❌ More complex protocol (need synchronization)
 *   ❌ Requires voltage conversion (±12V for RS-232)
 * 
 * SERIAL VS USB:
 *   Modern computers use USB instead of serial ports, but:
 *   - Virtual machines (QEMU, VirtualBox) emulate serial ports
 *   - Embedded systems still widely use serial
 *   - Serial is simpler to program than USB
 *   - Bootloaders and BIOS often support serial
 *   - USB-to-serial adapters bridge the gap
 * 
 * USE CASES IN TINYOS:
 * 
 * 1. DEBUG OUTPUT:
 *    - Print kernel messages to host machine
 *    - See output even if VGA is broken
 *    - Capture logs to file (qemu -serial file:log.txt)
 * 
 * 2. EARLY BOOT:
 *    - Output available BEFORE VGA initialization
 *    - Works even if video hardware fails
 *    - First resort for debugging boot issues
 * 
 * 3. PANIC MESSAGES:
 *    - Reliable output when system is dying
 *    - Less likely to fail than VGA (simpler hardware)
 *    - Can be logged automatically
 * 
 * 4. REMOTE DEBUGGING:
 *    - Access kernel without monitor/keyboard
 *    - Useful for servers or embedded systems
 *    - Can attach debugger over serial (GDB remote)
 * 
 * PHYSICAL CONNECTION:
 * 
 * Traditional (real hardware):
 *   PC Serial Port (DB-9 connector)
 *     ↓
 *   Serial Cable (null modem if PC-to-PC)
 *     ↓
 *   Another PC's Serial Port
 *     ↓
 *   Terminal Software (PuTTY, minicom, screen)
 * 
 * Modern (virtual machine):
 *   QEMU VM
 *     ↓
 *   -serial stdio (or file:log.txt)
 *     ↓
 *   Host Terminal Window
 * 
 * No physical cable needed in VM!
 *
 *=============================================================================
 * SECTION 2: THE UART HARDWARE
 *=============================================================================
 * 
 * UART = Universal Asynchronous Receiver/Transmitter
 * 
 * WHAT IS A UART?
 * 
 * A UART is a hardware chip (or IP core) that converts between:
 *   - PARALLEL data (8-bit bus inside computer)
 *   - SERIAL data (1-bit stream on wire)
 * 
 * TRANSMIT (TX) PATH:
 *   CPU writes byte → UART converts to bits → Bits sent on TX line
 *   
 *   Example: Sending 'A' (0x41 = 01000001 binary)
 *   
 *   Parallel (inside computer):  [0 1 0 0 0 0 0 1]
 *                                         ↓
 *   Serial (on wire):  START 1 0 0 0 0 0 1 0 STOP
 *                       \_/ \_________/ \_/
 *                        |       |        |
 *                      start   data     stop
 *                       bit    bits      bit
 * 
 * RECEIVE (RX) PATH:
 *   Bits arrive on RX line → UART converts to byte → CPU reads byte
 * 
 * THE 16550 UART:
 * 
 * The 16550 is a specific UART chip (and compatible clones):
 *   - Introduced by National Semiconductor in 1987
 *   - PC standard (all x86 PCs have 16550 or compatible)
 *   - Includes 16-byte FIFO buffers (reduces interrupt overhead)
 *   - Programmable baud rate (up to 115200 bps)
 *   - Supports hardware flow control (RTS/CTS)
 * 
 * UART VERSIONS:
 *   - 8250:  Original (no FIFO, slow, obsolete)
 *   - 16450: Improved 8250 (still no FIFO)
 *   - 16550: Added FIFO buffers (most common) ← TINYOS USES THIS
 *   - 16550A: Fixed FIFO bugs
 *   - 16750: 64-byte FIFO (not common)
 * 
 * FIFO = First-In, First-Out Buffer:
 *   Without FIFO:
 *     - CPU must read each byte immediately
 *     - High interrupt rate (one per byte)
 *     - CPU spends lots of time servicing interrupts
 *   
 *   With FIFO:
 *     - UART buffers up to 16 bytes
 *     - CPU can read in bursts
 *     - Lower interrupt rate (one per 14 bytes)
 *     - Better performance
 * 
 * TinyOS uses FIFO mode for efficiency.
 * 
 * UART PINS (Physical Hardware):
 * 
 * Minimal connection (what we use):
 *   - TxD (Transmit Data):  Output pin, sends bits
 *   - RxD (Receive Data):   Input pin, receives bits
 *   - GND (Ground):         Common reference voltage
 * 
 * Full connection (hardware flow control):
 *   - RTS (Request To Send):    We're ready to receive
 *   - CTS (Clear To Send):      Other side ready to receive
 *   - DSR (Data Set Ready):     Modem is powered on
 *   - DTR (Data Terminal Ready): PC is powered on
 *   - DCD (Data Carrier Detect): Carrier signal detected
 *   - RI (Ring Indicator):      Phone is ringing (modem)
 * 
 * TinyOS only uses TxD (transmit only, no receive).
 * We don't implement RxD because we only need debug OUTPUT.
 *
 *=============================================================================
 * SECTION 3: RS-232 PROTOCOL
 *=============================================================================
 * 
 * RS-232 is the electrical standard for serial communication.
 * It defines voltages, timing, and signal meanings.
 * 
 * VOLTAGE LEVELS (Traditional RS-232):
 * 
 * RS-232 uses ±12V signaling (not TTL 0V/5V):
 *   - Logic 0 (SPACE): +3V to +15V (typically +12V)
 *   - Logic 1 (MARK):  -3V to -15V (typically -12V)
 *   - Invalid range:   -3V to +3V (noise margin)
 * 
 * Why ±12V?
 *   - Long cable distances (up to 50 feet)
 *   - Noise immunity (large voltage swings)
 *   - Historical reasons (telephone system compatibility)
 * 
 * Modern systems (like PCs) use voltage converters:
 *   UART (0V/5V TTL) → MAX232 chip → RS-232 (±12V)
 * 
 * FRAME FORMAT:
 * 
 * Each byte is sent as a "frame" with start/stop bits:
 * 
 *   IDLE  START  D0 D1 D2 D3 D4 D5 D6 D7  [PARITY]  STOP  IDLE
 *   ────┐     ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐ ┌─┐     ┌─┐   ┌──────
 *       └─────┘ └─┘ └─┘ └─┘ └─┘ └─┘ └─┘ └─┘ └─────┘ └───┘
 *       
 *       MARK  SPACE (varies)           SPACE  MARK
 *       (-12V)(+12V)                  (+12V) (-12V)
 * 
 * IDLE state: Line is MARK (logic 1, -12V)
 * START bit: SPACE (logic 0, +12V) for 1 bit time
 * DATA bits: 5-8 bits, LSB first (least significant bit)
 * PARITY bit: Optional (even, odd, or none)
 * STOP bits: MARK (logic 1) for 1-2 bit times
 * 
 * TinyOS uses 8N1 format:
 *   - 8 data bits (full byte, ASCII characters)
 *   - No parity bit
 *   - 1 stop bit
 * 
 * This is the most common configuration.
 * 
 * TIMING:
 * 
 * All timing is based on BAUD RATE (bits per second).
 * 
 * Example: 115200 baud
 *   - One bit time = 1 / 115200 = 8.68 microseconds
 *   - One frame (10 bits) = 86.8 microseconds
 *   - Maximum throughput = 115200 / 10 = 11520 bytes/second
 * 
 * WHY "ASYNCHRONOUS"?
 * 
 * No shared clock between sender and receiver!
 * 
 * Instead:
 *   1. Both sides agree on baud rate beforehand
 *   2. Receiver detects START bit (falling edge)
 *   3. Receiver samples data bits at 1-bit intervals
 *   4. Receiver expects STOP bit at end
 * 
 * If baud rates don't match:
 *   - Garbled data (receiver samples at wrong times)
 *   - Classic symptom: "garbage characters" on terminal
 * 
 * NOISE AND ERRORS:
 * 
 * RS-232 can detect some errors:
 *   - Framing error: STOP bit not found where expected
 *   - Parity error: Parity bit doesn't match data
 *   - Overrun error: New data arrived before old data read
 * 
 * TinyOS doesn't check for errors (transmit-only, no receive).
 *
 *=============================================================================
 * SECTION 4: COM PORTS AND I/O ADDRESSES
 *=============================================================================
 * 
 * COM PORTS are the standard PC names for serial ports:
 * 
 * Port Name  I/O Base  IRQ   Notes
 * ---------  --------  ---   -------------------------------------
 * COM1       0x3F8     4     Most common, primary serial port
 * COM2       0x2F8     3     Secondary serial port
 * COM3       0x3E8     4     Less common, shares IRQ with COM1
 * COM4       0x2E8     3     Less common, shares IRQ with COM2
 * 
 * TinyOS uses COM1 at 0x3F8.
 * 
 * WHY 0x3F8?
 * 
 * These are I/O PORT ADDRESSES (not memory addresses):
 *   - x86 has separate I/O address space (64K ports)
 *   - Access via IN/OUT instructions (not MOV)
 *   - 0x3F8 is the BASE address for COM1
 *   - Individual registers are at BASE+0, BASE+1, etc.
 * 
 * I/O PORTS VS MEMORY:
 * 
 * Memory-mapped I/O (like VGA at 0xB8000):
 *   - Uses regular memory addresses
 *   - Access with MOV instructions
 *   - Part of 4GB memory space
 *   - Example: VGA buffer
 * 
 * Port I/O (like COM1 at 0x3F8):
 *   - Uses separate I/O address space
 *   - Access with IN/OUT instructions
 *   - 64K ports (0x0000-0xFFFF)
 *   - Example: Serial ports, keyboard, PIC
 * 
 * INB/OUTB INSTRUCTIONS:
 * 
 * Read from I/O port:
 *   mov dx, 0x3F8     ; Port address in DX
 *   in al, dx         ; Read byte from port into AL
 * 
 * Write to I/O port:
 *   mov dx, 0x3F8     ; Port address in DX
 *   mov al, 'A'       ; Value to write in AL
 *   out dx, al        ; Write AL to port
 * 
 * Our inline assembly wrappers (inb/outb) do this.
 * 
 * PORT LAYOUT (COM1 at 0x3F8):
 * 
 * Offset  Register             Read/Write  Description
 * ------  -------------------  ----------  ---------------------------
 * +0      Data/DLAB Low        R/W         Transmit/Receive buffer
 *                                          (or divisor latch low byte)
 * +1      IER/DLAB High        R/W         Interrupt Enable Register
 *                                          (or divisor latch high byte)
 * +2      IIR/FCR              R/W         Interrupt ID / FIFO Control
 * +3      LCR                  R/W         Line Control Register
 * +4      MCR                  R/W         Modem Control Register
 * +5      LSR                  R           Line Status Register
 * +6      MSR                  R           Modem Status Register
 * +7      Scratch              R/W         Scratch register
 * 
 * The "+0" and "+1" registers have dual purposes:
 *   - When DLAB=0: Data and Interrupt Enable
 *   - When DLAB=1: Baud rate divisor (low/high bytes)
 * 
 * DLAB = Divisor Latch Access Bit (bit 7 of LCR register)
 * 
 * This multiplexing saves I/O ports (limited resource).
 *
 *=============================================================================
 * SECTION 5: UART REGISTERS
 *=============================================================================
 * 
 * The UART has 8 registers accessed via COM1+0 through COM1+7.
 * Let's examine each one in detail.
 * 
 * REGISTER 0: DATA REGISTER (or DLAB_LOW)
 * 
 * When DLAB=0 (normal mode):
 *   Write: Transmit Buffer
 *     - Write byte to send over serial line
 *     - UART automatically frames and transmits it
 *   
 *   Read: Receive Buffer
 *     - Read byte received from serial line
 *     - UART automatically unframes it
 * 
 * When DLAB=1 (divisor latch mode):
 *   Read/Write: Divisor Latch Low Byte
 *     - Lower 8 bits of baud rate divisor
 * 
 * REGISTER 1: INTERRUPT ENABLE REGISTER (or DLAB_HIGH)
 * 
 * When DLAB=0 (normal mode):
 *   Bit 0: Enable Receive Data Available interrupt
 *   Bit 1: Enable Transmitter Empty interrupt
 *   Bit 2: Enable Receive Line Status interrupt
 *   Bit 3: Enable Modem Status interrupt
 *   Bits 4-7: Reserved (must be 0)
 * 
 *   TinyOS sets this to 0x00 (all interrupts disabled).
 *   We use POLLING instead of interrupts (simpler).
 * 
 * When DLAB=1 (divisor latch mode):
 *   Read/Write: Divisor Latch High Byte
 *     - Upper 8 bits of baud rate divisor
 * 
 * REGISTER 2: INTERRUPT IDENTIFICATION / FIFO CONTROL
 * 
 * Read (IIR - Interrupt Identification Register):
 *   Identifies which interrupt occurred (if any).
 *   Not used by TinyOS (interrupts disabled).
 * 
 * Write (FCR - FIFO Control Register):
 *   Bit 0: Enable FIFO (1 = enable, 0 = disable)
 *   Bit 1: Clear receive FIFO
 *   Bit 2: Clear transmit FIFO
 *   Bit 3: DMA mode (not used)
 *   Bits 4-5: Reserved
 *   Bits 6-7: Interrupt trigger level
 *     00 = 1 byte
 *     01 = 4 bytes
 *     10 = 8 bytes
 *     11 = 14 bytes
 * 
 *   TinyOS sets this to 0xC7 (11000111 binary):
 *     - Enable FIFO
 *     - Clear both FIFOs
 *     - 14-byte trigger level
 * 
 * REGISTER 3: LINE CONTROL REGISTER (LCR)
 * 
 * This register configures the data format:
 * 
 *   Bits 0-1: Word length
 *     00 = 5 bits
 *     01 = 6 bits
 *     10 = 7 bits
 *     11 = 8 bits ← TinyOS uses this
 * 
 *   Bit 2: Stop bits
 *     0 = 1 stop bit ← TinyOS uses this
 *     1 = 2 stop bits (or 1.5 for 5-bit words)
 * 
 *   Bits 3-5: Parity
 *     000 = No parity ← TinyOS uses this
 *     001 = Odd parity
 *     011 = Even parity
 *     101 = Mark parity (always 1)
 *     111 = Space parity (always 0)
 * 
 *   Bit 6: Break signal
 *     0 = Normal ← TinyOS uses this
 *     1 = Send break (force line to SPACE)
 * 
 *   Bit 7: DLAB (Divisor Latch Access Bit)
 *     0 = Normal mode (access data registers)
 *     1 = Divisor latch mode (access baud rate divisor)
 * 
 *   TinyOS uses 0x03 for normal operation (8N1):
 *     - 8 data bits
 *     - No parity
 *     - 1 stop bit
 *     - DLAB=0 (normal mode)
 * 
 *   During baud rate setup, we use 0x83 (DLAB=1):
 *     - Same as above but DLAB bit set
 * 
 * REGISTER 4: MODEM CONTROL REGISTER (MCR)
 * 
 * This register controls modem handshaking lines:
 * 
 *   Bit 0: DTR (Data Terminal Ready)
 *     1 = Assert DTR line (we're ready)
 * 
 *   Bit 1: RTS (Request To Send)
 *     1 = Assert RTS line (we can receive)
 * 
 *   Bit 2: OUT1 (auxiliary output 1)
 *     General-purpose output
 * 
 *   Bit 3: OUT2 (auxiliary output 2)
 *     On PCs, must be 1 to enable interrupts
 * 
 *   Bit 4: Loopback mode
 *     1 = Enable loopback (for testing)
 * 
 *   Bits 5-7: Reserved
 * 
 *   TinyOS sets this to 0x0B (00001011 binary):
 *     - DTR = 1 (assert)
 *     - RTS = 1 (assert)
 *     - OUT1 = 0 (don't care)
 *     - OUT2 = 1 (enable interrupts, though we don't use them)
 *     - Loopback = 0 (normal mode)
 * 
 * REGISTER 5: LINE STATUS REGISTER (LSR)
 * 
 * This register shows current status (READ ONLY):
 * 
 *   Bit 0: Data Ready
 *     1 = Byte available in receive buffer
 * 
 *   Bit 1: Overrun Error
 *     1 = Data lost (new data arrived before old data read)
 * 
 *   Bit 2: Parity Error
 *     1 = Parity bit didn't match
 * 
 *   Bit 3: Framing Error
 *     1 = Stop bit not found where expected
 * 
 *   Bit 4: Break Interrupt
 *     1 = Break signal detected
 * 
 *   Bit 5: Transmitter Holding Register Empty ← WE USE THIS!
 *     1 = Safe to write next byte
 *     0 = Transmitter busy, wait
 * 
 *   Bit 6: Transmitter Empty
 *     1 = Both holding register and shift register empty
 * 
 *   Bit 7: FIFO Error
 *     1 = At least one error in FIFO
 * 
 *   TinyOS polls bit 5 (0x20) to check if transmitter is ready.
 * 
 * REGISTER 6: MODEM STATUS REGISTER (MSR)
 * 
 * This register shows modem control line status (READ ONLY).
 * Not used by TinyOS (we don't check modem lines).
 * 
 * REGISTER 7: SCRATCH REGISTER
 * 
 * General-purpose 8-bit storage.
 * Can be used to test if UART is present (write value, read it back).
 * Not used by TinyOS.
 *
 *=============================================================================
 * SECTION 6: BAUD RATE CONFIGURATION
 *=============================================================================
 * 
 * BAUD RATE = Bits per second
 * 
 * Common baud rates:
 *   300, 1200, 2400, 4800, 9600 (slow, legacy)
 *   19200, 38400, 57600 (medium)
 *   115200 (fast, most common today) ← TinyOS USES THIS
 *   230400, 460800, 921600 (very fast, less reliable)
 * 
 * TinyOS uses 115200 baud because:
 *   ✅ Fast enough for debug output (11.5 KB/sec)
 *   ✅ Widely supported (most systems can do 115200)
 *   ✅ Reliable (not so fast that errors occur)
 *   ❌ Not fastest (but faster isn't needed for debug)
 * 
 * HOW BAUD RATE IS SET:
 * 
 * The UART has a base clock frequency: 115200 Hz (on most PCs).
 * 
 * Baud rate = Base Clock / Divisor
 * 
 * To get 115200 baud:
 *   Divisor = 115200 / 115200 = 1
 * 
 * To get 57600 baud:
 *   Divisor = 115200 / 57600 = 2
 * 
 * To get 9600 baud:
 *   Divisor = 115200 / 9600 = 12
 * 
 * DIVISOR LATCH:
 * 
 * The divisor is a 16-bit value split into two 8-bit registers:
 *   - Divisor Latch Low (DLL) at COM1+0 (when DLAB=1)
 *   - Divisor Latch High (DLH) at COM1+1 (when DLAB=1)
 * 
 * To set divisor:
 *   1. Set DLAB=1 (bit 7 of LCR)
 *   2. Write low byte to COM1+0
 *   3. Write high byte to COM1+1
 *   4. Clear DLAB=0 (back to normal mode)
 * 
 * Example for 115200 baud (divisor = 1 = 0x0001):
 *   DLL = 0x01
 *   DLH = 0x00
 * 
 * Example for 9600 baud (divisor = 12 = 0x000C):
 *   DLL = 0x0C
 *   DLH = 0x00
 * 
 * STANDARD DIVISORS:
 * 
 * Baud Rate  Divisor (decimal)  Divisor (hex)  DLH  DLL
 * ---------  -----------------  -------------  ---  ---
 * 115200     1                  0x0001         0x00 0x01
 * 57600      2                  0x0002         0x00 0x02
 * 38400      3                  0x0003         0x00 0x03
 * 19200      6                  0x0006         0x00 0x06
 * 9600       12                 0x000C         0x00 0x0C
 * 4800       24                 0x0018         0x00 0x18
 * 2400       48                 0x0030         0x00 0x30
 * 1200       96                 0x0060         0x00 0x60
 * 
 * WHY 115200?
 * 
 * Historical reasons:
 *   - Original UART base clock was 1.8432 MHz
 *   - 1,843,200 Hz / 16 = 115,200 Hz
 *   - 115200 became the "standard fast" rate
 *   - Modern UARTs still use this for compatibility
 * 
 * Why not higher?
 *   - Cable length limits (RS-232 spec is 50 feet at 19200)
 *   - Noise increases at higher frequencies
 *   - Not all devices support >115200
 *   - 115200 is fast enough for debug output
 *
 *=============================================================================
 * SECTION 7: INITIALIZATION SEQUENCE
 *=============================================================================
 * 
 * UART initialization must be done in a specific order to work correctly.
 * Our serial_init() function performs these steps:
 * 
 * STEP 1: DISABLE INTERRUPTS
 *   Write 0x00 to IER (COM1+1, when DLAB=0)
 *   
 *   Why first?
 *     - Prevents spurious interrupts during setup
 *     - Ensures clean state before configuration
 *     - TinyOS uses polling, not interrupts
 * 
 * STEP 2: ENABLE DLAB (Access Divisor Latch)
 *   Write 0x80 to LCR (COM1+3)
 *   
 *   Why?
 *     - Sets DLAB=1 (bit 7)
 *     - Now COM1+0 and COM1+1 access divisor instead of data/IER
 *     - Required to set baud rate
 * 
 * STEP 3: SET DIVISOR LOW BYTE
 *   Write 0x01 to DLL (COM1+0, when DLAB=1)
 *   
 *   This is the low byte of divisor = 1 (for 115200 baud)
 * 
 * STEP 4: SET DIVISOR HIGH BYTE
 *   Write 0x00 to DLH (COM1+1, when DLAB=1)
 *   
 *   This is the high byte of divisor = 1 (for 115200 baud)
 *   Together: divisor = 0x0001 = 1
 * 
 * STEP 5: CONFIGURE LINE (8N1, Disable DLAB)
 *   Write 0x03 to LCR (COM1+3)
 *   
 *   This sets:
 *     - Bits 0-1 = 11 (8 data bits)
 *     - Bit 2 = 0 (1 stop bit)
 *     - Bits 3-5 = 000 (no parity)
 *     - Bit 7 = 0 (DLAB=0, back to normal mode)
 *   
 *   Result: 8N1 format (8 data, no parity, 1 stop)
 * 
 * STEP 6: ENABLE FIFO, CLEAR BUFFERS
 *   Write 0xC7 to FCR (COM1+2)
 *   
 *   This sets:
 *     - Bit 0 = 1 (enable FIFO)
 *     - Bit 1 = 1 (clear receive FIFO)
 *     - Bit 2 = 1 (clear transmit FIFO)
 *     - Bits 6-7 = 11 (14-byte interrupt trigger)
 *   
 *   Result: FIFO enabled and cleared, ready for use
 * 
 * STEP 7: CONFIGURE MODEM CONTROL
 *   Write 0x0B to MCR (COM1+4)
 *   
 *   This sets:
 *     - Bit 0 = 1 (DTR asserted)
 *     - Bit 1 = 1 (RTS asserted)
 *     - Bit 3 = 1 (OUT2 enabled, for interrupts)
 *   
 *   Result: Handshaking lines asserted, ready to transmit
 * 
 * AFTER INITIALIZATION:
 *   - UART is ready to transmit
 *   - Baud rate set to 115200
 *   - Format set to 8N1
 *   - FIFO enabled
 *   - Can call serial_putc() to send bytes
 * 
 * WHAT IF INITIALIZATION IS WRONG?
 * 
 * Common mistakes:
 *   ❌ Forget to set DLAB before divisor → Baud rate wrong
 *   ❌ Forget to clear DLAB after divisor → Can't send data
 *   ❌ Wrong divisor value → Garbled output
 *   ❌ Wrong LCR value → Garbled output (wrong format)
 *   ❌ Forget to enable FIFO → Slower performance
 * 
 * Symptoms:
 *   - Garbled characters on terminal
 *   - No output at all
 *   - Output too fast or too slow
 *   - Missing characters
 *
 *=============================================================================
 * SECTION 8: TRANSMISSION PROCESS
 *=============================================================================
 * 
 * To transmit a byte over serial:
 * 
 * STEP 1: WAIT FOR TRANSMITTER READY
 *   Poll LSR (COM1+5) bit 5 until it's 1
 *   
 *   Why wait?
 *     - UART can only hold one byte in transmit buffer
 *     - If we write while busy, byte is lost
 *     - Must wait for previous byte to finish transmitting
 *   
 *   How long?
 *     - At 115200 baud: ~86 microseconds per byte
 *     - FIFO can buffer 16 bytes, so usually no wait
 * 
 * STEP 2: WRITE BYTE TO DATA REGISTER
 *   Write byte to COM1+0 (when DLAB=0)
 *   
 *   What happens:
 *     - Byte enters transmit FIFO (or holding register)
 *     - UART starts transmission automatically
 *     - Byte is framed (start bit, data bits, stop bit)
 *     - Bits are sent at baud rate (8.68 µs per bit)
 * 
 * STEP 3: UART TRANSMITS BYTE
 *   Hardware automatically:
 *     1. Sends START bit (0)
 *     2. Sends 8 data bits (LSB first)
 *     3. Sends STOP bit (1)
 *     4. Sets LSR bit 5 (ready for next byte)
 * 
 * EXAMPLE: Sending 'A' (0x41 = 01000001 binary)
 * 
 * Bit stream on wire (LSB first):
 *   START  D0 D1 D2 D3 D4 D5 D6 D7  STOP
 *     0     1  0  0  0  0  0  1  0    1
 *   
 *   (Note: Data bits are reversed because LSB first!)
 * 
 * TIMING (at 115200 baud):
 *   - 1 bit time = 8.68 µs
 *   - START bit: 8.68 µs
 *   - 8 data bits: 69.44 µs
 *   - STOP bit: 8.68 µs
 *   - Total: 86.8 µs per byte
 *   - Throughput: 11,520 bytes/second
 * 
 * POLLING VS INTERRUPTS:
 * 
 * Polling (TinyOS method):
 *   while (!tx_ready()) {}  // Wait
 *   outb(COM1, byte);       // Send
 *   
 *   Pros:
 *     ✅ Simple (no interrupt handler)
 *     ✅ No race conditions
 *     ✅ Predictable timing
 *   
 *   Cons:
 *     ❌ Wastes CPU time waiting
 *     ❌ Can't do other work while transmitting
 * 
 * Interrupt-driven (not implemented in TinyOS):
 *   outb(COM1, byte);       // Send
 *   // IRQ fires when done, handler sends next byte
 *   
 *   Pros:
 *     ✅ CPU can do other work
 *     ✅ More efficient
 *   
 *   Cons:
 *     ❌ More complex (need interrupt handler)
 *     ❌ Race conditions (need locking)
 *     ❌ More overhead (interrupt latency)
 * 
 * For TinyOS:
 *   - Polling is adequate (debug output is infrequent)
 *   - Simplicity > efficiency (learning OS)
 *   - Production kernels use interrupt-driven
 *
 *=============================================================================
 * SECTION 9: LINE ENDINGS (CR/LF)
 *=============================================================================
 * 
 * LINE ENDINGS are a historical mess in computing!
 * 
 * THREE STANDARDS:
 * 
 * Unix/Linux: LF only (\n = 0x0A)
 *   Example: "Hello\nWorld"
 *   
 * Windows: CR+LF (\r\n = 0x0D 0x0A)
 *   Example: "Hello\r\nWorld"
 *   
 * Old Mac: CR only (\r = 0x0D)
 *   Example: "Hello\rWorld"
 *   (Obsolete, modern macOS uses Unix style)
 * 
 * TELETYPE HISTORY:
 * 
 * These codes come from mechanical teletypes:
 *   - CR (Carriage Return): Move print head to left edge
 *   - LF (Line Feed): Advance paper one line
 * 
 * On a physical teletype:
 *   - CR alone: Overwrite current line
 *   - LF alone: Print on same column, next line
 *   - CR+LF together: Move to start of next line
 * 
 * TERMINAL BEHAVIOR:
 * 
 * Most terminal emulators (PuTTY, minicom, QEMU console):
 *   - Treat LF as "move to next line" (implicit CR)
 *   - Or can be configured to require CR+LF
 * 
 * If terminal requires CR+LF but we only send LF:
 *   Line 1: Hello
 *           Line 2: World
 *                   Line 3: !
 *   
 *   (Output appears diagonal because CR is missing!)
 * 
 * TINYOS SOLUTION:
 * 
 * Our serial_putc() automatically converts LF to CR+LF:
 *   
 *   if (c == '\n') {
 *       serial_putc('\r');  // Send CR first
 *   }
 *   // Then send original character
 * 
 * This ensures:
 *   - Code uses Unix-style '\n'
 *   - Serial output works on any terminal
 *   - No diagonal output!
 * 
 * Why do this conversion?
 *   ✅ Code is cleaner (use '\n' like normal C)
 *   ✅ Works with any terminal configuration
 *   ✅ Matches VGA behavior (VGA also interprets '\n' as newline)
 * 
 * RECURSION NOTE:
 * 
 * The conversion is NOT infinite recursion:
 *   
 *   serial_putc('\n'):
 *     if (c == '\n') {
 *       serial_putc('\r');  // Sends CR (0x0D)
 *     }
 *     // Now send LF (0x0A)
 *   
 *   The recursive call sends '\r', which doesn't match '\n',
 *   so it doesn't recurse again.
 * 
 * ALTERNATIVE APPROACHES:
 * 
 * Could convert at higher level (serial_puts):
 *   - Less code duplication
 *   - But serial_putc('\n') would be wrong
 *   - Our approach is more consistent
 * 
 * Could leave it to caller:
 *   - Call serial_puts("Hello\r\n")
 *   - More control but more error-prone
 *   - Easy to forget \r
 *
 *=============================================================================
 * SECTION 10: DESIGN DECISIONS AND TRADE-OFFS
 *=============================================================================
 * 
 * DECISION 1: POLLING VS INTERRUPTS
 * 
 * TinyOS uses polling (wait for ready flag).
 * 
 * Why polling?
 *   ✅ Simple (no IRQ handler needed)
 *   ✅ No race conditions
 *   ✅ Predictable behavior
 *   ✅ Adequate for debug output
 * 
 * Why not interrupts?
 *   ❌ More complex (need IRQ3/4 handler)
 *   ❌ Need buffer management
 *   ❌ Race conditions (need locking)
 *   ❌ Overkill for debug output
 * 
 * When interrupts make sense:
 *   - High-throughput applications
 *   - Receive data (must not lose bytes)
 *   - Background transmission
 * 
 * 
 * DECISION 2: TRANSMIT-ONLY (NO RECEIVE)
 * 
 * TinyOS only implements transmit, not receive.
 * 
 * Why?
 *   - Debug output doesn't need input
 *   - Simpler code (no receive buffer)
 *   - No need to poll/handle incoming data
 * 
 * To add receive:
 *   - Check LSR bit 0 (data ready)
 *   - Read from COM1+0
 *   - Store in buffer
 *   - Process commands
 * 
 * Use cases for receive:
 *   - Interactive debugging shell
 *   - Remote control
 *   - File transfer (XMODEM, etc.)
 * 
 * 
 * DECISION 3: 115200 BAUD
 * 
 * TinyOS uses 115200 baud (fastest standard rate).
 * 
 * Why 115200?
 *   ✅ Fast (11.5 KB/sec)
 *   ✅ Widely supported
 *   ✅ Reliable
 * 
 * Why not faster (230400, 460800)?
 *   ❌ Not all systems support it
 *   ❌ Less reliable (more errors)
 *   ❌ Not needed for debug output
 * 
 * Why not slower (9600)?
 *   ❌ Too slow for modern use
 *   ❌ Noticeable delay when printing
 * 
 * 
 * DECISION 4: 8N1 FORMAT
 * 
 * TinyOS uses 8N1 (8 data bits, no parity, 1 stop bit).
 * 
 * This is the universal standard:
 *   - 8 bits = full ASCII byte
 *   - No parity = faster, no overhead
 *   - 1 stop bit = standard
 * 
 * Alternatives:
 *   - 7E1 (7 data, even parity, 1 stop): Old, pre-8-bit-byte era
 *   - 8E1 (8 data, even parity, 1 stop): Error detection
 *   - 8N2 (8 data, no parity, 2 stop): Extra stop time (unnecessary)
 * 
 * 
 * DECISION 5: INLINE ASSEMBLY FOR INB/OUTB
 * 
 * TinyOS uses inline assembly for I/O operations.
 * 
 * Why inline assembly?
 *   ✅ Direct hardware access
 *   ✅ No function call overhead
 *   ✅ Compiler can optimize
 *   ✅ Type-safe (constraints)
 * 
 * Could use #define macros:
 *   #define outb(p,v) __asm__("outb %0,%1"::"a"(v),"Nd"(p))
 *   
 *   But static inline functions are better:
 *   ✅ Type checking
 *   ✅ Debugger-friendly
 *   ✅ Can set breakpoints
 * 
 * 
 * DECISION 6: NO FLOW CONTROL
 * 
 * TinyOS doesn't implement hardware flow control (RTS/CTS).
 * 
 * Why not?
 *   - Not needed for transmit-only
 *   - No receive buffer to overflow
 *   - Terminal can keep up with 115200 baud
 * 
 * When flow control matters:
 *   - Bidirectional communication
 *   - Slow receiver (printer, modem)
 *   - Preventing buffer overflow
 * 
 * 
 * DECISION 7: AUTOMATIC CR/LF CONVERSION
 * 
 * TinyOS converts '\n' to '\r\n' automatically.
 * 
 * Why?
 *   ✅ Code uses Unix-style '\n' (clean)
 *   ✅ Works with any terminal
 *   ✅ Matches VGA behavior
 * 
 * Cost:
 *   - Extra function call for '\n'
 *   - Two bytes sent instead of one
 *   - Negligible performance impact
 *
 *=============================================================================
 * SECTION 11: COMMON PITFALLS AND SOLUTIONS
 *=============================================================================
 * 
 * PITFALL 1: FORGETTING TO INITIALIZE
 * 
 * Problem:
 *   Call serial_putc() without calling serial_init() first.
 *   Result: No output, or garbled output.
 * 
 * Why?
 *   - UART might be in unknown state
 *   - Baud rate might be wrong
 *   - FIFO might be disabled
 * 
 * Solution:
 *   Always call serial_init() before any output.
 *   Do this early in kernel_main().
 * 
 * 
 * PITFALL 2: WRONG BAUD RATE
 * 
 * Problem:
 *   Terminal configured for 9600, kernel uses 115200.
 *   Result: Garbage characters.
 * 
 * Why?
 *   - Receiver samples at wrong times
 *   - Bits interpreted incorrectly
 * 
 * Solution:
 *   Match baud rates on both sides.
 *   115200 is standard for modern systems.
 * 
 * Symptoms of baud mismatch:
 *   - Garbage: â–'â–'â–'â–'â–'â–'â–'â–'
 *   - Some characters correct, some wrong
 *   - Consistent pattern of errors
 * 
 * 
 * PITFALL 3: NOT CHECKING TRANSMITTER READY
 * 
 * Problem:
 *   Write to COM1+0 without checking LSR bit 5.
 *   Result: Lost characters.
 * 
 * Why?
 *   - UART can only buffer one byte
 *   - If busy, new byte overwrites old byte
 *   - Previous byte is lost
 * 
 * Solution:
 *   Always poll tx_ready() before writing.
 *   Our code does this correctly.
 * 
 * 
 * PITFALL 4: FORGETTING DLAB
 * 
 * Problem:
 *   Try to set baud rate without enabling DLAB.
 *   Result: Writing to wrong registers.
 * 
 * Sequence:
 *   outb(COM1+3, 0x03);  // Oops! Should be 0x83 to set DLAB
 *   outb(COM1+0, 0x01);  // This writes to DATA, not divisor!
 * 
 * Solution:
 *   1. Set DLAB=1 (LCR bit 7)
 *   2. Write divisor
 *   3. Clear DLAB=0
 * 
 * 
 * PITFALL 5: WRONG LCR VALUE
 * 
 * Problem:
 *   Use wrong LCR value, get wrong format.
 *   
 * Example:
 *   outb(COM1+3, 0x00);  // 5N1 instead of 8N1
 *   
 *   Result: Only 5 bits transmitted per byte.
 *   Output is garbled (missing bits).
 * 
 * Solution:
 *   Use 0x03 for 8N1 (standard format).
 *   Bits 0-1 = 11 (8 bits)
 *   Bit 2 = 0 (1 stop bit)
 *   Bits 3-5 = 000 (no parity)
 * 
 * 
 * PITFALL 6: INFINITE LOOP IN tx_ready()
 * 
 * Problem:
 *   UART is not responding, tx_ready() never returns 1.
 *   Result: Hang forever.
 * 
 * Why?
 *   - UART not initialized properly
 *   - Hardware failure
 *   - Wrong I/O address
 * 
 * Solution:
 *   Could add timeout:
 *   
 *   int timeout = 100000;
 *   while (!tx_ready() && timeout--) {}
 *   if (!timeout) return;  // Give up
 * 
 *   TinyOS doesn't do this (assumes UART works).
 * 
 * 
 * PITFALL 7: USING PRINTF FOR SERIAL
 * 
 * Problem:
 *   Try to use printf() to output to serial.
 *   Result: Doesn't work (no printf in kernel!).
 * 
 * Why?
 *   - printf() is part of libc
 *   - Kernel is freestanding (no libc)
 *   - Must implement our own formatted output
 * 
 * Solution:
 *   Use kprintf() (implemented in kprintf.c).
 *   kprintf() outputs to both VGA and serial.
 * 
 * 
 * PITFALL 8: DIAGONAL OUTPUT
 * 
 * Problem:
 *   Output appears diagonal on terminal:
 *   
 *   H
 *    e
 *     l
 *      l
 *       o
 * 
 * Why?
 *   - Sent LF only, no CR
 *   - Terminal doesn't do automatic CR
 * 
 * Solution:
 *   Send CR+LF for newline (or just LF if terminal auto-CR).
 *   Our serial_putc() converts '\n' to '\r\n' automatically.
 *
 *=============================================================================
 * SECTION 12: INTEGRATION WITH THE KERNEL
 *=============================================================================
 * 
 * WHERE SERIAL IS USED IN TINYOS:
 * 
 * 1. EARLY INITIALIZATION (kernel.c)
 *    First thing in kernel_main():
 *    serial_init();
 *    
 *    Why first?
 *      - Provides debug output immediately
 *      - Works even if VGA fails
 *      - Can debug all subsequent initialization
 * 
 * 2. KPRINTF OUTPUT (kprintf.c)
 *    kprintf() calls serial_puts() for every string.
 *    This mirrors output to serial port.
 *    
 *    Usage:
 *      kprintf("Kernel initializing...\n");
 *      // Appears on both VGA and serial
 * 
 * 3. PANIC MESSAGES (util.c)
 *    panic() calls serial_puts() directly:
 *    serial_puts("*** KERNEL PANIC ***\n");
 *    
 *    Why direct?
 *      - More reliable (fewer dependencies)
 *      - Works even if kprintf is broken
 *      - Critical error path must be simple
 * 
 * 4. DEBUG MACROS (future)
 *    Could add: #define DEBUG_PRINT(...) serial_printf(__VA_ARGS__)
 *    For conditional debug output.
 * 
 * INITIALIZATION ORDER:
 * 
 * 1. serial_init()      ← First! (debug output)
 * 2. console_clear()    (VGA setup)
 * 3. CLI                (disable interrupts)
 * 4. pic_mask_all()     (block IRQs)
 * 5. kprintf(...)       ← Can use after serial_init()
 * 6. ... rest of kernel initialization
 * 
 * CALL FREQUENCY:
 * 
 * serial_init():
 *   - Called once at boot
 *   - Never called again
 * 
 * serial_putc():
 *   - Called for every character
 *   - Hundreds/thousands of times
 *   - Not performance-critical (debug output)
 * 
 * serial_puts():
 *   - Called for every string
 *   - Convenient wrapper around serial_putc()
 * 
 * DEPENDENCY GRAPH:
 * 
 *   serial.c (THIS FILE)
 *     ↑
 *     └── kernel.h (types, inline functions)
 *     ↓
 *   Used by:
 *     ├── kernel.c (early init, boot messages)
 *     ├── kprintf.c (mirror output to serial)
 *     ├── util.c (panic messages)
 *     └── any code that wants debug output
 * 
 * QEMU INTEGRATION:
 * 
 * Run with serial output:
 *   qemu-system-i386 -kernel kernel.elf -serial stdio
 *   
 *   Serial output appears in terminal.
 * 
 * Log to file:
 *   qemu-system-i386 -kernel kernel.elf -serial file:log.txt
 *   
 *   All serial output saved to log.txt.
 * 
 * Both VGA and serial:
 *   qemu-system-i386 -kernel kernel.elf -serial stdio -display sdl
 *   
 *   VGA in window, serial in terminal.
 * 
 * REAL HARDWARE:
 * 
 * Connect serial cable:
 *   PC running TinyOS → Serial cable → Another PC
 * 
 * On other PC, run terminal:
 *   - Windows: PuTTY, TeraTerm
 *   - Linux: minicom, screen
 *   - macOS: screen, cu
 * 
 * Configure terminal:
 *   - Port: COM1 (or /dev/ttyS0 on Linux)
 *   - Baud: 115200
 *   - Data: 8 bits
 *   - Parity: None
 *   - Stop: 1 bit
 *   - Flow control: None
 * 
 * FUTURE ENHANCEMENTS:
 * 
 * This file could be extended with:
 * 
 * 1. serial_getc() - Receive characters
 *    uint8_t serial_getc(void);
 * 
 * 2. serial_available() - Check if data ready
 *    int serial_available(void);
 * 
 * 3. serial_printf() - Formatted output
 *    void serial_printf(const char* fmt, ...);
 * 
 * 4. Multiple ports (COM2, COM3, COM4)
 *    void serial_init_port(uint16_t port);
 * 
 * 5. Interrupt-driven transmit/receive
 *    void serial_irq_handler(void);
 * 
 * 6. Buffered I/O (ring buffer)
 *    Reduce polling overhead
 * 
 * 7. Binary transfer (XMODEM, YMODEM)
 *    File transfer protocol
 * 
 * 8. Flow control (RTS/CTS, XON/XOFF)
 *    Prevent buffer overflow
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "kernel.h"
#include "serial.h"

/*=============================================================================
 * INLINE ASSEMBLY HELPERS
 *=============================================================================
 * 
 * These functions provide type-safe, optimized access to I/O ports.
 * They use GCC inline assembly syntax.
 */

/**
 * outb - Write a byte to an I/O port
 * 
 * PARAMETERS:
 *   p - I/O port address (0x0000-0xFFFF)
 *   v - Byte value to write
 * 
 * ASSEMBLY BREAKDOWN:
 *   outb %0, %1
 *     - Instruction: OUTB (output byte to port)
 *     - %0: Value (from 'v', must be in AL register)
 *     - %1: Port (from 'p', can be immediate or DX register)
 * 
 * CONSTRAINTS:
 *   "a"(v):  Value must be in AL/AX/EAX register
 *   "Nd"(p): Port can be immediate (0-255) or DX register (256-65535)
 * 
 * VOLATILE:
 *   Prevents compiler from:
 *   - Removing the instruction (has side effects)
 *   - Reordering with other I/O operations
 * 
 * USAGE:
 *   outb(0x3F8, 'A');  // Send 'A' to COM1
 */
static inline void outb(uint16_t p, uint8_t v) {
    __asm__ volatile("outb %0,%1" : : "a"(v), "Nd"(p));
}

/**
 * inb - Read a byte from an I/O port
 * 
 * PARAMETERS:
 *   p - I/O port address (0x0000-0xFFFF)
 * 
 * RETURN VALUE:
 *   Byte read from port
 * 
 * ASSEMBLY BREAKDOWN:
 *   inb %1, %0
 *     - Instruction: INB (input byte from port)
 *     - %1: Port (from 'p')
 *     - %0: Result (stored in 'r', must be in AL register)
 * 
 * CONSTRAINTS:
 *   "=a"(r): Result goes to AL/AX/EAX register
 *   "Nd"(p): Port can be immediate or DX register
 * 
 * USAGE:
 *   uint8_t status = inb(0x3FD);  // Read LSR from COM1
 */
static inline uint8_t inb(uint16_t p) {
    uint8_t r;
    __asm__ volatile("inb %1,%0" : "=a"(r) : "Nd"(p));
    return r;
}

/*=============================================================================
 * CONSTANTS
 *=============================================================================
 */

/**
 * COM1 - I/O base address for COM1 serial port
 * 
 * Standard PC I/O addresses:
 *   COM1: 0x3F8 (IRQ4) ← We use this
 *   COM2: 0x2F8 (IRQ3)
 *   COM3: 0x3E8 (IRQ4, shares with COM1)
 *   COM4: 0x2E8 (IRQ3, shares with COM2)
 * 
 * Register offsets from base:
 *   +0: Data register (or divisor latch low)
 *   +1: Interrupt Enable Register (or divisor latch high)
 *   +2: Interrupt ID / FIFO Control Register
 *   +3: Line Control Register
 *   +4: Modem Control Register
 *   +5: Line Status Register
 *   +6: Modem Status Register
 *   +7: Scratch Register
 */
#define COM1 0x3F8

/*=============================================================================
 * FUNCTION: serial_init
 *=============================================================================
 * 
 * PURPOSE:
 *   Initialize the COM1 serial port for 115200 baud, 8N1 format.
 *   Must be called before any serial output functions.
 * 
 * PARAMETERS:
 *   None
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * WHAT IT DOES:
 *   1. Disable interrupts
 *   2. Set baud rate to 115200 (divisor = 1)
 *   3. Configure 8N1 format (8 data, no parity, 1 stop)
 *   4. Enable and clear FIFO buffers
 *   5. Assert modem control lines (DTR, RTS)
 * 
 * CONFIGURATION:
 *   Baud rate: 115200 bps
 *   Data bits: 8
 *   Parity:    None
 *   Stop bits: 1
 *   Format:    8N1 (universal standard)
 * 
 * WHEN TO CALL:
 *   Call this FIRST in kernel initialization, before any output.
 *   Example: First line of kernel_main().
 * 
 * SAFETY:
 *   - Can be called multiple times (re-initializes)
 *   - Safe to call even if UART not present (no side effects)
 *   - No error checking (assumes UART exists and works)
 * 
 * THREAD SAFETY:
 *   Not thread-safe (modifies global hardware state).
 *   Should only be called during single-threaded init.
 */
void serial_init(void) {
    /*
     * STEP 1: DISABLE ALL INTERRUPTS
     * 
     * Write 0x00 to Interrupt Enable Register (COM1+1).
     * This disables all UART interrupts.
     * 
     * Why?
     *   - We use polling (not interrupts)
     *   - Prevents spurious IRQs during initialization
     *   - Clean starting state
     * 
     * IER bits (all disabled):
     *   Bit 0: Receive data available
     *   Bit 1: Transmitter empty
     *   Bit 2: Line status change
     *   Bit 3: Modem status change
     * 
     * Note: Must write to IER before enabling DLAB,
     * otherwise we'd be writing to divisor latch high byte.
     */
    outb(COM1 + 1, 0x00);
    
    /*
     * STEP 2: ENABLE DLAB (Divisor Latch Access Bit)
     * 
     * Write 0x80 to Line Control Register (COM1+3).
     * This sets bit 7 (DLAB) to 1.
     * 
     * When DLAB=1:
     *   - COM1+0 becomes Divisor Latch Low
     *   - COM1+1 becomes Divisor Latch High
     * 
     * LCR value: 0x80 (10000000 binary)
     *   Bit 7 (DLAB) = 1: Enable divisor latch
     *   Bits 0-6 = 0: Other settings will be configured later
     * 
     * Why?
     *   Required to set baud rate (next two steps).
     */
    outb(COM1 + 3, 0x80);
    
    /*
     * STEP 3: SET BAUD RATE DIVISOR (LOW BYTE)
     * 
     * Write 0x01 to Divisor Latch Low (COM1+0, when DLAB=1).
     * 
     * Baud rate calculation:
     *   Baud = 115200 / divisor
     *   For 115200 baud: divisor = 1
     * 
     * Divisor = 1 = 0x0001
     *   Low byte (DLL) = 0x01
     *   High byte (DLH) = 0x00
     * 
     * Other common divisors:
     *   57600 baud: divisor = 2
     *   38400 baud: divisor = 3
     *   19200 baud: divisor = 6
     *   9600 baud:  divisor = 12
     */
    outb(COM1 + 0, 0x01);
    
    /*
     * STEP 4: SET BAUD RATE DIVISOR (HIGH BYTE)
     * 
     * Write 0x00 to Divisor Latch High (COM1+1, when DLAB=1).
     * 
     * This is the upper 8 bits of the 16-bit divisor.
     * For divisor = 1 (0x0001), high byte is 0x00.
     * 
     * Together with previous step:
     *   DLL = 0x01, DLH = 0x00 → divisor = 0x0001 = 1
     *   Baud rate = 115200 / 1 = 115200 baud
     */
    outb(COM1 + 1, 0x00);
    
    /*
     * STEP 5: CONFIGURE LINE (8N1) AND DISABLE DLAB
     * 
     * Write 0x03 to Line Control Register (COM1+3).
     * 
     * LCR value: 0x03 (00000011 binary)
     *   Bits 0-1 = 11: 8 data bits
     *   Bit 2 = 0:     1 stop bit
     *   Bits 3-5 = 000: No parity
     *   Bit 6 = 0:     Normal operation (no break)
     *   Bit 7 = 0:     DLAB=0 (disable divisor latch access)
     * 
     * Result: 8N1 format (8 data bits, no parity, 1 stop bit)
     * 
     * This is the standard format used by virtually all systems.
     * 
     * IMPORTANT: Setting DLAB=0 returns COM1+0 and COM1+1 to
     * their normal functions (data register and IER).
     */
    outb(COM1 + 3, 0x03);
    
    /*
     * STEP 6: ENABLE FIFO AND CLEAR BUFFERS
     * 
     * Write 0xC7 to FIFO Control Register (COM1+2).
     * 
     * FCR value: 0xC7 (11000111 binary)
     *   Bit 0 = 1:     Enable FIFO
     *   Bit 1 = 1:     Clear receive FIFO
     *   Bit 2 = 1:     Clear transmit FIFO
     *   Bit 3 = 0:     DMA mode disabled (not used)
     *   Bits 4-5 = 00: Reserved
     *   Bits 6-7 = 11: Interrupt trigger level: 14 bytes
     * 
     * Effect:
     *   - Enables 16-byte FIFO buffers
     *   - Clears any garbage data in FIFOs
     *   - Sets interrupt trigger to 14 bytes (not used, we poll)
     * 
     * Why FIFO?
     *   - Reduces interrupt overhead (if we were using interrupts)
     *   - Better performance (can buffer multiple bytes)
     *   - Standard feature on all modern UARTs
     * 
     * The 16550 UART supports 16-byte FIFO:
     *   - Transmit FIFO: Buffers up to 16 bytes to send
     *   - Receive FIFO: Buffers up to 16 bytes received
     */
    outb(COM1 + 2, 0xC7);
    
    /*
     * STEP 7: CONFIGURE MODEM CONTROL
     * 
     * Write 0x0B to Modem Control Register (COM1+4).
     * 
     * MCR value: 0x0B (00001011 binary)
     *   Bit 0 = 1: DTR (Data Terminal Ready) asserted
     *   Bit 1 = 1: RTS (Request To Send) asserted
     *   Bit 2 = 0: OUT1 (not used)
     *   Bit 3 = 1: OUT2 (on PC, enables interrupts)
     *   Bit 4 = 0: Loopback mode disabled (normal operation)
     *   Bits 5-7: Reserved
     * 
     * Modem control lines:
     *   DTR: Tells modem/device we're ready and powered on
     *   RTS: Tells modem/device we're ready to receive data
     *   
     * These are handshaking signals used in RS-232:
     *   - DTR/DSR pair: Device ready status
     *   - RTS/CTS pair: Flow control (ready to send/receive)
     * 
     * Why assert DTR and RTS?
     *   - Some devices won't transmit unless these are set
     *   - Standard practice to assert both
     *   - Indicates we're ready for communication
     * 
     * Why set OUT2?
     *   - On PC hardware, OUT2 gates the interrupt line
     *   - Must be 1 for IRQs to fire (though we don't use IRQs)
     *   - Harmless to set even if not using interrupts
     */
    outb(COM1 + 4, 0x0B);
    
    /*
     * INITIALIZATION COMPLETE!
     * 
     * The serial port is now ready to transmit.
     * Configuration summary:
     *   - Port: COM1 (0x3F8)
     *   - Baud: 115200
     *   - Format: 8N1
     *   - FIFO: Enabled (16 bytes)
     *   - Interrupts: Disabled (polling mode)
     *   - Modem lines: DTR and RTS asserted
     * 
     * Can now call serial_putc() and serial_puts() to send data.
     */
}

/*=============================================================================
 * FUNCTION: tx_ready
 *=============================================================================
 * 
 * PURPOSE:
 *   Check if the UART transmitter is ready to accept a new byte.
 * 
 * PARAMETERS:
 *   None
 * 
 * RETURN VALUE:
 *   Non-zero if transmitter is ready
 *   Zero if transmitter is busy
 * 
 * HOW IT WORKS:
 *   Reads Line Status Register (LSR) at COM1+5.
 *   Checks bit 5 (Transmitter Holding Register Empty).
 * 
 * LSR BIT 5:
 *   1 = Transmit buffer empty (safe to write next byte)
 *   0 = Transmit buffer full (wait before writing)
 * 
 * TIMING:
 *   At 115200 baud, one byte takes ~86 microseconds.
 *   With 16-byte FIFO, can usually write immediately.
 * 
 * USAGE:
 *   while (!tx_ready()) {}  // Wait until ready
 *   outb(COM1, byte);       // Send byte
 * 
 * THREAD SAFETY:
 *   Thread-safe (read-only operation, no side effects).
 */
static int tx_ready(void) {
    /*
     * Read Line Status Register (COM1+5).
     * 
     * LSR bits:
     *   Bit 0: Data ready (receive buffer has data)
     *   Bit 1: Overrun error
     *   Bit 2: Parity error
     *   Bit 3: Framing error
     *   Bit 4: Break interrupt
     *   Bit 5: Transmitter holding register empty ← THIS ONE!
     *   Bit 6: Transmitter empty (holding and shift registers)
     *   Bit 7: FIFO error
     * 
     * We mask with 0x20 (00100000 binary) to isolate bit 5.
     * 
     * Result:
     *   Non-zero if bit 5 is set (transmitter ready)
     *   Zero if bit 5 is clear (transmitter busy)
     * 
     * Example:
     *   LSR = 0x60 (01100000) → 0x60 & 0x20 = 0x20 (ready!)
     *   LSR = 0x40 (01000000) → 0x40 & 0x20 = 0x00 (busy)
     */
    return inb(COM1 + 5) & 0x20;
}

/*=============================================================================
 * FUNCTION: serial_putc
 *=============================================================================
 * 
 * PURPOSE:
 *   Transmit a single character over the serial port.
 *   Automatically converts Unix-style newlines (LF) to CR+LF.
 * 
 * PARAMETERS:
 *   c - Character to transmit (ASCII)
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * BEHAVIOR:
 *   1. If c is '\n' (LF), recursively send '\r' (CR) first
 *   2. Wait for transmitter to be ready (poll LSR bit 5)
 *   3. Write character to data register (COM1+0)
 *   4. UART automatically frames and transmits the byte
 * 
 * LINE ENDING CONVERSION:
 *   Input:  '\n' (LF only)
 *   Output: '\r\n' (CR+LF)
 *   
 *   This ensures proper newline display on all terminals.
 *   Some terminals require CR+LF, others accept LF alone.
 *   Our conversion works with both types.
 * 
 * RECURSION:
 *   When c == '\n':
 *     - Recursively call serial_putc('\r')  [sends CR]
 *     - Then continue to send '\n'  [sends LF]
 *   
 *   The recursive call sends '\r', which does NOT match '\n',
 *   so it doesn't recurse again. Not infinite recursion!
 * 
 * TIMING:
 *   At 115200 baud:
 *     - One character: ~86 microseconds
 *     - Newline (CR+LF): ~172 microseconds
 *   
 *   FIFO buffering reduces effective wait time.
 * 
 * POLLING:
 *   This function BLOCKS until transmitter is ready.
 *   For high-performance I/O, use interrupt-driven approach.
 *   For debug output, polling is simple and adequate.
 * 
 * THREAD SAFETY:
 *   NOT thread-safe if called concurrently (race on UART).
 *   TinyOS is single-threaded, so this is not a concern.
 * 
 * EXAMPLE USAGE:
 *   serial_putc('H');   // Send 'H'
 *   serial_putc('\n');  // Send CR+LF (newline)
 */
void serial_putc(char c) {
    /*
     * LINE ENDING CONVERSION
     * 
     * If character is newline (LF = 0x0A = '\n'):
     *   1. Recursively send carriage return (CR = 0x0D = '\r') first
     *   2. Then fall through to send LF
     * 
     * Result: '\n' becomes '\r\n' (CR+LF sequence)
     * 
     * Why CR+LF?
     *   - CR (Carriage Return): Moves cursor to left edge
     *   - LF (Line Feed): Moves cursor down one line
     *   - Together: Move to start of next line
     * 
     * Historical background:
     *   On mechanical teletypes, CR and LF were separate operations:
     *     - CR physically moved the print head left
     *     - LF physically advanced the paper
     *   Modern terminals emulate this behavior.
     * 
     * Why automatic conversion?
     *   - Code can use Unix-style '\n' (clean, standard)
     *   - Serial output works on any terminal configuration
     *   - Matches behavior of VGA console (also interprets '\n')
     */
    if (c == '\n') {
        serial_putc('\r');  /* Send CR before LF */
    }
    
    /*
     * WAIT FOR TRANSMITTER READY
     * 
     * Poll tx_ready() until it returns non-zero.
     * This checks LSR bit 5 (transmitter holding register empty).
     * 
     * Why wait?
     *   - UART can only buffer one byte in holding register
     *   - If we write while busy, byte is lost or corrupted
     *   - Must wait for previous byte to finish transmitting
     * 
     * How long to wait?
     *   - At 115200 baud: ~86 microseconds per byte
     *   - With FIFO (16 bytes): Usually no wait at all
     *   - In worst case: Wait for 16 bytes = 1.4 milliseconds
     * 
     * Infinite loop risk:
     *   If UART is not working, this loops forever.
     *   Could add timeout, but TinyOS assumes UART works.
     * 
     * Alternatives:
     *   - Interrupt-driven: IRQ fires when ready
     *   - DMA: Hardware copies buffer automatically
     *   - For debug output, polling is simplest
     */
    while (!tx_ready()) {}
    
    /*
     * TRANSMIT BYTE
     * 
     * Write character to data register (COM1+0).
     * 
     * What happens next (automatic, hardware-controlled):
     *   1. Byte enters transmit FIFO (or holding register if FIFO disabled)
     *   2. When shift register is empty, byte moves to shift register
     *   3. UART starts transmission:
     *      a. Send START bit (0)
     *      b. Send 8 data bits (LSB first)
     *      c. Send STOP bit (1)
     *   4. After transmission complete, LSR bit 5 is set (ready for next byte)
     * 
     * Bit timing (at 115200 baud):
     *   - 1 bit = 8.68 microseconds
     *   - START: 8.68 µs
     *   - 8 DATA: 69.44 µs
     *   - STOP: 8.68 µs
     *   - Total: 86.8 µs per byte
     * 
     * Cast to uint8_t:
     *   Ensures only lower 8 bits are used (char might be signed).
     *   Safe for all ASCII characters (0-127) and extended ASCII (128-255).
     */
    outb(COM1, (uint8_t)c);
}

/*=============================================================================
 * FUNCTION: serial_puts
 *=============================================================================
 * 
 * PURPOSE:
 *   Transmit a null-terminated string over the serial port.
 *   Convenience wrapper around serial_putc().
 * 
 * PARAMETERS:
 *   s - Pointer to null-terminated string
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * BEHAVIOR:
 *   Iterates through string, calling serial_putc() for each character.
 *   Stops when null terminator ('\0') is encountered.
 * 
 * PERFORMANCE:
 *   For string "Hello\n" (6 characters):
 *     - 5 regular characters: 5 × 86 µs = 430 µs
 *     - 1 newline (CR+LF): 2 × 86 µs = 172 µs
 *     - Total: ~602 µs (0.6 milliseconds)
 * 
 * NULL POINTER:
 *   If s is NULL, behavior is UNDEFINED (will crash).
 *   Caller must ensure valid pointer.
 *   Could add check: if (!s) return;
 * 
 * EMPTY STRING:
 *   If s points to "\0", loop doesn't execute (correct).
 *   No output, returns immediately.
 * 
 * THREAD SAFETY:
 *   NOT thread-safe (calls serial_putc, which is not thread-safe).
 * 
 * EXAMPLE USAGE:
 *   serial_puts("Hello, World!\n");
 *   serial_puts("Kernel initializing...\n");
 */
void serial_puts(const char* s) {
    /*
     * ITERATE THROUGH STRING
     * 
     * Loop structure:
     *   - while (*s): Continue while current character is not '\0'
     *   - serial_putc(*s++): Send current character, then advance pointer
     * 
     * Step-by-step for "Hi\n":
     *   1. s points to 'H', *s = 'H' (not '\0'), send 'H', s++
     *   2. s points to 'i', *s = 'i' (not '\0'), send 'i', s++
     *   3. s points to '\n', *s = '\n' (not '\0'), send '\r\n', s++
     *   4. s points to '\0', *s = '\0' (loop exits)
     * 
     * Why *s++ instead of s[i]?
     *   - More idiomatic C (pointer iteration)
     *   - Slightly more efficient (no index arithmetic)
     *   - Common pattern in string functions
     * 
     * Post-increment (s++):
     *   - Uses current value (*s) in expression
     *   - Then increments pointer (s = s + 1)
     *   - Next iteration uses next character
     * 
     * Alternative implementation:
     *   for (int i = 0; s[i] != '\0'; i++) {
     *       serial_putc(s[i]);
     *   }
     *   
     *   Same behavior, different style.
     */
    while (*s) {
        serial_putc(*s++);
    }
}

/*=============================================================================
 * END OF FILE: serial.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Implemented COM1 serial port driver
 *   ✅ Configured 115200 baud, 8N1 format
 *   ✅ Enabled FIFO for efficiency
 *   ✅ Automatic CR/LF conversion for newlines
 *   ✅ Polling-based transmission (simple, reliable)
 *   ✅ Comprehensive documentation for learning
 * 
 * WHAT HAPPENS NEXT:
 *   → serial_init() is called first in kernel_main()
 *   → serial_puts() is used by kprintf() for mirror output
 *   → serial_puts() is used by panic() for critical errors
 *   → Serial output appears in QEMU terminal or log file
 * 
 * KEY TAKEAWAYS:
 *   1. Serial communication is bit-by-bit over a wire
 *   2. UART handles framing (start/stop bits) automatically
 *   3. RS-232 uses ±12V signaling (for noise immunity)
 *   4. Baud rate set via divisor (115200 / divisor)
 *   5. 8N1 is universal format (8 data, no parity, 1 stop)
 *   6. FIFO buffers improve performance (16 bytes)
 *   7. Polling is simple; interrupts are more efficient
 *   8. CR+LF conversion ensures proper newlines on all terminals
 * 
 * LEARNING RESOURCES:
 *   - 16550 UART Datasheet: National Semiconductor
 *   - OSDev Wiki: https://wiki.osdev.org/Serial_Ports
 *   - RS-232 Standard: TIA-232-F specification
 *   - Linux serial driver: drivers/tty/serial/8250/8250_core.c
 * 
 * DEBUGGING TIPS:
 *   - No output? Check baud rate matches terminal (115200)
 *   - Garbled output? Verify 8N1 format in terminal settings
 *   - Diagonal output? Enable automatic CR/LF conversion
 *   - Slow output? 115200 baud = 11.5 KB/sec (expected)
 *   - Still broken? Try loopback test (MCR bit 4)
 * 
 * FUTURE ENHANCEMENTS:
 *   - Receive support (serial_getc, serial_available)
 *   - Interrupt-driven I/O (IRQ3/4 handlers)
 *   - Multiple ports (COM2, COM3, COM4)
 *   - Hardware flow control (RTS/CTS)
 *   - Software flow control (XON/XOFF)
 *   - Binary transfer protocols (XMODEM)
 *   - Error detection and recovery
 *   - Buffered I/O (ring buffers)
 * 
 * PERFORMANCE NOTES:
 *   Current implementation (polling) is SIMPLE, not FAST.
 *   
 *   Throughput:
 *     - Theoretical: 115200 bits/sec = 11,520 bytes/sec
 *     - Actual: Lower due to polling overhead and protocol overhead
 *     - Real-world: ~10 KB/sec (adequate for debug output)
 *   
 *   For high-performance:
 *     - Use interrupt-driven I/O (eliminates polling overhead)
 *     - Use DMA (eliminates CPU involvement entirely)
 *     - Use higher baud rates (230400, 460800)
 *     - Use binary protocols (no CR/LF conversion overhead)
 *   
 *   For TinyOS:
 *     - Current implementation is perfectly adequate
 *     - Debug output is infrequent (not performance-critical)
 *     - Simplicity and reliability are more important than speed
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - How serial communication works at hardware level
 *   - The RS-232 protocol and framing
 *   - UART initialization and register programming
 *   - Baud rate calculation and divisor setting
 *   - Polling vs interrupt-driven I/O trade-offs
 *   - Line ending conventions and terminal compatibility
 * 
 *   You've mastered a fundamental I/O device used everywhere from
 *   embedded systems to data centers! 🎉
 *============================================================================*/
