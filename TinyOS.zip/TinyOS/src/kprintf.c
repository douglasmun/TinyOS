/*=============================================================================
 *  kprintf.c — Kernel Printf: Unified Formatted Output for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file implements kprintf(), a printf-like formatted output function
 *   that works in the kernel environment. It outputs simultaneously to both
 *   VGA text console and serial port, providing dual-channel debug output.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Environment: Freestanding (no libc)
 *   - Output: Dual (VGA + serial simultaneously)
 *   - Format: Subset of C99 printf specification
 *   - Implementation: Custom (no standard library dependencies)
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is printf and Why We Need It
 * 2. Variadic Functions (stdarg.h)
 * 3. Format String Parsing
 * 4. Number-to-String Conversion
 * 5. Width and Padding
 * 6. Flags (-, 0, +, #)
 * 7. Length Modifiers (l, ll)
 * 8. Supported Format Specifiers
 * 9. Design Decisions and Trade-offs
 * 10. Common Pitfalls and Solutions
 * 11. Performance Considerations
 * 12. Integration with the Kernel
 *
 *=============================================================================
 * SECTION 1: WHAT IS PRINTF AND WHY WE NEED IT
 *=============================================================================
 * 
 * PRINTF = PRINT FORMATTED
 * 
 * printf is one of the most fundamental functions in C programming.
 * It converts various data types to human-readable text and outputs them.
 * 
 * THE PROBLEM:
 * 
 * Without printf:
 *   int x = 42;
 *   // How do we display x?
 *   // We'd need separate functions for each type:
 *   print_int(x);           // Integers
 *   print_hex(0x1234);      // Hex numbers
 *   print_pointer(&x);      // Pointers
 *   print_string("hello");  // Strings
 * 
 * With printf:
 *   int x = 42;
 *   printf("x = %d (hex: %x, addr: %p)\n", x, x, &x);
 *   // Output: x = 42 (hex: 2a, addr: 0xbffff7a4)
 * 
 * ONE FUNCTION FOR EVERYTHING!
 * 
 * STANDARD C printf():
 * 
 * Format: printf(format_string, arguments...)
 * 
 * Example:
 *   printf("Hello, %s! You are %d years old.\n", "Alice", 25);
 *   Output: Hello, Alice! You are 25 years old.
 * 
 * Format specifiers:
 *   %d - Decimal integer
 *   %x - Hexadecimal
 *   %s - String
 *   %c - Character
 *   %p - Pointer
 *   %% - Literal %
 * 
 * WHY KERNEL NEEDS PRINTF:
 * 
 * 1. DEBUGGING:
 *    kprintf("IRQ fired: vector=%d, count=%d\n", vec, count);
 *    Much easier than printing each value separately!
 * 
 * 2. BOOT MESSAGES:
 *    kprintf("Initializing %s... ", subsystem_name);
 *    kprintf("OK\n");
 * 
 * 3. ERROR REPORTING:
 *    kprintf("ERROR: Failed to allocate %d bytes\n", size);
 * 
 * 4. MEMORY/REGISTER DUMPS:
 *    kprintf("EAX=%08x EBX=%08x ECX=%08x\n", eax, ebx, ecx);
 * 
 * 5. STATUS INFORMATION:
 *    kprintf("Free memory: %llu KB\n", free_bytes / 1024);
 * 
 * WHY NOT USE STANDARD printf()?
 * 
 * Standard printf() is part of libc (C standard library).
 * In freestanding kernel environment:
 *   ❌ No libc available
 *   ❌ printf depends on FILE*, stdout, heap allocation
 *   ❌ printf uses system calls (write, etc.)
 *   ❌ We ARE the system (can't call ourselves!)
 * 
 * Solution: Implement our own!
 *   ✅ No dependencies (only stdarg.h)
 *   ✅ Direct hardware output (VGA + serial)
 *   ✅ Subset of features (what we need)
 *   ✅ Complete control
 * 
 * KPRINTF VS PRINTF:
 * 
 * Similarities:
 *   ✅ Same basic syntax: kprintf("format", args...)
 *   ✅ Same format specifiers: %d, %x, %s, %c, %p
 *   ✅ Width and flags: %08x, %-10s
 * 
 * Differences:
 *   ❌ No floating point (%f, %e, %g) - not needed in kernel
 *   ❌ No return value (standard printf returns character count)
 *   ❌ Simpler (no FILE*, no buffering)
 *   ✅ Dual output (VGA + serial simultaneously)
 *   ✅ Kernel-safe (no allocations, no system calls)
 * 
 * DESIGN PHILOSOPHY:
 * 
 * "Simple enough to debug, powerful enough to be useful"
 * 
 * Goals:
 *   1. Provide essential formatting (numbers, strings, pointers)
 *   2. Support width and padding (for aligned output)
 *   3. Mirror output to both VGA and serial (dual debug)
 *   4. Minimize code size (kernel should be small)
 *   5. No dynamic allocation (use stack buffers)
 *   6. No dependencies (except stdarg.h)
 *
 *=============================================================================
 * SECTION 2: VARIADIC FUNCTIONS (stdarg.h)
 *=============================================================================
 * 
 * VARIADIC = Variable number of arguments
 * 
 * printf() is a variadic function: it accepts any number of arguments!
 * 
 * Examples:
 *   kprintf("Hello\n");                          // 1 arg
 *   kprintf("x=%d\n", x);                        // 2 args
 *   kprintf("x=%d y=%d z=%d\n", x, y, z);        // 4 args
 * 
 * How does the function know how many arguments there are?
 * Answer: IT DOESN'T! You tell it via the format string.
 * 
 * THE CHALLENGE:
 * 
 * Normal function:
 *   void foo(int a, int b, int c) {
 *       // Fixed number of parameters
 *       // Easy: just use a, b, c
 *   }
 * 
 * Variadic function:
 *   void bar(const char* fmt, ...) {
 *       // Unknown number of parameters
 *       // How do we access them?
 *   }
 * 
 * THE SOLUTION: stdarg.h
 * 
 * stdarg.h provides macros to access variable arguments:
 * 
 * 1. va_list - Type to hold argument list
 *    va_list ap;  // 'ap' = argument pointer
 * 
 * 2. va_start(ap, last_fixed_param) - Initialize argument list
 *    va_start(ap, fmt);  // fmt is last fixed parameter
 * 
 * 3. va_arg(ap, type) - Get next argument
 *    int x = va_arg(ap, int);        // Get int
 *    char* s = va_arg(ap, char*);    // Get string
 * 
 * 4. va_end(ap) - Cleanup (required!)
 *    va_end(ap);  // Done with arguments
 * 
 * EXAMPLE: Simple variadic function
 * 
 * int sum(int count, ...) {
 *     va_list ap;
 *     va_start(ap, count);  // count is last fixed param
 *     
 *     int total = 0;
 *     for (int i = 0; i < count; i++) {
 *         int value = va_arg(ap, int);  // Get next int
 *         total += value;
 *     }
 *     
 *     va_end(ap);
 *     return total;
 * }
 * 
 * Usage:
 *   sum(3, 10, 20, 30);  // Returns 60
 *   sum(5, 1, 2, 3, 4, 5);  // Returns 15
 * 
 * HOW IT WORKS (x86 ABI):
 * 
 * Arguments are pushed onto the stack in reverse order:
 * 
 * Call: kprintf("x=%d y=%d\n", 42, 99)
 * 
 * Stack layout (grows downward):
 *   [higher addresses]
 *   ...
 *   99          ← arg 3 (pushed first)
 *   42          ← arg 2
 *   "x=%d y=%d\n"  ← arg 1 (fmt parameter)
 *   [return address]
 *   [lower addresses]
 * 
 * va_list is essentially a pointer into the stack.
 * va_start sets it to point after 'fmt'.
 * va_arg reads the current argument and advances the pointer.
 * 
 * TYPE SAFETY WARNING:
 * 
 * va_arg doesn't know the actual type!
 * You must specify the correct type:
 * 
 *   int x = va_arg(ap, int);     // Correct
 *   int x = va_arg(ap, char);    // WRONG! Causes undefined behavior
 *   char* s = va_arg(ap, char*); // Correct
 *   char* s = va_arg(ap, int);   // WRONG! Will crash or return garbage
 * 
 * This is why format strings are essential:
 *   %d → tells us to use va_arg(ap, int)
 *   %s → tells us to use va_arg(ap, char*)
 *   %p → tells us to use va_arg(ap, void*)
 * 
 * COMMON MISTAKES:
 * 
 * 1. Wrong type in va_arg:
 *    // Format: "%d"
 *    char* s = va_arg(ap, char*);  // WRONG! Should be int
 * 
 * 2. Too many va_arg calls:
 *    kprintf("%d", 42);
 *    // Inside kprintf:
 *    int a = va_arg(ap, int);  // OK
 *    int b = va_arg(ap, int);  // WRONG! No second argument
 * 
 * 3. Too few va_arg calls:
 *    kprintf("%d %d", 42, 99);
 *    // Inside kprintf:
 *    int a = va_arg(ap, int);  // OK
 *    // Forgot second va_arg! 99 is leaked
 * 
 * 4. Forgetting va_end:
 *    va_start(ap, fmt);
 *    // ... use arguments ...
 *    // Oops, forgot va_end(ap)!
 *    // Can cause resource leaks on some architectures
 * 
 * ARGUMENT PROMOTION:
 * 
 * Small types are promoted when passed to variadic functions:
 *   - char → int
 *   - short → int
 *   - float → double
 * 
 * So even if format is %c (character):
 *   va_arg(ap, int)  // Correct (promoted to int)
 *   va_arg(ap, char) // WRONG (not promoted)
 * 
 * This is why kprintf uses:
 *   case 'c': int ch = va_arg(ap, int);  // Not char!
 *
 *=============================================================================
 * SECTION 3: FORMAT STRING PARSING
 *=============================================================================
 * 
 * FORMAT STRING: A string with special % sequences
 * 
 * Structure of a format specifier:
 *   %[flags][width][.precision][length]specifier
 * 
 * Example: %08x
 *   % - Introduces format specifier
 *   0 - Flag: Pad with zeros
 *   8 - Width: Minimum 8 characters
 *   x - Specifier: Hexadecimal
 * 
 * TinyOS supports:
 *   %[flags][width][length]specifier
 *   (No precision field - not needed in kernel)
 * 
 * PARSING ALGORITHM:
 * 
 * State machine:
 *   1. LITERAL: Copy characters until '%' found
 *   2. FLAGS: Parse optional flags (-, 0)
 *   3. WIDTH: Parse optional width (digits)
 *   4. LENGTH: Parse optional length (l, ll)
 *   5. SPECIFIER: Process conversion character (d, x, s, etc.)
 * 
 * Example: Parsing "%08x"
 * 
 * Input: "%08x"
 * Position: ^
 * 
 * Step 1: See '%', enter format parsing
 * Position: ^
 *          %08x
 * 
 * Step 2: Parse flags
 * Position:  ^
 *          %08x
 * Check '0': Yes, it's a flag (zero-padding)
 * Set zero = true
 * Advance: position++
 * 
 * Step 3: Parse width
 * Position:   ^
 *          %08x
 * Check '8': Yes, it's a digit
 * width = 0 * 10 + 8 = 8
 * Advance: position++
 * Check next: 'x' is not a digit, stop
 * 
 * Step 4: Parse length
 * Position:    ^
 *          %08x
 * Check 'x': Not 'l', no length modifier
 * 
 * Step 5: Process specifier
 * Position:    ^
 *          %08x
 * Check 'x': Hexadecimal conversion
 * Call print_unsigned with width=8, zero=true, base=16
 * 
 * FLAGS:
 * 
 * - (minus): Left-justify
 *   Example: "%-5d" with 42 → "42   " (padded on right)
 *   Default: Right-justify → "   42" (padded on left)
 * 
 * 0 (zero): Pad with zeros (only for right-justify)
 *   Example: "%05d" with 42 → "00042"
 *   Example: "%-05d" with 42 → "42   " (- overrides 0)
 * 
 * TinyOS doesn't support:
 *   + (plus): Always show sign (+42, -42)
 *   space: Show space for positive (42, -42)
 *   # (hash): Alternate form (0x prefix, decimal point)
 * 
 * WIDTH:
 * 
 * Minimum field width (number of characters):
 *   "%5d" with 42 → "   42" (5 chars, right-justified)
 *   "%-5d" with 42 → "42   " (5 chars, left-justified)
 *   "%5d" with 123456 → "123456" (exceeds width, no truncation)
 * 
 * Width can be:
 *   - Literal number: %10d
 *   - * (asterisk): int w = va_arg(ap, int); (not implemented in TinyOS)
 * 
 * LENGTH MODIFIERS:
 * 
 * Specify size of argument:
 *   (none): int (4 bytes on i386)
 *   l: long (4 bytes on i386, same as int)
 *   ll: long long (8 bytes, 64-bit)
 * 
 * Examples:
 *   %d   → int (32-bit)
 *   %ld  → long (32-bit on i386)
 *   %lld → long long (64-bit)
 * 
 * TinyOS doesn't support:
 *   hh: char
 *   h: short
 *   L: long double
 *   z: size_t
 *   t: ptrdiff_t
 * 
 * SPECIFIERS (Conversion Types):
 * 
 * %c - Character
 *   kprintf("%c", 'A') → "A"
 * 
 * %s - String (null-terminated)
 *   kprintf("%s", "Hello") → "Hello"
 * 
 * %d, %i - Signed decimal integer
 *   kprintf("%d", 42) → "42"
 *   kprintf("%d", -42) → "-42"
 * 
 * %u - Unsigned decimal integer
 *   kprintf("%u", 42) → "42"
 *   kprintf("%u", -1) → "4294967295" (on 32-bit)
 * 
 * %x - Unsigned hexadecimal (lowercase)
 *   kprintf("%x", 255) → "ff"
 * 
 * %X - Unsigned hexadecimal (uppercase)
 *   kprintf("%X", 255) → "FF"
 * 
 * %p - Pointer
 *   kprintf("%p", ptr) → "0x12345678"
 *   (Always shows 0x prefix, 8 hex digits on i386)
 * 
 * %% - Literal percent sign
 *   kprintf("100%%") → "100%"
 * 
 * ESCAPE SEQUENCES:
 * 
 * These are handled by the output functions (console_putc, serial_putc):
 *   \n - Newline (moves to next line)
 *   \r - Carriage return (moves to start of line)
 *   \t - Tab (not implemented in TinyOS VGA)
 *   \\ - Backslash (literal \)
 * 
 * Example:
 *   kprintf("Line 1\nLine 2\n") →
 *     Line 1
 *     Line 2
 *
 *=============================================================================
 * SECTION 4: NUMBER-TO-STRING CONVERSION
 *=============================================================================
 * 
 * THE CHALLENGE: Convert binary number to decimal/hex string
 * 
 * Problem:
 *   Number: 42 (binary: 00101010)
 *   Want: "42" (string: {'4', '2', '\0'})
 * 
 * Can't just cast: (char)42 = '*' (ASCII 42), not "42"!
 * 
 * ALGORITHM: Repeated Division
 * 
 * To convert number to base B:
 *   1. Divide number by B, get quotient and remainder
 *   2. Remainder is the rightmost digit
 *   3. Repeat with quotient until quotient is 0
 *   4. Digits come out in REVERSE order
 * 
 * Example: 42 in base 10
 * 
 * Step 1: 42 ÷ 10 = 4 remainder 2  → digit '2'
 * Step 2: 4 ÷ 10 = 0 remainder 4   → digit '4'
 * Step 3: Quotient is 0, stop
 * 
 * Digits: ['2', '4'] (reversed!)
 * Reverse them: "42"
 * 
 * Example: 255 in base 16 (hex)
 * 
 * Step 1: 255 ÷ 16 = 15 remainder 15  → digit 'f'
 * Step 2: 15 ÷ 16 = 0 remainder 15    → digit 'f'
 * Step 3: Quotient is 0, stop
 * 
 * Digits: ['f', 'f'] (reversed!)
 * Reverse them: "ff"
 * 
 * DIGIT MAPPING:
 * 
 * Remainder 0-9: Map to '0'-'9'
 *   remainder 0 → '0' (ASCII 48)
 *   remainder 1 → '1' (ASCII 49)
 *   ...
 *   remainder 9 → '9' (ASCII 57)
 * 
 * Remainder 10-15 (hex): Map to 'a'-'f' or 'A'-'F'
 *   remainder 10 → 'a' or 'A' (hex digit A)
 *   remainder 11 → 'b' or 'B' (hex digit B)
 *   ...
 *   remainder 15 → 'f' or 'F' (hex digit F)
 * 
 * Digit table:
 *   const char digits[] = "0123456789abcdef";
 *   char digit = digits[remainder];
 * 
 * PSEUDOCODE:
 * 
 * function number_to_string(number, base):
 *     if number == 0:
 *         return "0"
 *     
 *     digits = []
 *     while number > 0:
 *         remainder = number % base
 *         digit = digit_char[remainder]
 *         digits.append(digit)
 *         number = number / base
 *     
 *     return reverse(digits)
 * 
 * SIGNED NUMBERS:
 * 
 * For negative numbers:
 *   1. Check if number is negative
 *   2. Convert to positive (absolute value)
 *   3. Convert positive number to string
 *   4. Prepend '-' sign
 * 
 * Example: -42
 *   1. Negative? Yes
 *   2. Absolute: 42
 *   3. Convert: "42"
 *   4. Prepend: "-42"
 * 
 * Special case: Most negative number
 *   On 32-bit: -2147483648 (0x80000000)
 *   Absolute value: Can't represent +2147483648 as signed int!
 *   
 *   Solution: Use unsigned arithmetic
 *     uint32_t u = (val < 0) ? -(uint32_t)val : val;
 * 
 * TINYOS APPROACH:
 * 
 * u64_to_str function:
 *   - Takes 64-bit unsigned value
 *   - Converts to any base (2-16)
 *   - Stores digits in REVERSE order in buffer
 *   - Returns digit count
 * 
 * Why reverse order?
 *   - Easier to generate (no need to calculate length first)
 *   - Print loop reads buffer backwards
 * 
 * Example: u64_to_str(42, 10, false, buf)
 *   Returns: 2 (digit count)
 *   Buffer: ['2', '4'] (reversed)
 *   Print loop: for (i=1; i>=0; i--) print(buf[i])
 *   Output: "42"
 * 
 * EFFICIENCY:
 * 
 * Division is slow (especially 64-bit division on 32-bit CPU).
 * 
 * Optimizations (not in TinyOS, but used in production):
 *   1. Use shifts for powers of 2 (divide by 2^n = shift right n)
 *      42 ÷ 16 = 42 >> 4 (much faster)
 *   
 *   2. Use multiplication + shift for division by constants
 *      Compiler trick: x / 10 ≈ (x * magic) >> shift
 *   
 *   3. Convert multiple digits at once
 *      Divide by 100, get two decimal digits
 *   
 *   4. Use lookup tables for small numbers
 *      Table of pre-computed strings for 0-99
 * 
 * TinyOS uses simple repeated division:
 *   - Easy to understand
 *   - Adequate for debug output
 *   - Compiler may optimize anyway
 *
 *=============================================================================
 * SECTION 5: WIDTH AND PADDING
 *=============================================================================
 * 
 * WIDTH: Minimum number of characters to output
 * 
 * Examples:
 *   kprintf("%5d", 42)    → "   42" (3 spaces + 2 digits = 5 chars)
 *   kprintf("%5d", 12345) → "12345" (no padding, already 5 chars)
 *   kprintf("%5d", 123456) → "123456" (exceeds width, no truncation!)
 * 
 * Why width?
 *   - Aligned columns in tables
 *   - Fixed-width output
 *   - Pretty formatting
 * 
 * Example: Memory dump
 *   kprintf("0x%08x: %02x %02x %02x %02x\n", addr, b0, b1, b2, b3);
 *   Output: 0x12345678: ab cd ef 01
 * 
 * PADDING:
 * 
 * If output is shorter than width, add padding characters.
 * 
 * Padding character:
 *   - Space ' ' (default)
 *   - Zero '0' (if flag 0 is present)
 * 
 * Padding position:
 *   - Left side (default, right-justify)
 *   - Right side (if flag - is present, left-justify)
 * 
 * ALIGNMENT:
 * 
 * Right-justify (default):
 *   %5d with 42 → "   42"
 *   └─┴─┴─┴─┴─┘
 *   Padding on left, value on right
 * 
 * Left-justify (- flag):
 *   %-5d with 42 → "42   "
 *   └─┴─┴─┴─┴─┘
 *   Value on left, padding on right
 * 
 * ZERO PADDING:
 * 
 * %05d with 42 → "00042"
 * Useful for:
 *   - Hex addresses: 0x00001234
 *   - Fixed-width numbers: 00042
 *   - Binary dumps: 01010101
 * 
 * Flag interaction:
 *   %05d   → "00042" (zero padding, right-justify)
 *   %-05d  → "42   " (- overrides 0, space padding)
 * 
 * SIGN AND PADDING:
 * 
 * For negative numbers, sign comes before padding:
 * 
 * Right-justify, space padding:
 *   %5d with -42 → "  -42"
 *   Not: "  - 42" or " -  42"
 * 
 * Right-justify, zero padding:
 *   %05d with -42 → "-0042"
 *   Not: "0-042" or "-00 42"
 *   
 *   Sign is printed FIRST, then zeros
 * 
 * Left-justify:
 *   %-5d with -42 → "-42  "
 *   Sign is part of value, padding on right
 * 
 * ALGORITHM:
 * 
 * 1. Convert number to string (e.g., "42" or "-42")
 * 2. Calculate length (including sign if present)
 * 3. Calculate padding needed: max(width - length, 0)
 * 4. If right-justify:
 *      a. Print padding (spaces or zeros)
 *      b. If zero-padding, print sign first (before zeros)
 *      c. Print digits
 * 5. If left-justify:
 *      a. Print sign (if present)
 *      b. Print digits
 *      c. Print padding (always spaces)
 * 
 * Example: %08d with -42
 * 
 * Step 1: Convert: "-42"
 * Step 2: Length: 3 (sign + 2 digits)
 * Step 3: Padding: 8 - 3 = 5 zeros needed
 * Step 4: Right-justify, zero padding:
 *   a. Print sign: "-"
 *   b. Print zeros: "00000"
 *   c. Print digits: "42"
 *   Result: "-0000042"
 * 
 * EDGE CASES:
 * 
 * Width 0:
 *   %0d with 42 → "42" (no padding, just the number)
 * 
 * Negative width:
 *   Not possible in TinyOS (width is unsigned)
 *   Standard printf treats negative width as left-justify
 * 
 * Width larger than buffer:
 *   %100d with 42 → "                                        42"
 *   (98 spaces + "42")
 *   Must ensure buffer is large enough!
 * 
 * Value longer than width:
 *   %5d with 123456 → "123456" (no truncation!)
 *   Width is MINIMUM, not maximum
 *
 *=============================================================================
 * SECTION 6: FLAGS (-, 0, +, #)
 *=============================================================================
 * 
 * FLAGS: Modifiers that change formatting behavior
 * 
 * TinyOS supports:
 *   - (minus): Left-justify
 *   0 (zero): Zero-padding
 * 
 * Standard printf also has:
 *   + (plus): Always show sign (not in TinyOS)
 *   space: Show space for positive (not in TinyOS)
 *   # (hash): Alternate form (not in TinyOS)
 * 
 * MINUS FLAG: Left-Justify
 * 
 * Default (no flag): Right-justify
 *   "%5d" with 42 → "   42"
 * 
 * With - flag: Left-justify
 *   "%-5d" with 42 → "42   "
 * 
 * Use cases:
 *   - Text that should be left-aligned
 *   - Labels: "Error:     Something went wrong"
 *   - Tables with left-aligned columns
 * 
 * Example: Column alignment
 *   kprintf("%-20s %10d\n", "Total memory:", 32768);
 *   kprintf("%-20s %10d\n", "Free memory:", 28456);
 *   Output:
 *   Total memory:             32768
 *   Free memory:              28456
 * 
 * ZERO FLAG: Zero-Padding
 * 
 * Default (no flag): Space-padding
 *   "%5d" with 42 → "   42"
 * 
 * With 0 flag: Zero-padding
 *   "%05d" with 42 → "00042"
 * 
 * Use cases:
 *   - Hex addresses: 0x0000ABCD
 *   - Fixed-width IDs: Employee #00042
 *   - Binary representation: 00101010
 * 
 * Example: Memory dump
 *   kprintf("0x%08x: %02x %02x %02x %02x\n", addr, b[0], b[1], b[2], b[3]);
 *   Output: 0x12345678: ab cd ef 01
 * 
 * FLAG INTERACTION: - vs 0
 * 
 * Rule: Minus flag overrides zero flag
 * 
 * "%05d" with 42 → "00042" (zero padding)
 * "%-05d" with 42 → "42   " (space padding, - overrides 0)
 * 
 * Why? Left-justified zero-padding makes no sense:
 *   "42000" is confusing (looks like 42000, not 42)
 *   "42   " is clear (42 followed by spaces)
 * 
 * PLUS FLAG (Standard printf, not in TinyOS):
 * 
 * Default: Only show sign for negative
 *   "%d" with 42 → "42"
 *   "%d" with -42 → "-42"
 * 
 * With + flag: Always show sign
 *   "%+d" with 42 → "+42"
 *   "%+d" with -42 → "-42"
 * 
 * Use cases:
 *   - Temperature: +20°C vs -5°C
 *   - Voltage: +5V vs -12V
 *   - Coordinate changes: +10 pixels, -5 pixels
 * 
 * SPACE FLAG (Standard printf, not in TinyOS):
 * 
 * Default: No space for positive
 *   "%d" with 42 → "42"
 *   "%d" with -42 → "-42"
 * 
 * With space flag: Space for positive, minus for negative
 *   "% d" with 42 → " 42" (leading space)
 *   "% d" with -42 → "-42" (minus sign)
 * 
 * Use cases:
 *   - Aligned columns where some values are negative
 *   - Ensures all numbers have same width including sign
 * 
 * HASH FLAG (Standard printf, not in TinyOS):
 * 
 * Alternate form for certain conversions:
 * 
 * %#x: Show 0x prefix
 *   "%x" with 255 → "ff"
 *   "%#x" with 255 → "0xff"
 * 
 * %#o: Show 0 prefix for octal
 *   "%o" with 8 → "10"
 *   "%#o" with 8 → "010"
 * 
 * %#f: Always show decimal point
 *   "%f" with 42.0 → "42"
 *   "%#f" with 42.0 → "42.0"
 * 
 * WHY TINYOS OMITS + AND #:
 * 
 * + flag:
 *   - Rarely needed in kernel (usually don't care about positive sign)
 *   - Adds complexity (need to track whether to show +)
 *   - Can implement if needed later
 * 
 * # flag:
 *   - %p (pointer) always shows 0x (built-in)
 *   - Hex dumps usually want 0x anyway
 *   - Can add 0x manually in format: "0x%x"
 * 
 * Simplicity > completeness (for learning OS)
 *
 *=============================================================================
 * SECTION 7: LENGTH MODIFIERS (l, ll)
 *=============================================================================
 * 
 * LENGTH MODIFIERS: Specify size of integer argument
 * 
 * THE PROBLEM:
 * 
 * Different integer types have different sizes:
 *   char:      1 byte  (8 bits)
 *   short:     2 bytes (16 bits)
 *   int:       4 bytes (32 bits) on i386
 *   long:      4 bytes (32 bits) on i386, 8 bytes on x86-64
 *   long long: 8 bytes (64 bits)
 * 
 * printf needs to know the size to read the correct number of bytes!
 * 
 * Example:
 *   long long x = 0x123456789ABCDEF0;
 *   kprintf("%d", x);  // WRONG! Reads only 4 bytes
 *   // Output: -1985229328 (garbage, only read lower 32 bits)
 *   
 *   kprintf("%lld", x);  // CORRECT! Reads 8 bytes
 *   // Output: 1311768467463790320
 * 
 * STANDARD LENGTH MODIFIERS:
 * 
 * (none): int (or unsigned int)
 *   %d → int (4 bytes on i386)
 *   %u → unsigned int
 * 
 * hh: char (or unsigned char)
 *   %hhd → signed char (1 byte)
 *   %hhu → unsigned char
 * 
 * h: short (or unsigned short)
 *   %hd → short (2 bytes)
 *   %hu → unsigned short
 * 
 * l: long (or unsigned long)
 *   %ld → long (4 bytes on i386, 8 on x86-64)
 *   %lu → unsigned long
 * 
 * ll: long long (or unsigned long long)
 *   %lld → long long (8 bytes)
 *   %llu → unsigned long long
 * 
 * z: size_t
 *   %zd → signed size_t
 *   %zu → size_t (unsigned)
 * 
 * t: ptrdiff_t
 *   %td → ptrdiff_t
 * 
 * TINYOS SUPPORTS:
 * 
 * (none): int / unsigned int
 *   %d, %u, %x
 * 
 * l: long / unsigned long
 *   %ld, %lu, %lx
 *   Note: On i386, long is same size as int (4 bytes)
 * 
 * ll: long long / unsigned long long
 *   %lld, %llu, %llx
 *   Always 8 bytes (64-bit)
 * 
 * WHY LONG LONG?
 * 
 * Use cases in kernel:
 *   - 64-bit timestamps (milliseconds since boot)
 *   - 64-bit disk offsets (files larger than 4 GB)
 *   - 64-bit memory sizes (systems with >4 GB RAM)
 *   - 64-bit counters (network statistics, etc.)
 * 
 * Example:
 *   uint64_t bytes_transferred = 5000000000ULL;  // 5 GB
 *   kprintf("Transferred %llu bytes\n", bytes_transferred);
 *   Output: Transferred 5000000000 bytes
 * 
 * SIZE MISMATCH PROBLEMS:
 * 
 * Too small length modifier:
 *   long long x = 0x123456789ABCDEF0;
 *   kprintf("%d", x);  // Reads 4 bytes instead of 8
 *   Result: Reads 0x9ABCDEF0 (lower 32 bits)
 *   Output: "-1698898192" (interpreted as signed int)
 * 
 * Too large length modifier:
 *   int x = 42;
 *   kprintf("%lld", x);  // Reads 8 bytes instead of 4
 *   Result: Reads 42 + garbage from stack
 *   Output: Random number (depends on stack contents)
 * 
 * ARGUMENT PROMOTION:
 * 
 * When passed to variadic function, small types are promoted:
 *   - char, short → int
 *   - float → double
 * 
 * This is why we can't use %hh or %h correctly without special handling:
 * 
 * Wrong:
 *   char c = 'A';
 *   kprintf("%hhd", c);  // c is promoted to int!
 *   va_arg(ap, char);    // WRONG! c is int on stack
 * 
 * Correct:
 *   char c = 'A';
 *   kprintf("%c", c);    // Use %c for characters
 *   va_arg(ap, int);     // Read as int, cast to char
 * 
 * VA_ARG TYPE MAPPING:
 * 
 * Format → va_arg type:
 *   %d, %i → int
 *   %ld → long (cast to long long for uniformity)
 *   %lld → long long
 *   %u → unsigned int
 *   %lu → unsigned long (cast to unsigned long long)
 *   %llu → unsigned long long
 *   %x, %X → unsigned int (or with l/ll)
 *   %p → void* (cast to uintptr_t)
 *   %c → int (promoted from char)
 *   %s → char*
 * 
 * TINYOS IMPLEMENTATION:
 * 
 * Length enum:
 *   enum { LEN_DEF, LEN_L, LEN_LL } len = LEN_DEF;
 * 
 * Parsing:
 *   if (*p == 'l') {
 *       if (*(p+1) == 'l') {
 *           len = LEN_LL;  // Found "ll"
 *           p += 2;
 *       } else {
 *           len = LEN_L;   // Found "l"
 *           ++p;
 *       }
 *   }
 * 
 * Usage:
 *   long long v = (len == LEN_LL) ? va_arg(ap, long long)
 *                 : (len == LEN_L) ? (long long)va_arg(ap, long)
 *                 : (long long)va_arg(ap, int);
 * 
 * Why cast everything to long long?
 *   - Uniform handling (one print function)
 *   - Simpler code
 *   - No precision loss (long long is largest)
 *
 *=============================================================================
 * SECTION 8: SUPPORTED FORMAT SPECIFIERS
 *=============================================================================
 * 
 * TINYOS kprintf() supports a useful subset of C99 printf.
 * 
 * %c - CHARACTER
 * 
 * Prints a single character.
 * 
 * Usage:
 *   kprintf("%c", 'A');  → "A"
 *   kprintf("%c", 65);   → "A" (ASCII 65 is 'A')
 *   kprintf("%c", '\n'); → (newline)
 * 
 * Width:
 *   kprintf("%5c", 'A');  → "    A" (4 spaces + A)
 *   kprintf("%-5c", 'A'); → "A    " (A + 4 spaces)
 * 
 * Argument type: int (char is promoted to int)
 * 
 * 
 * %s - STRING
 * 
 * Prints a null-terminated string.
 * 
 * Usage:
 *   kprintf("%s", "Hello");  → "Hello"
 *   kprintf("Error: %s\n", error_msg);
 * 
 * NULL handling:
 *   kprintf("%s", NULL);  → "(null)"
 *   (TinyOS safety feature - prevents crash)
 * 
 * Width:
 *   kprintf("%10s", "Hi");  → "        Hi" (8 spaces + "Hi")
 *   kprintf("%-10s", "Hi"); → "Hi        " ("Hi" + 8 spaces)
 * 
 * No precision support (no %.10s to truncate).
 * 
 * Argument type: const char*
 * 
 * 
 * %d, %i - SIGNED DECIMAL INTEGER
 * 
 * Prints signed integer in decimal (base 10).
 * %d and %i are identical (historical reasons).
 * 
 * Usage:
 *   kprintf("%d", 42);    → "42"
 *   kprintf("%d", -42);   → "-42"
 *   kprintf("%d", 0);     → "0"
 * 
 * Width and zero-padding:
 *   kprintf("%5d", 42);   → "   42"
 *   kprintf("%05d", 42);  → "00042"
 *   kprintf("%05d", -42); → "-0042" (sign before zeros)
 * 
 * Length modifiers:
 *   kprintf("%d", x);     → int (32-bit)
 *   kprintf("%ld", x);    → long (32-bit on i386)
 *   kprintf("%lld", x);   → long long (64-bit)
 * 
 * Range (32-bit):
 *   -2,147,483,648 to 2,147,483,647
 * 
 * Argument type: int, long, or long long
 * 
 * 
 * %u - UNSIGNED DECIMAL INTEGER
 * 
 * Prints unsigned integer in decimal (base 10).
 * 
 * Usage:
 *   kprintf("%u", 42);   → "42"
 *   kprintf("%u", -1);   → "4294967295" (2^32-1 on 32-bit)
 * 
 * Width and padding:
 *   kprintf("%10u", 42); → "        42"
 *   kprintf("%010u", 42); → "0000000042"
 * 
 * Length modifiers:
 *   kprintf("%u", x);    → unsigned int
 *   kprintf("%lu", x);   → unsigned long
 *   kprintf("%llu", x);  → unsigned long long
 * 
 * Use cases:
 *   - Sizes: kprintf("Size: %u bytes\n", size);
 *   - Counts: kprintf("Count: %u\n", count);
 *   - IDs: kprintf("Process ID: %u\n", pid);
 * 
 * Argument type: unsigned int, unsigned long, or unsigned long long
 * 
 * 
 * %x, %X - UNSIGNED HEXADECIMAL
 * 
 * Prints unsigned integer in hexadecimal (base 16).
 * %x: lowercase (a-f)
 * %X: uppercase (A-F)
 * 
 * Usage:
 *   kprintf("%x", 255);  → "ff"
 *   kprintf("%X", 255);  → "FF"
 *   kprintf("%x", 0);    → "0"
 * 
 * Width and zero-padding (common for addresses):
 *   kprintf("%08x", 0x1234);  → "00001234"
 *   kprintf("0x%x", 0xABCD);  → "0xabcd"
 * 
 * Length modifiers:
 *   kprintf("%x", x);    → unsigned int
 *   kprintf("%lx", x);   → unsigned long
 *   kprintf("%llx", x);  → unsigned long long
 * 
 * Use cases:
 *   - Memory addresses: kprintf("addr=%08x\n", addr);
 *   - Bit patterns: kprintf("flags=%02x\n", flags);
 *   - Debugging: kprintf("value=%x\n", value);
 * 
 * Note: No 0x prefix automatically (use "0x%x" if needed).
 * 
 * Argument type: unsigned int, unsigned long, or unsigned long long
 * 
 * 
 * %p - POINTER
 * 
 * Prints pointer value in hexadecimal with 0x prefix.
 * 
 * Usage:
 *   int x = 42;
 *   kprintf("%p", &x);  → "0x12345678" (example address)
 * 
 * Format:
 *   - Always shows "0x" prefix
 *   - Default width: 8 hex digits on i386 (10 chars total with 0x)
 *   - Can override: kprintf("%p", ptr) uses default
 *                   kprintf("%12p", ptr) uses width 12
 * 
 * Width:
 *   kprintf("%p", ptr);   → "0x00001234" (default 8 digits)
 *   kprintf("%12p", ptr); → "0x0000001234" (10 digits + 0x = 12)
 * 
 * Use cases:
 *   - Debugging: kprintf("ptr=%p\n", ptr);
 *   - Memory dumps: kprintf("0x%p: ...\n", addr);
 *   - Comparing addresses: if (p1 > p2) ...
 * 
 * Argument type: void*
 * 
 * 
 * %% - LITERAL PERCENT
 * 
 * Prints a literal '%' character.
 * 
 * Usage:
 *   kprintf("100%%");  → "100%"
 *   kprintf("%%d");    → "%d" (not a format specifier)
 * 
 * Necessary because % introduces format specifiers.
 * 
 * 
 * UNSUPPORTED (Standard printf has these, TinyOS doesn't):
 * 
 * %f, %e, %g - Floating point
 *   Why not: Kernel rarely needs floating point
 *            Adds significant code size
 *            FPU may not be initialized
 * 
 * %o - Octal
 *   Why not: Rarely used (hex is more common)
 *            Easy to add if needed
 * 
 * %n - Store character count
 *   Why not: Rarely used, security risk
 *            Can cause vulnerabilities if misused
 * 
 * .precision - Precision field
 *   Why not: Not essential for kernel output
 *            Adds parsing complexity
 * 
 * * width - Dynamic width
 *   Why not: Adds complexity
 *            Can specify width directly
 * 
 * Remember: kprintf is for DEBUGGING, not production output.
 * Keep it simple, add features only as needed!
 *
 *=============================================================================
 * SECTION 9: DESIGN DECISIONS AND TRADE-OFFS
 *=============================================================================
 * 
 * DECISION 1: DUAL OUTPUT (VGA + SERIAL)
 * 
 * kprintf outputs to both VGA and serial simultaneously.
 * 
 * Why both?
 *   ✅ VGA: User sees output on screen
 *   ✅ Serial: Developer can log output to file
 *   ✅ Redundancy: If one fails, other still works
 * 
 * Alternative: Separate functions
 *   vga_printf(), serial_printf()
 *   ❌ More code, more typing
 *   ❌ Easy to forget one
 *   ❌ Output can get out of sync
 * 
 * Implementation:
 *   kputc(char c) {
 *       console_putc(c);  // VGA
 *       serial_putc(c);   // Serial
 *   }
 * 
 * 
 * DECISION 2: NO FLOATING POINT
 * 
 * kprintf does not support %f, %e, %g (floating point).
 * 
 * Why not?
 *   - Kernel rarely needs floating point
 *   - Adds 10+ KB of code (float-to-string conversion is complex)
 *   - FPU may not be initialized at boot
 *   - Can cause issues in interrupt handlers
 * 
 * Workaround if needed:
 *   Print as fixed-point:
 *     float temp = 98.6;
 *     int whole = (int)temp;
 *     int frac = (int)((temp - whole) * 100);
 *     kprintf("%d.%02d", whole, frac);  // "98.60"
 * 
 * 
 * DECISION 3: SIMPLE LENGTH MODIFIERS
 * 
 * kprintf only supports l and ll, not hh, h, z, t.
 * 
 * Why?
 *   - l and ll cover most use cases
 *   - hh and h are rarely needed (arguments promoted anyway)
 *   - z and t can be worked around (cast to unsigned long)
 * 
 * Example:
 *   size_t size = 1024;
 *   kprintf("%lu", (unsigned long)size);  // Cast to unsigned long
 * 
 * 
 * DECISION 4: NO PRECISION FIELD
 * 
 * Standard printf supports %.precision (e.g., %.2f, %.10s).
 * kprintf does not.
 * 
 * Why not?
 *   - Width is more useful (alignment)
 *   - Precision is mainly for floats (which we don't support)
 *   - String truncation rarely needed in kernel
 * 
 * Workaround for string truncation:
 *   char buf[11];
 *   strncpy(buf, long_string, 10);
 *   buf[10] = '\0';
 *   kprintf("%s", buf);
 * 
 * 
 * DECISION 5: STACK BUFFERS (NO ALLOCATION)
 * 
 * kprintf uses stack buffers for number conversion.
 * 
 * Buffer sizes:
 *   char buf[32];  // Max 32 digits (enough for 64-bit in binary)
 * 
 * Why stack (not heap)?
 *   ✅ Fast (no allocation overhead)
 *   ✅ Safe (no malloc failures)
 *   ✅ Simple (no memory management)
 *   ✅ Works before heap is initialized
 * 
 * Why 32 bytes?
 *   - 64-bit number in binary: 64 digits max
 *   - 64-bit number in decimal: 20 digits max
 *   - 64-bit number in hex: 16 digits max
 *   - 32 is safe upper bound
 * 
 * 
 * DECISION 6: NO BUFFERING
 * 
 * kprintf outputs character-by-character.
 * Standard printf buffers output for efficiency.
 * 
 * Why no buffering?
 *   ✅ Simple (no buffer management)
 *   ✅ Immediate output (debugging-friendly)
 *   ✅ Safe in crashes (partial output visible)
 * 
 * Downside:
 *   ❌ Slower (many small I/O operations)
 *   ❌ But speed is not critical for debug output
 * 
 * 
 * DECISION 7: REVERSE DIGIT ORDER
 * 
 * u64_to_str generates digits in reverse order.
 * Print loop reads buffer backwards.
 * 
 * Why?
 *   - Number-to-string algorithm naturally produces reversed digits
 *   - Simpler than:
 *     a. Generate digits, then reverse
 *     b. Calculate length first, then fill buffer forwards
 * 
 * Example:
 *   u64_to_str(42, 10, false, buf) → buf = ['2', '4']
 *   Print: for (i=1; i>=0; i--) print(buf[i]) → "42"
 * 
 * Alternative (not used):
 *   Generate: ['2', '4']
 *   Reverse: ['4', '2']
 *   Print forward: "42"
 *   (Extra reversal step, more complex)
 * 
 * 
 * DECISION 8: TWO PRINT FUNCTIONS
 * 
 * print_signed() for signed integers
 * print_unsigned() for unsigned integers
 * 
 * Why separate?
 *   - Different handling (sign vs prefix)
 *   - Clearer code (separate concerns)
 *   - Easier to maintain
 * 
 * Alternative (not used):
 *   One print_number() function with flags
 *   ❌ More complex (many if statements)
 *   ❌ Harder to understand
 *
 *=============================================================================
 * SECTION 10: COMMON PITFALLS AND SOLUTIONS
 *=============================================================================
 * 
 * PITFALL 1: TYPE MISMATCH
 * 
 * Problem:
 *   long long x = 123456789;
 *   kprintf("%d", x);  // WRONG! %d expects int, x is long long
 * 
 * Result:
 *   Only reads 4 bytes (lower 32 bits)
 *   Output is wrong or garbage
 * 
 * Solution:
 *   kprintf("%lld", x);  // Correct! Use %lld for long long
 * 
 * 
 * PITFALL 2: MISSING ARGUMENT
 * 
 * Problem:
 *   kprintf("x=%d y=%d\n", x);  // WRONG! Missing y argument
 * 
 * Result:
 *   Reads garbage from stack for y
 *   Undefined behavior
 * 
 * Solution:
 *   kprintf("x=%d y=%d\n", x, y);  // Provide all arguments
 * 
 * 
 * PITFALL 3: EXTRA ARGUMENT
 * 
 * Problem:
 *   kprintf("x=%d\n", x, y);  // WRONG! y is unused
 * 
 * Result:
 *   y is ignored (left on stack)
 *   Not an error, but wasteful and confusing
 * 
 * Solution:
 *   kprintf("x=%d\n", x);  // Remove extra argument
 *   // Or add format: kprintf("x=%d y=%d\n", x, y);
 * 
 * 
 * PITFALL 4: UNTERMINATED STRING
 * 
 * Problem:
 *   char buf[5] = {'H','e','l','l','o'};  // No '\0'!
 *   kprintf("%s", buf);
 * 
 * Result:
 *   Prints "Hello" plus garbage until '\0' found
 *   May read beyond buffer (crash)
 * 
 * Solution:
 *   char buf[6] = "Hello";  // Includes '\0'
 *   // Or: buf[5] = '\0';
 * 
 * 
 * PITFALL 5: PRINTF IN INTERRUPT HANDLER
 * 
 * Problem:
 *   void timer_interrupt() {
 *       kprintf("Tick\n");  // Dangerous!
 *   }
 * 
 * Why dangerous?
 *   - kprintf may be interrupted mid-execution
 *   - Console/serial state may be corrupted
 *   - Can deadlock if kprintf uses locks
 * 
 * Solution:
 *   Use direct VGA writes for interrupts:
 *   *(uint16_t*)(0xB8000 + offset) = 0x0F00 | '.';
 *   
 *   Or buffer message, print later:
 *   irq_message = "Tick";
 *   irq_flag = true;
 *   // Main loop: if (irq_flag) { kprintf("%s\n", irq_message); }
 * 
 * 
 * PITFALL 6: FORGETTING %%
 * 
 * Problem:
 *   kprintf("100% complete\n");  // WRONG! % is special
 * 
 * Result:
 *   Tries to parse format specifier
 *   ' c' is not valid specifier
 *   Prints "%c" literally (or crashes)
 * 
 * Solution:
 *   kprintf("100%% complete\n");  // Correct! Use %%
 * 
 * 
 * PITFALL 7: WIDTH OVERFLOW
 * 
 * Problem:
 *   kprintf("%1000d", 42);  // 1000-character width!
 * 
 * Result:
 *   Prints 998 spaces + "42"
 *   Very slow (1000 serial transmissions)
 *   May exceed screen width (VGA wraps)
 * 
 * Solution:
 *   Use reasonable widths (typically 2-20)
 *   kprintf("%10d", 42);  // Reasonable
 * 
 * 
 * PITFALL 8: SIGNED VS UNSIGNED HEX
 * 
 * Problem:
 *   int x = -1;
 *   kprintf("%x", x);  // What's printed?
 * 
 * Result:
 *   Prints "ffffffff" (2^32 - 1 on 32-bit)
 *   -1 is interpreted as unsigned
 * 
 * This is correct behavior!
 *   %x is for UNSIGNED hex
 *   Negative numbers have no sign in hex
 *   -1 = 0xFFFFFFFF in two's complement
 * 
 * If you want to show negativity:
 *   kprintf("%d", x);  // "-1" (decimal)
 *   // Or: kprintf("-%x", -x);  // "-1" (hex with sign)
 * 
 * 
 * PITFALL 9: NULL POINTER STRING
 * 
 * Problem:
 *   char* str = NULL;
 *   kprintf("%s", str);  // Dangerous!
 * 
 * Standard printf behavior: Undefined (usually crash)
 * 
 * TinyOS behavior: Prints "(null)" (safe)
 *   if (!s) s = "(null)";
 * 
 * Better approach: Check before calling
 *   if (str) kprintf("%s", str);
 *   else kprintf("(none)");
 * 
 * 
 * PITFALL 10: MIXING DECIMAL AND HEX
 * 
 * Problem:
 *   kprintf("value = %d %x\n", 42, 42);
 *   Output: "value = 42 2a"
 * 
 * Not wrong, but can be confusing!
 *   42 decimal = 2A hex
 *   Same value, different representation
 * 
 * Clarify with labels:
 *   kprintf("value = %d (0x%x)\n", 42, 42);
 *   Output: "value = 42 (0x2a)"
 *
 *=============================================================================
 * SECTION 11: PERFORMANCE CONSIDERATIONS
 *=============================================================================
 * 
 * kprintf is SLOW by design. It's for debugging, not production output.
 * 
 * BOTTLENECKS:
 * 
 * 1. SERIAL OUTPUT (Slowest)
 *    - 115200 baud = 11,520 bytes/second
 *    - Each character: ~86 microseconds
 *    - Polling (waiting for TX ready): Wastes CPU
 * 
 * 2. VGA OUTPUT (Fast)
 *    - Direct memory write: ~1-2 CPU cycles
 *    - No waiting, just memory store
 *    - Much faster than serial
 * 
 * 3. NUMBER CONVERSION (Medium)
 *    - Division in loop: ~10-50 cycles per digit
 *    - For 64-bit: ~20 divisions (decimal)
 *    - Total: ~200-1000 cycles
 * 
 * 4. FORMAT PARSING (Fast)
 *    - String scanning: ~1-2 cycles per character
 *    - Negligible compared to output
 * 
 * TIMING EXAMPLES (Rough estimates):
 * 
 * kprintf("Hello\n");
 *   - 6 characters
 *   - Serial: 6 × 86 µs = 516 µs
 *   - VGA: 6 × 2 cycles = 12 cycles ≈ 0.012 µs
 *   - Total: ~516 µs (serial dominates!)
 * 
 * kprintf("%d", 12345);
 *   - Conversion: ~500 cycles ≈ 0.5 µs
 *   - 5 characters output
 *   - Serial: 5 × 86 µs = 430 µs
 *   - Total: ~430 µs
 * 
 * kprintf("addr=0x%08x\n", ptr);
 *   - 15 characters total
 *   - Conversion: ~300 cycles ≈ 0.3 µs
 *   - Serial: 15 × 86 µs = 1290 µs
 *   - Total: ~1.3 milliseconds!
 * 
 * OPTIMIZATION OPPORTUNITIES (Not done in TinyOS):
 * 
 * 1. Remove serial output (10x faster!)
 *    - Only output to VGA
 *    - But lose logging capability
 * 
 * 2. Buffer output
 *    - Collect characters in buffer
 *    - Flush buffer periodically or when full
 *    - Reduces serial overhead (fewer waits)
 * 
 * 3. Interrupt-driven serial
 *    - Don't wait for TX ready
 *    - Let interrupt handler send when ready
 *    - Requires buffer and IRQ handler
 * 
 * 4. Optimize number conversion
 *    - Use faster division algorithms
 *    - Lookup tables for small numbers
 *    - SIMD for multiple digits at once
 * 
 * 5. Cache format strings
 *    - Parse format once, save state
 *    - Reuse for repeated prints
 *    - Helps for hot-path logging
 * 
 * WHY NOT OPTIMIZE?
 * 
 * For TinyOS (learning OS):
 *   ✅ Simple code is more important than speed
 *   ✅ Easy to understand and modify
 *   ✅ kprintf is for debugging (infrequent)
 *   ✅ Performance is "fast enough"
 * 
 * For production OS (Linux, FreeBSD):
 *   - Heavy optimization (buffering, caching, etc.)
 *   - Separate fast path for common cases
 *   - Compile-time format checking
 *   - Lock-free algorithms
 * 
 * WHEN TO WORRY ABOUT PERFORMANCE:
 * 
 * Don't optimize unless:
 *   1. kprintf is on hot path (called frequently)
 *   2. Profiling shows it's a bottleneck
 *   3. User-visible slowdown occurs
 * 
 * In kernel, this rarely happens because:
 *   - Debug output should be rare
 *   - Most time spent in application code
 *   - I/O and interrupts are real bottlenecks
 * 
 * MEMORY USAGE:
 * 
 * Stack usage per kprintf call:
 *   - va_list: ~16 bytes (pointer + state)
 *   - Local buffers: 32 bytes (digit buffer)
 *   - Local variables: ~32 bytes
 *   - Total: ~80 bytes per call
 * 
 * This is fine for kernel stack (usually 4-8 KB).
 * 
 * Code size:
 *   - kprintf.c compiled: ~2-3 KB
 *   - Reasonable for kernel (total kernel: ~50-100 KB)
 *
 *=============================================================================
 * SECTION 12: INTEGRATION WITH THE KERNEL
 *=============================================================================
 * 
 * WHERE KPRINTF IS USED IN TINYOS:
 * 
 * 1. BOOT MESSAGES (kernel.c)
 *    kprintf("TinyOS - Multiboot2 Kernel\n");
 *    kprintf("Initializing IDT...\n");
 *    kprintf("PMM: %d total frames, %d free\n", total, free);
 * 
 * 2. EXCEPTION HANDLERS (interrupts.c)
 *    kprintf("\nEXCEPTION: %s (vec=%d)\n", name, vector);
 *    kprintf("  EIP=%08x  CS=%04x  EFLAGS=%08x\n", eip, cs, eflags);
 * 
 * 3. DEBUGGING (everywhere)
 *    kprintf("DEBUG: Entering function %s\n", __func__);
 *    kprintf("DEBUG: ptr=%p size=%u\n", ptr, size);
 * 
 * 4. NOT IN INTERRUPT HANDLERS!
 *    Timer IRQ uses direct VGA write, not kprintf
 *    Why? kprintf is not reentrant-safe
 * 
 * INITIALIZATION ORDER:
 * 
 * kprintf depends on:
 *   1. serial_init() - Must be called first!
 *   2. console_clear() - Should be called first
 * 
 * Typical boot sequence:
 *   serial_init();        // Enable serial output
 *   console_clear();      // Clear VGA screen
 *   kprintf("Booting...\n");  // Now kprintf works!
 * 
 * DEPENDENCY GRAPH:
 * 
 *   kprintf.c (THIS FILE)
 *     ↓ calls
 *   ├── console_putc() (vga.c) → VGA output
 *   └── serial_putc() (serial.c) → Serial output
 *     ↑ uses
 *   kernel.h (types, declarations)
 *   stdarg.h (va_list, va_start, va_arg, va_end)
 * 
 * REENTRANCE AND THREAD SAFETY:
 * 
 * kprintf is NOT reentrant:
 *   - If interrupted mid-execution, state corrupted
 *   - VGA cursor position may be wrong
 *   - Serial output may interleave
 * 
 * This matters for:
 *   ❌ Interrupt handlers (don't use kprintf!)
 *   ❌ Multi-threaded code (need locks)
 * 
 * TinyOS is single-threaded, so not a problem currently.
 * 
 * ALTERNATIVES TO KPRINTF:
 * 
 * For interrupts:
 *   Direct VGA write: *(uint16_t*)0xB8000 = 0x0F00 | '.';
 * 
 * For production:
 *   Separate functions: printk() (kernel), printf() (userspace)
 * 
 * For logging:
 *   Ring buffer: Store messages, print later
 *   Log levels: DEBUG, INFO, WARN, ERROR
 * 
 * FUTURE ENHANCEMENTS:
 * 
 * This file could be extended with:
 * 
 * 1. snprintf() - Print to string buffer
 *    int snprintf(char* buf, size_t size, const char* fmt, ...);
 * 
 * 2. Log levels
 *    kprintf_debug("Debug message\n");
 *    kprintf_info("Info message\n");
 *    kprintf_error("Error message\n");
 * 
 * 3. Compile-time format checking
 *    __attribute__((format(printf, 1, 2)))
 * 
 * 4. Color support
 *    kprintf_color(RED, "Error: %s\n", msg);
 * 
 * 5. Binary format (%b)
 *    kprintf("%08b", 42); → "00101010"
 * 
 * 6. * width/precision
 *    kprintf("%*d", width, value);
 * 
 * 7. More length modifiers (z, t)
 *    kprintf("%zu", sizeof(x));
 * 
 * 8. Floating point (%f)
 *    Only if really needed (large code size!)
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "kernel.h"
#include "serial.h"
#include <stdarg.h>   // va_list, va_start, va_arg, va_end
#include <stdint.h>   // uint64_t, uintptr_t, etc.
#include <stdbool.h>  // bool, true, false

/*=============================================================================
 * LOW-LEVEL UNIFIED OUTPUT SINK
 *=============================================================================
 * 
 * These functions provide the foundation for all kprintf output.
 * They simultaneously write to both VGA console and serial port.
 */

/**
 * kputc - Output a single character to both VGA and serial
 * 
 * PARAMETERS:
 *   c - Character to output
 * 
 * BEHAVIOR:
 *   1. Write to VGA text console (visible on screen)
 *   2. Write to serial port (logged to host)
 * 
 * THREAD SAFETY:
 *   NOT thread-safe. Both console_putc and serial_putc modify global state.
 * 
 * PERFORMANCE:
 *   - console_putc: ~2 CPU cycles (direct memory write)
 *   - serial_putc: ~86 microseconds (waits for UART)
 *   - Total: Dominated by serial output
 * 
 * INLINE:
 *   Marked inline for performance (avoid function call overhead).
 *   Compiler may or may not inline (it's a hint, not a command).
 * 
 * USAGE:
 *   Internal function, called by kprintf implementation.
 *   Not intended for direct use by kernel code.
 */
static inline void kputc(char c) {
    console_putc(c);  /* Write to VGA (screen) */
    serial_putc(c);   /* Write to serial (log) */
}

/**
 * kputs - Output a null-terminated string to both VGA and serial
 * 
 * PARAMETERS:
 *   s - Pointer to null-terminated string
 * 
 * BEHAVIOR:
 *   Calls kputc() for each character until '\0' encountered.
 * 
 * SAFETY:
 *   Assumes s is valid and null-terminated.
 *   NULL pointer will crash (no check).
 * 
 * PERFORMANCE:
 *   For "Hello" (5 chars): 5 × 86 µs ≈ 430 microseconds
 * 
 * USAGE:
 *   Internal helper function.
 *   Used by format parsing code for literal strings.
 */
static void kputs(const char* s) {
    while (*s) {
        kputc(*s++);
    }
}

/*=============================================================================
 * NUMBER-TO-STRING CONVERSION HELPERS
 *=============================================================================
 */

/**
 * u64_to_str - Convert unsigned 64-bit number to string (reversed digits)
 * 
 * PARAMETERS:
 *   v - Value to convert
 *   base - Number base (2-16: binary, octal, decimal, hex)
 *   upper - Use uppercase digits (A-F) vs lowercase (a-f) for hex
 *   out_rev - Buffer to store reversed digits (must be at least 65 bytes)
 * 
 * RETURN VALUE:
 *   Number of digits generated
 * 
 * ALGORITHM:
 *   Repeated division by base, collecting remainders.
 *   Remainders are the digits, in reverse order.
 * 
 * EXAMPLE:
 *   u64_to_str(42, 10, false, buf)
 *   Step 1: 42 % 10 = 2, 42 / 10 = 4  → buf[0] = '2'
 *   Step 2: 4 % 10 = 4, 4 / 10 = 0    → buf[1] = '4'
 *   Result: buf = ['2', '4'], return 2
 * 
 * WHY REVERSED?
 *   Division produces digits right-to-left (least significant first).
 *   Storing reversed avoids needing to calculate length beforehand.
 *   Print loop reads buffer backwards to get correct order.
 * 
 * DIGIT TABLES:
 *   L (lowercase): "0123456789abcdef"
 *   U (uppercase): "0123456789ABCDEF"
 *   
 *   Remainder 0-9: '0'-'9' (same for both)
 *   Remainder 10-15: 'a'-'f' (lowercase) or 'A'-'F' (uppercase)
 * 
 * SPECIAL CASE:
 *   If v == 0, return "0" (one digit).
 *   Without this check, loop wouldn't execute (wrong!).
 * 
 * BUFFER SIZE:
 *   Maximum digits needed:
 *     - Binary (base 2): 64 bits = 64 digits
 *     - Decimal (base 10): 20 digits (max for 64-bit: 18,446,744,073,709,551,615)
 *     - Hex (base 16): 16 digits
 *   
 *   32 bytes is safe upper bound (supports all bases).
 * 
 * PERFORMANCE:
 *   - Each iteration: 1 division, 1 modulo, 1 array store
 *   - Division is slowest operation (~10-50 cycles on i386)
 *   - For 64-bit number in decimal: ~20 divisions ≈ 200-1000 cycles
 *   - Total: ~1-5 microseconds (negligible compared to output)
 */
static int u64_to_str(uint64_t v, unsigned base, bool upper, char* out_rev) {
    /* Digit tables for base conversion */
    static const char L[] = "0123456789abcdef";  /* Lowercase hex */
    static const char U[] = "0123456789ABCDEF";  /* Uppercase hex */
    const char* D = upper ? U : L;               /* Select table */

    int n = 0;  /* Digit count */

    /* Special case: zero */
    if (v == 0) {
        out_rev[n++] = '0';
        return n;
    }

    /* Repeated division to extract digits */
    while (v) {
        out_rev[n++] = D[v % base];  /* Get remainder, map to digit */
        v /= base;                   /* Reduce number */
    }

    return n;
}

/**
 * emit_pad - Output padding characters
 * 
 * PARAMETERS:
 *   count - Number of padding characters to output
 *   ch - Padding character (typically ' ' or '0')
 * 
 * BEHAVIOR:
 *   Outputs 'ch' character 'count' times.
 * 
 * EXAMPLE:
 *   emit_pad(5, ' ')  → "     " (5 spaces)
 *   emit_pad(3, '0')  → "000"   (3 zeros)
 * 
 * USAGE:
 *   Used for width padding in format specifiers.
 *   Example: %10d with 42 → emit_pad(8, ' ') then "42"
 * 
 * PERFORMANCE:
 *   count × output_time
 *   For emit_pad(100, ' '): 100 × 86 µs = 8.6 milliseconds!
 *   (This is why large widths are slow)
 */
static void emit_pad(int count, char ch) {
    while (count-- > 0) {
        kputc(ch);
    }
}

/*=============================================================================
 * CORE PRINT FUNCTIONS
 *=============================================================================
 */

/**
 * print_signed - Print signed integer with formatting
 * 
 * PARAMETERS:
 *   val - Signed integer value
 *   base - Number base (usually 10 for decimal)
 *   upper - Use uppercase digits (not used for decimal)
 *   width - Minimum field width
 *   left - Left-justify (otherwise right-justify)
 *   zero - Pad with zeros (otherwise spaces)
 * 
 * BEHAVIOR:
 *   1. Convert to absolute value (handle sign separately)
 *   2. Convert number to string (reversed digits)
 *   3. Calculate padding needed
 *   4. Output in correct order:
 *      - Right-justify: padding, sign, digits
 *      - Left-justify: sign, digits, padding
 * 
 * SIGN HANDLING:
 *   - Negative: Add '-' sign before digits
 *   - Positive: No sign (could add '+' with flag, but TinyOS doesn't support)
 * 
 * ZERO-PADDING WITH SIGN:
 *   Sign must come BEFORE zeros:
 *     Correct: "-0042" (sign, then zeros, then digits)
 *     Wrong: "0-042" (confusing! looks like "0 - 42")
 * 
 * EXAMPLE: %05d with -42
 *   1. val = -42, neg = true, u = 42
 *   2. Convert 42: buf = ['2', '4'], nd = 2
 *   3. len = 2 + 1 = 3 (2 digits + sign)
 *   4. pads = 5 - 3 = 2
 *   5. Output: (no left padding), "-", "00", "42"
 *   6. Result: "-0042"
 * 
 * EXAMPLE: %-5d with -42
 *   1-3. Same as above
 *   4. pads = 5 - 3 = 2
 *   5. Output: "-", "42", "  " (2 spaces)
 *   6. Result: "-42  "
 */
static void print_signed(long long val, unsigned base,
                         bool upper, int width, bool left, bool zero) {
    char buf[32];  /* Buffer for digits (reversed) */
    bool neg = (val < 0);  /* Check sign */

    /* Convert to unsigned (handle most negative number correctly) */
    uint64_t u = neg ? (uint64_t)(-(long long)val) : (uint64_t)val;

    /* Convert to string (digits reversed) */
    int nd = u64_to_str(u, base, upper, buf);

    /* Calculate total length (digits + sign if negative) */
    int len = nd + (neg ? 1 : 0);

    /* Calculate padding needed */
    int pads = (width > len) ? (width - len) : 0;

    /* Output with correct order */
    if (!left) {
        /* Right-justify */
        if (zero) {
            /* Zero-padding: sign first, then zeros, then digits */
            if (neg) kputc('-');
            emit_pad(pads, '0');
        } else {
            /* Space-padding: spaces, then sign, then digits */
            emit_pad(pads, ' ');
            if (neg) kputc('-');
        }
    } else {
        /* Left-justify: sign, digits, then spaces */
        if (neg) kputc('-');
    }

    /* Output digits (reversed, so print backwards) */
    for (int i = nd - 1; i >= 0; --i) {
        kputc(buf[i]);
    }

    /* Left-justify padding (always spaces) */
    if (left) {
        emit_pad(pads, ' ');
    }
}

/**
 * print_unsigned - Print unsigned integer with formatting
 * 
 * PARAMETERS:
 *   u - Unsigned integer value
 *   base - Number base (10 for decimal, 16 for hex)
 *   upper - Use uppercase digits for hex (A-F vs a-f)
 *   width - Minimum field width
 *   left - Left-justify (otherwise right-justify)
 *   zero - Pad with zeros (otherwise spaces)
 *   prefix - Optional prefix string (e.g., "0x" for pointers)
 * 
 * BEHAVIOR:
 *   Similar to print_signed, but no sign handling.
 *   Optional prefix (used for %p to show "0x").
 * 
 * PREFIX:
 *   - NULL: No prefix
 *   - "0x": Hex prefix (for %p)
 *   - "0": Octal prefix (not used in TinyOS)
 * 
 * PREFIX AND WIDTH:
 *   Prefix counts toward total width:
 *     %8p with ptr → "0x" (2 chars) + 6 hex digits = 8 chars total
 * 
 * EXAMPLE: %08x with 0xAB
 *   1. u = 0xAB
 *   2. Convert: buf = ['b', 'a'], nd = 2
 *   3. prefix = NULL, prefix_len = 0
 *   4. len = 0 + 2 = 2
 *   5. pads = 8 - 2 = 6
 *   6. Output: "000000", "ab"
 *   7. Result: "000000ab"
 * 
 * EXAMPLE: %p with 0x1234
 *   1. u = 0x1234
 *   2. Convert: buf = ['4', '3', '2', '1'], nd = 4
 *   3. prefix = "0x", prefix_len = 2
 *   4. len = 2 + 4 = 6
 *   5. width = 8 + 2 = 10 (default for %p)
 *   6. pads = 10 - 6 = 4
 *   7. Output: "0000", "0x", "1234"
 *   8. Result: "0x00001234"
 */
static void print_unsigned(uint64_t u, unsigned base,
                           bool upper, int width, bool left, bool zero,
                           const char* prefix) {
    char buf[32];  /* Buffer for digits (reversed) */

    /* Convert to string (digits reversed) */
    int nd = u64_to_str(u, base, upper, buf);

    /* Calculate prefix length */
    int prefix_len = 0;
    if (prefix) {
        while (prefix[prefix_len]) prefix_len++;
    }

    /* Calculate total length (prefix + digits) */
    int len = prefix_len + nd;

    /* Calculate padding needed */
    int pads = (width > len) ? (width - len) : 0;

    /* Output with correct order */
    if (!left) {
        /* Right-justify: padding, prefix, digits */
        emit_pad(pads, zero ? '0' : ' ');
    }

    /* Output prefix (if any) */
    if (prefix) {
        kputs(prefix);
    }

    /* Output digits (reversed, so print backwards) */
    for (int i = nd - 1; i >= 0; --i) {
        kputc(buf[i]);
    }

    /* Left-justify padding (always spaces) */
    if (left) {
        emit_pad(pads, ' ');
    }
}

/*=============================================================================
 * FUNCTION: kprintf
 *=============================================================================
 * 
 * PURPOSE:
 *   Formatted output to VGA console and serial port.
 *   Main entry point for all kernel output.
 * 
 * SIGNATURE:
 *   void kprintf(const char* fmt, ...);
 * 
 * PARAMETERS:
 *   fmt - Format string with % specifiers
 *   ... - Variable arguments matching format specifiers
 * 
 * RETURN VALUE:
 *   None (void function)
 *   Standard printf returns character count, but we don't.
 * 
 * FORMAT STRING:
 *   %[flags][width][length]specifier
 *   
 *   Flags: -, 0
 *   Width: Decimal number (minimum field width)
 *   Length: l, ll
 *   Specifier: c, s, d, i, u, x, X, p, %
 * 
 * EXAMPLES:
 *   kprintf("Hello, World!\n");
 *   kprintf("x = %d\n", 42);
 *   kprintf("addr = %p\n", ptr);
 *   kprintf("%08x", value);
 *   kprintf("%-10s: %5d\n", "Count", count);
 * 
 * ALGORITHM:
 *   1. Initialize variadic argument list (va_start)
 *   2. Loop through format string:
 *      a. If literal character: Output it
 *      b. If '%': Parse format specifier
 *         - Parse flags (-, 0)
 *         - Parse width (digits)
 *         - Parse length (l, ll)
 *         - Process conversion specifier
 *         - Extract argument from va_list
 *         - Format and output value
 *   3. Clean up argument list (va_end)
 * 
 * SAFETY:
 *   - No buffer overflow (stack buffers are sized correctly)
 *   - NULL string pointer handled ("%s" with NULL → "(null)")
 *   - Unknown specifier: Print % and specifier literally
 * 
 * THREAD SAFETY:
 *   NOT thread-safe (console and serial have global state).
 *   Do NOT call from interrupt handlers!
 * 
 * PERFORMANCE:
 *   Slow (serial output dominates).
 *   Typical call: 0.5-5 milliseconds depending on string length.
 * 
 * USAGE:
 *   Called from anywhere in kernel (except interrupt handlers).
 *   Primary debug output mechanism for TinyOS.
 */
void kprintf(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);  /* Initialize argument list */

    /* Loop through format string */
    for (const char* p = fmt; *p; ++p) {
        /* Check for format specifier */
        if (*p != '%') {
            /* Literal character: output directly */
            kputc(*p);
            continue;
        }

        /*=====================================================================
         * FORMAT SPECIFIER PARSING
         *=====================================================================
         * We've encountered '%', now parse the complete format specifier.
         * Format: %[flags][width][length]specifier
         */

        /* STEP 1: PARSE FLAGS (-, 0) */
        bool left = false;  /* - flag: Left-justify */
        bool zero = false;  /* 0 flag: Zero-padding */
        bool parsing = true;

        while (parsing) {
            switch (*++p) {
                case '-':
                    left = true;
                    break;
                case '0':
                    zero = true;
                    break;
                default:
                    parsing = false;
                    break;
            }
            if (parsing == false) break;
        }

        /* FLAG INTERACTION: - overrides 0 */
        if (left) zero = false;

        /* STEP 2: PARSE WIDTH (decimal digits) */
        int width = 0;
        while (*p >= '0' && *p <= '9') {
            width = width * 10 + (*p - '0');
            ++p;
        }

        /* STEP 3: PARSE LENGTH MODIFIER (l, ll) */
        enum { LEN_DEF, LEN_L, LEN_LL } len = LEN_DEF;
        if (*p == 'l') {
            if (*(p+1) == 'l') {
                /* Found "ll" */
                len = LEN_LL;
                p += 2;
            } else {
                /* Found "l" */
                len = LEN_L;
                ++p;
            }
        }

        /* STEP 4: PROCESS CONVERSION SPECIFIER */
        char c = *p;
        switch (c) {
            /*=================================================================
             * %c - CHARACTER
             *=================================================================*/
            case 'c': {
                /* Extract character argument (promoted to int) */
                int ch = va_arg(ap, int);

                /* Calculate padding */
                int pads = (width > 1) ? (width - 1) : 0;

                /* Output with correct alignment */
                if (!left) emit_pad(pads, ' ');
                kputc((char)ch);
                if (left) emit_pad(pads, ' ');
            } break;

            /*=================================================================
             * %s - STRING
             *=================================================================*/
            case 's': {
                /* Extract string argument */
                const char* s = va_arg(ap, const char*);

                /* NULL safety: Print "(null)" instead of crashing */
                if (!s) s = "(null)";

                /* Calculate string length */
                int n = 0;
                while (s[n]) n++;

                /* Calculate padding */
                int pads = (width > n) ? (width - n) : 0;

                /* Output with correct alignment */
                if (!left) emit_pad(pads, ' ');
                kputs(s);
                if (left) emit_pad(pads, ' ');
            } break;

            /*=================================================================
             * %d, %i - SIGNED DECIMAL INTEGER
             *=================================================================*/
            case 'd':
            case 'i': {
                /* Extract integer argument (handle different sizes) */
                long long v = (len == LEN_LL) ? va_arg(ap, long long)
                              : (len == LEN_L)  ? (long long)va_arg(ap, long)
                                                : (long long)va_arg(ap, int);

                /* Print signed decimal */
                print_signed(v, 10, false, width, left, zero);
            } break;

            /*=================================================================
             * %u - UNSIGNED DECIMAL INTEGER
             *=================================================================*/
            case 'u': {
                /* Extract unsigned integer argument */
                unsigned long long v = (len == LEN_LL) ? va_arg(ap, unsigned long long)
                                        : (len == LEN_L)  ? (unsigned long long)va_arg(ap, unsigned long)
                                                          : (unsigned long long)va_arg(ap, unsigned int);

                /* Print unsigned decimal (no prefix) */
                print_unsigned(v, 10, false, width, left, zero, NULL);
            } break;

            /*=================================================================
             * %x, %X - UNSIGNED HEXADECIMAL
             *=================================================================*/
            case 'x':
            case 'X': {
                /* Determine case (lowercase vs uppercase) */
                bool upper = (c == 'X');

                /* Extract unsigned integer argument */
                unsigned long long v = (len == LEN_LL) ? va_arg(ap, unsigned long long)
                                        : (len == LEN_L)  ? (unsigned long long)va_arg(ap, unsigned long)
                                                          : (unsigned long long)va_arg(ap, unsigned int);

                /* Print unsigned hex (no prefix) */
                print_unsigned(v, 16, upper, width, left, zero, NULL);
            } break;

            /*=================================================================
             * %p - POINTER
             *=================================================================*/
            case 'p': {
                /* Extract pointer argument */
                uintptr_t v = (uintptr_t)va_arg(ap, void*);

                /* Default width: 8 hex digits + "0x" = 10 chars on i386 */
                /* User can override: %12p */
                int w = (width > 0) ? width : 8;

                /* Print with "0x" prefix */
                print_unsigned((uint64_t)v, 16, false, w + 2, left, zero, "0x");
            } break;

            /*=================================================================
             * %% - LITERAL PERCENT
             *=================================================================*/
            case '%':
                kputc('%');
                break;

            /*=================================================================
             * UNKNOWN SPECIFIER
             *=================================================================*/
            default:
                /* Print % and specifier literally (helps catch typos) */
                kputc('%');
                kputc(c);
                break;
        }
    }

    /* Clean up argument list (required!) */
    va_end(ap);
}

/*=============================================================================
 * END OF FILE: kprintf.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Implemented kprintf with format string parsing
 *   ✅ Support for c, s, d, i, u, x, X, p format specifiers
 *   ✅ Width and padding (-, 0 flags)
 *   ✅ Length modifiers (l, ll for 64-bit)
 *   ✅ Dual output (VGA + serial simultaneously)
 *   ✅ No dependencies (except stdarg.h)
 *   ✅ Comprehensive documentation for learning
 * 
 * WHAT HAPPENS NEXT:
 *   → kprintf is called throughout kernel for all output
 *   → Boot messages, debugging, errors all use kprintf
 *   → See kernel.c for usage examples
 * 
 * KEY TAKEAWAYS:
 *   1. printf is essential for debugging and user interaction
 *   2. Variadic functions use stdarg.h (va_list, va_start, va_arg, va_end)
 *   3. Format parsing is a state machine (flags, width, length, specifier)
 *   4. Number-to-string uses repeated division algorithm
 *   5. Width and padding enable aligned, formatted output
 *   6. Dual output (VGA + serial) provides maximum flexibility
 *   7. Simplicity > completeness (subset of features is adequate)
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - How variadic functions work at the ABI level
 *   - Format string parsing and state machines
 *   - Number-to-string conversion algorithms
 *   - Text formatting (width, padding, alignment)
 *   - How printf is implemented (it's not magic!)
 * 
 *   You've mastered one of the most complex and useful functions in C! 🎉
 *============================================================================*/
