/*=============================================================================
 *  kprintf.c — TinyOS unified printf (VGA + serial) with flags & width
 *============================================================================*/
#include "kernel.h"
#include "serial.h"
#include <stdarg.h>
#include <stdint.h>
#include <stdbool.h>

/* ---------- low-level unified sink ---------- */
static inline void kputc(char c) {          /* mirror to both sinks */
    console_putc(c);
    serial_putc(c);
}
static void kputs(const char* s) { while (*s) kputc(*s++); }

/* ---------- helpers ---------- */
static int u64_to_str(uint64_t v, unsigned base, bool upper, char* out_rev) {
    /* writes digits into out_rev backwards; returns count */
    static const char L[] = "0123456789abcdef";
    static const char U[] = "0123456789ABCDEF";
    const char* D = upper ? U : L;

    int n = 0;
    if (v == 0) { out_rev[n++] = '0'; return n; }
    while (v) { out_rev[n++] = D[v % base]; v /= base; }
    return n;
}

static void emit_pad(int count, char ch) { while (count-- > 0) kputc(ch); }

/* ---------- core print functions ---------- */
static void print_signed(long long val, unsigned base,
                         bool upper, int width, bool left, bool zero) {
    char buf[32];
    bool neg = (val < 0);
    uint64_t u = neg ? (uint64_t)(-(long long)val) : (uint64_t)val;

    int nd = u64_to_str(u, base, upper, buf);       /* digits reversed */
    int len = nd + (neg ? 1 : 0);                   /* include '-' if needed */

    int pads = (width > len) ? (width - len) : 0;
    if (!left) emit_pad(pads, zero ? '0' : ' ');
    if (neg) kputc('-');
    for (int i = nd - 1; i >= 0; --i) kputc(buf[i]);
    if (left) emit_pad(pads, ' ');
}

static void print_unsigned(uint64_t u, unsigned base,
                           bool upper, int width, bool left, bool zero,
                           const char* prefix) {
    char buf[32];
    int nd = u64_to_str(u, base, upper, buf);       /* digits reversed */

    int prefix_len = 0;
    if (prefix) while (prefix[prefix_len]) prefix_len++;

    int len = prefix_len + nd;
    int pads = (width > len) ? (width - len) : 0;

    if (!left) emit_pad(pads, zero ? '0' : ' ');
    if (prefix) kputs(prefix);
    for (int i = nd - 1; i >= 0; --i) kputc(buf[i]);
    if (left) emit_pad(pads, ' ');
}

/* ---------- printf with %, width, flags -,0 and length l/ll ---------- */
void kprintf(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);

    for (const char* p = fmt; *p; ++p) {
        if (*p != '%') { kputc(*p); continue; }

        /* parse flags */
        bool left = false, zero = false;
        bool parsing = true;
        while (parsing) {
            switch (*++p) {
                case '-': left = true;  break;
                case '0': zero = true;  break;
                default:  parsing = false; break;
            }
            if (parsing == false) break;
        }
        if (left) zero = false;  /* '-' overrides '0' */

        /* parse width */
        int width = 0;
        while (*p >= '0' && *p <= '9') {
            width = width * 10 + (*p - '0');
            ++p;
        }

        /* parse length: h, l, ll (we support l/ll only) */
        enum { LEN_DEF, LEN_L, LEN_LL } len = LEN_DEF;
        if (*p == 'l') {
            if (*(p+1) == 'l') { len = LEN_LL; p += 2; }
            else { len = LEN_L; ++p; }
        }

        /* conversion */
        char c = *p;
        switch (c) {
            case 'c': {
                int ch = va_arg(ap, int);
                int pads = (width > 1) ? (width - 1) : 0;
                if (!left) emit_pad(pads, ' ');
                kputc((char)ch);
                if (left) emit_pad(pads, ' ');
            } break;

            case 's': {
                const char* s = va_arg(ap, const char*);
                if (!s) s = "(null)";
                int n = 0; while (s[n]) n++;
                int pads = (width > n) ? (width - n) : 0;
                if (!left) emit_pad(pads, ' ');
                kputs(s);
                if (left) emit_pad(pads, ' ');
            } break;

            case 'd':
            case 'i': {
                long long v = (len==LEN_LL) ? va_arg(ap, long long)
                              : (len==LEN_L) ? (long long)va_arg(ap, long)
                                             : (long long)va_arg(ap, int);
                print_signed(v, 10, false, width, left, zero);
            } break;

            case 'u': {
                unsigned long long v = (len==LEN_LL) ? va_arg(ap, unsigned long long)
                                        : (len==LEN_L) ? (unsigned long long)va_arg(ap, unsigned long)
                                                       : (unsigned long long)va_arg(ap, unsigned int);
                print_unsigned(v, 10, false, width, left, zero, NULL);
            } break;

            case 'x':
            case 'X': {
                bool upper = (c == 'X');
                unsigned long long v = (len==LEN_LL) ? va_arg(ap, unsigned long long)
                                        : (len==LEN_L) ? (unsigned long long)va_arg(ap, unsigned long)
                                                       : (unsigned long long)va_arg(ap, unsigned int);
                print_unsigned(v, 16, upper, width, left, zero, NULL);
            } break;

            case 'p': {
                /* pointer width default: 8 hex chars on i386; respect explicit width if given */
                uintptr_t v = (uintptr_t)va_arg(ap, void*);
                int w = (width > 0) ? width : 8;
                print_unsigned((uint64_t)v, 16, false, w + 2, left, zero, "0x");
            } break;

            case '%':
                kputc('%'); break;

            default:
                /* unknown specifier: print it verbatim */
                kputc('%'); kputc(c); break;
        }
    }

    va_end(ap);
}
