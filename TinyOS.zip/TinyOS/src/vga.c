/*=============================================================================
* vga.c — Minimal console for VGA text mode (80x25)
*============================================================================*/
#include "kernel.h"


static volatile uint16_t* const vga = (uint16_t*)VGA_BUFFER_ADDR;
static uint8_t row = 0, col = 0, attr = VGA_DEFAULT_ATTR;


static inline void vga_put_at(char c, uint8_t a, uint8_t x, uint8_t y) {
vga[y * VGA_WIDTH + x] = (uint16_t)c | ((uint16_t)a << 8);
}


static void scroll(void) {
for (uint32_t y = 0; y < VGA_HEIGHT - 1; ++y)
for (uint32_t x = 0; x < VGA_WIDTH; ++x)
vga[y * VGA_WIDTH + x] = vga[(y + 1) * VGA_WIDTH + x];


for (uint32_t x = 0; x < VGA_WIDTH; ++x)
vga[(VGA_HEIGHT - 1) * VGA_WIDTH + x] = ' ' | ((uint16_t)attr << 8);
}


void console_clear(void) {
for (uint32_t y = 0; y < VGA_HEIGHT; ++y)
for (uint32_t x = 0; x < VGA_WIDTH; ++x)
vga_put_at(' ', attr, x, y);
row = col = 0;
}


static void advance(void) {
if (++col >= VGA_WIDTH) { col = 0; ++row; }
if (row >= VGA_HEIGHT) { scroll(); row = VGA_HEIGHT - 1; }
}


void console_putc(char c) {
if (c == '\n') {
col = 0; ++row;
if (row >= VGA_HEIGHT) { scroll(); row = VGA_HEIGHT - 1; }
return;
}
vga_put_at(c, attr, col, row);
advance();
}


void console_puts(const char* s) { while (*s) console_putc(*s++); }


void console_put_hex32(uint32_t v){
static const char H[] = "0123456789ABCDEF";
console_puts("0x");
for (int i = 7; i >= 0; --i) console_putc(H[(v >> (i*4)) & 0xF]);
}


void console_put_hex64(uint64_t v){
uint32_t hi = (uint32_t)(v >> 32), lo = (uint32_t)v;
if (hi) {
static const char H[] = "0123456789ABCDEF";
console_puts("0x");
for (int i=7;i>=0;--i) console_putc(H[(hi>>(i*4))&0xF]);
for (int i=7;i>=0;--i) console_putc(H[(lo>>(i*4))&0xF]);
} else {
console_put_hex32(lo);
}
}


void console_put_dec_u32(uint32_t v){
char buf[10]; int i=0;
if (!v) { console_putc('0'); return; }
while (v) { buf[i++] = '0' + (v % 10); v /= 10; }
while (i--) console_putc(buf[i]);
}


void console_put_dec_i32(int32_t v){
if (v < 0) { console_putc('-'); console_put_dec_u32((uint32_t)(-v)); }
else { console_put_dec_u32((uint32_t) v); }
}
