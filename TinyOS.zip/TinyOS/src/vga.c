/*=============================================================================
 *  vga.c — TinyOS VGA Text Mode Console Driver
 *=============================================================================
 *
 * PURPOSE:
 *   This file implements a basic VGA text mode console driver for displaying
 *   output on the screen. It provides character output, scrolling, and
 *   number formatting functions for kernel debugging and user interaction.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - i386 (32-bit x86)
 *   - VGA text mode (80×25 characters)
 *   - Memory-mapped I/O (direct video memory access)
 *
 * VGA TEXT MODE BASICS:
 *   VGA text mode uses a memory-mapped buffer at physical address 0xB8000.
 *   This buffer is 4000 bytes (80 columns × 25 rows × 2 bytes per character).
 *   
 *   Each character cell consists of 2 bytes:
 *     Byte 0: ASCII character code (what to display)
 *     Byte 1: Attribute byte (how to display it)
 *   
 *   Attribute Byte Format (8 bits):
 *     Bits 0-3: Foreground color (16 colors)
 *     Bits 4-6: Background color (8 colors)
 *     Bit 7:    Blink flag (character blinks if set)
 *   
 *   Color Values:
 *     0x0 = Black        0x8 = Dark Gray
 *     0x1 = Blue         0x9 = Light Blue
 *     0x2 = Green        0xA = Light Green
 *     0x3 = Cyan         0xB = Light Cyan
 *     0x4 = Red          0xC = Light Red
 *     0x5 = Magenta      0xD = Light Magenta
 *     0x6 = Brown        0xE = Yellow
 *     0x7 = Light Gray   0xF = White
 *
 * MEMORY LAYOUT:
 *   VGA buffer: 0xB8000 - 0xB8FA0 (4000 bytes)
 *   Each row:   160 bytes (80 characters × 2 bytes)
 *   Character at (x, y): 0xB8000 + (y × 160) + (x × 2)
 *
 * DESIGN DECISIONS:
 *   - Direct memory access: Fast, no BIOS calls needed
 *   - Volatile pointer: Prevents compiler optimization of VGA writes
 *   - Software cursor: Track position in variables (no hardware cursor)
 *   - Scrolling: Move all lines up when bottom reached
 *   - No buffering: Writes go directly to video memory
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Concurrent access to row/col will cause corruption.
 *   Future: Add spinlock or per-CPU consoles for SMP safety.
 *
 * PERFORMANCE:
 *   Direct memory writes are very fast (~1-2 cycles per character).
 *   Scrolling is slow (copies 3920 bytes), but rare.
 *   Good enough for kernel debugging and boot messages.
 *
 * FUTURE ENHANCEMENTS:
 *   - Hardware cursor support (via VGA ports 0x3D4/0x3D5)
 *   - Color control functions (change foreground/background)
 *   - Backspace and tab support
 *   - Input buffer (for reading from keyboard)
 *   - ANSI escape sequence parsing (colors, cursor movement)
 *   - Double-buffering (reduce flicker during updates)
 *
 *============================================================================*/

#include "kernel.h"

/*=============================================================================
 * VGA BUFFER POINTER
 *=============================================================================
 * DESCRIPTION:
 *   Pointer to the VGA text buffer in physical memory.
 *
 * TYPE: volatile uint16_t*
 *   - volatile: Tells compiler this memory can change unexpectedly
 *               (even though we're the only ones writing to it, it's
 *               memory-mapped I/O, so we want to prevent optimization)
 *   - uint16_t: Each character cell is 16 bits (2 bytes)
 *   - const:    The pointer itself never changes (always 0xB8000)
 *
 * ADDRESS: 0xB8000 (VGA_BUFFER_ADDR from kernel.h)
 *   This is a standard PC/AT architecture constant.
 *   All x86 systems with VGA have text buffer here.
 *
 * WHY VOLATILE:
 *   Without volatile, compiler might optimize away repeated writes:
 *     vga[0] = 'A';
 *     vga[0] = 'B';  // Compiler might remove this without volatile!
 *   
 *   With volatile, compiler always performs the actual memory write.
 *
 * ACCESSING SPECIFIC CELLS:
 *   Character at (column, row):
 *     vga[row * VGA_WIDTH + column] = char_value | (attr_value << 8);
 *
 * EXAMPLE:
 *   Write 'A' in white on black at top-left corner:
 *     vga[0] = 'A' | (0x0F << 8);
 *   
 *   Result in memory at 0xB8000:
 *     Byte 0: 0x41 (ASCII 'A')
 *     Byte 1: 0x0F (white on black)
 *============================================================================*/
static volatile uint16_t* const vga = (uint16_t*)VGA_BUFFER_ADDR;

/*=============================================================================
 * CURSOR POSITION STATE
 *=============================================================================
 * DESCRIPTION:
 *   Software cursor tracking the current output position.
 *   The next character will be written at (col, row).
 *
 * VARIABLES:
 *   row: Current row (0-24), top to bottom
 *   col: Current column (0-79), left to right
 *   attr: Current attribute byte (color and style)
 *
 * COORDINATE SYSTEM:
 *   Origin (0, 0) is at the TOP-LEFT corner of the screen.
 *   
 *   (0,0)                                               (79,0)
 *     ┌───────────────────────────────────────────────────┐
 *     │ 80 characters wide (columns 0-79)            │
 *     │                                               │
 *     │ 25 characters tall (rows 0-24)               │
 *     │                                               │
 *     └───────────────────────────────────────────────────┘
 *   (0,24)                                             (79,24)
 *
 * DEFAULT ATTRIBUTE: 0x0F (VGA_DEFAULT_ATTR)
 *   0x0F = 0000 1111 binary
 *     Bits 0-3 (0xF): White foreground
 *     Bits 4-7 (0x0): Black background
 *   Result: White text on black background (classic console)
 *
 * CURSOR MOVEMENT:
 *   - Printing a character: Increments col, wraps to next row at end
 *   - Newline (\n): Moves to start of next row
 *   - End of screen: Scrolls entire screen up one line
 *
 * INITIALIZATION:
 *   All start at 0 (top-left corner, white on black).
 *   Set by console_clear() during kernel initialization.
 *
 * THREAD SAFETY:
 *   NOT safe for concurrent access. If two threads write simultaneously,
 *   row/col can become inconsistent, causing garbled output.
 *   Future: Protect with spinlock or use per-CPU consoles.
 *============================================================================*/
static uint8_t row = 0;                  /* Current row (0-24) */
static uint8_t col = 0;                  /* Current column (0-79) */
static uint8_t attr = VGA_DEFAULT_ATTR;  /* Current attribute (0x0F) */

/*=============================================================================
 * FUNCTION: vga_put_at
 *=============================================================================
 * DESCRIPTION:
 *   Writes a character to a specific position on the screen with given
 *   attribute (color). This is the fundamental VGA write operation.
 *
 * PARAMETERS:
 *   c - ASCII character to display (any value 0-255)
 *       Common values: 0x20-0x7E (printable ASCII)
 *       Extended: 0x80-0xFF (line drawing, special chars)
 *   
 *   a - Attribute byte (color and style)
 *       Format: BBBBFFFF (4 bits background, 4 bits foreground)
 *       Example: 0x0F = white on black
 *                0x4E = yellow on red
 *   
 *   x - Column position (0-79)
 *       0 = leftmost column
 *       79 = rightmost column
 *   
 *   y - Row position (0-24)
 *       0 = top row
 *       24 = bottom row
 *
 * RETURNS:
 *   void (no return value)
 *
 * BEHAVIOR:
 *   Directly writes to VGA memory at calculated address.
 *   No bounds checking (caller must ensure valid coordinates).
 *
 * CALCULATION:
 *   VGA buffer is linear array: [row0_col0][row0_col1]...[row24_col79]
 *   Index = (y × 80) + x
 *   Address = 0xB8000 + (index × 2)
 *
 * MEMORY WRITE:
 *   Combines character and attribute into single 16-bit value:
 *     Low byte (bits 0-7):   Character code
 *     High byte (bits 8-15): Attribute byte
 *   
 *   Bitwise operation:
 *     (uint16_t)c | ((uint16_t)a << 8)
 *   
 *   Example: c='A' (0x41), a=0x0F
 *     0x0F41 = 0000111101000001 binary
 *              │       └─────────┐ character (0x41 = 'A')
 *              └──────────────────┘ attribute (0x0F = white on black)
 *
 * PERFORMANCE:
 *   Very fast: Single memory write instruction.
 *   No function call overhead (inline).
 *   Typical execution: 1-2 CPU cycles.
 *
 * NOTES:
 *   - No validation of x, y ranges (assumes caller provides valid values)
 *   - Does not update cursor position (col, row)
 *   - Immediate effect (visible on screen instantly)
 *
 * USAGE EXAMPLES:
 *   // Write 'X' at (10, 5) in red on black
 *   vga_put_at('X', 0x0C, 10, 5);
 *   
 *   // Clear character at (40, 12)
 *   vga_put_at(' ', 0x0F, 40, 12);
 *   
 *   // Draw blue line at top
 *   for (int x = 0; x < 80; x++)
 *       vga_put_at('─', 0x09, x, 0);
 *============================================================================*/
static inline void vga_put_at(char c, uint8_t a, uint8_t x, uint8_t y) {
    vga[y * VGA_WIDTH + x] = (uint16_t)c | ((uint16_t)a << 8);
}

/*=============================================================================
 * FUNCTION: scroll
 *=============================================================================
 * DESCRIPTION:
 *   Scrolls the entire screen up by one line. Copies rows 1-24 to rows 0-23,
 *   then clears the bottom row (row 24). Called when output reaches the
 *   bottom of the screen and needs to continue.
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   void
 *
 * ALGORITHM:
 *   1. Copy each row to the row above it (rows 1-24 → rows 0-23)
 *   2. Clear the newly vacated bottom row (row 24)
 *   3. Do NOT modify cursor position (caller handles that)
 *
 * VISUAL EXAMPLE (5 rows for clarity):
 *   BEFORE SCROLL:        AFTER SCROLL:
 *   Row 0: Line 1         Row 0: Line 2
 *   Row 1: Line 2         Row 1: Line 3
 *   Row 2: Line 3         Row 2: Line 4
 *   Row 3: Line 4         Row 3: Line 5
 *   Row 4: Line 5  ↓      Row 4: [empty]  ← cleared
 *   (cursor at row 5)     (cursor stays at row 4)
 *
 * MEMORY OPERATIONS:
 *   - Copies: 24 rows × 80 columns × 2 bytes = 3,840 bytes
 *   - Clears: 1 row × 80 columns × 2 bytes = 160 bytes
 *   - Total: 4,000 bytes touched (entire VGA buffer except first row)
 *
 * PERFORMANCE:
 *   SLOW: Copies 3,840 bytes (1,920 16-bit values).
 *   On 1 GHz CPU: ~4-10 microseconds (depending on memory speed).
 *   Fortunately, scrolling is rare (only when screen fills).
 *
 * OPTIMIZATION OPPORTUNITIES:
 *   1. Use memcpy() or rep movsw (assembly) for bulk copy
 *      Current: Byte-by-byte loop (simple but slow)
 *      Better: Block copy instruction (rep movsw copies words)
 *   
 *   2. Double-buffering
 *      Maintain off-screen buffer, swap pointers on scroll
 *      Reduces visible flicker during scroll
 *   
 *   3. Circular buffer
 *      Don't copy at all, just adjust base pointer
 *      Requires hardware scrolling support or more complex addressing
 *
 * VISIBILITY:
 *   Scroll happens instantly (direct VGA memory write).
 *   User may see brief flicker during the copy operation.
 *
 * THREAD SAFETY:
 *   NOT safe for concurrent calls. Two threads scrolling simultaneously
 *   can corrupt the screen with partial copies.
 *
 * NOTES:
 *   - Does not move the cursor (caller must update row/col if needed)
 *   - Clears bottom row with current attribute (maintains consistent color)
 *   - First row is always lost (no scroll history buffer)
 *============================================================================*/
static void scroll(void) {
    for (uint32_t y = 0; y < VGA_HEIGHT - 1; ++y)
        for (uint32_t x = 0; x < VGA_WIDTH; ++x)
            vga[y * VGA_WIDTH + x] = vga[(y + 1) * VGA_WIDTH + x];

    for (uint32_t x = 0; x < VGA_WIDTH; ++x)
        vga[(VGA_HEIGHT - 1) * VGA_WIDTH + x] = ' ' | ((uint16_t)attr << 8);
}

/*=============================================================================
 * FUNCTION: console_clear
 *=============================================================================
 * DESCRIPTION:
 *   Clears the entire screen by filling it with spaces and resets the
 *   cursor to the top-left corner (0, 0). This is typically called during
 *   kernel initialization to start with a clean display.
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   void
 *
 * BEHAVIOR:
 *   1. Fills all 2,000 character cells (80 × 25) with spaces
 *   2. Uses current attribute byte for all spaces
 *   3. Resets cursor position to (0, 0)
 *
 * VISUAL EFFECT:
 *   BEFORE:                  AFTER:
 *   ┌──────────────┐       ┌──────────────┐
 *   │Random text  │       │              │
 *   │and stuff    │       │              │
 *   │everywhere...│  →   │              │ (all blank)
 *   │  [cursor]   │       │[cursor]      │ (at top-left)
 *   └──────────────┘       └──────────────┘
 *
 * ALGORITHM:
 *   Nested loops iterate through every position:
 *     Outer loop: Each row (0-24)
 *     Inner loop: Each column (0-79)
 *     Action: Write space with current attribute
 *
 * MEMORY OPERATIONS:
 *   - Writes: 80 × 25 = 2,000 character cells
 *   - Bytes: 2,000 × 2 = 4,000 bytes (entire VGA buffer)
 *
 * PERFORMANCE:
 *   On 1 GHz CPU: ~2-5 microseconds
 *   Fast enough for boot-time clear
 *   Visible to user: Screen goes blank instantly
 *
 * OPTIMIZATION:
 *   Could use memset() or rep stosw (assembly) to fill buffer faster.
 *   Current loop is simple and adequate for infrequent operation.
 *
 * USAGE:
 *   Called once during kernel initialization (in kernel_main).
 *   Can be called anytime to clear screen (e.g., before panic message).
 *
 * ATTRIBUTE USAGE:
 *   Uses current 'attr' variable (default: 0x0F = white on black).
 *   Result: Screen cleared to black background with specified color.
 *   If attr changed before clear, screen takes on new background color.
 *
 * THREAD SAFETY:
 *   NOT thread-safe if called concurrently (row/col can become inconsistent).
 *   In practice, only called during single-threaded kernel initialization.
 *============================================================================*/
void console_clear(void) {
    for (uint32_t y = 0; y < VGA_HEIGHT; ++y)
        for (uint32_t x = 0; x < VGA_WIDTH; ++x)
            vga_put_at(' ', attr, x, y);
    row = col = 0;
}

/*=============================================================================
 * FUNCTION: advance
 *=============================================================================
 * DESCRIPTION:
 *   Advances the cursor to the next character position after writing.
 *   Handles line wrapping (when reaching right edge) and scrolling
 *   (when reaching bottom of screen).
 *
 * PARAMETERS:
 *   None (operates on global row/col variables)
 *
 * RETURNS:
 *   void
 *
 * BEHAVIOR:
 *   1. Increment column
 *   2. If column >= 80: wrap to next row (col = 0, row++)
 *   3. If row >= 25: scroll screen up and stay on row 24
 *
 * CURSOR MOVEMENT EXAMPLES:
 *   
 *   Normal advance (middle of line):
 *     Before: (col=40, row=10)
 *     After:  (col=41, row=10)
 *   
 *   Line wrap (at right edge):
 *     Before: (col=79, row=10)
 *     After:  (col=0, row=11)
 *   
 *   Scroll (at bottom-right):
 *     Before: (col=79, row=24)
 *     After:  (col=0, row=24)  [screen scrolled up]
 *
 * VISUAL DIAGRAM:
 *   
 *   Row 0:  [....................................] → Row 1
 *   Row 1:  [....................................] → Row 2
 *   ...
 *   Row 23: [....................................] → Row 24
 *   Row 24: [...................X] → scroll! → Row 24 (cursor stays)
 *           ↑                     ↑
 *           col=19                wrap would go here,
 *                                 but scroll happens instead
 *
 * ALGORITHM DETAILS:
 *   
 *   Step 1: Increment column (++col)
 *     - Pre-increment: Modify col before checking condition
 *     - Result: col now points to NEXT position
 *   
 *   Step 2: Check for line wrap
 *     if (col >= VGA_WIDTH)  // col >= 80
 *       - Reset to start of next row: col = 0, ++row
 *   
 *   Step 3: Check for scroll
 *     if (row >= VGA_HEIGHT)  // row >= 25
 *       - Scroll entire screen up one line
 *       - Stay on last row: row = VGA_HEIGHT - 1 (row = 24)
 *
 * WHY SEPARATE FROM console_putc():
 *   Modular design: Character output and cursor management separated.
 *   Allows different cursor advancement strategies in the future.
 *   Makes code easier to understand and maintain.
 *
 * PERFORMANCE:
 *   Fast path (no wrap/scroll): Just ++col (1 instruction)
 *   Wrap case: col = 0, ++row (2 instructions)
 *   Scroll case: Calls scroll() which copies 3,840 bytes (slow)
 *
 * SCROLLING FREQUENCY:
 *   Scrolling only happens when:
 *     - Cursor is at bottom row (row = 24)
 *     - AND column reaches 80 (wraps to next line)
 *     - OR newline explicitly moves to row 25
 *   
 *   Typical boot sequence: Scrolls 10-50 times
 *   Not a performance bottleneck in practice
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Concurrent calls can corrupt row/col values.
 *   Must ensure only one thread outputs to console at a time.
 *============================================================================*/
static void advance(void) {
    if (++col >= VGA_WIDTH) { col = 0; ++row; }
    if (row >= VGA_HEIGHT) { scroll(); row = VGA_HEIGHT - 1; }
}

/*=============================================================================
 * FUNCTION: console_putc
 *=============================================================================
 * DESCRIPTION:
 *   Outputs a single character to the VGA console at the current cursor
 *   position. Handles newline (\n) specially by moving to the start of
 *   the next line. Automatically advances cursor and scrolls screen as needed.
 *
 * PARAMETERS:
 *   c - Character to display (0-255)
 *       - Printable ASCII (0x20-0x7E): Normal characters (A-Z, 0-9, etc.)
 *       - Newline (0x0A or '\n'): Move to next line
 *       - Other control chars: Displayed as-is (may show as symbols)
 *       - Extended ASCII (0x80-0xFF): Line drawing, special symbols
 *
 * RETURNS:
 *   void
 *
 * BEHAVIOR:
 *   1. If c is newline ('\n'):
 *        - Move to start of next row
 *        - Scroll if at bottom
 *        - Return without writing character
 *   
 *   2. Otherwise:
 *        - Write character at current (col, row) position
 *        - Advance cursor to next position
 *        - Automatically wrap/scroll as needed
 *
 * NEWLINE HANDLING:
 *   Newline is special: moves cursor but doesn't write a character.
 *   
 *   Before: (col=40, row=10)
 *   Call:   console_putc('\n')
 *   After:  (col=0, row=11)
 *   
 *   If at bottom:
 *   Before: (col=40, row=24)
 *   Call:   console_putc('\n')
 *   Action: Scroll screen up
 *   After:  (col=0, row=24)
 *
 * CHARACTER DISPLAY:
 *   For non-newline characters, writes to current position with current
 *   attribute, then advances cursor.
 *   
 *   Example sequence:
 *     console_putc('H');  // (0,0) → 'H', cursor → (1,0)
 *     console_putc('i');  // (1,0) → 'i', cursor → (2,0)
 *     console_putc('\n'); // cursor → (0,1)
 *     console_putc('!');  // (0,1) → '!', cursor → (1,1)
 *   
 *   Result on screen:
 *     Row 0: Hi
 *     Row 1: !
 *
 * CONTROL CHARACTERS:
 *   Only '\n' (0x0A) is handled specially.
 *   Other control characters are displayed as VGA glyphs:
 *     '\t' (0x09): Displays as circle (♂ symbol)
 *     '\r' (0x0D): Displays as musical note
 *     '\b' (0x08): Displays as backspace symbol
 *   
 *   Future: Could add special handling for \t, \r, \b, etc.
 *
 * VGA CHARACTER SET:
 *   Standard ASCII (0x00-0x7F):
 *     0x20-0x7E: Normal printable characters
 *     0x00-0x1F: Control chars shown as symbols
 *   
 *   Extended ASCII (0x80-0xFF):
 *     Box-drawing characters: ┌ ├ ─ │ etc.
 *     Greek letters, math symbols, etc.
 *
 * PERFORMANCE:
 *   Fast path (no newline, no scroll): ~10 CPU cycles
 *     1. vga_put_at: 1 memory write (~2 cycles)
 *     2. advance: 1 increment (~1 cycle)
 *   
 *   Slow path (newline at bottom): ~10,000 cycles
 *     scroll() copies 3,840 bytes
 *
 * USAGE EXAMPLES:
 *   // Print "Hello\n"
 *   console_putc('H');
 *   console_putc('e');
 *   console_putc('l');
 *   console_putc('l');
 *   console_putc('o');
 *   console_putc('\n');
 *   
 *   // Print extended ASCII box corner
 *   console_putc(0xDA);  // ┌ character
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Concurrent calls can interleave characters or
 *   corrupt cursor position. Use locking in multi-threaded environment.
 *============================================================================*/
void console_putc(char c) {
    if (c == '\n') {
        col = 0; ++row;
        if (row >= VGA_HEIGHT) { scroll(); row = VGA_HEIGHT - 1; }
        return;
    }
    vga_put_at(c, attr, col, row);
    advance();
}

/*=============================================================================
 * FUNCTION: console_puts
 *=============================================================================
 * DESCRIPTION:
 *   Outputs a null-terminated string to the console by repeatedly calling
 *   console_putc() for each character. This is the primary string output
 *   function used throughout the kernel.
 *
 * PARAMETERS:
 *   s - Pointer to null-terminated string (array of characters ending in \0)
 *       Must not be NULL (undefined behavior if NULL)
 *       Can contain newlines (\n) and other special characters
 *
 * RETURNS:
 *   void
 *
 * BEHAVIOR:
 *   Iterates through string character by character until null terminator.
 *   Each character is output via console_putc(), which handles all special
 *   cases (newlines, scrolling, etc.).
 *
 * ALGORITHM:
 *   while (*s != '\0')
 *       console_putc(*s)
 *       s++
 *
 * NULL TERMINATOR:
 *   Strings must end with '\0' (null byte, value 0x00).
 *   If string is not null-terminated, will read past end of string
 *   until it finds a zero byte (undefined behavior, possible crash).
 *
 * PERFORMANCE:
 *   O(n) where n is string length.
 *   Each character: ~10-20 CPU cycles (no scroll)
 *   With scrolls: Can be slower due to scroll() overhead
 *
 * USAGE EXAMPLES:
 *   // Simple string
 *   console_puts("Hello, World!\n");
 *   
 *   // Multiple lines
 *   console_puts("Line 1\nLine 2\nLine 3\n");
 *   
 *   // Constant string from .rodata
 *   console_puts("TinyOS v0.1\n");
 *   
 *   // String variable
 *   const char* msg = "Booting...\n";
 *   console_puts(msg);
 *
 * STRING LITERALS:
 *   String literals in C are automatically null-terminated:
 *     "Hello"  is stored as  {'H','e','l','l','o','\0'}
 *   
 *   Length: 5 visible characters + 1 null byte = 6 bytes total
 *
 * SAFETY NOTES:
 *   - Does NOT check for NULL pointer (caller must ensure s != NULL)
 *   - Assumes string is properly null-terminated
 *   - No length limit (will output entire string)
 *   - Can overflow screen (will scroll as needed)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. If two threads call console_puts() simultaneously,
 *   output will be interleaved character-by-character.
 *   
 *   Example concurrent output:
 *     Thread 1: "AAAA\n"
 *     Thread 2: "BBBB\n"
 *     Result:   "ABAABB\nAB\n" (corrupted)
 *
 * ALTERNATIVE IMPLEMENTATION:
 *   Could be implemented with explicit loop and index:
 *     for (int i = 0; s[i] != '\0'; i++)
 *         console_putc(s[i]);
 *   
 *   Current pointer arithmetic approach is more idiomatic in C.
 *============================================================================*/
void console_puts(const char* s) { 
    while (*s) console_putc(*s++); 
}

/*=============================================================================
 * FUNCTION: console_put_hex32
 *=============================================================================
 * DESCRIPTION:
 *   Outputs a 32-bit unsigned integer in hexadecimal format with "0x" prefix.
 *   Always displays exactly 8 hex digits (with leading zeros if necessary).
 *   Used for displaying memory addresses, register values, and other hex data.
 *
 * PARAMETERS:
 *   v - 32-bit unsigned integer value to display
 *
 * RETURNS:
 *   void
 *
 * OUTPUT FORMAT:
 *   "0x" followed by 8 uppercase hexadecimal digits
 *   
 *   Examples:
 *     v = 0          → "0x00000000"
 *     v = 255        → "0x000000FF"
 *     v = 4096       → "0x00001000"
 *     v = 0xDEADBEEF → "0xDEADBEEF"
 *     v = 0xFFFFFFFF → "0xFFFFFFFF"
 *
 * ALGORITHM:
 *   1. Output "0x" prefix
 *   2. For each of 8 hex digits (most significant to least significant):
 *        a. Extract 4 bits using shift and mask
 *        b. Convert to hex character (0-9, A-F)
 *        c. Output character
 *
 * BIT EXTRACTION:
 *   To get digit i (where i=7 is leftmost, i=0 is rightmost):
 *     shift = i × 4               // Number of bits to shift right
 *     digit = (v >> shift) & 0xF  // Extract lower 4 bits after shift
 *   
 *   Example: v = 0x12AB, extract digit at position 1 (third from right = 'A')
 *     shift = 1 × 4 = 4
 *     (v >> 4) = 0x012A
 *     (0x012A & 0xF) = 0xA
 *     H[0xA] = 'A'  ✓
 *
 * HEX DIGIT TABLE:
 *   static const char H[] = "0123456789ABCDEF";
 *   
 *   Indexed by 4-bit value (0-15):
 *     H[0]  = '0'    H[8]  = '8'
 *     H[1]  = '1'    H[9]  = '9'
 *     ...            H[10] = 'A'
 *     H[7]  = '7'    H[15] = 'F'
 *
 * LOOP DETAILS:
 *   for (int i = 7; i >= 0; --i)
 *   
 *   Iterates from most significant digit (leftmost) to least significant
 *   (rightmost). This produces correct left-to-right output order.
 *   
 *   i=7: Bits 28-31 (leftmost hex digit)
 *   i=6: Bits 24-27
 *   ...
 *   i=1: Bits 4-7
 *   i=0: Bits 0-3 (rightmost hex digit)
 *
 * STATIC KEYWORD:
 *   'static' means the array H is initialized once and persists for the
 *   lifetime of the program (not recreated on each function call).
 *   Stored in .rodata section (read-only data).
 *
 * PERFORMANCE:
 *   Fixed cost: Always outputs exactly 10 characters (0x + 8 digits)
 *   Fast: No division or expensive operations, just shifts and masks
 *   Typical execution: ~100-200 CPU cycles
 *
 * USE CASES:
 *   - Memory addresses: console_put_hex32((uint32_t)ptr);
 *   - Register values: console_put_hex32(eax);
 *   - Status codes: console_put_hex32(error_code);
 *   - Page directory entries: console_put_hex32(pde);
 *
 * COMPARISON WITH console_put_hex64:
 *   This function:  32-bit (4 bytes), 8 hex digits
 *   hex64 version:  64-bit (8 bytes), 16 hex digits (or 8 if high bits zero)
 *
 * THREAD SAFETY:
 *   Safe to call concurrently (uses static const data and local variables).
 *   However, output will interleave if multiple threads call simultaneously.
 *============================================================================*/
void console_put_hex32(uint32_t v){
    static const char H[] = "0123456789ABCDEF";
    console_puts("0x");
    for (int i = 7; i >= 0; --i) console_putc(H[(v >> (i*4)) & 0xF]);
}

/*=============================================================================
 * FUNCTION: console_put_hex64
 *=============================================================================
 * DESCRIPTION:
 *   Outputs a 64-bit unsigned integer in hexadecimal format. If the high
 *   32 bits are zero, only displays 8 hex digits (same as 32-bit). Otherwise,
 *   displays full 16 hex digits. Always includes "0x" prefix.
 *
 * PARAMETERS:
 *   v - 64-bit unsigned integer value to display
 *
 * RETURNS:
 *   void
 *
 * OUTPUT FORMAT:
 *   "0x" followed by 8 or 16 uppercase hexadecimal digits
 *   
 *   Examples:
 *     v = 0                    → "0x00000000" (8 digits, high 32 bits zero)
 *     v = 0x123               → "0x00000123" (8 digits)
 *     v = 0xFFFFFFFF          → "0xFFFFFFFF" (8 digits)
 *     v = 0x100000000         → "0x0000000100000000" (16 digits)
 *     v = 0x123456789ABCDEF0  → "0x123456789ABCDEF0" (16 digits)
 *
 * ALGORITHM:
 *   1. Split 64-bit value into high and low 32-bit halves
 *   2. If high half is non-zero:
 *        a. Output "0x"
 *        b. Output 8 hex digits for high half
 *        c. Output 8 hex digits for low half
 *   3. Else (high half is zero):
 *        a. Call console_put_hex32() with low half
 *
 * 64-BIT VALUE STRUCTURE:
 *   A 64-bit value consists of:
 *     Bits 63-32: High 32 bits
 *     Bits 31-0:  Low 32 bits
 *   
 *   Example: v = 0x123456789ABCDEF0
 *     High half (hi): 0x12345678
 *     Low half (lo):  0x9ABCDEF0
 *   
 *   Output: "0x" + digits(hi) + digits(lo)
 *         = "0x" + "12345678" + "9ABCDEF0"
 *         = "0x123456789ABCDEF0"
 *
 * SPLITTING 64-BIT VALUE:
 *   uint32_t hi = (uint32_t)(v >> 32);  // Extract high 32 bits
 *   uint32_t lo = (uint32_t)v;          // Extract low 32 bits
 *   
 *   The right shift (>> 32) moves high bits into low position.
 *   Cast to uint32_t truncates to lower 32 bits.
 *
 * OPTIMIZATION:
 *   If high 32 bits are zero, value fits in 32 bits, so output as 32-bit hex.
 *   This saves screen space for small values (common case).
 *   
 *   Small value:  0x000000000000ABCD → "0x0000ABCD" (8 digits)
 *   Large value:  0x123400000000ABCD → "0x123400000000ABCD" (16 digits)
 *
 * HEX DIGIT TABLE:
 *   Same as console_put_hex32(): "0123456789ABCDEF"
 *   Used for both high and low halves.
 *
 * USE CASES:
 *   - 64-bit memory addresses (on x86-64 systems)
 *   - Large physical addresses (PAE mode)
 *   - Time stamps (64-bit tick counters)
 *   - File sizes (64-bit byte counts)
 *
 * PERFORMANCE:
 *   Small values (hi=0): Same as console_put_hex32() (~100 cycles)
 *   Large values (hi≠0): Outputs 18 characters (~200 cycles)
 *
 * THREAD SAFETY:
 *   Safe regarding static data (uses static const).
 *   Output may interleave if called concurrently from multiple threads.
 *============================================================================*/
void console_put_hex64(uint64_t v){
    uint32_t hi = (uint32_t)(v >> 32), lo = (uint32_t)v;
    if (hi) {
        static const char H[] = "0123456789ABCDEF";
        console_puts("0x");
        for (int i=7;i>=0;--i) console_putc(H[(hi>>(i*4))&0xF]);
        for (int i=7;i>=0;--i) console_putc(H[(lo>>(i*4))&0xF]);
    } else {
        console_put_hex32(lo);
    }
}

/*=============================================================================
 * FUNCTION: console_put_dec_u32
 *=============================================================================
 * DESCRIPTION:
 *   Outputs an unsigned 32-bit integer in decimal (base 10) format without
 *   any prefix. No leading zeros are displayed. Used for counters, sizes,
 *   and other numeric values where decimal representation is more natural.
 *
 * PARAMETERS:
 *   v - 32-bit unsigned integer value to display (0 to 4,294,967,295)
 *
 * RETURNS:
 *   void
 *
 * OUTPUT FORMAT:
 *   Decimal digits without leading zeros (except value 0 displays as "0")
 *   
 *   Examples:
 *     v = 0          → "0"
 *     v = 5          → "5"
 *     v = 42         → "42"
 *     v = 1000       → "1000"
 *     v = 999999     → "999999"
 *     v = 4294967295 → "4294967295" (max 32-bit unsigned)
 *
 * ALGORITHM:
 *   1. Special case: If v is 0, output "0" and return
 *   2. Extract decimal digits right-to-left (least to most significant):
 *        a. Digit = v % 10 (remainder when divided by 10)
 *        b. Store digit character ('0' + digit) in buffer
 *        c. v = v / 10 (remove rightmost digit)
 *        d. Repeat until v becomes 0
 *   3. Output digits left-to-right (reverse of extraction order)
 *
 * WHY EXTRACT BACKWARDS:
 *   Extracting digits via modulo and division naturally produces
 *   digits from least significant to most significant (right-to-left).
 *   
 *   Example: v = 1234
 *     First:  1234 % 10 = 4, 1234 / 10 = 123  (digit '4')
 *     Second: 123  % 10 = 3, 123  / 10 = 12   (digit '3')
 *     Third:  12   % 10 = 2, 12   / 10 = 1    (digit '2')
 *     Fourth: 1    % 10 = 1, 1    / 10 = 0    (digit '1')
 *   
 *   Buffer after extraction: ['4', '3', '2', '1']
 *   Output in reverse: "1234" ✓
 *
 * BUFFER SIZE:
 *   char buf[10] is sufficient for 32-bit unsigned integers.
 *   Maximum value: 4,294,967,295 (10 digits)
 *   Buffer holds up to 10 digits, no overflow possible.
 *
 * DIGIT TO CHARACTER CONVERSION:
 *   Digit value 0-9 converts to character '0'-'9':
 *     '0' + 0 = '0' (ASCII 0x30)
 *     '0' + 1 = '1' (ASCII 0x31)
 *     ...
 *     '0' + 9 = '9' (ASCII 0x39)
 *   
 *   In C, character arithmetic works because ASCII digits are consecutive.
 *
 * PERFORMANCE:
 *   Small values (0-9):     ~20 CPU cycles (single digit)
 *   Medium values (10-999): ~50-100 cycles (2-3 digits)
 *   Large values (1M+):     ~200-300 cycles (7-10 digits)
 *   
 *   Division and modulo are relatively expensive operations
 *   (~20-40 cycles each on modern CPUs).
 *
 * USE CASES:
 *   - Frame counts: console_put_dec_u32(pmm_free_frames());
 *   - Memory sizes: console_put_dec_u32(bytes / 1024); (KiB)
 *   - Timer ticks: console_put_dec_u32(get_timer_ticks());
 *   - Loop counters: console_put_dec_u32(iteration);
 *
 * COMPARISON WITH console_put_dec_i32:
 *   This function:  Unsigned (0 to 4,294,967,295), no sign
 *   Signed version: Signed (-2,147,483,648 to 2,147,483,647), handles '-'
 *
 * THREAD SAFETY:
 *   Uses local variables only (stack-allocated).
 *   Safe to call concurrently from multiple threads.
 *   Output may interleave if called simultaneously.
 *============================================================================*/
void console_put_dec_u32(uint32_t v){
    char buf[10]; int i=0;
    if (!v) { console_putc('0'); return; }
    while (v) { buf[i++] = '0' + (v % 10); v /= 10; }
    while (i--) console_putc(buf[i]);
}

/*=============================================================================
 * FUNCTION: console_put_dec_i32
 *=============================================================================
 * DESCRIPTION:
 *   Outputs a signed 32-bit integer in decimal format. Negative values are
 *   displayed with a leading minus sign. Zero and positive values have no
 *   sign prefix. Uses console_put_dec_u32() for the actual digit output.
 *
 * PARAMETERS:
 *   v - 32-bit signed integer value to display (-2,147,483,648 to 2,147,483,647)
 *
 * RETURNS:
 *   void
 *
 * OUTPUT FORMAT:
 *   Decimal digits with optional leading minus sign for negative values
 *   
 *   Examples:
 *     v = 0           → "0"
 *     v = 42          → "42"
 *     v = -42         → "-42"
 *     v = 2147483647  → "2147483647" (max positive 32-bit signed)
 *     v = -2147483648 → "-2147483648" (max negative 32-bit signed)
 *
 * ALGORITHM:
 *   1. If v is negative:
 *        a. Output '-' character
 *        b. Convert v to positive (negate)
 *        c. Output unsigned value
 *   2. Else (v is zero or positive):
 *        a. Output unsigned value directly
 *
 * NEGATIVE VALUE HANDLING:
 *   For negative values, output '-' then treat as positive.
 *   
 *   Example: v = -123
 *     1. Output '-'
 *     2. Negate: -(-123) = 123
 *     3. Call console_put_dec_u32(123)
 *     4. Result: "-123"
 *
 * NEGATION:
 *   For v < 0, need to convert to positive magnitude.
 *   Cannot just use -v because of two's complement representation.
 *   
 *   Correct: (uint32_t)(-v)
 *     First negate (giving positive int32_t if not minimum)
 *     Then cast to unsigned (handles INT32_MIN correctly)
 *   
 *   Why cast to unsigned:
 *     Negating INT32_MIN (-2,147,483,648) would overflow in signed arithmetic.
 *     In unsigned arithmetic, result wraps correctly: 2,147,483,648.
 *
 * SPECIAL CASE: INT32_MIN
 *   The most negative 32-bit signed integer: -2,147,483,648
 *   
 *   In two's complement (32-bit signed):
 *     INT32_MIN = 0x80000000 = -2,147,483,648
 *     INT32_MAX = 0x7FFFFFFF = +2,147,483,647
 *   
 *   Notice: |INT32_MIN| = 2,147,483,648, but INT32_MAX = 2,147,483,647
 *   So |INT32_MIN| cannot be represented as positive int32_t!
 *   
 *   Solution: Cast to uint32_t before negating.
 *   (uint32_t)(-INT32_MIN) = (uint32_t)(0x80000000) = 2,147,483,648 ✓
 *   This fits in unsigned 32-bit and displays correctly.
 *
 * USE CASES:
 *   - Signed counters: console_put_dec_i32(delta_frames);
 *   - Temperature values: console_put_dec_i32(temp_celsius);
 *   - Relative positions: console_put_dec_i32(offset);
 *   - Error codes: console_put_dec_i32(result);
 *
 * PERFORMANCE:
 *   Negative values: Extra '-' output + negation (~10 extra cycles)
 *   Otherwise: Same as console_put_dec_u32()
 *
 * THREAD SAFETY:
 *   Safe regarding data (no shared state modified).
 *   Output may interleave if called concurrently from multiple threads.
 *============================================================================*/
void console_put_dec_i32(int32_t v){
    if (v < 0) { console_putc('-'); console_put_dec_u32((uint32_t)(-v)); }
    else { console_put_dec_u32((uint32_t) v); }
}

/*=============================================================================
 * VGA CONSOLE DRIVER SUMMARY
 *=============================================================================
 *
 * PUBLIC API:
 *   console_clear()         - Clear screen and reset cursor
 *   console_putc(char)      - Output single character
 *   console_puts(string)    - Output null-terminated string
 *   console_put_hex32(u32)  - Output 32-bit hex (0x + 8 digits)
 *   console_put_hex64(u64)  - Output 64-bit hex (0x + 8 or 16 digits)
 *   console_put_dec_u32(u32) - Output unsigned decimal
 *   console_put_dec_i32(i32) - Output signed decimal
 *
 * KEY FEATURES:
 *   ✅ Direct VGA memory access (fast, no BIOS calls)
 *   ✅ 80×25 text mode support
 *   ✅ Automatic line wrapping
 *   ✅ Scrolling when screen fills
 *   ✅ Newline (\n) support
 *   ✅ Hex and decimal number formatting
 *   ✅ Configurable colors (via attribute byte)
 *
 * LIMITATIONS:
 *   ❌ No hardware cursor (software position tracking only)
 *   ❌ No backspace support (future enhancement)
 *   ❌ Not thread-safe (needs locking for SMP)
 *   ❌ No ANSI escape sequence support
 *   ❌ No input capabilities (display only)
 *   ❌ Limited to VGA text mode (no graphics)
 *
 * TYPICAL USAGE PATTERN:
 *   // Early initialization
 *   console_clear();
 *   
 *   // Output text
 *   console_puts("TinyOS booting...\n");
 *   
 *   // Output numbers
 *   console_puts("RAM: ");
 *   console_put_dec_u32(ram_mb);
 *   console_puts(" MiB\n");
 *   
 *   // Output addresses
 *   console_puts("Kernel at ");
 *   console_put_hex32((uint32_t)&kernel_start);
 *   console_putc('\n');
 *
 * FUTURE ENHANCEMENTS:
 *   - Hardware cursor via VGA ports 0x3D4/0x3D5
 *   - Color change functions (set_fg_color, set_bg_color)
 *   - Backspace and tab character handling
 *   - Scrollback buffer (save off-screen lines)
 *   - ANSI escape sequence parser (colors, cursor control)
 *   - Multiple virtual consoles (switch between screens)
 *   - Thread safety (spinlock protection for SMP)
 *   - Printf-style formatting (already available via kprintf.c)
 *
 *=============================================================================
 * END OF FILE: vga.c
 *============================================================================*/