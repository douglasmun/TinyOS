/*=============================================================================
 *  kernel.c — TinyOS Main Kernel Entry Point and Initialization
 *=============================================================================
 *
 * PURPOSE:
 *   This is the heart of TinyOS. After the bootloader (GRUB) loads the kernel
 *   and transfers control to boot.s, execution arrives here at kernel_main().
 *   This file orchestrates the critical boot sequence, initializing all
 *   subsystems in a carefully designed order to avoid triple-fault loops.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ENTRY POINT:
 *   void kernel_main(uint32_t magic, uint32_t info_ptr)
 *   Called from boot.s with:
 *     - magic:    0x36D76289 if booted via Multiboot2
 *     - info_ptr: Physical address of Multiboot2 info structure
 *
 * CRITICAL INITIALIZATION ORDER:
 *   The order of initialization is EXTREMELY important. Getting it wrong
 *   causes triple faults (reboot loops) or silent failures. Here's why:
 *
 *   1. SERIAL + VGA + CLI + PIC MASK  (Lines 80-84)
 *      WHY FIRST: Need output for debugging; disable interrupts for safety
 *      REASON: If anything fails later, we can print error messages
 *      DANGER: Skip this = blind debugging (no output if crash occurs)
 *
 *   2. IDT INITIALIZATION  (Line 106)
 *      WHY BEFORE PAGING: Page faults during paging setup need handlers
 *      REASON: Enabling paging can trigger #PF (page fault) if tables wrong
 *      DANGER: No IDT = triple fault on first exception during paging init
 *
 *   3. PMM INITIALIZATION  (Line 110)
 *      WHY BEFORE PAGING: Need to know which memory is usable
 *      REASON: Paging setup needs to avoid allocating protected regions
 *      DANGER: Skip this = may allocate kernel's own memory (corruption)
 *
 *   4. PAGING SETUP & ENABLE  (Lines 116-118)
 *      WHY AFTER IDT: Page faults during setup need exception handlers
 *      WHY BEFORE IRQs: Need stable memory environment before interrupts
 *      REASON: Once enabled, all memory access goes through page tables
 *      DANGER: Enable before IDT = triple fault on #PF during setup
 *
 *   5. PIC REMAP (commented out, line 131)
 *      WHY AFTER PAGING: Interrupts may access paged memory
 *      WHY BEFORE STI: Must remap before enabling interrupts
 *      REASON: Default PIC vectors (0x08-0x0F) conflict with CPU exceptions
 *      DANGER: Enable IRQs before remap = interrupt fires on exception vector
 *
 *   6. PIT INITIALIZATION (commented out, line 132)
 *      WHY AFTER PIC REMAP: Timer uses remapped IRQ0 vector
 *      WHY BEFORE STI: Configure timer before enabling interrupts
 *      REASON: Timer starts ticking immediately after init
 *      DANGER: Init after STI = interrupt fires before handler ready
 *
 *   7. STI - ENABLE INTERRUPTS (commented out, line 134)
 *      WHY LAST: Everything must be ready before interrupts fire
 *      REASON: Once enabled, timer and other IRQs start firing
 *      DANGER: Enable too early = interrupt fires before system ready
 *
 * TRIPLE FAULT PREVENTION:
 *   A triple fault occurs when the CPU encounters an exception while
 *   handling an exception while handling an exception. It causes a reboot.
 *
 *   Common causes in wrong initialization order:
 *     - No IDT → Exception → Triple fault (most common)
 *     - Paging enabled but tables wrong → #PF → No #PF handler → Triple fault
 *     - IRQ fires before handler ready → #GP → No #GP handler → Triple fault
 *     - Stack overflow during init → #PF → Corrupt stack → Triple fault
 *
 * CURRENT STATE:
 *   Hardware interrupts (PIC/PIT/STI) are currently DISABLED (lines 131-134).
 *   This was done during debugging to isolate paging issues.
 *   To enable timer interrupts, uncomment lines 131-135 and rebuild.
 *
 * DEPENDENCIES:
 *   - idt.c        (Interrupt Descriptor Table)
 *   - pmm.c        (Physical Memory Manager)
 *   - paging.c     (Virtual Memory)
 *   - serial.c     (COM1 debug output)
 *   - vga.c        (Screen output)
 *   - kprintf.c    (Unified formatted output)
 *   - pic.c        (8259 Interrupt Controller)
 *   - pit.c        (Programmable Interval Timer)
 *   - multiboot.c  (Boot info parsing)
 *
 *============================================================================*/

#include "kernel.h"
#include "idt.h"
#include "pmm.h"
#include "paging.h"
#include "serial.h"
#include "kprintf.h"
#include "pic.h"
#include "pit.h"

/*-----------------------------------------------------------------------------
 * External Function: get_timer_ticks()
 *-----------------------------------------------------------------------------
 * Returns the current timer tick count (incremented by IRQ0 handler).
 * Defined in interrupts.c
 * Used for: Timing, delays, scheduling (future)
 *---------------------------------------------------------------------------*/
extern uint32_t get_timer_ticks(void);

/*=============================================================================
 * FUNCTION: kernel_main
 *=============================================================================
 * DESCRIPTION:
 *   Main entry point of the TinyOS kernel. Called by boot.s after GRUB
 *   loads the kernel into memory and sets up basic protected mode.
 *
 * PARAMETERS:
 *   magic    - Magic number passed by bootloader in EAX
 *              Expected: 0x36D76289 for Multiboot2
 *              Used to: Verify we were booted by Multiboot2-compliant loader
 *
 *   info_ptr - Physical address of Multiboot2 information structure in EBX
 *              Contains: Memory map, bootloader name, command line, etc.
 *              Used by: PMM initialization, boot info display
 *
 * RETURNS:
 *   Never returns. Enters infinite idle loop at end.
 *
 * CALLING CONVENTION:
 *   C cdecl (called from assembly with parameters pushed on stack)
 *
 * CPU STATE ON ENTRY (from GRUB via boot.s):
 *   - Mode:       32-bit protected mode
 *   - Paging:     DISABLED (CR0.PG = 0)
 *   - Interrupts: DISABLED (EFLAGS.IF = 0)
 *   - A20:        ENABLED (full memory access)
 *   - Segments:   Flat model (base=0, limit=4GB)
 *   - Stack:      Set up by boot.s (16 KiB at stack_top)
 *
 * EXECUTION FLOW:
 *   1. Initialize output (serial, VGA) for debugging
 *   2. Disable interrupts and mask PIC (paranoid safety)
 *   3. Print boot banner and verify Multiboot2 magic
 *   4. Install IDT (CRITICAL: must be before paging!)
 *   5. Initialize PMM from Multiboot2 memory map
 *   6. Set up paging (identity map first 32 MiB)
 *   7. Enable paging (CR0.PG = 1)
 *   8. Test PMM allocation (optional verification)
 *   9. [FUTURE] Set up hardware interrupts (PIC, PIT, STI)
 *   10. Enter idle loop (HLT waits for interrupts)
 *
 * ERROR HANDLING:
 *   - Wrong magic → Print error, halt (lines 93-96)
 *   - Exceptions during init → Handled by IDT, system halts
 *   - No error recovery: this is kernel initialization
 *
 *============================================================================*/
void kernel_main(uint32_t magic, uint32_t info_ptr) {
    /*=========================================================================
     * PHASE 0: EARLY INITIALIZATION (BEFORE ANYTHING ELSE)
     *=========================================================================
     * GOAL: Set up basic I/O and ensure CPU is in a safe, known state
     *
     * ORDER IMPORTANCE: CRITICAL - This must be absolutely first
     *
     * WHY THIS ORDER:
     *   1. Serial first → Can debug even if VGA fails
     *   2. Console clear → Clean slate for output
     *   3. CLI → Disable interrupts (paranoid, already disabled by GRUB)
     *   4. PIC mask → Block all hardware IRQs during initialization
     *
     * WHAT IF OUT OF ORDER:
     *   - Skip serial_init → No debug output if early crash
     *   - Skip CLI → Spurious interrupt could fire (unlikely but possible)
     *   - Skip PIC mask → Hardware IRQ could fire before handler ready
     *
     * NOTES:
     *   - GRUB already disabled interrupts (IF=0) but we CLI anyway
     *   - PIC mask is extra paranoid: blocks IRQs even if IF somehow set
     *   - This is the "make system safe" phase
     *=======================================================================*/
    
    /* Initialize serial port (COM1) for debug output */
    serial_init();                  /* 115200 bps, 8N1, no flow control */
    
    /* Clear VGA screen and reset cursor */
    console_clear();                /* 80×25 text mode, attribute 0x0F */
    
    /* Disable interrupts (paranoid: GRUB already did this) */
    __asm__ volatile("cli");        /* Clear IF flag in EFLAGS */
    
    /* Mask all PIC interrupt lines (block all hardware IRQs) */
    pic_mask_all();                 /* Write 0xFF to PIC mask registers */

    /*=========================================================================
     * PHASE 1: BOOT INFORMATION DISPLAY
     *=========================================================================
     * GOAL: Print boot banner and verify we were booted correctly
     *
     * ORDER IMPORTANCE: LOW - Can be done anytime after I/O init
     *
     * MAGIC VALUE CHECK:
     *   - 0x36D76289 = Multiboot2 (GRUB 2.x)
     *   - 0x2BADB002 = Multiboot1 (GRUB Legacy) - not fully supported
     *   - Other      = Unknown bootloader, halt
     *
     * WHAT WE PRINT:
     *   - Kernel name and boot message
     *   - Magic number (for verification)
     *   - Info pointer address (for debugging)
     *   - kprintf format demonstrations
     *=======================================================================*/
    
    /* Print boot banner */
    kprintf("TinyOS - Multiboot2 Kernel\n");
    kprintf("Magic: 0x%08x\n", magic);
    kprintf("Info:  0x%08x\n\n", info_ptr);
    
    /*-------------------------------------------------------------------------
     * CRITICAL CHECK: Verify Multiboot2 Magic Number
     *-------------------------------------------------------------------------
     * If magic != 0x36D76289, we were NOT booted by a Multiboot2 loader.
     * This means:
     *   - info_ptr might be garbage (invalid pointer)
     *   - Memory map might not exist
     *   - System state is unknown
     *
     * ACTION: Print error and halt. Cannot continue safely.
     *-----------------------------------------------------------------------*/
    if (magic != 0x36D76289) {
        kprintf("ERROR: Not booted by Multiboot2!\n");
        kprintf("Expected: 0x36D76289\n");
        kprintf("Got:      0x%08x\n", magic);
        for (;;) __asm__ volatile("cli; hlt");  /* Halt forever */
    }
    
    /* Parse and display Multiboot2 information */
    mb_dump_mb2((const void*)(uintptr_t)info_ptr);

    /*=========================================================================
     * PHASE 2: INTERRUPT DESCRIPTOR TABLE (IDT) SETUP
     *=========================================================================
     * GOAL: Install exception and IRQ handlers so faults don't triple-fault
     *
     * ORDER IMPORTANCE: CRITICAL - MUST BE BEFORE PAGING!
     *
     * WHY THIS MUST BE FIRST (after I/O):
     *   The next steps (PMM, paging) can trigger CPU exceptions:
     *     - Page faults (#PF, vector 14) if paging setup is wrong
     *     - General protection (#GP, vector 13) if segments wrong
     *     - Stack faults (#SS, vector 12) if stack corrupted
     *
     *   Without IDT:
     *     Exception → No handler → Double fault (#DF, vector 8)
     *     Double fault → No handler → Triple fault → CPU RESET
     *
     *   With IDT:
     *     Exception → Handler prints error → Halts cleanly (we can debug!)
     *
     * WHAT IDT SETUP DOES:
     *   - Creates 256-entry interrupt descriptor table
     *   - Installs handlers for exceptions (vectors 0-31)
     *   - Installs handlers for IRQs (vectors 32-47, after PIC remap)
     *   - Loads IDT register (IDTR) with table address
     *
     * WHAT IF OUT OF ORDER:
     *   ❌ IDT after paging → Page fault during paging init → TRIPLE FAULT
     *   ❌ No IDT at all → Any exception → TRIPLE FAULT
     *   ✅ IDT before paging → Page fault → Handler prints error → Debug!
     *
     * REAL-WORLD DEBUGGING EXAMPLE:
     *   During TinyOS development, paging setup had a bug (wrong selector
     *   in IDT entries). Without IDT installed first, the system just
     *   rebooted in a loop. With IDT first, we got a readable "#GP" message
     *   and fixed the selector bug (0x08 → 0x10).
     *=======================================================================*/
    kprintf("\nInitializing IDT...\n");
    idt_init();                     /* Install all 256 interrupt gates */
    kprintf("IDT installed\n");

    /*=========================================================================
     * PHASE 3: PHYSICAL MEMORY MANAGER (PMM) INITIALIZATION
     *=========================================================================
     * GOAL: Learn which RAM is usable and set up frame allocator
     *
     * ORDER IMPORTANCE: HIGH - Must be before paging needs memory
     *
     * WHY BEFORE PAGING:
     *   Paging setup needs to know:
     *     - Which memory is usable (can allocate)
     *     - Which memory is reserved (BIOS, kernel, etc.)
     *   PMM provides this information via the bitmap allocator.
     *
     * WHAT PMM INIT DOES:
     *   1. Parses Multiboot2 memory map (E820 entries)
     *   2. Marks all memory as "used" (pessimistic start)
     *   3. Marks usable regions as "free" (from memory map)
     *   4. Reserves critical regions:
     *      - Low 1 MiB (BIOS, real mode, VGA)
     *      - Kernel image (text, data, bss)
     *      - PMM bitmap itself
     *   5. Provides pmm_alloc() / pmm_free() for 4 KiB frames
     *
     * MEMORY MAP EXAMPLE (from QEMU):
     *   0x00000000-0x0009FFFF  Usable (640 KiB)
     *   0x000A0000-0x000FFFFF  Reserved (VGA, BIOS)
     *   0x00100000-0x07FFFFFF  Usable (127 MiB)
     *
     * PMM AFTER INIT:
     *   - Total frames: 32768 (128 MiB / 4 KiB)
     *   - Free frames: ~31000 (some reserved for kernel/BIOS)
     *
     * WHAT IF OUT OF ORDER:
     *   ⚠️  PMM after paging → Can't verify memory safety during paging setup
     *   ⚠️  No PMM at all → Can't allocate memory for future features
     *=======================================================================*/
    kprintf("Initializing PMM...\n");
    pmm_init_from_mb2((const void*)(uintptr_t)info_ptr);
    kprintf("PMM: %u total frames, %u free\n",
            pmm_total_frames(), pmm_free_frames());

    /*=========================================================================
     * PHASE 4: PAGING SETUP AND ACTIVATION
     *=========================================================================
     * GOAL: Enable virtual memory with identity mapping
     *
     * ORDER IMPORTANCE: CRITICAL - Must be after IDT and PMM!
     *
     * WHY AFTER IDT:
     *   Enabling paging can trigger page faults if tables are wrong.
     *   Without IDT, page fault → triple fault (reboot).
     *   With IDT, page fault → handler prints CR2 (faulting address) → debug!
     *
     * WHY AFTER PMM:
     *   Paging needs to know which memory is safe to use.
     *   PMM provides this via the memory map.
     *
     * WHAT PAGING SETUP DOES:
     *   1. Creates page directory (1024 entries, covers 4 GiB)
     *   2. Creates page tables (up to 8 tables, covers 32 MiB)
     *   3. Identity maps: virtual address = physical address
     *      - 0x00000000 → 0x00000000
     *      - 0x00001000 → 0x00001000
     *      - ... (all addresses in first 32 MiB)
     *   4. Ensures page directory and tables are in mapped region
     *   5. Loads CR3 with page directory address
     *   6. Sets CR0.PG bit (enables paging)
     *
     * IDENTITY MAPPING:
     *   Virtual address = Physical address (for simplicity)
     *   Means code continues to work after paging enabled
     *   Future: Use higher-half kernel (virtual != physical)
     *
     * CRITICAL ADDRESSES THAT MUST BE MAPPED:
     *   - Kernel code (0x00100000+) → Must be executable
     *   - Kernel stack (in .bss) → Must be writable
     *   - Page directory/tables → Must be accessible by CPU
     *   - VGA buffer (0x000B8000) → Must be writable
     *
     * DEBUG OUTPUT:
     *   We print messages BEFORE and AFTER critical steps:
     *     - "About to load CR3" → If hangs here: CR3 load failed
     *     - "CR3 loaded" → If hangs here: Page tables bad but CR3 OK
     *     - "About to set PG bit" → If hangs here: CR0 write failed
     *     - "PG=1 set" → If we see this: PAGING WORKS! 🎉
     *
     * WHAT IF OUT OF ORDER:
     *   ❌ Paging before IDT → Page fault → Triple fault → Reboot loop
     *   ❌ Paging before PMM → Can't verify memory safety
     *   ❌ Paging with wrong tables → Page fault → (with IDT: debug!)
     *   ✅ Current order → Paging works, safe, debuggable
     *=======================================================================*/
    kprintf("Enabling paging...\n");
    kprintf("About to load CR3...\n");
    
    /* Build page directory and tables (static arrays in .bss) */
    paging_identity_map_early(32u * 1024u * 1024u);  /* Identity map 32 MiB */
    
    kprintf("CR3 loaded. About to set PG bit...\n");
    
    /* Enable paging: set CR0.PG bit */
    paging_enable();                /* Read CR0, OR with 0x80000000, write back */
    
    kprintf("PG=1 set. Still alive.\n");
    kprintf("Paging enabled (32 MiB identity mapped)\n");

    /*=========================================================================
     * PHASE 5: PMM ALLOCATION TEST (OPTIONAL VERIFICATION)
     *=========================================================================
     * GOAL: Verify PMM works after paging is enabled
     *
     * ORDER IMPORTANCE: LOW - This is just a sanity check
     *
     * WHAT THIS DOES:
     *   1. Allocate two 4 KiB frames
     *   2. Print their addresses
     *   3. Free both frames
     *   4. Print updated free count
     *
     * WHY THIS IS USEFUL:
     *   - Proves PMM still works after paging enabled
     *   - Shows frame allocation in action
     *   - Demonstrates that freed frames return to pool
     *
     * EXPECTED OUTPUT:
     *   Alloc frames: 0x00001000 0x00002000  (example addresses)
     *   PMM free now: 31744                  (should match earlier free count)
     *
     * WHAT IF IT FAILS:
     *   - Returns 0 → PMM has no free frames (shouldn't happen)
     *   - Page fault → Allocated address not in identity map (bug!)
     *   - Free count wrong → PMM bookkeeping broken (bug!)
     *=======================================================================*/
    uint32_t a = pmm_alloc();       /* Allocate first frame */
    uint32_t b = pmm_alloc();       /* Allocate second frame */
    kprintf("Alloc frames: %p %p\n", (void*)a, (void*)b);
    pmm_free(a);                    /* Free first frame */
    pmm_free(b);                    /* Free second frame */
    kprintf("PMM free now: %u\n", pmm_free_frames());

    /*=========================================================================
     * PHASE 6: HARDWARE INTERRUPT SETUP (CURRENTLY DISABLED)
     *=========================================================================
     * GOAL: Enable timer interrupts for scheduling and timing
     *
     * ORDER IMPORTANCE: CRITICAL - Must be last!
     *
     * WHY DISABLED:
     *   During TinyOS development, these were causing issues (selector bug).
     *   Commented out to isolate the paging problem.
     *   Now that paging works, these can be re-enabled.
     *
     * WHY THIS ORDER (when enabled):
     *   1. PIC remap MUST be before STI
     *      - Default PIC vectors (0x08-0x0F) conflict with CPU exceptions
     *      - Remap to 0x20-0x2F to avoid conflicts
     *      - Without remap: timer interrupt → vector 0 (#DE) → confusion!
     *
     *   2. PIT init MUST be before STI
     *      - Timer starts ticking immediately after init
     *      - If STI before init: interrupt fires, no handler ready
     *
     *   3. PIC unmask MUST be after handlers ready
     *      - Only enable IRQs we have handlers for
     *      - Start with IRQ0 (timer) only
     *
     *   4. STI MUST BE ABSOLUTELY LAST
     *      - Enables interrupts globally (sets EFLAGS.IF)
     *      - After STI, interrupts can fire at any time
     *      - Everything must be ready before this point
     *
     * TO RE-ENABLE:
     *   Uncomment lines 131-135 below and rebuild
     *
     * WHAT HAPPENS AFTER RE-ENABLE:
     *   - Timer fires at 100 Hz (every 10 ms)
     *   - Interrupt handler increments tick counter
     *   - Dot printed to screen every second (100 ticks)
     *   - System responds to hardware events
     *
     * WHAT IF OUT OF ORDER:
     *   ❌ STI before PIC remap → IRQ0 fires on vector 0x08 (#DF) → Crash
     *   ❌ STI before PIT init → Interrupt fires before handler ready → #GP
     *   ❌ PIC unmask before handlers → Interrupt fires, no handler → #GP
     *   ✅ Current order (when uncommented) → Timer works safely
     *=======================================================================*/
    
    // UNCOMMENT THESE LINES TO ENABLE TIMER INTERRUPTS:
    kprintf("\nSetting up hardware interrupts...\n");
    pic_remap();                    /* Remap PIC: master=0x20, slave=0x28 */
    pic_mask_all();                 /* Mask all IRQs (start with clean slate) */
    pit_init(100);                  /* Initialize timer: 100 Hz (10 ms period) */
    pic_unmask(0);                  /* Unmask IRQ0 (timer) only */
    
    kprintf("Enabling interrupts...\n");
    __asm__ volatile("sti");        /* Set IF flag: enable interrupts! */
    kprintf("Interrupts enabled!\n");
    
    kprintf("\nTimer running at 100 Hz\n");
    kprintf("Dots will appear on screen (1 per second)\n");
    kprintf("System is now in idle loop.\n\n");

    /*=========================================================================
     * PHASE 7: IDLE LOOP (KERNEL MAIN LOOP)
     *=========================================================================
     * GOAL: Keep CPU running in low-power state, wake on interrupts
     *
     * ORDER IMPORTANCE: Must be last (after all initialization)
     *
     * WHAT THIS DOES:
     *   Infinite loop that:
     *     1. Executes HLT instruction
     *     2. CPU goes to sleep (low power)
     *     3. Hardware interrupt fires (e.g., timer)
     *     4. CPU wakes up, handles interrupt
     *     5. Returns to HLT (loop continues)
     *
     * WHY HLT:
     *   - Saves power (CPU not burning cycles)
     *   - Reduces heat generation
     *   - Good practice even in VMs
     *   - Alternative: "for(;;);" (busy wait, wastes power)
     *
     * INTERRUPTS MUST BE ENABLED:
     *   If STI not called, HLT waits forever (no wake-up source)
     *   Currently: interrupts disabled, so HLT truly sleeps forever
     *   After uncommenting STI: timer wakes CPU every 10 ms
     *
     * WHAT HAPPENS WITH INTERRUPTS ENABLED:
     *   1. HLT → CPU sleeps
     *   2. Timer fires (10 ms later)
     *   3. CPU wakes, executes timer ISR
     *   4. ISR increments tick counter
     *   5. ISR sends EOI to PIC
     *   6. ISR returns (IRET)
     *   7. CPU resumes at HLT instruction
     *   8. Loop back to step 1
     *
     * FUTURE ENHANCEMENTS:
     *   - Scheduler: switch to different task after interrupt
     *   - Power management: deeper sleep states (C-states)
     *   - Work queue: do background tasks in idle loop
     *
     * EXIT CONDITION:
     *   Never. This loop runs forever.
     *   Only way out: power off, reset, or panic/halt.
     *=======================================================================*/
    kprintf("\nKernel initialization complete.\n");
    kprintf("Entering idle loop (HLT)...\n");
    kprintf("System is running. Nothing more to do.\n");
    
    /* Idle loop: sleep and wait for interrupts (currently forever) */
    for (;;) {
        __asm__ volatile("hlt");    /* Halt CPU until next interrupt */
    }
    
    /*-------------------------------------------------------------------------
     * UNREACHABLE CODE
     *-------------------------------------------------------------------------
     * The for(;;) loop above never exits, so this point is never reached.
     * If somehow we get here, it means something is terribly wrong.
     * (This would require a bug in the CPU or memory corruption)
     *-----------------------------------------------------------------------*/
}

/*=============================================================================
 * INITIALIZATION ORDER SUMMARY
 *=============================================================================
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 0: MAKE SYSTEM SAFE                                              │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  1. serial_init()      → Debug output available                         │
 * │  2. console_clear()    → Clean VGA screen                               │
 * │  3. CLI                → Disable interrupts (safety)                    │
 * │  4. pic_mask_all()     → Block all hardware IRQs                        │
 * │                                                                          │
 * │  WHY: Need output for debugging, ensure no interrupts during init       │
 * │  DANGER: Skip this = blind debugging, possible spurious interrupts      │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 1: VERIFY BOOT                                                   │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  5. Print boot banner  → Announce kernel start                          │
 * │  6. Check magic        → Verify Multiboot2 boot                         │
 * │  7. mb_dump_mb2()      → Parse and display boot info                    │
 * │                                                                          │
 * │  WHY: Confirm correct boot, get memory map                              │
 * │  DANGER: Skip check = might not have valid memory map                   │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 2: EXCEPTION HANDLING (CRITICAL!)                                │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  8. idt_init()         → Install exception handlers                     │
 * │                                                                          │
 * │  WHY: Next steps can trigger exceptions (especially page faults)        │
 * │  DANGER: Skip this = triple fault on any exception                      │
 * │                                                                          │
 * │  ⚠️  THIS MUST BE BEFORE PAGING! ⚠️                                     │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 3: MEMORY MANAGEMENT                                             │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  9. pmm_init_from_mb2() → Set up frame allocator                        │
 * │                                                                          │
 * │  WHY: Need to know usable memory before paging                          │
 * │  DANGER: Skip this = can't verify memory safety                         │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 4: VIRTUAL MEMORY (CRITICAL!)                                    │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  10. paging_identity_map_early() → Build page tables                    │
 * │  11. paging_enable()             → Set CR0.PG bit                       │
 * │                                                                          │
 * │  WHY: Enable virtual memory, protection (future)                        │
 * │  DANGER: Wrong tables = page fault (but IDT handles it!)                │
 * │                                                                          │
 * │  ⚠️  THIS MUST BE AFTER IDT! ⚠️                                         │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 5: OPTIONAL VERIFICATION                                         │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  12. pmm_alloc() test  → Verify PMM works after paging                  │
 * │                                                                          │
 * │  WHY: Sanity check, demonstrate frame allocation                        │
 * │  DANGER: None (just verification)                                       │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 6: HARDWARE INTERRUPTS (CURRENTLY DISABLED)                      │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  13. pic_remap()       → Remap PIC vectors (0x20-0x2F)                  │
 * │  14. pit_init()        → Initialize timer (100 Hz)                      │
 * │  15. pic_unmask(0)     → Enable IRQ0 (timer) only                       │
 * │  16. STI               → Enable interrupts globally                     │
 * │                                                                          │
 * │  WHY: Enable timer for scheduling, timing                               │
 * │  DANGER: Wrong order = interrupt on wrong vector = crash                │
 * │                                                                          │
 * │  ⚠️  STI MUST BE ABSOLUTELY LAST! ⚠️                                    │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │  PHASE 7: IDLE LOOP                                                     │
 * │  ═══════════════════════════════════════════════════════════════════════│
 * │  17. for(;;) HLT       → Sleep and wait for interrupts                  │
 * │                                                                          │
 * │  WHY: Keep CPU running in low-power mode                                │
 * │  DANGER: None (this is normal operation)                                │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 *=============================================================================
 * COMMON MISTAKES AND HOW TO AVOID THEM
 *=============================================================================
 *
 * ❌ MISTAKE #1: Enable paging before IDT
 *    SYMPTOM: System reboots immediately (triple fault)
 *    REASON: Page fault during paging setup → No handler → Triple fault
 *    FIX: Move idt_init() before paging_identity_map_early()
 *
 * ❌ MISTAKE #2: STI before PIC remap
 *    SYMPTOM: System crashes when timer fires
 *    REASON: IRQ0 fires on vector 0x08 (conflicts with #DF exception)
 *    FIX: pic_remap() must be before __asm__ volatile("sti")
 *
 * ❌ MISTAKE #3: No serial_init() at start
 *    SYMPTOM: Can't debug early crashes (no output)
 *    REASON: No output method available during initialization
 *    FIX: serial_init() must be absolutely first
 *
 * ❌ MISTAKE #4: Forget CLI at start
 *    SYMPTOM: Spurious interrupt during init (rare but possible)
 *    REASON: GRUB might leave interrupts enabled (spec doesn't guarantee)
 *    FIX: Always CLI immediately after I/O init
 *
 * ❌ MISTAKE #5: Wrong IDT selector (0x08 instead of 0x10)
 *    SYMPTOM: General Protection Fault when interrupt fires
 *    REASON: GRUB's GDT has code segment at 0x10, not 0x08
 *    FIX: Set selector to 0x10 in idt_set_gate() (idt.c)
 *
 * ✅ CORRECT ORDER (REMEMBER THIS):
 *    1. I/O first (serial, VGA)
 *    2. Safety (CLI, PIC mask)
 *    3. IDT (before paging!)
 *    4. PMM (before paging needs memory)
 *    5. Paging (after IDT, after PMM)
 *    6. Hardware interrupts (last!)
 *    7. STI (absolutely last!)
 *    8. Idle loop
 *
 *=============================================================================
 * END OF FILE: kernel.c
 *=============================================================================
 */
