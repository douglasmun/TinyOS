/*=============================================================================
 *  kernel.c — Final working kernel with timer interrupts
 *============================================================================*/
#include "kernel.h"
#include "idt.h"
#include "pmm.h"
#include "paging.h"
#include "serial.h"
#include "kprintf.h"
#include "pic.h"
#include "pit.h"

extern uint32_t get_timer_ticks(void);

void kernel_main(uint32_t magic, uint32_t info_ptr) {
    serial_init();
    console_clear();
    __asm__ volatile("cli");
    pic_mask_all();

    kprintf("TinyOS - Multiboot2 Kernel\n");
    kprintf("Magic: 0x%08x\n", magic);
    kprintf("Info:  0x%08x\n\n", magic);
    
    if (magic != 0x36D76289) {
        kprintf("Not Multiboot2!\n");
        for (;;) __asm__ volatile("cli; hlt");
    }
    
    /* Dump Multiboot2 info */
    mb_dump_mb2((const void*)(uintptr_t)info_ptr);
    
    /* Initialize IDT */
    kprintf("\nInitializing IDT...\n");
    idt_init();
    kprintf("IDT installed\n");
    
    /* Initialize PMM */
    kprintf("Initializing PMM...\n");
    pmm_init_from_mb2((const void*)(uintptr_t)info_ptr);
    kprintf("PMM: %u total frames, %u free\n",
            pmm_total_frames(), pmm_free_frames());
    
    /* Enable paging */
    kprintf("Enabling paging...\n");
    paging_identity_map_early(32u * 1024u * 1024u);
    paging_enable();
    kprintf("Paging enabled (32 MiB identity mapped)\n");
    
    /* Set up hardware interrupts */
    kprintf("\nSetting up hardware interrupts...\n");
    pic_remap();
    pic_mask_all();
    pit_init(100);  /* 100 Hz timer */
    pic_unmask(0);  /* Enable IRQ0 (timer) */
    
    kprintf("Enabling interrupts...\n");
    __asm__ volatile("sti");
    kprintf("Interrupts enabled!\n");
    
    kprintf("\nTimer running at 100 Hz\n");
    kprintf("Dots will appear on screen (1 per second)\n");
    kprintf("System is now in idle loop.\n\n");
    
    /* Idle loop - HLT saves power */
    for (;;) {
        __asm__ volatile("hlt");
    }
}
