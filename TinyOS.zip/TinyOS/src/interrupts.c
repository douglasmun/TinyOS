/*=============================================================================
 *  interrupts.c — Working interrupt handler with timer
 *============================================================================*/
#include "kernel.h"
#include "idt.h"
#include "kprintf.h"

static const char* exc_name[32] = {
    "#DE", "#DB", "NMI", "#BP", "#OF", "#BR", "#UD", "#NM",
    "#DF", "CoProc", "#TS", "#NP", "#SS", "#GP", "#PF", "Rsv",
    "#MF", "#AC", "#MC", "#XF", "Virt", "CP", "R", "R",
    "R", "R", "R", "R", "R", "R", "R", "R"
};

static volatile uint32_t timer_ticks = 0;

void isr_common_handler(uint32_t vector, uint32_t err)
{
    /* Exceptions: print and halt */
    if (vector < 32) {
        kprintf("\n*** EXCEPTION %u (%s) err=0x%x ***\n", 
                vector, exc_name[vector], err);
        
        if (vector == 14) {
            uint32_t cr2;
            __asm__ volatile ("mov %%cr2,%0" : "=r"(cr2));
            kprintf("CR2=0x%08x\n", cr2);
        }
        
        for (;;) __asm__ volatile("cli; hlt");
    }

    /* IRQs */
    if (vector >= 32 && vector <= 47) {
        uint8_t irq = (uint8_t)(vector - 32);
        
        /* IRQ0: Timer */
        if (irq == 0) {
            timer_ticks++;
            
            /* Print dot every second (100 ticks at 100Hz) */
            if (timer_ticks % 100 == 0) {
                /* Direct VGA write - safe in interrupt */
                volatile uint16_t* vga = (volatile uint16_t*)0xB8000;
                static uint8_t col = 0;
                if (col < 80) {
                    vga[col++] = 0x0F00 | '.';
                }
            }
        }
        
        /* Send EOI */
        if (irq >= 8) {
            __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x20), "Nd"((uint16_t)0xA0) : "memory");
        }
        __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x20), "Nd"((uint16_t)0x20) : "memory");
    }
}

uint32_t get_timer_ticks(void) {
    return timer_ticks;
}
