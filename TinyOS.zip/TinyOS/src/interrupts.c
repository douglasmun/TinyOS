/*=============================================================================
 *  interrupts.c — TinyOS Common Interrupt and Exception Handler
 *=============================================================================
 *
 * PURPOSE:
 *   This file contains the C-level interrupt handler that processes all CPU
 *   exceptions (vectors 0-31) and hardware IRQs (vectors 32-47). It's called
 *   from the assembly stubs in isr.S after registers are saved.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - i386 (32-bit x86) protected mode
 *   - Interrupt-driven architecture
 *   - Integrated with IDT (idt.c), PIC (pic.c), PIT (pit.c)
 *
 * CALL CHAIN (How we get here):
 *   1. Hardware/CPU triggers interrupt (e.g., timer tick, divide by zero)
 *   2. CPU looks up vector in IDT (Interrupt Descriptor Table)
 *   3. CPU finds ISR stub address (isr0-isr31, irq32-irq47 in isr.S)
 *   4. CPU pushes EFLAGS, CS, EIP (and error code for some exceptions)
 *   5. CPU jumps to ISR stub
 *   6. ISR stub pushes vector number and error code (if not already pushed)
 *   7. ISR stub calls isr_common (assembly)
 *   8. isr_common saves all registers (PUSHA)
 *   9. isr_common calls THIS FUNCTION → isr_common_handler()
 *   10. We process the interrupt here (C code)
 *   11. Return to isr_common
 *   12. isr_common restores registers (POPA)
 *   13. isr_common executes IRET
 *   14. CPU restores EFLAGS, CS, EIP and resumes execution
 *
 * RESPONSIBILITIES:
 *   - Handle CPU exceptions (print error, halt)
 *   - Handle hardware IRQs (process, send EOI)
 *   - Maintain timer tick counter
 *   - Provide visual feedback (dots on screen)
 *
 * CRITICAL CONCEPTS:
 *   - Reentrancy: Can this function be interrupted while running?
 *   - Atomicity: Are operations safe from partial completion?
 *   - Side effects: What global state does this modify?
 *   - Performance: How fast must this execute?
 *
 * INTERRUPT SAFETY:
 *   This code runs with interrupts DISABLED (IF=0) because:
 *     - CPU automatically clears IF when entering interrupt
 *     - Assembly stub executes CLI (paranoid extra safety)
 *     - Prevents nested interrupts (interrupt within interrupt)
 *     - Ensures atomic operations on shared data
 *
 * FUTURE ENHANCEMENTS:
 *   - Per-IRQ handler registration (function pointers)
 *   - Interrupt statistics (count per vector)
 *   - Interrupt latency measurement
 *   - Deferred interrupt processing (bottom halves)
 *
 *============================================================================*/

#include "kernel.h"
#include "idt.h"        /* For isr_common_handler prototype */
#include "kprintf.h"    /* For error messages (exceptions) */

/*-----------------------------------------------------------------------------
 * IMPORTANT: Why not use kprintf in interrupt handlers?
 *-----------------------------------------------------------------------------
 * kprintf() calls console_putc() and serial_putc(), which:
 *   - May have their own state (cursor position, serial buffer)
 *   - Could be in the middle of execution when interrupt fires
 *   - Not designed for reentrancy (safe interrupt use)
 *
 * For timer interrupts, we use DIRECT VGA WRITES instead:
 *   - Write directly to 0xB8000 (VGA text buffer)
 *   - No function calls, no state, just memory write
 *   - Guaranteed safe in interrupt context
 *   - Fast (important for high-frequency interrupts)
 *
 * For exceptions, we DO use kprintf because:
 *   - Exception = fatal error, system will halt anyway
 *   - No concern about reentrancy (we won't return)
 *   - Need detailed error output for debugging
 *---------------------------------------------------------------------------*/

/*=============================================================================
 * CPU EXCEPTION NAMES
 *=============================================================================
 * DESCRIPTION:
 *   Human-readable names for the 32 CPU exception vectors.
 *   Used when printing exception information to help developers identify
 *   the type of fault that occurred.
 *
 * EXCEPTION TYPES:
 *   Faults:     Correctable, EIP points to faulting instruction
 *               Example: #PF (page fault) - can fix and retry
 *   
 *   Traps:      Reported after execution, EIP points to next instruction
 *               Example: #BP (breakpoint) - for debugging
 *   
 *   Aborts:     Severe error, cannot continue, EIP may be unreliable
 *               Example: #MC (machine check) - hardware failure
 *
 * VECTORS 0-31: Reserved by Intel for CPU exceptions
 * VECTORS 32-255: Available for hardware IRQs and software interrupts
 *
 * ERROR CODES:
 *   Some exceptions push error codes, others don't:
 *     - Vector 8:  Always 0 (reserved)
 *     - Vector 10: Segment selector (TSS)
 *     - Vector 11: Segment selector (not present)
 *     - Vector 12: Segment selector or 0 (stack fault)
 *     - Vector 13: Segment selector or 0 (general protection)
 *     - Vector 14: Error flags + CR2 has faulting address
 *     - Vector 17: Always 0 (alignment check)
 *============================================================================*/
static const char* exc_name[32] = {
    /* Vector 0-7 */
    "#DE Divide Error",           /* Division by zero or overflow */
    "#DB Debug",                  /* Debugger breakpoint or single-step */
    "NMI",                        /* Non-Maskable Interrupt (hardware) */
    "#BP Breakpoint",             /* INT 3 instruction (debugger) */
    "#OF Overflow",               /* INTO instruction with OF=1 */
    "#BR BOUND Range",            /* BOUND instruction out of range */
    "#UD Invalid Opcode",         /* Undefined or illegal instruction */
    "#NM Device Not Available",   /* FPU instruction without FPU */
    
    /* Vector 8-15 */
    "#DF Double Fault",           /* Exception while handling exception */
    "Coprocessor Segment Overrun",/* Legacy, shouldn't happen on modern CPUs */
    "#TS Invalid TSS",            /* Task state segment invalid/not present */
    "#NP Segment Not Present",    /* Segment marked "not present" */
    "#SS Stack Fault",            /* Stack segment fault (limit/not present) */
    "#GP General Protection",     /* Many causes: segment, privilege, etc. */
    "#PF Page Fault",             /* Page not present, protection violation */
    "Reserved",                   /* Intel reserved, shouldn't fire */
    
    /* Vector 16-23 */
    "#MF x87 FP Exception",       /* x87 FPU floating-point error */
    "#AC Alignment Check",        /* Unaligned memory access (if enabled) */
    "#MC Machine Check",          /* Processor or bus error (serious!) */
    "#XF SIMD FP Exception",      /* SSE/AVX floating-point exception */
    "Virtualization",             /* Virtualization exception (EPT, etc.) */
    "Control Protection",         /* Control-flow enforcement (CET) */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    
    /* Vector 24-31 */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    "Reserved",                   /* Intel reserved */
    "Reserved"                    /* Intel reserved */
};

/*=============================================================================
 * GLOBAL TIMER TICK COUNTER
 *=============================================================================
 * DESCRIPTION:
 *   Counts the number of timer interrupts (IRQ0) that have occurred.
 *   Incremented by timer interrupt handler, can be read by kernel code.
 *
 * TYPE: volatile uint32_t
 *   - volatile: Tells compiler this can change unexpectedly (by IRQ)
 *   - uint32_t: 32-bit unsigned, wraps at 4,294,967,296 ticks
 *
 * WHY VOLATILE:
 *   Without 'volatile', compiler might optimize away reads:
 *     while (timer_ticks < 100) {} // Might become infinite loop!
 *   
 *   With 'volatile', compiler always reads from memory:
 *     while (timer_ticks < 100) {} // Works correctly
 *
 * WRAPAROUND:
 *   At 100 Hz, wraps after: 4,294,967,296 / 100 / 60 / 60 / 24 = 497 days
 *   For longer uptime, use 64-bit counter or track wraparounds.
 *
 * THREAD SAFETY:
 *   - Reads are atomic (single 32-bit load instruction)
 *   - Writes are atomic (single 32-bit store instruction)
 *   - Increment is NOT atomic (read-modify-write)
 *   - Safe here because only IRQ handler modifies it (interrupts disabled)
 *
 * USAGE EXAMPLES:
 *   - Delays: while (timer_ticks < start + 100) {} // Wait 1 second
 *   - Uptime: uptime_seconds = timer_ticks / 100
 *   - Scheduling: if (timer_ticks >= next_task_time) switch_task();
 *============================================================================*/
static volatile uint32_t timer_ticks = 0;

/*=============================================================================
 * FUNCTION: isr_common_handler
 *=============================================================================
 * DESCRIPTION:
 *   The main C interrupt handler. Called from assembly (isr_common in isr.S)
 *   after all registers have been saved. Processes CPU exceptions and
 *   hardware IRQs, then returns to assembly for register restoration.
 *
 * PARAMETERS:
 *   vector - Interrupt vector number (0-255)
 *            0-31:  CPU exceptions
 *            32-47: Hardware IRQs (after PIC remap to 0x20-0x2F)
 *            48+:   Available (not currently used)
 *
 *   err    - Error code (if exception pushed one, otherwise 0)
 *            Meaning varies by exception type:
 *              Vector 8:  Always 0
 *              Vector 10: Segment selector (TSS)
 *              Vector 11: Segment selector (segment not present)
 *              Vector 12: Segment selector or 0 (stack fault)
 *              Vector 13: Segment selector or 0 (GP fault)
 *              Vector 14: Page fault error code (see below)
 *              Vector 17: Always 0
 *
 * RETURNS:
 *   void - Never returns for exceptions (system halts)
 *          Returns normally for IRQs (execution resumes)
 *
 * CALLING CONVENTION:
 *   C cdecl (called from assembly, parameters on stack)
 *
 * CPU STATE ON ENTRY:
 *   - Interrupts: DISABLED (IF=0, set by CPU and assembly stub)
 *   - Stack:      Contains saved registers and return information
 *   - Segments:   Same as when interrupt occurred (kernel segments)
 *
 * EXECUTION CONTEXT:
 *   This runs in INTERRUPT CONTEXT, which means:
 *     - Cannot sleep or block (no waiting)
 *     - Cannot call most kernel functions (many not interrupt-safe)
 *     - Must be fast (blocks all other interrupts)
 *     - Cannot access user memory safely (might cause page fault)
 *     - Must not use floating-point (FPU state not saved)
 *
 * PERFORMANCE CONSIDERATIONS:
 *   - Timer fires 100 times per second (every 10 ms)
 *   - This function should complete in microseconds
 *   - Avoid loops, complex logic, function calls
 *   - Defer heavy work to kernel threads (future)
 *
 *============================================================================*/
void isr_common_handler(uint32_t vector, uint32_t err)
{
    /*=========================================================================
     * EXCEPTION HANDLING (Vectors 0-31)
     *=========================================================================
     * CPU exceptions are serious errors that usually indicate bugs:
     *   - Programming errors: divide by zero, invalid opcode
     *   - Memory errors: page fault, segment fault
     *   - Hardware errors: machine check
     *
     * EXCEPTION STRATEGY:
     *   1. Print detailed error information
     *   2. Print special registers (CR2 for page faults)
     *   3. Halt system (infinite loop with HLT)
     *   4. Never return (exception = fatal error)
     *
     * WHY HALT INSTEAD OF RECOVER:
     *   - Early kernel development: recovery is complex
     *   - No userspace yet: can't just kill one process
     *   - Better to halt and debug than continue with corruption
     *   - Future: could try recovery for some exceptions
     *
     * DEBUGGING EXCEPTIONS:
     *   When exception occurs, you'll see:
     *     *** CPU EXCEPTION ***
     *     Vector : 14 (#PF Page Fault)
     *     Error  : 0x00000002
     *     CR2    : 0x00500000  ← Faulting address
     *
     *   Error code bits (for #PF):
     *     Bit 0 (P):    0 = not present, 1 = protection violation
     *     Bit 1 (W/R):  0 = read, 1 = write
     *     Bit 2 (U/S):  0 = kernel mode, 1 = user mode
     *     Bit 3 (RSVD): 1 = reserved bit set in page table
     *     Bit 4 (I/D):  1 = instruction fetch
     *=======================================================================*/
    if (vector < 32) {
        /*---------------------------------------------------------------------
         * CPU EXCEPTION OCCURRED
         *---------------------------------------------------------------------
         * This is a serious error. Print detailed information and halt.
         *
         * INFORMATION PRINTED:
         *   - Vector number and name (e.g., "14 (#PF Page Fault)")
         *   - Error code (interpretation varies by exception)
         *   - CR2 register (page fault only: faulting address)
         *
         * AFTER PRINTING:
         *   - Enter infinite loop
         *   - CLI to ensure interrupts stay disabled
         *   - HLT to reduce CPU usage
         *   - Never returns
         *
         * COMMON EXCEPTIONS DURING DEVELOPMENT:
         *   #GP (13): Wrong segment selector, privilege violation
         *   #PF (14): Page not present, wrong permissions, bad address
         *   #DF (8):  Exception while handling exception (very bad!)
         *   #UD (6):  Invalid instruction (wrong opcode, compiler bug)
         *-------------------------------------------------------------------*/
        
        /* Print exception banner */
        kprintf("\n*** CPU EXCEPTION ***\n");
        
        /* Print vector and exception name */
        kprintf("Vector : %u (%s)\n", vector, exc_name[vector]);
        
        /* Print error code (interpretation varies by exception type) */
        kprintf("Error  : 0x%08x\n", err);

        /*---------------------------------------------------------------------
         * SPECIAL HANDLING: Page Fault (#PF, Vector 14)
         *---------------------------------------------------------------------
         * Page faults are the most common exception during kernel development.
         * They occur when:
         *   - Accessing unmapped memory (page not present)
         *   - Writing to read-only memory (protection violation)
         *   - User mode accessing kernel memory (privilege violation)
         *
         * CR2 REGISTER:
         *   When page fault occurs, CPU stores faulting address in CR2.
         *   This tells us EXACTLY where the bad memory access occurred.
         *
         * ERROR CODE BITS (for page faults):
         *   Bit 0 (P):    0 = page not present, 1 = protection violation
         *   Bit 1 (W/R):  0 = read access, 1 = write access
         *   Bit 2 (U/S):  0 = kernel mode, 1 = user mode
         *   Bit 3 (RSVD): 1 = reserved bit was set in page table entry
         *   Bit 4 (I/D):  1 = instruction fetch caused fault
         *
         * EXAMPLE:
         *   CR2    : 0x00500000
         *   Error  : 0x00000002 (bit 1 set)
         *   Meaning: Tried to WRITE to address 0x00500000, page not present
         *
         * DEBUGGING TIPS:
         *   - CR2 in kernel space (0x00100000+): kernel bug
         *   - CR2 near NULL (0x00000000): null pointer dereference
         *   - CR2 in unmapped region: wrong paging setup
         *   - Error bit 0 clear: page table entry missing
         *   - Error bit 1 set: write to read-only page
         *-------------------------------------------------------------------*/
        if (vector == 14) {
            uint32_t cr2;
            
            /* Read CR2 register (contains faulting linear address) */
            __asm__ volatile ("mov %%cr2,%0" : "=r"(cr2));
            
            /* Print the faulting address */
            kprintf("CR2    : 0x%08x\n", cr2);
            
            /* FUTURE: Could print decoded error code:
             *   kprintf("Cause  : %s %s in %s mode\n",
             *           (err & 1) ? "protection" : "not present",
             *           (err & 2) ? "write" : "read",
             *           (err & 4) ? "user" : "kernel");
             */
        }

        /*---------------------------------------------------------------------
         * HALT SYSTEM AFTER EXCEPTION
         *---------------------------------------------------------------------
         * Cannot recover from exception safely at this point.
         * Halt with clear message so developer can debug.
         *
         * WHY INFINITE LOOP:
         *   - Prevents execution from continuing with corrupted state
         *   - Keeps error message visible on screen
         *   - Allows debugger to examine state (if using GDB)
         *
         * WHY CLI:
         *   - Ensures interrupts stay disabled
         *   - Prevents interrupt handlers from running on corrupted state
         *   - Paranoid safety (interrupts already disabled)
         *
         * WHY HLT:
         *   - Reduces CPU usage (saves power)
         *   - Prevents CPU from burning cycles doing nothing
         *   - Better than empty loop: for(;;);
         *
         * WHAT HAPPENS:
         *   System is frozen. Only way out:
         *     - Press reset button
         *     - Power cycle
         *     - QEMU: Ctrl-A X (quit)
         *     - GDB: Can still examine state
         *-------------------------------------------------------------------*/
        kprintf("System halted.\n");
        
        /* Infinite halt loop */
        for (;;) {
            __asm__ volatile("cli; hlt");
        }
        
        /* UNREACHABLE - This point never reached because loop is infinite */
        return;
    }

    /*=========================================================================
     * HARDWARE IRQ HANDLING (Vectors 32-47)
     *=========================================================================
     * Hardware interrupts are generated by external devices:
     *   - IRQ 0 (vector 32): PIT timer (ticks 100 times per second)
     *   - IRQ 1 (vector 33): Keyboard (when key pressed/released)
     *   - IRQ 2 (vector 34): PIC cascade (never fires, internal)
     *   - IRQ 3-7: Serial, parallel, etc.
     *   - IRQ 8-15: RTC, mouse, hard disk, etc.
     *
     * IRQ HANDLING STRATEGY:
     *   1. Calculate IRQ number from vector (irq = vector - 32)
     *   2. Process the specific IRQ (switch statement)
     *   3. Send EOI (End-Of-Interrupt) to PIC(s)
     *   4. Return (execution resumes where interrupted)
     *
     * PIC CONSIDERATIONS:
     *   - Must send EOI before returning
     *   - IRQ 8-15 need EOI to both slave and master PIC
     *   - If no EOI sent, that IRQ will never fire again
     *
     * PERFORMANCE:
     *   IRQs should be FAST (microseconds, not milliseconds):
     *     - Timer fires 100 times per second
     *     - Slow handler = system lag
     *     - Heavy work should be deferred to kernel threads
     *=======================================================================*/
    if (vector >= 32 && vector <= 47) {
        /*---------------------------------------------------------------------
         * Calculate IRQ number from vector
         *---------------------------------------------------------------------
         * After PIC remap (pic_remap in pic.c):
         *   Vector 32 = IRQ 0 (timer)
         *   Vector 33 = IRQ 1 (keyboard)
         *   ...
         *   Vector 47 = IRQ 15 (secondary IDE)
         *
         * Formula: IRQ = Vector - 32
         *-------------------------------------------------------------------*/
        uint8_t irq = (uint8_t)(vector - 32);
        
        /*---------------------------------------------------------------------
         * IRQ-SPECIFIC HANDLERS
         *---------------------------------------------------------------------
         * Different IRQs need different handling logic.
         * Currently implemented:
         *   IRQ 0: Timer (increment counter, print dots)
         *   IRQ 1: Keyboard (future - not implemented yet)
         *   Others: Ignored (just send EOI)
         *-------------------------------------------------------------------*/
        
        /*=====================================================================
         * IRQ 0: PROGRAMMABLE INTERVAL TIMER (PIT)
         *=====================================================================
         * FREQUENCY: 100 Hz (configured in pit_init)
         * PERIOD:    10 milliseconds per tick
         * PURPOSE:   System timing, scheduling, delays
         *
         * WHAT WE DO:
         *   1. Increment global tick counter
         *   2. Every 100 ticks (1 second), print a dot to screen
         *
         * WHY DIRECT VGA WRITES:
         *   Cannot use kprintf() or console_putc() because:
         *     - Not interrupt-safe (could be mid-operation when IRQ fires)
         *     - Too slow for high-frequency interrupts
         *     - Could cause reentrancy issues
         *
         *   Direct VGA write is safe because:
         *     - Just a memory write to 0xB8000
         *     - No state, no locks, no function calls
         *     - Very fast (one or two instructions)
         *
         * DOT DISPLAY LOGIC:
         *   - Timer fires 100 times per second
         *   - timer_ticks % 100 == 0 means "1 second elapsed"
         *   - Write a dot character (ASCII 0x2E) to VGA memory
         *   - Attribute byte 0x0F = white on black
         *   - Stop at column 80 to prevent wrapping
         *
         * VGA MEMORY LAYOUT:
         *   Address: 0xB8000 + (row * 160) + (col * 2)
         *   Each character cell = 2 bytes:
         *     Byte 0: ASCII character code
         *     Byte 1: Attribute (color)
         *
         *   For row 0, simplified:
         *     0xB8000 + (col * 2) = character
         *     0xB8000 + (col * 2) + 1 = attribute
         *
         *   Writing as 16-bit value:
         *     vga[col] = 0x0F2E  // High byte = attr, low byte = char
         *
         * STATIC VARIABLE: col
         *   - Persists across function calls (retains position)
         *   - Not volatile (only modified here, no concurrent access)
         *   - Reset would require reboot or explicit call
         *===================================================================*/
        if (irq == 0) {
            /* Increment the global timer tick counter */
            timer_ticks++;
            
            /*-----------------------------------------------------------------
             * VISUAL FEEDBACK: Print dot every second
             *-----------------------------------------------------------------
             * Purpose: Shows system is alive and timer is working
             * Frequency: Once per second (100 ticks at 100 Hz)
             * Method: Direct VGA memory write (interrupt-safe)
             *---------------------------------------------------------------*/
            if (timer_ticks % 100 == 0) {
                /*-------------------------------------------------------------
                 * DIRECT VGA MEMORY ACCESS
                 *-------------------------------------------------------------
                 * VGA text buffer: 80 columns × 25 rows × 2 bytes per char
                 * Base address: 0xB8000 (physical = virtual, identity mapped)
                 * Format: [char][attr][char][attr]...
                 *
                 * Volatile pointer needed because:
                 *   - Memory-mapped I/O (not regular RAM)
                 *   - Compiler might optimize away writes
                 *   - Must ensure actual memory write occurs
                 *
                 * Type: uint16_t (16-bit value)
                 *   Low byte (bits 0-7):   ASCII character code
                 *   High byte (bits 8-15): Attribute byte
                 *
                 * Attribute byte format:
                 *   Bits 0-3: Foreground color
                 *   Bits 4-6: Background color
                 *   Bit 7:    Blink (usually ignored by modern video cards)
                 *
                 * 0x0F = White foreground (15), black background (0)
                 *-----------------------------------------------------------*/
                volatile uint16_t* vga = (volatile uint16_t*)0xB8000;
                
                /*-------------------------------------------------------------
                 * Column tracking (static variable)
                 *-------------------------------------------------------------
                 * Static: value preserved across function calls
                 * Starts at 0 on first call
                 * Increments each time we print a dot
                 * Stops at 80 (screen width) to prevent wrapping
                 *-----------------------------------------------------------*/
                static uint8_t col = 0;
                
                /*-------------------------------------------------------------
                 * Write dot to screen if room available
                 *-------------------------------------------------------------
                 * ASCII 0x2E = '.' (period/dot character)
                 * Attribute 0x0F = white on black
                 * Combined as 16-bit: 0x0F2E
                 *
                 * Memory layout:
                 *   vga[0] = first character (column 0)
                 *   vga[1] = second character (column 1)
                 *   ...
                 *   vga[79] = last character (column 79)
                 *
                 * After write:
                 *   Increment col to move to next position
                 *   Stop at 80 to prevent writing off-screen
                 *-----------------------------------------------------------*/
                if (col < 80) {
                    /* Write dot: high byte = attribute, low byte = character */
                    vga[col] = 0x0F00 | '.';
                    
                    /* Move to next column for next dot */
                    col++;
                }
                
                /*-------------------------------------------------------------
                 * ALTERNATIVE: Could wrap to next line
                 *-------------------------------------------------------------
                 * if (col >= 80) {
                 *     col = 0;
                 *     row++;
                 *     if (row >= 25) row = 0;  // Wrap to top
                 * }
                 * vga[row * 80 + col] = 0x0F2E;
                 * col++;
                 *
                 * Current design: just stop at column 80 (simpler)
                 *-----------------------------------------------------------*/
            }
        }
        
        /*---------------------------------------------------------------------
         * IRQ 1: KEYBOARD (FUTURE)
         *---------------------------------------------------------------------
         * Keyboard generates IRQ1 when key pressed or released.
         *
         * TO IMPLEMENT:
         *   1. Read scancode from port 0x60:
         *        uint8_t scancode;
         *        __asm__ volatile("inb $0x60,%0" : "=a"(scancode));
         *
         *   2. Translate scancode to ASCII (scancode table)
         *
         *   3. Handle special keys (shift, ctrl, alt)
         *
         *   4. Store in keyboard buffer (circular queue)
         *
         *   5. Wake any processes waiting for input
         *
         * SCANCODES:
         *   Make codes (key press):   0x01-0x58
         *   Break codes (key release): 0x81-0xD8 (make code | 0x80)
         *
         * EXAMPLE SCANCODES:
         *   0x1E = 'A' key pressed
         *   0x9E = 'A' key released (0x1E | 0x80)
         *
         * REFERENCE: https://wiki.osdev.org/PS/2_Keyboard
         *-------------------------------------------------------------------*/
        /* if (irq == 1) {
         *     // Keyboard handler here
         * }
         */

        /*---------------------------------------------------------------------
         * SEND EOI (END-OF-INTERRUPT) TO PIC
         *---------------------------------------------------------------------
         * CRITICAL: Must send EOI before returning, or IRQ won't fire again!
         *
         * WHY EOI IS NEEDED:
         *   - PIC latches interrupt line when IRQ fires
         *   - Latch must be cleared by sending EOI command
         *   - Without EOI, PIC thinks interrupt is still being serviced
         *   - That IRQ will never fire again
         *
         * WHICH PIC(S):
         *   - IRQ 0-7 (master PIC): Send EOI to port 0x20
         *   - IRQ 8-15 (slave PIC): Send EOI to BOTH 0xA0 and 0x20
         *
         * EOI COMMAND:
         *   Value: 0x20 (generic EOI, non-specific)
         *   Port 0x20: Master PIC command register
         *   Port 0xA0: Slave PIC command register
         *
         * WHY INLINE ASSEMBLY:
         *   - pic_eoi() function call adds overhead
         *   - Inline is faster (important for high-frequency IRQs)
         *   - Direct control over exact instructions
         *
         * MEMORY BARRIER:
         *   The "memory" clobber tells compiler:
         *     - Don't reorder this instruction
         *     - Don't optimize away
         *     - Treat as having side effects
         *-------------------------------------------------------------------*/
        
        /* Slave PIC (IRQ 8-15): Send EOI to both slave and master */
        if (irq >= 8) {
            /* Send EOI to slave PIC (0xA0) */
            __asm__ volatile(
                "outb %0, %1"           /* OUT 0xA0, AL (AL = 0x20) */
                :                       /* No outputs */
                : "a"((uint8_t)0x20),   /* Input: AL = 0x20 (EOI command) */
                  "Nd"((uint16_t)0xA0)  /* Input: port = 0xA0 (slave PIC) */
                : "memory"              /* Clobber: has memory side effects */
            );
        }
        
        /* Master PIC (all IRQs): Always send EOI to master */
        __asm__ volatile(
            "outb %0, %1"               /* OUT 0x20, AL (AL = 0x20) */
            :                           /* No outputs */
            : "a"((uint8_t)0x20),       /* Input: AL = 0x20 (EOI command) */
              "Nd"((uint16_t)0x20)      /* Input: port = 0x20 (master PIC) */
            : "memory"                  /* Clobber: has memory side effects */
        );
        
        /*---------------------------------------------------------------------
         * Return to caller (isr_common in isr.S)
         *---------------------------------------------------------------------
         * After return:
         *   - isr_common restores all registers (POPA)
         *   - isr_common removes vector and error from stack
         *   - isr_common executes IRET
         *   - CPU restores EFLAGS, CS, EIP
         *   - Execution resumes where interrupted
         *
         * INTERRUPT FLAG:
         *   - IF is still 0 (interrupts disabled) at this point
         *   - IRET will restore IF from saved EFLAGS
         *   - If IF was 1 before interrupt, it will be 1 after IRET
         *   - This allows nested interrupts (if IF was 1)
         *
         * REENTRANCY:
         *   If another IRQ fires immediately after IRET:
         *     - This function might be called again
         *     - Before previous call completely finished
         *     - Must be careful with shared state
         *     - Static variables, global variables must be safe
         *-------------------------------------------------------------------*/
        return;
    }

    /*=========================================================================
     * SPURIOUS OR UNHANDLED INTERRUPTS (Vectors 48-255)
     *=========================================================================
     * WHAT ARE THESE:
     *   - Vectors not used by CPU exceptions or hardware IRQs
     *   - Could be:
     *       * Software interrupts (INT instruction)
     *       * Spurious interrupts (PIC glitch)
     *       * Future hardware (additional devices)
     *       * Bugs (wrong vector in IDT)
     *
     * WHY PRINT WARNING:
     *   - Helps identify configuration errors
     *   - Shows if spurious interrupts occurring
     *   - Debugging aid
     *
     * WHY NOT HALT:
     *   - Might not be fatal
     *   - Could be expected (software interrupt)
     *   - Let kernel continue and see if it works
     *
     * SPURIOUS INTERRUPTS:
     *   - Can occur on IRQ 7 (vector 39) and IRQ 15 (vector 47)
     *   - Caused by PIC hardware quirk
     *   - Should NOT send EOI for spurious interrupts
     *   - Rare in modern systems
     *
     * FUTURE:
     *   Could have handler registration system:
     *     irq_handlers[vector] = my_handler;
     *   Then call: irq_handlers[vector](vector, err);
     *=========================================================================*/
    kprintf("\n[warn] Unhandled vector: %u (err=0x%08x)\n", vector, err);
}

/*=============================================================================
 * FUNCTION: get_timer_ticks
 *=============================================================================
 * DESCRIPTION:
 *   Returns the current value of the timer tick counter.
 *   Each tick represents one timer interrupt (10 ms at 100 Hz).
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   uint32_t - Number of timer ticks since boot
 *
 * THREAD SAFETY:
 *   - Read is atomic (single 32-bit load)
 *   - Safe to call from any context
 *   - Value can change between consecutive reads
 *
 * USAGE EXAMPLES:
 *   // Get current uptime in seconds
 *   uint32_t uptime = get_timer_ticks() / 100;
 *
 *   // Delay for 1 second
 *   uint32_t start = get_timer_ticks();
 *   while (get_timer_ticks() < start + 100) {
 *       __asm__ volatile("hlt");  // Sleep while waiting
 *   }
 *
 *   // Check if timeout occurred
 *   uint32_t deadline = get_timer_ticks() + 500;  // 5 seconds
 *   while (get_timer_ticks() < deadline) {
 *       if (operation_complete()) break;
 *   }
 *
 * WRAPAROUND:
 *   Counter wraps at 2^32 (4,294,967,296)
 *   At 100 Hz: wraps after 497 days
 *   Code should handle wraparound:
 *     if ((int32_t)(deadline - get_timer_ticks()) > 0) {
 *         // deadline not reached
 *     }
 *============================================================================*/
uint32_t get_timer_ticks(void) {
    return timer_ticks;
}

/*=============================================================================
 * INTERRUPT HANDLING BEST PRACTICES
 *=============================================================================
 *
 * DO:
 *   ✅ Keep handlers FAST (microseconds, not milliseconds)
 *   ✅ Use volatile for variables modified by interrupts
 *   ✅ Send EOI before returning (or IRQ won't fire again)
 *   ✅ Use direct hardware access (VGA, not console functions)
 *   ✅ Print detailed info for exceptions (aids debugging)
 *   ✅ Halt on fatal errors (better than corruption)
 *
 * DON'T:
 *   ❌ Call non-interrupt-safe functions (printf, malloc, etc.)
 *   ❌ Use floating-point (FPU state not saved)
 *   ❌ Do heavy computation (blocks other interrupts)
 *   ❌ Access user memory without validation
 *   ❌ Sleep or wait for events
 *   ❌ Forget to send EOI (IRQ won't fire again!)
 *
 * DEBUGGING TIPS:
 *   - Add static counter per IRQ: static int count; count++;
 *   - Print counter every N ticks: if (count % 100 == 0) kprintf(...)
 *   - Use QEMU logging: qemu -d int,cpu_reset -D qemu.log
 *   - Check IDT entries: objdump -d kernel.elf | grep isr
 *   - Verify selector: should be 0x10 (GRUB's code segment)
 *
 * PERFORMANCE:
 *   Timer at 100 Hz = 100 interrupts per second
 *   If handler takes 10 µs: 100 × 10µs = 1 ms/sec = 0.1% CPU
 *   If handler takes 100 µs: 100 × 100µs = 10 ms/sec = 1% CPU
 *   Goal: keep under 1% (< 100 µs per interrupt)
 *
 *=============================================================================
 * END OF FILE: interrupts.c
 *=============================================================================
 */
