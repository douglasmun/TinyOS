/*=============================================================================
 *  paging.c — TinyOS Virtual Memory Management (Identity Mapping Bootstrap)
 *=============================================================================
 *
 * PURPOSE:
 *   This file implements the x86 paging subsystem that enables virtual memory.
 *   It creates and enables page tables with identity mapping (virtual address
 *   = physical address) for the first 32 MiB of memory. This is a bootstrap
 *   setup used during kernel initialization before a full MMU is available.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - i386 (32-bit x86)
 *   - 4 KiB pages (standard x86 page size)
 *   - Two-level paging: Page Directory → Page Tables
 *   - Identity mapping: Virtual address = Physical address
 *
 * VIRTUAL MEMORY BASICS:
 *   Virtual memory allows each process to have its own address space,
 *   providing isolation and protection. The CPU's Memory Management Unit
 *   (MMU) translates virtual addresses to physical addresses using page tables.
 *
 *   Benefits:
 *     1. Isolation: Processes can't access each other's memory
 *     2. Protection: Read-only pages, executable pages, kernel-only pages
 *     3. Flexibility: Can map same physical page to multiple virtual addresses
 *     4. Efficiency: Can use less physical RAM than virtual address space
 *
 * X86 PAGING ARCHITECTURE (32-BIT):
 *   x86 uses a two-level page table structure:
 *
 *   ┌─────────────────────────────────────────────────────────────────────┐
 *   │  Virtual Address (32 bits)                                          │
 *   ├──────────────┬──────────────┬──────────────────────────────────────┤
 *   │  Directory   │    Table     │           Offset                     │
 *   │  Index       │    Index     │           (12 bits)                  │
 *   │  (10 bits)   │   (10 bits)  │                                      │
 *   └──────────────┴──────────────┴──────────────────────────────────────┘
 *        Bits          Bits            Bits
 *       31-22         21-12           11-0
 *
 *   Translation Process:
 *     1. CPU reads CR3 register (contains Page Directory physical address)
 *     2. Extract Directory Index (bits 31-22) from virtual address
 *     3. Read Page Directory Entry (PDE) at index in Page Directory
 *     4. PDE contains physical address of Page Table
 *     5. Extract Table Index (bits 21-12) from virtual address
 *     6. Read Page Table Entry (PTE) at index in Page Table
 *     7. PTE contains physical address of actual page frame
 *     8. Add Offset (bits 11-0) to page frame address
 *     9. Result: Physical address!
 *
 * PAGE SIZE AND COVERAGE:
 *   - Page size: 4096 bytes (4 KiB) - standard x86
 *   - Page Table: 1024 entries × 4 KiB = 4 MiB coverage
 *   - Page Directory: 1024 entries × 4 MiB = 4 GiB coverage (full 32-bit)
 *
 * IDENTITY MAPPING:
 *   Identity mapping means virtual address equals physical address:
 *     Virtual 0x00000000 → Physical 0x00000000
 *     Virtual 0x00001000 → Physical 0x00001000
 *     Virtual 0x00100000 → Physical 0x00100000 (kernel at 1 MiB)
 *
 *   Why use identity mapping:
 *     1. Simplicity: Code continues to work after paging enabled
 *     2. No address translation needed during early boot
 *     3. Kernel can directly access all physical memory
 *     4. Easier debugging: addresses mean the same thing
 *
 *   Future improvement: Higher-half kernel
 *     Map kernel to 0xC0000000+ (3 GiB), leaving 0-3GiB for user space
 *
 * PAGE DIRECTORY ENTRY (PDE) FORMAT:
 *   32-bit entry pointing to a Page Table
 *
 *   Bits 31-12: Physical address of Page Table (page-aligned, 20 bits)
 *   Bit  11-9:  Available for OS use (ignored by CPU)
 *   Bit  8:     G (Global) - ignored in PDE
 *   Bit  7:     PS (Page Size) - 0 = 4KiB pages, 1 = 4MiB pages (requires PSE)
 *   Bit  6:     D (Dirty) - ignored in PDE
 *   Bit  5:     A (Accessed) - set by CPU when entry is used
 *   Bit  4:     PCD (Cache Disable) - 1 = disable caching for this page table
 *   Bit  3:     PWT (Write-Through) - 1 = write-through caching
 *   Bit  2:     U/S (User/Supervisor) - 0 = kernel only, 1 = user accessible
 *   Bit  1:     R/W (Read/Write) - 0 = read-only, 1 = read-write
 *   Bit  0:     P (Present) - 0 = not present (page fault), 1 = present
 *
 * PAGE TABLE ENTRY (PTE) FORMAT:
 *   32-bit entry pointing to a physical page frame
 *
 *   Bits 31-12: Physical address of page frame (page-aligned, 20 bits)
 *   Bit  11-9:  Available for OS use (ignored by CPU)
 *   Bit  8:     G (Global) - 1 = don't flush from TLB on CR3 write
 *   Bit  7:     PAT (Page Attribute Table) - memory type control
 *   Bit  6:     D (Dirty) - set by CPU when page is written to
 *   Bit  5:     A (Accessed) - set by CPU when page is accessed
 *   Bit  4:     PCD (Cache Disable) - 1 = disable caching for this page
 *   Bit  3:     PWT (Write-Through) - 1 = write-through caching
 *   Bit  2:     U/S (User/Supervisor) - 0 = kernel only, 1 = user accessible
 *   Bit  1:     R/W (Read/Write) - 0 = read-only, 1 = read-write
 *   Bit  0:     P (Present) - 0 = not present (page fault), 1 = present
 *
 * CONTROL REGISTERS:
 *   CR0: Control Register 0 - System control flags
 *     Bit 31 (PG): Paging enable - 0 = disabled, 1 = enabled
 *     Bit 0 (PE): Protected mode enable
 *     Setting PG=1 enables paging; CPU starts translating addresses
 *
 *   CR3: Control Register 3 - Page Directory Base Register (PDBR)
 *     Bits 31-12: Physical address of Page Directory (must be page-aligned)
 *     Bits 11-0: Flags (PWT, PCD) - usually zero for kernel
 *     CPU reads this to find the Page Directory
 *
 *   CR2: Control Register 2 - Page Fault Linear Address
 *     Contains the virtual address that caused the last page fault
 *     Read by page fault handler to determine what address was accessed
 *
 * TLB (TRANSLATION LOOKASIDE BUFFER):
 *   The TLB is a CPU cache of virtual → physical address translations.
 *   Without TLB: Every memory access requires 2-3 memory reads (walk tables)
 *   With TLB: Cached translations give ~1 cycle access time
 *
 *   TLB Management:
 *     - Automatically populated by CPU during page table walks
 *     - Must be flushed when page tables change
 *     - Writing CR3 flushes entire TLB (except Global pages)
 *     - INVLPG instruction flushes single page from TLB
 *
 * BOOTSTRAP STRATEGY:
 *   This file provides a minimal paging setup for kernel boot:
 *     1. Static page tables in .bss (no dynamic allocation needed)
 *     2. Identity map first 32 MiB (enough for kernel + early data)
 *     3. Ensure page tables themselves are in mapped region
 *     4. Load CR3 with Page Directory address
 *     5. Set CR0.PG to enable paging
 *
 *   After this bootstrap, a full memory manager can take over.
 *
 * MEMORY LAYOUT AFTER PAGING:
 *   Virtual Address    Physical Address    Contents
 *   ===============    ================    ========
 *   0x00000000         0x00000000          First 1 MiB (reserved)
 *   0x00100000         0x00100000          Kernel code, data, bss
 *   0x001XXXXX         0x001XXXXX          Page directory and tables
 *   0x01FFFFFF         0x01FFFFFF          End of mapped region (32 MiB)
 *
 * PAGE FAULT CAUSES:
 *   A page fault (#PF, exception 14) occurs when:
 *     1. Accessing unmapped memory (Present bit = 0)
 *     2. Writing to read-only page (R/W bit = 0, attempted write)
 *     3. User mode accessing supervisor page (U/S bit = 0 in user mode)
 *     4. Reserved bit set in page table entry
 *     5. Instruction fetch from non-executable page (NX bit, if enabled)
 *
 *   Page faults are NOT always errors! They're used for:
 *     - Demand paging: Allocate pages on first access
 *     - Copy-on-write: Share pages until write occurs
 *     - Swapping: Move pages to disk when memory is low
 *
 * INITIALIZATION ORDER:
 *   Critical: Paging MUST be initialized after:
 *     1. IDT (Interrupt Descriptor Table) - to handle page faults
 *     2. PMM (Physical Memory Manager) - to verify memory ranges
 *
 *   If paging is enabled before IDT:
 *     Page fault → No handler → Double fault → Triple fault → REBOOT!
 *
 * STATIC ALLOCATION:
 *   Page tables live in .bss section (uninitialized data):
 *     - Page Directory: 4 KiB (1024 entries × 4 bytes)
 *     - Page Tables: 8 × 4 KiB = 32 KiB (up to 8 tables)
 *     - Total: 36 KiB of static data
 *
 *   Benefits:
 *     - No dynamic allocation needed during boot
 *     - Guaranteed to be in low memory (kernel space)
 *     - Page-aligned by linker attribute
 *
 * LIMITATIONS:
 *   - Fixed 32 MiB mapping (MAX_TABLES = 8)
 *   - Identity mapping only (no virtual address space flexibility)
 *   - No demand paging (all pages mapped upfront)
 *   - No page protection (all pages R/W)
 *   - No user/supervisor distinction (all kernel pages)
 *   - Static allocation (no dynamic page table creation)
 *
 * DESIGN DECISIONS:
 *   - Identity mapping: Simplifies early boot, code works before/after paging
 *   - Static tables: Avoids dependency on dynamic memory allocator
 *   - 32 MiB limit: Enough for kernel + early data, keeps .bss small
 *   - Self-coverage: Page tables map themselves (CPU can walk tables)
 *   - Present + R/W: All pages accessible and writable (kernel needs this)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. This is single-threaded bootstrap code.
 *   Future: Multi-core support requires per-CPU page tables or TLB shootdown.
 *
 * PERFORMANCE:
 *   Initialization: O(n) where n = number of pages (8192 pages max)
 *   Typical time: ~1-2 milliseconds on 1 GHz CPU
 *   Not performance-critical (runs once during boot)
 *
 * FUTURE ENHANCEMENTS:
 *   - Demand paging: Allocate pages on access (page fault handler)
 *   - Higher-half kernel: Map kernel to 3+ GiB virtual address
 *   - Page protection: Read-only text, no-execute data
 *   - User/kernel split: Separate page tables for processes
 *   - Large pages: 2 MiB / 4 MiB pages for better TLB efficiency
 *   - PAE (Physical Address Extension): Support >4 GiB RAM on 32-bit
 *   - Dynamic page table allocation: Grow as needed
 *   - Memory-mapped files: Map file contents into virtual memory
 *   - Copy-on-write: Share pages until written
 *   - Swapping: Move pages to disk when memory low
 *
 *============================================================================*/

#include "kernel.h"
#include "paging.h"
#include <stdint.h>

/*=============================================================================
 * PAGE TABLE FLAGS (x86)
 *=============================================================================
 * DESCRIPTION:
 *   Bit flags used in Page Directory Entries (PDEs) and Page Table Entries
 *   (PTEs). These control how the CPU handles memory access.
 *
 * PDE_P (Present):
 *   Value: 0x001 (bit 0)
 *   Meaning: Page table is present in memory
 *   If clear: Accessing any address in this 4 MiB range causes page fault
 *   If set: CPU will look up the page table
 *
 * PDE_RW (Read/Write):
 *   Value: 0x002 (bit 1)
 *   Meaning: Pages in this table are writable
 *   If clear: All pages in table are read-only (write causes page fault)
 *   If set: Pages can be written (unless PTE overrides)
 *
 * PTE_P (Present):
 *   Value: 0x001 (bit 0)
 *   Meaning: Page is present in memory
 *   If clear: Accessing this page causes page fault (not mapped)
 *   If set: Page is mapped to physical frame
 *
 * PTE_RW (Read/Write):
 *   Value: 0x002 (bit 1)
 *   Meaning: Page is writable
 *   If clear: Page is read-only (write causes page fault)
 *   If set: Page can be written
 *
 * COMBINING FLAGS:
 *   Flags are OR'ed together:
 *     PDE_P | PDE_RW = 0x003 (present + writable)
 *     PTE_P | PTE_RW = 0x003 (present + writable)
 *
 * TYPICAL USAGE:
 *   Kernel pages: PTE_P | PTE_RW (0x003) - present, writable
 *   Read-only data: PTE_P (0x001) - present, read-only
 *   Unmapped: 0x000 - not present
 *
 * OTHER FLAGS (not used in this implementation):
 *   Bit 2 (U/S): User/Supervisor (0=kernel, 1=user)
 *   Bit 3 (PWT): Write-through cache
 *   Bit 4 (PCD): Cache disable
 *   Bit 5 (A): Accessed (set by CPU)
 *   Bit 6 (D): Dirty (set by CPU on write)
 *   Bit 7 (PS/PAT): Page size or Page attribute table
 *   Bit 8 (G): Global (don't flush from TLB)
 *============================================================================*/
#define PDE_P   0x001u   /* Page Directory Entry: Present */
#define PDE_RW  0x002u   /* Page Directory Entry: Read/Write */
#define PTE_P   0x001u   /* Page Table Entry: Present */
#define PTE_RW  0x002u   /* Page Table Entry: Read/Write */

/*=============================================================================
 * PAGE GEOMETRY CONSTANTS
 *=============================================================================
 * DESCRIPTION:
 *   Constants defining the structure and size of x86 paging elements.
 *
 * PAGE_SIZE: 4096 bytes (4 KiB)
 *   Standard x86 page size. All pages are this size.
 *   Page-aligned addresses are multiples of 4096.
 *
 * PT_ENTRIES: 1024 entries per Page Table
 *   Each Page Table has 1024 PTEs.
 *   Each PTE is 4 bytes (32 bits).
 *   Total Page Table size: 1024 × 4 = 4096 bytes = 1 page.
 *
 * PD_ENTRIES: 1024 entries in Page Directory
 *   Each Page Directory has 1024 PDEs.
 *   Each PDE is 4 bytes (32 bits).
 *   Total Page Directory size: 1024 × 4 = 4096 bytes = 1 page.
 *
 * PT_COVERS_BYTES: 4 MiB per Page Table
 *   Each Page Table maps 1024 pages.
 *   Each page is 4 KiB.
 *   Coverage: 1024 × 4 KiB = 4 MiB.
 *
 * MAX_TABLES: 8 Page Tables maximum
 *   We allocate space for 8 Page Tables statically.
 *   Total coverage: 8 × 4 MiB = 32 MiB.
 *   Enough for kernel + early boot data.
 *
 * MEMORY USAGE CALCULATION:
 *   Page Directory: 1 × 4 KiB = 4 KiB
 *   Page Tables: 8 × 4 KiB = 32 KiB
 *   Total: 36 KiB of static data in .bss
 *
 * WHY 32 MiB LIMIT:
 *   - Keeps static allocation small (36 KiB vs. 4 MiB for full mapping)
 *   - Enough for kernel code, data, stack, early allocations
 *   - Can be increased by changing MAX_TABLES
 *   - Full 4 GiB would require 1024 Page Tables = 4 MiB of static data
 *============================================================================*/
#define PAGE_SIZE        4096u                         /* 4 KiB per page */
#define PT_ENTRIES       1024u                         /* Entries per Page Table */
#define PD_ENTRIES       1024u                         /* Entries in Page Directory */
#define PT_COVERS_BYTES  (PT_ENTRIES * PAGE_SIZE)     /* 4 MiB per table */
#define MAX_TABLES       8u                            /* 8 tables = 32 MiB */

/*=============================================================================
 * STATIC PAGE TABLES (in .bss)
 *=============================================================================
 * DESCRIPTION:
 *   The Page Directory and Page Tables are statically allocated in the
 *   kernel's .bss section. The .bss is zeroed by boot.s before kernel_main().
 *
 * early_pd: Page Directory
 *   Type: uint32_t[1024]
 *   Size: 4 KiB (1024 entries × 4 bytes)
 *   Purpose: Top-level paging structure, contains PDEs
 *   Alignment: 4096 bytes (required by CPU - CR3 loads this address)
 *   Location: Kernel .bss (guaranteed to be in low memory)
 *
 * early_pts: Array of Page Tables
 *   Type: uint32_t[8][1024]
 *   Size: 32 KiB (8 tables × 1024 entries × 4 bytes)
 *   Purpose: Second-level paging structure, contains PTEs
 *   Alignment: 4096 bytes (required by CPU)
 *   Location: Kernel .bss
 *
 * WHY STATIC ALLOCATION:
 *   1. No dependency on dynamic memory allocator (PMM not ready yet)
 *   2. Guaranteed to be in low memory (identity-mapped region)
 *   3. Zeroed automatically by boot.s
 *   4. Page-aligned by __attribute__((aligned(4096)))
 *   5. Simple and predictable
 *
 * MEMORY LAYOUT IN .bss:
 *   Address (example)    Size     Content
 *   =================    ======   =======
 *   0x0010A000           4 KiB    early_pd (Page Directory)
 *   0x0010B000           4 KiB    early_pts[0] (first Page Table)
 *   0x0010C000           4 KiB    early_pts[1] (second Page Table)
 *   ...
 *   0x00112000           4 KiB    early_pts[7] (eighth Page Table)
 *
 * ATTRIBUTE EXPLANATION:
 *   __attribute__((aligned(4096))):
 *     Forces compiler/linker to align variable to 4 KiB boundary.
 *     Required because:
 *       - CR3 register ignores lower 12 bits (assumes page-aligned)
 *       - PDEs ignore lower 12 bits of Page Table addresses
 *       - CPU generates #GP if alignment is wrong
 *
 * INITIALIZATION:
 *   Boot.s zeros .bss, so these arrays start as all zeros.
 *   paging_identity_map_early() fills them with actual mappings.
 *
 * LIFETIME:
 *   These tables persist for the entire kernel lifetime.
 *   Future: Could be replaced by dynamically allocated tables once
 *   a full MMU and page allocator are available.
 *============================================================================*/
static uint32_t __attribute__((aligned(PAGE_SIZE))) early_pd[PD_ENTRIES];
static uint32_t __attribute__((aligned(PAGE_SIZE))) early_pts[MAX_TABLES][PT_ENTRIES];

/*=============================================================================
 * FUNCTION: align_up
 *=============================================================================
 * DESCRIPTION:
 *   Rounds an address or size up to the next multiple of a given alignment.
 *   Used to ensure memory regions are page-aligned.
 *
 * PARAMETERS:
 *   x - Value to align (address or size)
 *   a - Alignment (must be power of 2)
 *
 * RETURNS:
 *   uint32_t: Value rounded up to next multiple of a
 *
 * ALGORITHM:
 *   Formula: (x + (a - 1)) & ~(a - 1)
 *
 *   How it works:
 *     1. Add (a - 1) to x - this ensures we round up, not down
 *     2. Mask with ~(a - 1) - clears lower bits, rounding to alignment
 *
 * EXAMPLE (align to 4096 bytes):
 *   x = 0x1234, a = 0x1000 (4096)
 *   Step 1: 0x1234 + 0x0FFF = 0x2233
 *   Step 2: 0x2233 & ~0x0FFF = 0x2233 & 0xFFFFF000 = 0x2000
 *   Result: 0x2000 (next 4 KiB boundary after 0x1234)
 *
 * BITWISE EXPLANATION:
 *   For alignment 4096 (0x1000):
 *     a - 1 = 0x0FFF = 0b111111111111 (lower 12 bits set)
 *     ~(a - 1) = 0xFFFFF000 (upper 20 bits set, lower 12 clear)
 *
 *   Masking with ~(a - 1) zeros the lower 12 bits, ensuring result is
 *   a multiple of 4096.
 *
 * WHY POWER OF 2:
 *   This trick only works for power-of-2 alignments.
 *   For other alignments, use: ((x + a - 1) / a) * a
 *
 * USAGE EXAMPLES:
 *   align_up(0x1234, 0x1000) = 0x2000 (round 0x1234 up to 4 KiB)
 *   align_up(0x1000, 0x1000) = 0x1000 (already aligned, no change)
 *   align_up(0x1001, 0x1000) = 0x2000 (round up 1 byte)
 *
 * PERFORMANCE:
 *   Very fast: 3 instructions (add, not, and)
 *   ~3 CPU cycles
 *============================================================================*/
static inline uint32_t align_up(uint32_t x, uint32_t a) {
    return (x + (a - 1u)) & ~(a - 1u);
}

/*=============================================================================
 * FUNCTION: paging_identity_map_early
 *=============================================================================
 * DESCRIPTION:
 *   Sets up identity-mapped paging for early kernel bootstrap. Creates page
 *   directory and page tables that map virtual addresses 1:1 to physical
 *   addresses for the first 32 MiB of memory.
 *
 * PARAMETERS:
 *   limit_bytes - Number of bytes to identity map (requested coverage)
 *                 Will be clamped to [1 MiB, 32 MiB] range
 *                 Will be extended if page tables fall outside range
 *
 * RETURNS:
 *   void
 *
 * ALGORITHM:
 *   PHASE 1: Validate and adjust limit
 *     - Ensure at least 1 MiB (kernel needs this)
 *     - Cap at 32 MiB (MAX_TABLES limit)
 *     - Extend if page tables themselves need more coverage
 *
 *   PHASE 2: Zero Page Directory
 *     - Initialize all PDEs to 0 (not present)
 *     - Only used entries will be filled
 *
 *   PHASE 3: Calculate number of Page Tables needed
 *     - Each table covers 4 MiB
 *     - Round up limit to 4 MiB boundaries
 *
 *   PHASE 4: Fill Page Tables
 *     - For each table (0 to tables-1):
 *       a. Fill all 1024 PTEs with identity mappings
 *       b. Each PTE maps 4 KiB: virtual = physical
 *       c. Set flags: Present (P) + Read/Write (RW)
 *
 *   PHASE 5: Fill Page Directory
 *     - For each table (0 to tables-1):
 *       a. Set PDE to point to corresponding Page Table
 *       b. Set flags: Present (P) + Read/Write (RW)
 *
 *   PHASE 6: Load CR3
 *     - Write Page Directory address to CR3
 *     - CPU now knows where to find page tables
 *     - Paging not yet enabled (CR0.PG still 0)
 *
 * IDENTITY MAPPING SCHEME:
 *   Virtual Address    Physical Address    PDE Index    PTE Index
 *   ===============    ================    =========    =========
 *   0x00000000         0x00000000          0            0
 *   0x00001000         0x00001000          0            1
 *   0x003FF000         0x003FF000          0            1023
 *   0x00400000         0x00400000          1            0
 *   0x01FFFFFF         0x01FFFFFF          7            1023
 *
 * SELF-COVERAGE REQUIREMENT:
 *   Critical: The page tables MUST map themselves!
 *   
 *   Why: After enabling paging, CPU walks page tables to translate addresses.
 *   If page tables aren't mapped, CPU can't read them → #PF → triple fault!
 *   
 *   Solution: Calculate where early_pd and early_pts are located.
 *   If they're above limit_bytes, extend limit_bytes to cover them.
 *
 * ADDRESS CALCULATION:
 *   To map virtual address V to physical address P:
 *
 *   1. PDE Index = V >> 22 (bits 31-22, range 0-1023)
 *   2. PTE Index = (V >> 12) & 0x3FF (bits 21-12, range 0-1023)
 *   3. Offset = V & 0xFFF (bits 11-0, range 0-4095)
 *
 *   For identity mapping: P = V, so:
 *   4. PTE value = (P & ~0xFFF) | flags
 *   5. PDE value = (PT_address & ~0xFFF) | flags
 *
 * FLAGS USED:
 *   PDE: PDE_P | PDE_RW = 0x003 (present, writable)
 *   PTE: PTE_P | PTE_RW = 0x003 (present, writable)
 *
 *   No user/supervisor distinction (bit 2 clear = kernel only)
 *   No cache control (bits 3-4 clear = default caching)
 *   No global pages (bit 8 clear = flush on CR3 write)
 *
 * MEMORY COVERAGE EXAMPLES:
 *   Request 8 MiB:
 *     - Creates 2 Page Tables (2 × 4 MiB = 8 MiB)
 *     - PDEs 0-1 active, PDEs 2-1023 empty
 *     - Maps virtual 0x00000000-0x007FFFFF
 *
 *   Request 32 MiB:
 *     - Creates 8 Page Tables (8 × 4 MiB = 32 MiB)
 *     - PDEs 0-7 active, PDEs 8-1023 empty
 *     - Maps virtual 0x00000000-0x01FFFFFF
 *
 * CR3 LOADING:
 *   CR3 register format (32-bit):
 *     Bits 31-12: Physical address of Page Directory (page-aligned)
 *     Bits 11-5:  Reserved (must be 0)
 *     Bit  4:     PCD (Page-level Cache Disable) - 0 = caching enabled
 *     Bit  3:     PWT (Page-level Write-Through) - 0 = write-back cache
 *     Bits 2-0:   Reserved (must be 0)
 *
 *   We load the physical address of early_pd:
 *     MOV CR3, address_of_early_pd
 *
 * WHAT HAPPENS AFTER THIS FUNCTION:
 *   1. Page tables are set up in memory
 *   2. CR3 points to Page Directory
 *   3. Paging is NOT yet enabled (CR0.PG = 0)
 *   4. Call paging_enable() to set CR0.PG = 1
 *
 * DEBUGGING:
 *   If page fault occurs after enabling paging:
 *     - Check CR2 register (faulting address)
 *     - If CR2 is near early_pd/early_pts: Self-coverage failed!
 *     - If CR2 is in kernel: Missing mapping
 *     - If CR2 is NULL: Null pointer dereference
 *
 * PERFORMANCE:
 *   Time complexity: O(n) where n = number of pages
 *   For 32 MiB: 8192 pages × ~10 cycles = ~80K cycles = ~80 microseconds
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Single-threaded bootstrap code.
 *
 * TYPICAL USAGE:
 *   paging_identity_map_early(32 * 1024 * 1024);  // Map 32 MiB
 *   paging_enable();                               // Enable paging
 *============================================================================*/
void paging_identity_map_early(uint32_t limit_bytes) {
    /*=========================================================================
     * PHASE 1: VALIDATE AND ADJUST MEMORY LIMIT
     *=========================================================================
     * Ensure requested limit is within reasonable bounds:
     *   - Minimum: 1 MiB (kernel needs at least this)
     *   - Maximum: 32 MiB (MAX_TABLES limit)
     *   - Extended: If page tables fall outside requested range
     *=======================================================================*/
    
    /*-------------------------------------------------------------------------
     * Set minimum limit: 1 MiB
     *-------------------------------------------------------------------------
     * Kernel is loaded at 1 MiB (0x100000), so we need at least this much.
     * If caller requests less, bump up to 1 MiB.
     *-----------------------------------------------------------------------*/
    if (limit_bytes < (1u << 20))  /* 1 << 20 = 1,048,576 = 1 MiB */
        limit_bytes = (1u << 20);
    
    /*-------------------------------------------------------------------------
     * Set maximum limit: 32 MiB
     *-------------------------------------------------------------------------
     * We only have space for 8 Page Tables (MAX_TABLES = 8).
     * Each table covers 4 MiB, so max is 8 × 4 MiB = 32 MiB.
     * If caller requests more, cap at 32 MiB.
     *-----------------------------------------------------------------------*/
    if (limit_bytes > (MAX_TABLES * PT_COVERS_BYTES))
        limit_bytes = (MAX_TABLES * PT_COVERS_BYTES);
    
    /*=========================================================================
     * SELF-COVERAGE CHECK: Ensure page tables are within mapped region
     *=========================================================================
     * CRITICAL: Page tables must map themselves!
     *
     * Problem: If page tables are at physical address X, and we only map
     *          up to address Y where Y < X, then CPU can't read the page
     *          tables after paging is enabled → page fault!
     *
     * Solution: Calculate where page tables end, extend limit if needed.
     *=======================================================================*/
    
    /*-------------------------------------------------------------------------
     * Calculate end addresses of page directory and page tables
     *-------------------------------------------------------------------------
     * Page Directory: early_pd[1024] = 4 KiB
     * Page Tables: early_pts[8][1024] = 32 KiB
     *
     * End address = Start address + Size
     *-----------------------------------------------------------------------*/
    uint32_t pd_end  = (uint32_t)(uintptr_t)early_pd  + sizeof(early_pd);
    uint32_t pts_end = (uint32_t)(uintptr_t)early_pts + sizeof(early_pts);
    
    /*-------------------------------------------------------------------------
     * Find highest address that must be covered
     *-------------------------------------------------------------------------
     * We need to cover both the Page Directory and all Page Tables.
     * Find the maximum of pd_end and pts_end.
     *-----------------------------------------------------------------------*/
    uint32_t must_cover = (pd_end > pts_end) ? pd_end : pts_end;
    
    /*-------------------------------------------------------------------------
     * Extend limit if page tables fall outside requested range
     *-------------------------------------------------------------------------
     * If must_cover > limit_bytes, bump limit to cover page tables.
     * Round up to 4 MiB boundary (PT_COVERS_BYTES) since we allocate
     * Page Tables in 4 MiB chunks.
     *
     * Example:
     *   Requested limit: 8 MiB (0x800000)
     *   Page tables end at: 10 MiB (0xA00000)
     *   must_cover = 10 MiB
     *   Aligned: align_up(10 MiB, 4 MiB) = 12 MiB
     *   New limit: 12 MiB (3 Page Tables)
     *-----------------------------------------------------------------------*/
    if (limit_bytes < must_cover)
        limit_bytes = align_up(must_cover, PT_COVERS_BYTES);
    
    /*=========================================================================
     * PHASE 2: ZERO PAGE DIRECTORY
     *=========================================================================
     * Initialize all Page Directory Entries (PDEs) to 0.
     * 0 means "not present" - accessing these ranges causes page fault.
     * We'll fill in only the entries we actually use.
     *=======================================================================*/
    for (uint32_t i = 0; i < PD_ENTRIES; ++i) {
        early_pd[i] = 0;
    }
    
    /*=========================================================================
     * PHASE 3: CALCULATE NUMBER OF PAGE TABLES NEEDED
     *=========================================================================
     * Each Page Table covers 4 MiB (PT_COVERS_BYTES).
     * Calculate how many tables are needed to cover limit_bytes.
     *
     * Formula: (limit_bytes + 4MiB - 1) / 4MiB
     * This rounds up to ensure we cover partial chunks.
     *=======================================================================*/
    uint32_t tables = (limit_bytes + (PT_COVERS_BYTES - 1u)) / PT_COVERS_BYTES;
    
    /*-------------------------------------------------------------------------
     * Clamp to maximum table count
     *-------------------------------------------------------------------------
     * We have space for MAX_TABLES (8) Page Tables.
     * If calculation exceeds this, cap at 8.
     *-----------------------------------------------------------------------*/
    if (tables > MAX_TABLES) 
        tables = MAX_TABLES;
    
    /*=========================================================================
     * PHASE 4: FILL PAGE TABLES WITH IDENTITY MAPPINGS
     *=========================================================================
     * For each Page Table (0 to tables-1):
     *   - Fill all 1024 PTEs
     *   - Each PTE maps one 4 KiB page
     *   - Identity mapping: virtual address = physical address
     *   - Set Present (P) and Read/Write (RW) flags
     *=======================================================================*/
    for (uint32_t t = 0; t < tables; ++t) {
        /*---------------------------------------------------------------------
         * Calculate base address for this Page Table
         *---------------------------------------------------------------------
         * Table 0: Maps 0x00000000-0x003FFFFF (0-4MiB)
         * Table 1: Maps 0x00400000-0x007FFFFF (4-8MiB)
         * Table t: Maps (t × 4MiB) to ((t+1) × 4MiB - 1)
         *-------------------------------------------------------------------*/
        uint32_t base = t * PT_COVERS_BYTES;
        
        /*---------------------------------------------------------------------
         * Fill all 1024 entries in this Page Table
         *---------------------------------------------------------------------
         * Each entry maps one 4 KiB page within the 4 MiB range.
         *-------------------------------------------------------------------*/
        for (uint32_t e = 0; e < PT_ENTRIES; ++e) {
            /*-----------------------------------------------------------------
             * Calculate physical address for this page
             *-----------------------------------------------------------------
             * Page address = base + (entry × page_size)
             * Entry 0: base + 0 × 4096 = base
             * Entry 1: base + 1 × 4096 = base + 4096
             * Entry e: base + e × 4096
             *---------------------------------------------------------------*/
            uint32_t phys = base + e * PAGE_SIZE;
            
            /*-----------------------------------------------------------------
             * Build Page Table Entry (PTE)
             *-----------------------------------------------------------------
             * Format: [Physical Address (bits 31-12)] [Flags (bits 11-0)]
             *
             * Physical address (bits 31-12):
             *   phys & ~0xFFF zeros lower 12 bits (page offset)
             *   Example: 0x12345 & ~0xFFF = 0x12000
             *
             * Flags (bits 11-0):
             *   PTE_P (0x001): Present bit = 1
             *   PTE_RW (0x002): Read/Write = 1
             *   Combined: 0x003
             *
             * Final PTE value:
             *   (phys & ~0xFFF) | 0x003
             *   Example: 0x12000 | 0x003 = 0x12003
             *---------------------------------------------------------------*/
            early_pts[t][e] = (phys & ~0xFFFu) | (PTE_P | PTE_RW);
        }
        
        /*---------------------------------------------------------------------
         * After this loop, Page Table t is fully initialized:
         *   early_pts[t][0]    → phys (base + 0)
         *   early_pts[t][1]    → phys (base + 4096)
         *   ...
         *   early_pts[t][1023] → phys (base + 4190208)
         *-------------------------------------------------------------------*/
    }
    
    /*=========================================================================
     * PHASE 5: FILL PAGE DIRECTORY
     *=========================================================================
     * For each Page Table we created:
     *   - Set corresponding PDE to point to that Page Table
     *   - Set Present (P) and Read/Write (RW) flags
     *=======================================================================*/
    for (uint32_t t = 0; t < tables; ++t) {
        /*---------------------------------------------------------------------
         * Build Page Directory Entry (PDE)
         *---------------------------------------------------------------------
         * Format: [Page Table Address (bits 31-12)] [Flags (bits 11-0)]
         *
         * Page Table address:
         *   (uintptr_t)early_pts[t] gets address of Page Table t
         *   Cast to uint32_t for bitwise operations
         *   & ~0xFFF zeros lower 12 bits (page offset)
         *
         * Flags:
         *   PDE_P (0x001): Present = 1
         *   PDE_RW (0x002): Read/Write = 1
         *   Combined: 0x003
         *
         * Final PDE value:
         *   (address & ~0xFFF) | 0x003
         *---------------------------------------------------------------------
         * EXAMPLE:
         *   early_pts[0] is at 0x0010B000
         *   Address: 0x0010B000 & ~0xFFF = 0x0010B000 (already aligned)
         *   Flags: 0x003
         *   PDE: 0x0010B003
         *-------------------------------------------------------------------*/
        early_pd[t] = (((uint32_t)(uintptr_t)early_pts[t]) & ~0xFFFu) 
                      | (PDE_P | PDE_RW);
    }
    
    /*=========================================================================
     * PHASE 6: LOAD CR3 REGISTER
     *=========================================================================
     * CR3 (Control Register 3) tells the CPU where the Page Directory is.
     * After writing CR3, CPU knows where to start page table walks.
     * Paging is not yet enabled (CR0.PG = 0), so this has no immediate effect.
     *=======================================================================*/
    
    /*-------------------------------------------------------------------------
     * Get physical address of Page Directory
     *-------------------------------------------------------------------------
     * Since we're using identity mapping and paging isn't enabled yet,
     * virtual address = physical address.
     *-----------------------------------------------------------------------*/
    uint32_t cr3 = (uint32_t)(uintptr_t)early_pd;
    
    /*-------------------------------------------------------------------------
     * Write Page Directory address to CR3
     *-------------------------------------------------------------------------
     * Inline assembly to write CR3 register:
     *   mov cr3, %0  — Move value to CR3
     *   %0 is placeholder for 'cr3' variable
     *   :: "r"(cr3) — Input constraint: cr3 in any register
     *
     * After this instruction:
     *   CR3 = physical address of early_pd
     *   CPU knows where to find page tables
     *   Ready to enable paging!
     *-----------------------------------------------------------------------*/
    __asm__ volatile ("mov %0, %%cr3" :: "r"(cr3));
    
    /*=========================================================================
     * POST-CONDITIONS:
     *   - Page Directory filled with active PDEs (0 to tables-1)
     *   - Page Tables filled with identity-mapped PTEs
     *   - All mappings: virtual = physical
     *   - CR3 loaded with Page Directory address
     *   - Page tables map themselves (self-coverage achieved)
     *   - Ready for paging_enable() to set CR0.PG
     *=========================================================================*/
}

/*=============================================================================
 * FUNCTION: paging_enable
 *=============================================================================
 * DESCRIPTION:
 *   Enables x86 paging by setting the PG (Paging) bit in CR0 register.
 *   After this function returns, all memory accesses go through page tables.
 *   This is the "point of no return" - page tables must be correct!
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   void
 *
 * ALGORITHM:
 *   1. Read current value of CR0 register
 *   2. Set bit 31 (PG bit) to 1
 *   3. Write modified value back to CR0
 *   4. CPU immediately begins using page tables for all memory access
 *
 * CR0 REGISTER (Control Register 0):
 *   32-bit register controlling CPU operating mode and features.
 *
 *   Key bits:
 *     Bit 31 (PG): Paging enable
 *       0 = Paging disabled (physical addresses used directly)
 *       1 = Paging enabled (virtual → physical translation)
 *
 *     Bit 0 (PE): Protected mode enable
 *       0 = Real mode (16-bit)
 *       1 = Protected mode (32-bit)
 *
 *     Other bits: Write-protect, cache control, FPU control, etc.
 *
 * ENABLING PAGING:
 *   To enable paging, we must set CR0.PG = 1.
 *   We do this by:
 *     1. Reading CR0 (preserve other bits)
 *     2. OR'ing with 0x80000000 (set bit 31)
 *     3. Writing back to CR0
 *
 *   Binary representation:
 *     0x80000000 = 0b10000000000000000000000000000000
 *                    ^
 *                    Bit 31 (PG)
 *
 * WHAT HAPPENS IMMEDIATELY AFTER:
 *   The VERY NEXT instruction fetch uses page tables!
 *   
 *   Sequence:
 *     1. Write CR0 (paging enabled)
 *     2. CPU fetches next instruction address (EIP)
 *     3. EIP is now treated as VIRTUAL address
 *     4. CPU walks page tables to translate EIP
 *     5. If page not present → #PF (page fault)
 *     6. If page present → fetch instruction, continue
 *
 * PREREQUISITES:
 *   Before calling this function:
 *     ✓ Page Directory must be set up
 *     ✓ Page Tables must be set up  
 *     ✓ CR3 must point to Page Directory
 *     ✓ Page tables must map themselves (self-coverage)
 *     ✓ Page tables must map kernel code (otherwise next instruction fails!)
 *     ✓ Page tables must map kernel stack (otherwise stack access fails!)
 *     ✓ IDT must be installed (to handle potential page faults)
 *
 * WHAT IF TABLES ARE WRONG:
 *   If page tables are incorrect, enabling paging causes immediate page fault:
 *
 *   Scenario 1: Page tables not mapped
 *     → CPU tries to walk tables → can't read them → #PF → triple fault
 *
 *   Scenario 2: Kernel code not mapped
 *     → CPU fetches next instruction → #PF → handler called
 *     → Handler code not mapped → #PF → double fault → triple fault
 *
 *   Scenario 3: Stack not mapped
 *     → Next instruction is RET or PUSH → #PF → handler called
 *     → Handler tries to use stack → #PF → double fault → triple fault
 *
 *   With proper IDT: Page fault handler can print CR2 (faulting address)
 *   and error code, helping us debug the problem!
 *
 * INLINE ASSEMBLY EXPLANATION:
 *   __asm__ volatile - Inline assembly with volatile qualifier
 *     volatile: Prevents compiler from optimizing away or reordering
 *
 *   First asm: Read CR0
 *     "mov %%cr0,%0"  — Move CR0 to output operand
 *     : "=r"(cr0)     — Output: cr0 variable, any register (=r)
 *
 *   Second asm: Write CR0
 *     "mov %0,%%cr0"  — Move input operand to CR0
 *     :: "r"(cr0)     — Input: cr0 variable, any register (r)
 *
 *   %% escapes %: In inline asm, %cr0 means "register CR0"
 *   %0 means "operand 0" (the variable)
 *
 * SIDE EFFECTS:
 *   - TLB (Translation Lookaside Buffer) is flushed
 *   - All subsequent memory accesses are translated
 *   - Performance: First access to each page is slow (page table walk)
 *   - Performance: Subsequent accesses are fast (TLB hit)
 *
 * DEBUGGING:
 *   If system reboots after calling this:
 *     - Triple fault occurred (page fault → double fault → triple fault)
 *     - Check: Are page tables covering themselves?
 *     - Check: Is kernel code mapped?
 *     - Check: Is kernel stack mapped?
 *     - Check: Is CR3 correct?
 *
 *   If system hangs after calling this:
 *     - Infinite loop somewhere in page table walking
 *     - Check: Are page table entries valid?
 *     - Check: Are present bits set correctly?
 *
 *   If page fault occurs (and you have IDT installed):
 *     - Page fault handler prints CR2 (faulting address)
 *     - Check what's at that address
 *     - Add mapping for that address
 *
 * TYPICAL CALL SEQUENCE:
 *   paging_identity_map_early(32 * 1024 * 1024);  // Setup tables, load CR3
 *   kprintf("About to enable paging...\n");
 *   paging_enable();                               // Set CR0.PG
 *   kprintf("Paging enabled!\n");                  // If this prints, success!
 *
 * PERFORMANCE:
 *   Execution time: ~10-20 CPU cycles
 *     - Read CR0: ~5 cycles (serializing instruction)
 *     - OR operation: 1 cycle
 *     - Write CR0: ~5-10 cycles (serializing instruction)
 *
 * THREAD SAFETY:
 *   NOT applicable. This is single-threaded bootstrap code.
 *   In SMP systems, only boot CPU enables paging; APs inherit.
 *
 * NOTES:
 *   - This function never fails (no error checking possible)
 *   - If tables are wrong, system will crash (triple fault or page fault)
 *   - Always test paging setup thoroughly before calling this!
 *   - Once paging is enabled, it's enabled until CPU reset (no disable)
 *============================================================================*/
void paging_enable(void) {
    /*=========================================================================
     * STEP 1: Read current CR0 value
     *=========================================================================
     * We need to preserve all existing bits in CR0 (like PE = protected mode).
     * Only change the PG bit (bit 31).
     *=======================================================================*/
    uint32_t cr0;
    __asm__ volatile ("mov %%cr0,%0" : "=r"(cr0));
    
    /*=========================================================================
     * STEP 2: Set PG bit (bit 31)
     *=========================================================================
     * OR with 0x80000000 sets bit 31 to 1, leaves all other bits unchanged.
     *
     * Binary:
     *   Before: cr0 = ??????????????0???????????????  (PG = 0, bit 31)
     *   Mask:        = 10000000000000000000000000000000  (0x80000000)
     *   After:  cr0 = ??????????????1???????????????  (PG = 1, bit 31)
     *=======================================================================*/
    cr0 |= 0x80000000u;  /* Set PG bit */
    
    /*=========================================================================
     * STEP 3: Write modified CR0 back to register
     *=========================================================================
     * This single instruction enables paging!
     * After this executes, the CPU immediately begins translating addresses.
     *=======================================================================*/
    __asm__ volatile ("mov %0,%%cr0" :: "r"(cr0));
    
    /*=========================================================================
     * POST-PAGING STATE:
     *   - CR0.PG = 1 (paging enabled)
     *   - All memory accesses now translated via page tables
     *   - Next instruction fetch uses virtual address
     *   - If page tables correct: Execution continues normally
     *   - If page tables wrong: Page fault or triple fault
     *
     * If execution reaches the next line of C code after this function,
     * congratulations — paging is working! 🎉
     *=========================================================================*/
}

/*=============================================================================
 * PAGING SUBSYSTEM SUMMARY
 *=============================================================================
 *
 * INITIALIZATION SEQUENCE:
 *   1. paging_identity_map_early(32 MiB)  — Setup page tables
 *   2. paging_enable()                     — Enable paging (set CR0.PG)
 *
 * MEMORY MAPPED AFTER INIT:
 *   Virtual 0x00000000-0x01FFFFFF → Physical 0x00000000-0x01FFFFFF (32 MiB)
 *
 * KEY STRUCTURES:
 *   - Page Directory: 1024 entries, points to Page Tables
 *   - Page Tables: Up to 8 tables, each maps 4 MiB (total 32 MiB)
 *   - Each page: 4 KiB
 *   - Total coverage: 32 MiB (8192 pages)
 *
 * MEMORY USAGE:
 *   Static allocation in .bss:
 *     - Page Directory: 4 KiB
 *     - Page Tables: 32 KiB (8 tables × 4 KiB)
 *     - Total: 36 KiB
 *
 * CURRENT LIMITATIONS:
 *   ❌ Fixed 32 MiB mapping (no dynamic expansion)
 *   ❌ Identity mapping only (no address space flexibility)
 *   ❌ All pages R/W (no read-only or no-execute protection)
 *   ❌ All pages kernel-mode (no user/kernel separation)
 *   ❌ Static allocation (no demand paging)
 *   ❌ No large pages (only 4 KiB pages supported)
 *
 * CURRENT FEATURES:
 *   ✅ Identity mapping (simple, predictable)
 *   ✅ Self-coverage (page tables map themselves)
 *   ✅ Static allocation (no PMM dependency)
 *   ✅ Sufficient for early boot (32 MiB plenty for kernel)
 *   ✅ Clean enabling sequence (works with IDT)
 *
 * FUTURE ENHANCEMENTS:
 *
 *   1. HIGHER-HALF KERNEL:
 *      Map kernel to high addresses (0xC0000000+)
 *      Benefits: Clear user/kernel boundary, more user space
 *      Example: Kernel at virtual 0xC0100000, physical 0x00100000
 *
 *   2. DEMAND PAGING:
 *      Don't map all pages upfront
 *      Allocate on first access (page fault handler)
 *      Benefits: Use less memory, start faster
 *
 *   3. PAGE PROTECTION:
 *      Read-only text segment (R/X, no W)
 *      No-execute data segment (R/W, no X) - requires NX bit
 *      Read-only data (R, no W/X)
 *      Benefits: Catch bugs, prevent exploits
 *
 *   4. USER MODE SUPPORT:
 *      Set U/S bit in PTEs for user pages
 *      Separate page tables for each process
 *      Benefits: Process isolation, security
 *
 *   5. DYNAMIC PAGE TABLES:
 *      Allocate page tables from PMM as needed
 *      Free unused page tables
 *      Benefits: Scale to full 4 GiB address space
 *
 *   6. COPY-ON-WRITE (COW):
 *      Map same physical page to multiple virtual addresses
 *      Copy page only when written to (page fault on write)
 *      Benefits: Fast fork(), efficient memory sharing
 *
 *   7. SWAPPING:
 *      Move pages to disk when RAM is low
 *      Page fault brings pages back from disk
 *      Benefits: Use more virtual memory than physical RAM
 *
 *   8. LARGE PAGES (PSE):
 *      Use 2 MiB or 4 MiB pages instead of 4 KiB
 *      Set PS bit in PDE
 *      Benefits: Fewer TLB entries needed, better performance
 *
 *   9. PAE (PHYSICAL ADDRESS EXTENSION):
 *      Support >4 GiB RAM on 32-bit systems
 *      Requires different page table structure (3-level)
 *      Benefits: Use all available RAM
 *
 *   10. PAGE TABLE ISOLATION (PTI):
 *       Separate kernel and user page tables
 *       Switch on every syscall/interrupt
 *       Benefits: Mitigate Meltdown vulnerability
 *
 * TYPICAL USAGE PATTERN:
 *   During kernel init (in kernel_main):
 *     paging_identity_map_early(32 * 1024 * 1024);
 *     paging_enable();
 *     // Now all memory accesses use page tables
 *
 *   Later, when allocating memory:
 *     uint32_t frame = pmm_alloc();         // Get physical frame
 *     map_page(virt_addr, frame, flags);    // Map to virtual address
 *
 *   When freeing memory:
 *     unmap_page(virt_addr);                // Remove mapping
 *     pmm_free(frame);                      // Return physical frame
 *
 * DEBUGGING TIPS:
 *   - Enable paging only AFTER IDT is installed
 *   - Print messages before/after paging_enable()
 *   - If triple fault: Check self-coverage of page tables
 *   - If page fault: Check CR2 register (faulting address)
 *   - Use QEMU debug mode: -d int,cpu_reset
 *
 * RESOURCES:
 *   - Intel® 64 and IA-32 Architectures Software Developer's Manual
 *     Volume 3A: System Programming Guide, Part 1
 *     Chapter 4: Paging
 *   - OSDev Wiki: Paging (https://wiki.osdev.org/Paging)
 *   - AMD64 Architecture Programmer's Manual Volume 2
 *
 *=============================================================================
 * END OF FILE: paging.c
 *============================================================================*/
