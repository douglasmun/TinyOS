/*=============================================================================
 *  paging.c — TinyOS Paging (static identity map for early bring-up)
 *-----------------------------------------------------------------------------
 *  - Identity-maps [0, limit) using a static page directory and up to 8 page
 *    tables (32 MiB max) placed in .bss and 4 KiB aligned.
 *  - Ensures the identity window also covers the PD/PT arrays themselves so
 *    enabling paging cannot #PF while the CPU is walking the tables.
 *  - No dependency on the Physical Memory Manager for this early phase.
 *============================================================================*/
#include "kernel.h"
#include "paging.h"
#include <stdint.h>

/* Page directory/table flags (i386) */
#define PDE_P   0x001u   /* present */
#define PDE_RW  0x002u   /* writable */
#define PTE_P   0x001u
#define PTE_RW  0x002u

/* Page geometry */
#define PAGE_SIZE        4096u
#define PT_ENTRIES       1024u
#define PD_ENTRIES       1024u
#define PT_COVERS_BYTES  (PT_ENTRIES * PAGE_SIZE)   /* 4 MiB */
#define MAX_TABLES       8u                         /* 8 * 4MiB = 32 MiB */

/* Early static tables (live in .bss, identity accessible pre-paging) */
static uint32_t __attribute__((aligned(PAGE_SIZE))) early_pd[PD_ENTRIES];
static uint32_t __attribute__((aligned(PAGE_SIZE))) early_pts[MAX_TABLES][PT_ENTRIES];

static inline uint32_t align_up(uint32_t x, uint32_t a) {
    return (x + (a - 1u)) & ~(a - 1u);
}

void paging_identity_map_early(uint32_t limit_bytes) {
    /* Require at least 1 MiB, cap at 32 MiB for this early bootstrap */
    if (limit_bytes < (1u << 20))  limit_bytes = (1u << 20);
    if (limit_bytes > (MAX_TABLES * PT_COVERS_BYTES))
        limit_bytes = (MAX_TABLES * PT_COVERS_BYTES);

    /* Make sure our PD/PT arrays themselves are covered by the identity map.
       If they sit higher than the requested limit, bump the limit. */
    uint32_t pd_end  = (uint32_t)(uintptr_t)early_pd  + sizeof(early_pd);
    uint32_t pts_end = (uint32_t)(uintptr_t)early_pts + sizeof(early_pts);
    uint32_t must_cover = (pd_end > pts_end) ? pd_end : pts_end;
    if (limit_bytes < must_cover)
        limit_bytes = align_up(must_cover, PT_COVERS_BYTES); /* multiple of 4 MiB */

    /* Zero the PD (not strictly required since we only touch used entries) */
    for (uint32_t i = 0; i < PD_ENTRIES; ++i) early_pd[i] = 0;

    /* How many 4 MiB chunks to map? */
    uint32_t tables = (limit_bytes + (PT_COVERS_BYTES - 1u)) / PT_COVERS_BYTES;
    if (tables > MAX_TABLES) tables = MAX_TABLES;

    /* Build up to 'tables' page tables with identity mapping */
    for (uint32_t t = 0; t < tables; ++t) {
        /* Fill PT t: each entry maps a 4 KiB page */
        uint32_t base = t * PT_COVERS_BYTES;
        for (uint32_t e = 0; e < PT_ENTRIES; ++e) {
            uint32_t phys = base + e * PAGE_SIZE;
            early_pts[t][e] = (phys & ~0xFFFu) | (PTE_P | PTE_RW);
        }
        /* Point PD[t] to PT t */
        early_pd[t] = (((uint32_t)(uintptr_t)early_pts[t]) & ~0xFFFu) | (PDE_P | PDE_RW);
    }

    /* Load CR3 with the (identity-mapped) physical address of the PD */
    uint32_t cr3 = (uint32_t)(uintptr_t)early_pd;
    __asm__ volatile ("mov %0, %%cr3" :: "r"(cr3));
}

void paging_enable(void) {
    uint32_t cr0;
    __asm__ volatile ("mov %%cr0,%0" : "=r"(cr0));
    cr0 |= 0x80000000u; /* set PG bit */
    __asm__ volatile ("mov %0,%%cr0" :: "r"(cr0));
}
