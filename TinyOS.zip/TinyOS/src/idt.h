/*=============================================================================
 *  idt.h — IDT descriptors and initialization
 *============================================================================*/
#ifndef TINYOS_IDT_H
#define TINYOS_IDT_H
#include "kernel.h"

struct PACKED idt_entry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;          /* not used on i386, keep 0 */
    uint8_t  type_attr;    /* present | DPL | gate type */
    uint16_t offset_high;
};

struct PACKED idt_ptr {
    uint16_t limit;
    uint32_t base;
};

void idt_init(void);

/* Called by assembly stubs */
void isr_common_handler(uint32_t vector, uint32_t err);

#endif
