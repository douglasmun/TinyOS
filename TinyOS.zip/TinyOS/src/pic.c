/*=============================================================================
 *  pic.c — 8259 Programmable Interrupt Controller Driver for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file implements a driver for the Intel 8259 Programmable Interrupt
 *   Controller (PIC). The PIC manages hardware interrupts (IRQs) from devices
 *   like the keyboard, timer, and disk controllers, routing them to the CPU.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Chip: Intel 8259A (or compatible)
 *   - Configuration: Cascaded (master + slave)
 *   - Mode: Edge-triggered, fully nested
 *   - Remapping: IRQs moved from 0x08-0x0F to 0x20-0x2F
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is the PIC?
 * 2. Why We Need Interrupt Controllers
 * 3. The 8259 Hardware
 * 4. Master-Slave Cascading
 * 5. The Remapping Problem
 * 6. Initialization Command Words (ICWs)
 * 7. Operation Command Words (OCWs)
 * 8. The Remap Process
 * 9. End-Of-Interrupt (EOI)
 * 10. Memory Barriers and I/O Delays
 * 11. Design Decisions and Trade-offs
 * 12. Common Pitfalls and Solutions
 * 13. APIC vs PIC
 * 14. Integration with the Kernel
 *
 *=============================================================================
 * SECTION 1: WHAT IS THE PIC?
 *=============================================================================
 * 
 * PIC = Programmable Interrupt Controller
 * 
 * THE PROBLEM:
 * 
 * CPUs can only handle one interrupt signal at a time. But computers have
 * many devices that need to interrupt the CPU:
 *   - Timer (needs to fire periodically)
 *   - Keyboard (user pressed a key)
 *   - Mouse (user moved the mouse)
 *   - Hard disk (data ready)
 *   - Network card (packet arrived)
 *   - And many more...
 * 
 * How do we connect multiple interrupt sources to one CPU interrupt line?
 * 
 * SOLUTION: THE PIC
 * 
 * The PIC is a hardware chip that:
 *   1. Accepts interrupts from multiple devices (8 interrupt lines)
 *   2. Prioritizes them (which is most important?)
 *   3. Signals the CPU (one interrupt line out)
 *   4. Tells the CPU which device interrupted (vector number)
 * 
 * ANALOGY:
 * 
 * Think of the PIC like a receptionist at a busy office:
 *   - Multiple people (devices) arrive with messages (interrupts)
 *   - Receptionist (PIC) decides who's most important
 *   - Receptionist tells the boss (CPU) someone needs attention
 *   - Boss asks "Who is it?" and receptionist says "Person #3" (vector)
 * 
 * HISTORICAL CONTEXT:
 * 
 * The 8259 was introduced by Intel in 1976 for the 8080/8085 processors.
 * It became the standard interrupt controller for the IBM PC (1981).
 * Still used in modern x86 systems (though often emulated by APIC).
 * 
 * MODERN ALTERNATIVES:
 * 
 * Modern systems use APIC (Advanced PIC) or x2APIC:
 *   - Supports more interrupts (up to 224 with x2APIC)
 *   - Better multiprocessor support
 *   - More sophisticated priority handling
 *   - But backwards compatible with 8259 PIC
 * 
 * For TinyOS, we use the legacy 8259 PIC because:
 *   ✅ Simpler to program
 *   ✅ Widely documented
 *   ✅ Always present (real hardware and VMs)
 *   ✅ Sufficient for single-CPU, 16 IRQ systems
 *
 *=============================================================================
 * SECTION 2: WHY WE NEED INTERRUPT CONTROLLERS
 *=============================================================================
 * 
 * WHAT IS AN INTERRUPT?
 * 
 * An interrupt is a signal that tells the CPU to stop what it's doing and
 * handle an urgent event. There are two types:
 * 
 * 1. SOFTWARE INTERRUPTS (Exceptions):
 *    - Triggered by CPU itself
 *    - Examples: Divide by zero, page fault, invalid opcode
 *    - Handled directly by IDT (Interrupt Descriptor Table)
 * 
 * 2. HARDWARE INTERRUPTS (IRQs):
 *    - Triggered by external devices
 *    - Examples: Timer tick, keyboard press, disk ready
 *    - Routed through PIC before reaching CPU
 * 
 * WHY NOT CONNECT DEVICES DIRECTLY TO CPU?
 * 
 * Problems with direct connection:
 *   ❌ CPU has limited interrupt pins (often just one!)
 *   ❌ No way to identify which device interrupted
 *   ❌ No priority system (all devices equal)
 *   ❌ Race conditions if two devices interrupt simultaneously
 * 
 * PIC SOLVES THESE PROBLEMS:
 * 
 * ✅ MULTIPLEXING:
 *    Multiple device interrupt lines → One CPU interrupt line
 *    Devices connect to PIC → PIC connects to CPU
 * 
 * ✅ IDENTIFICATION:
 *    PIC tells CPU which device interrupted (vector number)
 *    CPU can call the correct handler
 * 
 * ✅ PRIORITY:
 *    IRQ 0 has highest priority, IRQ 15 lowest
 *    Timer (IRQ 0) can interrupt keyboard handler (IRQ 1)
 * 
 * ✅ MASKING:
 *    Can disable specific interrupts
 *    Example: Disable keyboard during initialization
 * 
 * IRQ LINES (Standard PC Configuration):
 * 
 * IRQ 0  - Programmable Interval Timer (PIT) - 100 Hz in TinyOS
 * IRQ 1  - Keyboard
 * IRQ 2  - Cascade (slave PIC signals through this)
 * IRQ 3  - COM2 (serial port)
 * IRQ 4  - COM1 (serial port)
 * IRQ 5  - LPT2 (parallel port) or Sound card
 * IRQ 6  - Floppy disk controller
 * IRQ 7  - LPT1 (parallel port) or spurious IRQ
 * IRQ 8  - Real-Time Clock (RTC)
 * IRQ 9  - ACPI / available
 * IRQ 10 - Available
 * IRQ 11 - Available
 * IRQ 12 - PS/2 Mouse
 * IRQ 13 - FPU (x87 coprocessor)
 * IRQ 14 - Primary IDE (hard disk)
 * IRQ 15 - Secondary IDE (hard disk)
 * 
 * NESTING AND PRIORITY:
 * 
 * Lower-numbered IRQs can interrupt higher-numbered ones:
 *   - Keyboard handler (IRQ 1) running
 *   - Timer (IRQ 0) fires
 *   - Timer handler interrupts keyboard handler
 *   - Timer handler completes
 *   - Keyboard handler resumes
 * 
 * This is called "nested interrupts" or "interrupt nesting."
 *
 *=============================================================================
 * SECTION 3: THE 8259 HARDWARE
 *=============================================================================
 * 
 * CHIP SPECIFICATIONS:
 * 
 * - Manufacturer: Intel (originally), many clones
 * - Part number: 8259A (improved version of 8259)
 * - Package: 28-pin DIP (Dual Inline Package)
 * - Power: +5V
 * - Interrupt lines: 8 per chip
 * - Cascading: Up to 9 chips (1 master + 8 slaves = 64 IRQs)
 * 
 * PIN CONNECTIONS (Simplified):
 * 
 * Input pins:
 *   - IR0-IR7: Interrupt Request lines (from devices)
 *   - CS: Chip Select (active low, selects this chip)
 *   - RD: Read signal (CPU reads from PIC)
 *   - WR: Write signal (CPU writes to PIC)
 *   - A0: Address line (selects register)
 *   - D0-D7: Data bus (8-bit bidirectional)
 * 
 * Output pins:
 *   - INT: Interrupt signal to CPU (active high)
 *   - CAS0-CAS2: Cascade lines (master ↔ slave communication)
 * 
 * I/O PORTS:
 * 
 * Each 8259 has two I/O ports:
 *   - Command port (A0=0): Send commands, read status
 *   - Data port (A0=1): Write masks, read vectors
 * 
 * Master PIC:
 *   - Command: 0x20
 *   - Data: 0x21
 * 
 * Slave PIC:
 *   - Command: 0xA0
 *   - Data: 0xA1
 * 
 * REGISTERS:
 * 
 * 1. IRR (Interrupt Request Register):
 *    - Shows which interrupt lines are active
 *    - Bit N = 1: IRQ N is requesting service
 * 
 * 2. ISR (In-Service Register):
 *    - Shows which interrupts are being serviced
 *    - Bit N = 1: IRQ N handler is running
 * 
 * 3. IMR (Interrupt Mask Register):
 *    - Controls which interrupts are enabled
 *    - Bit N = 1: IRQ N is MASKED (disabled)
 *    - Bit N = 0: IRQ N is UNMASKED (enabled)
 * 
 * OPERATION FLOW:
 * 
 * 1. Device asserts interrupt line (IR0-IR7)
 * 2. PIC sets corresponding bit in IRR
 * 3. PIC checks if interrupt is masked (IMR)
 * 4. If unmasked and higher priority than current ISR:
 *    a. PIC asserts INT line to CPU
 *    b. CPU acknowledges (INTA cycles)
 *    c. PIC provides vector number on data bus
 *    d. PIC sets bit in ISR (interrupt now in-service)
 *    e. PIC clears bit in IRR
 * 5. CPU calls interrupt handler
 * 6. Handler sends EOI (End-Of-Interrupt) to PIC
 * 7. PIC clears bit in ISR
 * 8. PIC can now accept lower-priority interrupts
 * 
 * PRIORITY:
 * 
 * Default priority (highest to lowest):
 *   IR0 > IR1 > IR2 > IR3 > IR4 > IR5 > IR6 > IR7
 * 
 * This can be rotated (priority rotation mode), but TinyOS doesn't use this.
 * 
 * EDGE VS LEVEL TRIGGERING:
 * 
 * Edge-triggered (default, used by TinyOS):
 *   - Interrupt occurs on rising edge (0→1 transition)
 *   - Device must pulse the line (high, then low)
 *   - Simpler, but can miss interrupts if not careful
 * 
 * Level-triggered:
 *   - Interrupt occurs when line is high
 *   - Device holds line high until serviced
 *   - More reliable, but needs proper EOI handling
 *
 *=============================================================================
 * SECTION 4: MASTER-SLAVE CASCADING
 *=============================================================================
 * 
 * THE 8-INTERRUPT LIMIT:
 * 
 * A single 8259 chip has only 8 interrupt lines (IR0-IR7).
 * But IBM PC needed more than 8 interrupts!
 * 
 * SOLUTION: CASCADING
 * 
 * Connect two 8259 chips:
 *   - Master PIC: Connected to CPU
 *   - Slave PIC: Connected to master's IR2 line
 * 
 * This gives 15 usable IRQs (not 16, because IR2 is used for cascading).
 * 
 * CASCADE CONNECTION:
 * 
 * Physical wiring:
 *   Master IR2 ← Slave INT
 *   Master CAS[2:0] → Slave CAS[2:0]
 * 
 * Logical view:
 * 
 *   CPU ← Master 8259
 *          ↑
 *          IR0: Timer
 *          IR1: Keyboard
 *          IR2: Cascade (Slave INT) ← Slave 8259
 *          IR3: COM2                    ↑
 *          IR4: COM1                    IR0 (8): RTC
 *          IR5: LPT2                    IR1 (9): Available
 *          IR6: Floppy                  IR2 (10): Available
 *          IR7: LPT1                    IR3 (11): Available
 *                                       IR4 (12): Mouse
 *                                       IR5 (13): FPU
 *                                       IR6 (14): Primary IDE
 *                                       IR7 (15): Secondary IDE
 * 
 * IRQ NUMBERING:
 * 
 * Master IRQs: 0-7 (but 2 is cascade)
 *   IRQ 0 = Master IR0
 *   IRQ 1 = Master IR1
 *   IRQ 2 = Cascade (not usable for devices)
 *   IRQ 3 = Master IR3
 *   ...
 *   IRQ 7 = Master IR7
 * 
 * Slave IRQs: 8-15
 *   IRQ 8 = Slave IR0
 *   IRQ 9 = Slave IR1
 *   ...
 *   IRQ 15 = Slave IR7
 * 
 * HOW CASCADING WORKS:
 * 
 * Example: Mouse interrupt (IRQ 12 = Slave IR4)
 * 
 * 1. Mouse asserts slave IR4 line
 * 2. Slave PIC sees IR4 request
 * 3. Slave PIC asserts its INT output
 * 4. Master PIC sees IR2 request (cascade line)
 * 5. Master PIC signals CPU on its INT line
 * 6. CPU acknowledges (INTA)
 * 7. Master PIC sees it's from slave (cascade)
 * 8. Master PIC signals slave via CAS lines
 * 9. Slave PIC provides vector on data bus
 * 10. CPU receives vector and calls handler
 * 
 * EOI FOR CASCADED INTERRUPTS:
 * 
 * For IRQ 0-7 (master only):
 *   Send EOI to master PIC only
 * 
 * For IRQ 8-15 (slave):
 *   Send EOI to BOTH slave AND master PICs
 *   Why both? Master needs to know slave finished
 * 
 * Code example:
 *   if (irq >= 8) {
 *       outb(0xA0, 0x20);  // EOI to slave
 *   }
 *   outb(0x20, 0x20);      // EOI to master (always)
 * 
 * PRIORITY WITH CASCADING:
 * 
 * Actual priority (highest to lowest):
 *   IRQ 0, 1, 8, 9, 10, 11, 12, 13, 14, 15, 3, 4, 5, 6, 7
 *   
 * Why this order?
 *   - IRQ 0-1 come before cascade (IR2)
 *   - IRQ 8-15 come through cascade (IR2)
 *   - IRQ 3-7 come after cascade (IR3-IR7)
 * 
 * So slave interrupts (8-15) have higher priority than IRQ 3-7!
 *
 *=============================================================================
 * SECTION 5: THE REMAPPING PROBLEM
 *=============================================================================
 * 
 * THE PROBLEM: VECTOR COLLISION
 * 
 * By default (after PC reset), the PIC uses vectors 0x08-0x0F for IRQs:
 *   IRQ 0 → Vector 0x08
 *   IRQ 1 → Vector 0x09
 *   ...
 *   IRQ 7 → Vector 0x0F
 *   IRQ 8 → Vector 0x70
 *   ...
 *   IRQ 15 → Vector 0x77
 * 
 * But Intel CPU uses vectors 0x00-0x1F for exceptions!
 *   Vector 0x00 = Divide Error (#DE)
 *   Vector 0x01 = Debug (#DB)
 *   ...
 *   Vector 0x08 = Double Fault (#DF) ← CONFLICT!
 *   Vector 0x09 = Coprocessor Segment Overrun
 *   ...
 *   Vector 0x0D = General Protection (#GP)
 *   Vector 0x0E = Page Fault (#PF)
 *   Vector 0x0F = Reserved
 * 
 * COLLISION EXAMPLES:
 * 
 * Without remapping:
 *   - Timer (IRQ 0) fires → Vector 0x08
 *   - CPU thinks it's a Double Fault!
 *   - Calls #DF handler instead of timer handler
 *   - Chaos!
 * 
 * Or vice versa:
 *   - Double Fault occurs → Vector 0x08
 *   - CPU might think it's timer interrupt
 *   - Calls timer handler instead of panic
 *   - System continues with corrupted state!
 * 
 * WHY INTEL CHOSE THIS LAYOUT:
 * 
 * Historical reasons:
 *   - 8259 was designed before 8086
 *   - 8086 reserved vectors 0x00-0x04 for exceptions
 *   - 8259 default was 0x08 (seemed safe)
 *   - Later CPUs (286, 386, 486) added more exceptions
 *   - Now 0x00-0x1F are reserved, but PIC defaults didn't change
 *   - Backwards compatibility kept the bad default
 * 
 * THE SOLUTION: REMAPPING
 * 
 * Move PIC vectors away from exception range:
 *   - CPU exceptions: 0x00-0x1F (fixed, can't change)
 *   - IRQs: 0x20-0x2F (configurable, we choose this)
 * 
 * After remapping:
 *   IRQ 0 → Vector 0x20 (32)
 *   IRQ 1 → Vector 0x21 (33)
 *   ...
 *   IRQ 7 → Vector 0x27 (39)
 *   IRQ 8 → Vector 0x28 (40)
 *   ...
 *   IRQ 15 → Vector 0x2F (47)
 * 
 * Now no conflicts!
 *   - Exceptions: 0x00-0x1F
 *   - IRQs: 0x20-0x2F
 *   - Available for other uses: 0x30-0xFF
 * 
 * WHY 0x20 (32)?
 * 
 * Common choice, also used by Linux and most OSes:
 *   ✅ Well after exception range (0x1F + 1 = 0x20)
 *   ✅ Round number (32 = 2^5)
 *   ✅ Leaves room for expansion
 *   ✅ Standard convention (easier to debug)
 * 
 * Could choose other values (0x30, 0x40, etc.), but 0x20 is conventional.
 * 
 * WHEN TO REMAP:
 * 
 * CRITICAL: Remap BEFORE enabling interrupts (STI)!
 * 
 * Initialization order:
 *   1. Set up IDT with exception handlers (0x00-0x1F)
 *   2. Set up IDT with IRQ handlers (0x20-0x2F)
 *   3. Remap PIC to use vectors 0x20-0x2F ← MUST BE HERE!
 *   4. Enable interrupts (STI)
 * 
 * If you enable interrupts before remapping:
 *   - Timer fires → Vector 0x08 (#DF)
 *   - No handler at 0x08 (or wrong handler)
 *   - Triple fault → Reboot
 *
 *=============================================================================
 * SECTION 6: INITIALIZATION COMMAND WORDS (ICWs)
 *=============================================================================
 * 
 * PIC INITIALIZATION:
 * 
 * The 8259 must be initialized with a sequence of 2-4 command words.
 * These are called ICWs (Initialization Command Words).
 * 
 * ICW SEQUENCE:
 *   ICW1: Start initialization, set modes
 *   ICW2: Set vector offset (remapping!)
 *   ICW3: Set cascade configuration
 *   ICW4: Set operating mode
 * 
 * Which ICWs are needed?
 *   - ICW1: Always required (starts initialization)
 *   - ICW2: Always required (sets vectors)
 *   - ICW3: Required if cascading (IC4 bit in ICW1)
 *   - ICW4: Required if ICW1 says so (IC4 bit)
 * 
 * TinyOS uses all four ICWs.
 * 
 * ============================================================================
 * ICW1: INITIALIZATION CONTROL WORD 1
 * ============================================================================
 * 
 * Sent to command port (0x20 or 0xA0).
 * Starts initialization sequence.
 * 
 * Bit layout:
 *   Bit 0 (IC4): 1 = ICW4 needed, 0 = ICW4 not needed
 *   Bit 1 (SNGL): 1 = Single PIC, 0 = Cascaded PICs
 *   Bit 2 (ADI): Call address interval (not used on x86)
 *   Bit 3 (LTIM): 1 = Level triggered, 0 = Edge triggered
 *   Bit 4: Must be 1 (identifies this as ICW1)
 *   Bits 5-7: Address bits (not used on x86)
 * 
 * TinyOS value: 0x11 (00010001 binary)
 *   Bit 0 = 1: ICW4 needed
 *   Bit 1 = 0: Cascaded mode (two PICs)
 *   Bit 2 = 0: (not used)
 *   Bit 3 = 0: Edge triggered
 *   Bit 4 = 1: (identifies as ICW1)
 *   Bits 5-7 = 0: (not used)
 * 
 * Why these choices?
 *   - IC4=1: We need ICW4 to set 8086 mode
 *   - SNGL=0: We have cascaded PICs (master + slave)
 *   - LTIM=0: Edge triggered (standard for PC)
 * 
 * After ICW1:
 *   PIC is now in initialization mode.
 *   Next write to data port (0x21 or 0xA1) will be ICW2.
 * 
 * ============================================================================
 * ICW2: INTERRUPT VECTOR ADDRESS
 * ============================================================================
 * 
 * Sent to data port (0x21 or 0xA1).
 * Sets the base vector for IRQs.
 * 
 * Bit layout:
 *   Bits 0-2: Unused on x86 (always 0)
 *   Bits 3-7: Base vector address (upper 5 bits)
 * 
 * Actual vector = (ICW2 & 0xF8) + IRQ_number
 * 
 * TinyOS values:
 *   Master ICW2: 0x20 (00100000 binary)
 *     Base = 0x20
 *     IRQ 0 → 0x20, IRQ 1 → 0x21, ..., IRQ 7 → 0x27
 *   
 *   Slave ICW2: 0x28 (00101000 binary)
 *     Base = 0x28
 *     IRQ 8 → 0x28, IRQ 9 → 0x29, ..., IRQ 15 → 0x2F
 * 
 * Why 0x20 and 0x28?
 *   - Avoids exception range (0x00-0x1F)
 *   - Consecutive (master ends at 0x27, slave starts at 0x28)
 *   - Standard convention
 * 
 * After ICW2:
 *   Next write will be ICW3 (if cascaded) or ICW4 (if not).
 * 
 * ============================================================================
 * ICW3: CASCADE IDENTITY
 * ============================================================================
 * 
 * Sent to data port (0x21 or 0xA1).
 * Configures cascade connections between master and slave.
 * 
 * MASTER ICW3:
 *   Bit N = 1: Slave PIC is connected to IR(N)
 *   
 *   TinyOS value: 0x04 (00000100 binary)
 *     Bit 2 = 1: Slave connected to IR2
 *     Other bits = 0: No other slaves
 * 
 * SLAVE ICW3:
 *   Bits 0-2: Slave ID (which master IR line it's on)
 *   
 *   TinyOS value: 0x02 (00000010 binary)
 *     Slave ID = 2: Connected to master's IR2
 * 
 * Why IR2?
 *   - Historical convention (IBM PC design)
 *   - IR0 and IR1 reserved for timer and keyboard
 *   - IR2 chosen for cascade
 * 
 * After ICW3:
 *   Next write will be ICW4 (if ICW1 requested it).
 * 
 * ============================================================================
 * ICW4: OPERATION MODE
 * ============================================================================
 * 
 * Sent to data port (0x21 or 0xA1).
 * Sets various operational modes.
 * 
 * Bit layout:
 *   Bit 0 (μPM): 1 = 8086/8088 mode, 0 = MCS-80/85 mode
 *   Bit 1 (AEOI): 1 = Auto EOI, 0 = Normal EOI
 *   Bit 2 (M/S): Master/Slave (only for buffered mode)
 *   Bit 3 (BUF): 1 = Buffered mode, 0 = Non-buffered
 *   Bit 4 (SFNM): 1 = Special fully nested mode
 *   Bits 5-7: Reserved (0)
 * 
 * TinyOS value: 0x01 (00000001 binary)
 *   Bit 0 = 1: 8086 mode (required for x86)
 *   Bit 1 = 0: Normal EOI (we send EOI manually)
 *   Bit 2 = 0: (not buffered)
 *   Bit 3 = 0: Non-buffered mode
 *   Bit 4 = 0: Normal nested mode
 * 
 * Why these choices?
 *   - μPM=1: We're on x86, need 8086 mode
 *   - AEOI=0: We want control over EOI (safer)
 *   - BUF=0: Non-buffered (simpler)
 *   - SFNM=0: Normal nesting is adequate
 * 
 * After ICW4:
 *   Initialization complete!
 *   PIC is now ready to accept interrupts.
 *   Next writes will be OCWs (Operation Command Words).
 * 
 * ============================================================================
 * INITIALIZATION SEQUENCE SUMMARY
 * ============================================================================
 * 
 * Master PIC (ports 0x20, 0x21):
 *   1. outb(0x20, 0x11);  // ICW1: Start init, need ICW4
 *   2. outb(0x21, 0x20);  // ICW2: Vector base = 0x20
 *   3. outb(0x21, 0x04);  // ICW3: Slave on IR2
 *   4. outb(0x21, 0x01);  // ICW4: 8086 mode
 * 
 * Slave PIC (ports 0xA0, 0xA1):
 *   1. outb(0xA0, 0x11);  // ICW1: Start init, need ICW4
 *   2. outb(0xA1, 0x28);  // ICW2: Vector base = 0x28
 *   3. outb(0xA1, 0x02);  // ICW3: Slave ID = 2
 *   4. outb(0xA1, 0x01);  // ICW4: 8086 mode
 * 
 * Result:
 *   IRQ 0-7 → Vectors 0x20-0x27
 *   IRQ 8-15 → Vectors 0x28-0x2F
 *
 *=============================================================================
 * SECTION 7: OPERATION COMMAND WORDS (OCWs)
 *=============================================================================
 * 
 * After initialization, the PIC is controlled via OCWs.
 * 
 * OCW TYPES:
 *   OCW1: Interrupt Mask Register (IMR)
 *   OCW2: End-Of-Interrupt and priority rotation
 *   OCW3: Read IRR/ISR, set special masks
 * 
 * ============================================================================
 * OCW1: INTERRUPT MASK REGISTER
 * ============================================================================
 * 
 * Sent to data port (0x21 or 0xA1).
 * Controls which interrupts are enabled/disabled.
 * 
 * Bit layout:
 *   Bit N = 1: IRQ N is MASKED (disabled)
 *   Bit N = 0: IRQ N is UNMASKED (enabled)
 * 
 * Examples:
 *   0xFF: All IRQs masked (disabled)
 *   0x00: All IRQs unmasked (enabled)
 *   0xFE: Only IRQ 0 unmasked (11111110 binary)
 *   0xFC: IRQ 0 and 1 unmasked (11111100 binary)
 * 
 * TinyOS usage:
 *   // Mask all IRQs initially
 *   outb(0x21, 0xFF);  // Master: all masked
 *   outb(0xA1, 0xFF);  // Slave: all masked
 *   
 *   // Unmask IRQ 0 (timer)
 *   uint8_t mask = inb(0x21);  // Read current mask
 *   mask &= ~(1 << 0);          // Clear bit 0 (unmask IRQ 0)
 *   outb(0x21, mask);           // Write back
 * 
 * Why mask then unmask?
 *   - Start with all IRQs disabled (safe)
 *   - Enable only IRQs we have handlers for
 *   - Prevents spurious interrupts during init
 * 
 * ============================================================================
 * OCW2: END-OF-INTERRUPT COMMAND
 * ============================================================================
 * 
 * Sent to command port (0x20 or 0xA0).
 * Tells PIC that interrupt handling is complete.
 * 
 * Bit layout:
 *   Bits 0-2: IRQ level (for specific EOI)
 *   Bits 3-4: Must be 0
 *   Bit 5 (EOI): 1 = EOI command
 *   Bit 6 (SL): 1 = Specific EOI, 0 = Non-specific EOI
 *   Bit 7 (R): Priority rotation
 * 
 * TinyOS uses non-specific EOI:
 *   Value: 0x20 (00100000 binary)
 *     Bits 0-2 = 0: (ignored for non-specific)
 *     Bit 5 = 1: EOI command
 *     Bit 6 = 0: Non-specific
 *     Bit 7 = 0: No rotation
 * 
 * Non-specific vs Specific EOI:
 * 
 * Non-specific (0x20):
 *   - PIC clears highest-priority ISR bit
 *   - Simple, most common
 *   - Used by TinyOS
 * 
 * Specific (0x60 + IRQ):
 *   - Explicitly specify which IRQ to clear
 *   - Example: 0x61 clears IRQ 1
 *   - Useful for out-of-order completion
 * 
 * When to send EOI:
 *   - End of interrupt handler (before IRET)
 *   - For IRQ 8-15: Send to both slave AND master
 * 
 * Example:
 *   void timer_handler() {
 *       // Handle timer interrupt
 *       tick_count++;
 *       
 *       // Send EOI (IRQ 0, master only)
 *       outb(0x20, 0x20);
 *       
 *       // Return (IRET)
 *   }
 * 
 * ============================================================================
 * OCW3: READ/SPECIAL COMMANDS
 * ============================================================================
 * 
 * Sent to command port (0x20 or 0xA0).
 * Controls reading of IRR/ISR and special modes.
 * 
 * Bit layout:
 *   Bits 0-1: Read register command
 *     10 = Read IRR on next read
 *     11 = Read ISR on next read
 *   Bit 2: Poll command
 *   Bit 3: Must be 1 (identifies as OCW3)
 *   Bits 4-7: Special mask and other options
 * 
 * TinyOS doesn't use OCW3 (we don't read IRR/ISR).
 * 
 * Useful for debugging:
 *   // Read IRR (pending interrupts)
 *   outb(0x20, 0x0A);  // OCW3: read IRR
 *   uint8_t irr = inb(0x20);
 *   
 *   // Read ISR (in-service interrupts)
 *   outb(0x20, 0x0B);  // OCW3: read ISR
 *   uint8_t isr = inb(0x20);
 *
 *=============================================================================
 * SECTION 8: THE REMAP PROCESS
 *=============================================================================
 * 
 * ALGORITHM:
 * 
 * 1. Save current interrupt masks (don't lose configuration)
 * 2. Send ICW1 to both PICs (start initialization)
 * 3. Send ICW2 to both PICs (set vector offsets)
 * 4. Send ICW3 to both PICs (configure cascade)
 * 5. Send ICW4 to both PICs (set operating mode)
 * 6. Restore interrupt masks (re-enable what was enabled)
 * 
 * STEP-BY-STEP EXECUTION:
 * 
 * Step 1: Save masks
 *   a1 = inb(0x21);  // Read master mask
 *   a2 = inb(0xA1);  // Read slave mask
 *   
 *   Why? Remapping resets the masks. We want to restore them after.
 * 
 * Step 2: Initialize master
 *   outb(0x20, 0x11);  // ICW1
 *   outb(0x21, 0x20);  // ICW2: Vectors 0x20-0x27
 *   outb(0x21, 0x04);  // ICW3: Slave on IR2
 *   outb(0x21, 0x01);  // ICW4: 8086 mode
 * 
 * Step 3: Initialize slave
 *   outb(0xA0, 0x11);  // ICW1
 *   outb(0xA1, 0x28);  // ICW2: Vectors 0x28-0x2F
 *   outb(0xA1, 0x02);  // ICW3: Slave ID = 2
 *   outb(0xA1, 0x01);  // ICW4: 8086 mode
 * 
 * Step 4: Restore masks
 *   outb(0x21, a1);  // Restore master mask
 *   outb(0xA1, a2);  // Restore slave mask
 * 
 * TIMING CONSIDERATIONS:
 * 
 * Old PIC hardware was slow. Modern PICs are faster, but we still need
 * small delays between operations to ensure proper sequencing.
 * 
 * Original PIC timing (Intel 8259A):
 *   - Write pulse width: 400ns minimum
 *   - Setup time: 0ns
 *   - Hold time: 40ns
 * 
 * On modern CPUs (1+ GHz), instructions execute in ~1ns.
 * But I/O operations are slower (~1µs).
 * 
 * TinyOS uses "I/O delay" between operations:
 *   - Jump instructions (jmp 1f; 1: jmp 1f; 1: nop)
 *   - Each jump: ~1 CPU cycle
 *   - Three jumps: ~3 CPU cycles ≈ 3ns @ 1GHz
 *   - I/O itself: ~1000ns
 *   - Total: Plenty of time for PIC to respond
 * 
 * Why not just sleep?
 *   - Sleep is milliseconds (too long)
 *   - Need microsecond-level delays
 *   - I/O delay is self-timing (adapts to CPU speed)
 * 
 * WHEN REMAP FAILS:
 * 
 * Symptoms:
 *   - Triple fault on first timer interrupt
 *   - Exceptions misidentified as IRQs
 *   - System reboots when STI executed
 * 
 * Common causes:
 *   - Wrong ICW values (typo in vector offset)
 *   - Missing ICW (forgot ICW3 or ICW4)
 *   - Wrong order (ICW2 before ICW1)
 *   - No delay between commands (too fast)
 *   - Remapping after STI (too late!)
 * 
 * Debugging:
 *   - Add kprintf before/after each ICW
 *   - Verify vectors in IDT match PIC remap
 *   - Check initialization order
 *   - Use QEMU with -d int to log interrupts
 *
 *=============================================================================
 * SECTION 9: END-OF-INTERRUPT (EOI)
 *=============================================================================
 * 
 * WHAT IS EOI?
 * 
 * EOI = End-Of-Interrupt
 * 
 * A command sent to the PIC to signal that interrupt handling is complete.
 * 
 * WHY IS EOI NEEDED?
 * 
 * When an IRQ fires:
 *   1. PIC sets bit in ISR (In-Service Register)
 *   2. PIC blocks lower-priority interrupts
 *   3. CPU calls interrupt handler
 *   4. Handler executes
 *   5. Handler sends EOI to PIC
 *   6. PIC clears ISR bit
 *   7. PIC can now accept lower-priority interrupts
 * 
 * Without EOI:
 *   - ISR bit stays set forever
 *   - That IRQ (and lower) will never fire again
 *   - System appears to hang
 * 
 * WHEN TO SEND EOI:
 * 
 * At the END of the interrupt handler, just before returning (IRET).
 * 
 * Correct:
 *   void irq_handler() {
 *       // Handle interrupt
 *       do_work();
 *       
 *       // Send EOI
 *       outb(0x20, 0x20);
 *       
 *       // Return (IRET restores execution)
 *   }
 * 
 * Wrong:
 *   void irq_handler() {
 *       // Send EOI too early!
 *       outb(0x20, 0x20);
 *       
 *       // Do work (might get interrupted by lower-priority IRQ)
 *       do_work();
 *   }
 * 
 * Early EOI problem:
 *   - Lower-priority IRQ can interrupt current handler
 *   - If current handler uses shared resources (not reentrant)
 *   - Race condition → Corruption
 * 
 * MASTER VS SLAVE EOI:
 * 
 * For IRQ 0-7 (master PIC):
 *   outb(0x20, 0x20);  // One EOI to master
 * 
 * For IRQ 8-15 (slave PIC):
 *   outb(0xA0, 0x20);  // EOI to slave first
 *   outb(0x20, 0x20);  // Then EOI to master
 * 
 * Why both?
 *   - Slave IRQ came through master's IR2 (cascade)
 *   - Master has IRQ 2 in-service (for the cascade)
 *   - Slave has actual IRQ in-service (e.g., IRQ 12)
 *   - Both must be cleared
 * 
 * Order matters!
 *   Slave first, then master.
 *   If reversed, master might accept new IR2 before slave is ready.
 * 
 * TINYOS IMPLEMENTATION:
 * 
 * pic_eoi(uint8_t irq) {
 *     if (irq >= 8) {
 *         outb(0xA0, 0x20);  // Slave EOI (for IRQ 8-15)
 *     }
 *     outb(0x20, 0x20);      // Master EOI (always)
 * }
 * 
 * Usage in interrupt handler:
 *   void interrupt_handler(uint8_t vector) {
 *       uint8_t irq = vector - 32;  // Vector 32 = IRQ 0
 *       
 *       // Handle specific IRQ
 *       switch (irq) {
 *           case 0: handle_timer(); break;
 *           case 1: handle_keyboard(); break;
 *           // ...
 *       }
 *       
 *       // Send EOI
 *       pic_eoi(irq);
 *   }
 * 
 * SPECIFIC VS NON-SPECIFIC EOI:
 * 
 * Non-specific EOI (0x20):
 *   - PIC automatically clears highest-priority ISR bit
 *   - Simple, works for normal operation
 *   - TinyOS uses this
 * 
 * Specific EOI (0x60 + IRQ number):
 *   - Explicitly specify which IRQ to clear
 *   - Example: 0x61 = Clear IRQ 1
 *   - Needed for special cases:
 *     * Shared interrupts
 *     * Out-of-order completion
 *     * Nested interrupts with different priorities
 * 
 * When non-specific fails:
 *   If IRQ handlers can complete out of order, non-specific EOI
 *   might clear the wrong ISR bit. Use specific EOI instead.
 * 
 * SPURIOUS INTERRUPTS:
 * 
 * Sometimes the PIC generates fake interrupts (spurious IRQs):
 *   - IRQ 7 on master
 *   - IRQ 15 on slave
 * 
 * How to detect:
 *   - Read ISR register
 *   - If ISR bit is not set, it's spurious
 * 
 * How to handle:
 *   - For IRQ 7: Don't send EOI (it's fake!)
 *   - For IRQ 15: Send EOI to master only (not slave)
 * 
 * TinyOS doesn't handle spurious IRQs (not critical for learning OS).
 *
 *=============================================================================
 * SECTION 10: MEMORY BARRIERS AND I/O DELAYS
 *=============================================================================
 * 
 * THE PROBLEM: COMPILER REORDERING
 * 
 * Modern compilers optimize aggressively. They might reorder operations:
 * 
 * Source code:
 *   outb(0x20, 0x11);  // ICW1
 *   outb(0x21, 0x20);  // ICW2
 * 
 * Compiled (optimized):
 *   outb(0x21, 0x20);  // ICW2 first (optimizer thinks it's faster)
 *   outb(0x20, 0x11);  // ICW1 second (WRONG!)
 * 
 * Result: PIC initialization fails (ICW2 before ICW1 is invalid).
 * 
 * SOLUTION: MEMORY BARRIERS
 * 
 * Memory barrier = Tell compiler "Don't reorder past this point"
 * 
 * In GCC inline assembly:
 *   __asm__ volatile("..." : : : "memory");
 *                              ↑
 *                              Memory clobber = barrier
 * 
 * Effect:
 *   - Compiler won't move memory operations across this point
 *   - All operations before stay before
 *   - All operations after stay after
 *   - Order is preserved
 * 
 * TINYOS APPROACH:
 * 
 * safe_outb() with memory barrier:
 *   static inline void safe_outb(uint16_t port, uint8_t value) {
 *       __asm__ volatile(
 *           "outb %0, %1\n\t"
 *           : 
 *           : "a"(value), "Nd"(port)
 *           : "memory"  ← Memory barrier!
 *       );
 *   }
 * 
 * Now compiler can't reorder outb() calls.
 * 
 * THE PROBLEM: HARDWARE TIMING
 * 
 * Old PIC chips were slow. Modern emulations (QEMU, VirtualBox) are
 * slower (they simulate timing).
 * 
 * If we write commands too fast:
 *   outb(0x20, 0x11);  // ICW1
 *   outb(0x21, 0x20);  // ICW2 immediately after
 *   
 *   PIC might not be ready for ICW2 yet!
 * 
 * SOLUTION: I/O DELAYS
 * 
 * Historical solutions:
 *   - Read from port 0x80 (POST diagnostic port)
 *   - Wastes ~1µs on ISA bus
 *   - Called "I/O delay" or "port 0x80 trick"
 * 
 * Modern solution (TinyOS):
 *   - Execute a few NOPs or jumps
 *   - Gives CPU time to complete I/O operation
 * 
 * TinyOS delay:
 *   __asm__ volatile(
 *       "outb %0, %1\n\t"
 *       "jmp 1f\n\t"         // Jump to next instruction
 *       "1: jmp 1f\n\t"      // Jump to next instruction
 *       "1: nop"             // No operation
 *       : : "a"(value), "Nd"(port) : "memory"
 *   );
 * 
 * How it works:
 *   - Each jump: ~1 CPU cycle
 *   - Three operations: ~3 cycles
 *   - On 1 GHz CPU: 3 nanoseconds
 *   - Plus I/O latency: ~1 microsecond
 *   - Total: Plenty for PIC
 * 
 * Why not sleep()?
 *   - sleep() is milliseconds (WAY too long)
 *   - Need microseconds or nanoseconds
 *   - I/O delay is self-adjusting (scales with CPU speed)
 * 
 * VOLATILE KEYWORD:
 * 
 * volatile in __asm__ volatile means:
 *   - This code has side effects
 *   - Don't optimize away
 *   - Don't assume result is constant
 *   - Always execute every time
 * 
 * Without volatile:
 *   Compiler might think "I've already done outb(0x20, 0x11), skip it"
 *   But we need to execute it every time!
 * 
 * WHY BOTH BARRIERS AND DELAYS?
 * 
 * Memory barrier:
 *   - Prevents compiler reordering (software issue)
 *   - No cost at runtime (compile-time only)
 * 
 * I/O delay:
 *   - Gives hardware time to respond (hardware issue)
 *   - Small cost at runtime (~3 cycles)
 * 
 * Both are needed:
 *   - Barrier: Correct order in assembly
 *   - Delay: Hardware has time to process
 * 
 * DO WE ALWAYS NEED DELAYS?
 * 
 * For PIC initialization: YES
 *   - Critical, must work correctly
 *   - Done once at boot (performance doesn't matter)
 * 
 * For PIC EOI: MAYBE
 *   - Done on every interrupt (performance matters)
 *   - Modern systems are fast enough
 *   - TinyOS uses delay to be safe
 * 
 * For other I/O: DEPENDS
 *   - VGA: No delay needed (direct memory access)
 *   - Serial: Built-in delays (wait for TX ready)
 *   - Disk: DMA controller handles timing
 *   - Network: Buffer-based, timing handled by card
 *
 *=============================================================================
 * SECTION 11: DESIGN DECISIONS AND TRADE-OFFS
 *=============================================================================
 * 
 * DECISION 1: USE 8259 PIC (NOT APIC)
 * 
 * Modern systems have APIC (Advanced PIC):
 *   ✅ More interrupts (up to 224)
 *   ✅ Better multiprocessor support
 *   ✅ Message-based (not edge/level)
 *   ✅ More sophisticated priority
 * 
 * Why TinyOS uses 8259 PIC:
 *   ✅ Simpler (easier to learn)
 *   ✅ Always present (real hardware and VMs)
 *   ✅ Well-documented
 *   ✅ Sufficient for single-CPU, 15 IRQ system
 * 
 * APIC is more complex:
 *   - Local APIC (one per CPU core)
 *   - I/O APIC (for device interrupts)
 *   - Must be discovered via ACPI or MP tables
 *   - Memory-mapped (not I/O ports)
 * 
 * For learning OS: 8259 PIC is better choice.
 * For production OS: APIC is necessary (multicore, more IRQs).
 * 
 * 
 * DECISION 2: SAFE_OUTB WITH DELAYS
 * 
 * TinyOS uses safe_outb() with I/O delays and memory barriers.
 * 
 * Alternative: Plain outb() without delays
 *   pros: Faster (3 fewer instructions)
 *   cons: Might fail on slow hardware/VMs
 * 
 * Why safe version?
 *   - Initialization is once (performance doesn't matter)
 *   - Correctness > Speed
 *   - Works on all hardware (real and virtual)
 *   - Easier to debug (no mysterious failures)
 * 
 * Could optimize EOI:
 *   Use fast outb() for EOI (called frequently)
 *   Use safe_outb() for init (called once)
 *   
 *   TinyOS uses safe version everywhere (simplicity).
 * 
 * 
 * DECISION 3: NON-SPECIFIC EOI
 * 
 * TinyOS uses non-specific EOI (0x20).
 * 
 * Alternative: Specific EOI (0x60 + IRQ)
 *   pros: More control, works with out-of-order completion
 *   cons: Slightly more complex
 * 
 * Why non-specific?
 *   - Simpler (just send 0x20)
 *   - TinyOS doesn't have nested interrupts with out-of-order completion
 *   - Standard approach for simple kernels
 * 
 * When specific is needed:
 *   - Shared interrupts (multiple devices on same IRQ)
 *   - Deferred interrupt handling
 *   - Complex priority schemes
 * 
 * 
 * DECISION 4: REMAP TO 0x20-0x2F
 * 
 * TinyOS remaps to vectors 0x20-0x2F.
 * 
 * Alternatives:
 *   - 0x30-0x3F: Some OSes use this
 *   - 0x40-0x4F: Also valid
 *   - 0x50-0x5F: Also valid
 * 
 * Why 0x20?
 *   - Standard convention (Linux, most OSes)
 *   - Just after exception range (0x00-0x1F)
 *   - Round number (easy to remember)
 *   - Easier to debug (known convention)
 * 
 * Does it matter?
 *   Not really! Any range above 0x1F works.
 *   But conventions help with debugging and understanding.
 * 
 * 
 * DECISION 5: MASK ALL, THEN UNMASK SELECTIVELY
 * 
 * TinyOS masks all IRQs, then unmasks only IRQ 0 (timer).
 * 
 * Alternative: Leave all unmasked
 *   pros: Simpler (no masking code)
 *   cons: Spurious interrupts during init
 * 
 * Why mask then unmask?
 *   - Safe (no unexpected interrupts)
 *   - Control (only enable what we handle)
 *   - Standard practice
 * 
 * Analogy:
 *   Like turning off all circuit breakers, then enabling only the ones
 *   you need. Prevents electrical accidents during work.
 * 
 * 
 * DECISION 6: SAVE AND RESTORE MASKS
 * 
 * TinyOS saves masks before remap, restores after.
 * 
 * Alternative: Don't save/restore
 *   pros: Simpler (less code)
 *   cons: Loses any bootloader configuration
 * 
 * Why save/restore?
 *   - Defensive programming
 *   - Preserves bootloader settings (if any)
 *   - Standard practice
 * 
 * In practice:
 *   Bootloader usually masks all IRQs anyway.
 *   So saving/restoring has no effect.
 *   But it's good practice to do it.
 * 
 * 
 * DECISION 7: INLINE FUNCTIONS IN HEADER
 * 
 * pic.h defines pic_mask_all() and pic_unmask() as inline.
 * 
 * Why inline?
 *   - Small functions (just one or two I/O operations)
 *   - Called frequently (unmask for each device)
 *   - Function call overhead avoided
 * 
 * Why in header?
 *   - Can be inlined by caller
 *   - Compiler can optimize better
 *   - No need for separate object file
 * 
 * Alternative: Non-inline in pic.c
 *   pros: Smaller code (one copy of function)
 *   cons: Function call overhead
 *   
 *   For small functions like these, inline is better.
 *
 *=============================================================================
 * SECTION 12: COMMON PITFALLS AND SOLUTIONS
 *=============================================================================
 * 
 * PITFALL 1: ENABLING INTERRUPTS BEFORE REMAPPING
 * 
 * Problem:
 *   __asm__ volatile("sti");  // Enable interrupts
 *   pic_remap();               // WRONG! Too late!
 * 
 * What happens:
 *   - Timer fires → Vector 0x08 (#DF Double Fault)
 *   - CPU calls wrong handler
 *   - System crashes (triple fault → reboot)
 * 
 * Solution:
 *   pic_remap();              // Remap first
 *   __asm__ volatile("sti");  // Then enable
 * 
 * Rule: ALWAYS remap before STI!
 * 
 * 
 * PITFALL 2: WRONG ICW ORDER
 * 
 * Problem:
 *   outb(0x21, 0x20);  // ICW2 first
 *   outb(0x20, 0x11);  // ICW1 second (WRONG!)
 * 
 * What happens:
 *   - PIC doesn't accept ICW2 (not in init mode)
 *   - Initialization fails silently
 *   - Interrupts don't work or go to wrong vectors
 * 
 * Solution:
 *   Always follow ICW sequence: ICW1, ICW2, ICW3, ICW4
 * 
 * 
 * PITFALL 3: FORGETTING SLAVE EOI
 * 
 * Problem:
 *   void irq12_handler() {  // Mouse (IRQ 12 = slave)
 *       handle_mouse();
 *       outb(0x20, 0x20);   // EOI to master only (WRONG!)
 *   }
 * 
 * What happens:
 *   - Slave ISR bit stays set
 *   - IRQ 12-15 never fire again
 *   - Mouse stops working
 * 
 * Solution:
 *   if (irq >= 8) {
 *       outb(0xA0, 0x20);  // EOI to slave
 *   }
 *   outb(0x20, 0x20);      // EOI to master (always)
 * 
 * 
 * PITFALL 4: EOI TOO EARLY
 * 
 * Problem:
 *   void irq_handler() {
 *       outb(0x20, 0x20);  // EOI first (WRONG!)
 *       do_long_work();     // Lower-priority IRQ can interrupt here
 *   }
 * 
 * What happens:
 *   - Current handler gets interrupted
 *   - If not reentrant, race condition
 *   - Data corruption
 * 
 * Solution:
 *   void irq_handler() {
 *       do_long_work();     // Work first
 *       outb(0x20, 0x20);  // EOI last
 *   }
 * 
 * 
 * PITFALL 5: WRONG REMAP VECTORS
 * 
 * Problem:
 *   outb(0x21, 0x08);  // ICW2: Vector 0x08 (WRONG! Conflicts!)
 * 
 * What happens:
 *   - IRQ 0 → Vector 0x08 (#DF)
 *   - Same problem as no remap
 *   - Crash on first interrupt
 * 
 * Solution:
 *   outb(0x21, 0x20);  // ICW2: Vector 0x20 (safe)
 *   
 *   Use vectors >= 0x20 (above exception range).
 * 
 * 
 * PITFALL 6: MASKING IRQ 2
 * 
 * Problem:
 *   uint8_t mask = 0xFF;  // Mask all
 *   mask &= ~(1 << 8);    // Unmask IRQ 8
 *   outb(0x21, mask);     // But IRQ 2 is still masked!
 * 
 * What happens:
 *   - IRQ 2 is cascade line to slave
 *   - If IRQ 2 masked, slave interrupts can't reach CPU
 *   - IRQ 8-15 don't work
 * 
 * Solution:
 *   If using any slave IRQ (8-15), also unmask IRQ 2:
 *   mask &= ~(1 << 2);  // Unmask cascade
 * 
 * Better: Use pic_unmask(irq) which handles this automatically.
 * 
 * 
 * PITFALL 7: NO I/O DELAYS
 * 
 * Problem:
 *   outb(0x20, 0x11);
 *   outb(0x21, 0x20);  // Too fast!
 * 
 * What happens:
 *   - Works on fast modern hardware
 *   - Fails on slow hardware or VMs (QEMU, VirtualBox)
 *   - Hard to debug (works on some systems, not others)
 * 
 * Solution:
 *   Use safe_outb() with delays.
 *   Or add explicit delays: inb(0x80) after each outb.
 * 
 * 
 * PITFALL 8: FORGETTING MEMORY BARRIERS
 * 
 * Problem:
 *   Compiler reorders I/O operations.
 *   Initialization sequence broken.
 * 
 * Solution:
 *   Use "memory" clobber in inline assembly:
 *   __asm__ volatile("..." : : : "memory");
 * 
 * Or use safe_outb() which includes barriers.
 * 
 * 
 * PITFALL 9: TESTING ON ONE SYSTEM ONLY
 * 
 * Problem:
 *   "Works on my machine!" (famous last words)
 *   - Works on QEMU, fails on VirtualBox
 *   - Works on real hardware, fails on VM
 * 
 * Why?
 *   - Different PIC implementations (chip vs emulation)
 *   - Different timing requirements
 *   - Different quirks
 * 
 * Solution:
 *   Test on multiple platforms:
 *   - QEMU (most common)
 *   - VirtualBox
 *   - Bochs
 *   - Real hardware (if possible)
 * 
 * 
 * PITFALL 10: DEBUGGING WITHOUT SERIAL
 * 
 * Problem:
 *   PIC initialization fails.
 *   Screen is blank (no output).
 *   How to debug?
 * 
 * Solution:
 *   - Use serial port (kprintf to serial)
 *   - Add debug prints after each ICW
 *   - QEMU: -serial stdio to see output
 *   - QEMU: -d int to log interrupts
 * 
 * Example:
 *   kprintf("PIC: Sending ICW1\n");
 *   safe_outb(0x20, 0x11);
 *   kprintf("PIC: Sending ICW2\n");
 *   safe_outb(0x21, 0x20);
 *   // etc.
 *
 *=============================================================================
 * SECTION 13: APIC VS PIC
 *=============================================================================
 * 
 * APIC = Advanced Programmable Interrupt Controller
 * 
 * Modern x86 systems have APIC, not 8259 PIC.
 * But APIC usually emulates 8259 for backwards compatibility.
 * 
 * PIC (8259A):
 *   ✅ Simple (I/O ports, easy to program)
 *   ✅ Always present (real and virtual hardware)
 *   ✅ Sufficient for single-CPU systems
 *   ❌ Only 15 usable IRQs (16 with cascade)
 *   ❌ Poor multiprocessor support
 *   ❌ Edge or level triggered (not message-based)
 * 
 * APIC (Advanced PIC):
 *   ✅ Up to 224 interrupts
 *   ✅ Excellent multiprocessor support (one LAPIC per core)
 *   ✅ Message-based (more flexible)
 *   ✅ Better priority handling
 *   ❌ More complex (memory-mapped, not I/O ports)
 *   ❌ Must be discovered via ACPI or MP tables
 *   ❌ Different for each CPU vendor (Intel vs AMD quirks)
 * 
 * APIC COMPONENTS:
 * 
 * Local APIC (LAPIC):
 *   - One per CPU core
 *   - Handles inter-processor interrupts (IPI)
 *   - Handles local timer
 *   - Receives interrupts from I/O APIC
 * 
 * I/O APIC:
 *   - One per system (or per I/O subsystem)
 *   - Routes device interrupts to LAPICs
 *   - Replaces 8259 PIC
 * 
 * WHEN TO USE APIC:
 * 
 * You need APIC if:
 *   - Multicore/multiprocessor system
 *   - More than 15 IRQs needed
 *   - Modern features (MSI, MSI-X)
 *   - Production OS (Linux, Windows use APIC)
 * 
 * You can use PIC if:
 *   - Single CPU
 *   - 15 IRQs sufficient
 *   - Learning/educational OS
 *   - Simplicity is priority
 * 
 * TRANSITIONING FROM PIC TO APIC:
 * 
 * 1. Keep PIC code for initial boot
 * 2. Detect APIC presence (CPUID, ACPI tables)
 * 3. Initialize APIC if present
 * 4. Disable 8259 PIC (mask all IRQs)
 * 5. Use APIC for all interrupts
 * 
 * TinyOS approach:
 *   - Use PIC only (simpler)
 *   - APIC support can be added later
 *   - Educational value of PIC is higher
 *
 *=============================================================================
 * SECTION 14: INTEGRATION WITH THE KERNEL
 *=============================================================================
 * 
 * WHERE PIC IS USED IN TINYOS:
 * 
 * 1. INITIALIZATION (kernel.c)
 *    pic_remap();       // Remap IRQs to 0x20-0x2F
 *    pic_mask_all();    // Mask all IRQs
 *    pic_unmask(0);     // Unmask IRQ 0 (timer)
 * 
 * 2. INTERRUPT HANDLERS (interrupts.c)
 *    pic_eoi(irq);      // Send EOI after handling
 * 
 * INITIALIZATION ORDER:
 * 
 * Critical order (from kernel.c):
 *   1. IDT setup (exception and IRQ handlers)
 *   2. PIC remap (IRQs → 0x20-0x2F)
 *   3. PIC mask all (disable all IRQs)
 *   4. PIT init (configure timer)
 *   5. PIC unmask IRQ 0 (enable timer only)
 *   6. STI (enable interrupts globally)
 * 
 * Why this order?
 *   - IDT first: Handlers must exist before IRQs fire
 *   - Remap before STI: Avoid vector conflicts
 *   - Mask before unmask: Start safe, enable selectively
 *   - STI last: Everything ready before enabling
 * 
 * DEPENDENCY GRAPH:
 * 
 *   pic.c (THIS FILE)
 *     ↑
 *     ├── kernel.h (types, inb/outb declarations)
 *     └── pic.h (function prototypes)
 *     ↓
 *   Used by:
 *     ├── kernel.c (initialization)
 *     └── interrupts.c (EOI in handlers)
 * 
 * FUNCTIONS EXPORTED:
 * 
 * pic_remap():
 *   - Called once during boot
 *   - Remaps IRQs from 0x08-0x0F to 0x20-0x2F
 * 
 * pic_eoi(irq):
 *   - Called at end of every IRQ handler
 *   - Sends EOI to appropriate PIC(s)
 * 
 * pic_mask_all() (inline in pic.h):
 *   - Called during initialization
 *   - Masks all 16 IRQs
 * 
 * pic_unmask(irq) (inline in pic.h):
 *   - Called to enable specific IRQ
 *   - Example: pic_unmask(0) for timer
 * 
 * FUTURE ENHANCEMENTS:
 * 
 * This file could be extended with:
 * 
 * 1. pic_mask(irq) - Mask specific IRQ
 *    void pic_mask(uint8_t irq);
 * 
 * 2. pic_get_irr() - Read Interrupt Request Register
 *    uint16_t pic_get_irr(void);
 * 
 * 3. pic_get_isr() - Read In-Service Register
 *    uint16_t pic_get_isr(void);
 * 
 * 4. pic_set_priority() - Change interrupt priority
 *    void pic_set_priority(uint8_t irq);
 * 
 * 5. pic_disable() - Completely disable PIC (for APIC)
 *    void pic_disable(void);
 * 
 * 6. Spurious IRQ detection
 *    bool pic_is_spurious(uint8_t irq);
 * 
 * 7. Statistics
 *    uint32_t pic_get_irq_count(uint8_t irq);
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "kernel.h"
#include "pic.h"

/*=============================================================================
 * SAFE I/O FUNCTIONS WITH MEMORY BARRIERS AND DELAYS
 *=============================================================================
 * 
 * These functions provide safe I/O operations for PIC programming:
 *   - Memory barriers prevent compiler reordering
 *   - I/O delays give hardware time to respond
 *   - Volatile ensures operations are not optimized away
 */

/**
 * safe_outb - Write byte to I/O port with delays and barriers
 * 
 * PARAMETERS:
 *   port - I/O port address (0x20, 0x21, 0xA0, or 0xA1 for PIC)
 *   value - Byte value to write
 * 
 * BEHAVIOR:
 *   1. Execute OUTB instruction (CPU → port)
 *   2. Execute delay sequence (jumps + NOP)
 *   3. Memory barrier prevents reordering
 * 
 * DELAY SEQUENCE:
 *   jmp 1f        ; Jump to next instruction (label 1 forward)
 *   1: jmp 1f     ; Jump to next instruction (label 1 forward again)
 *   1: nop        ; No operation
 * 
 *   This provides ~3 CPU cycles of delay.
 *   On 1 GHz CPU: 3 nanoseconds.
 *   Plus I/O latency: ~1 microsecond.
 *   Total: Plenty for PIC to process command.
 * 
 * WHY INLINE:
 *   Small function, called frequently.
 *   Inlining eliminates function call overhead.
 * 
 * WHY STATIC:
 *   Only used in this file.
 *   Prevents name pollution in global namespace.
 * 
 * MEMORY CLOBBER:
 *   The "memory" in clobber list tells compiler:
 *   - This instruction has side effects
 *   - Don't reorder memory operations around it
 *   - Treat as a memory barrier
 * 
 * VOLATILE:
 *   Prevents compiler from:
 *   - Removing this code (thinks it's unused)
 *   - Moving this code (thinks order doesn't matter)
 *   - Caching the result (thinks it's constant)
 */
static inline void safe_outb(uint16_t port, uint8_t value) {
    __asm__ volatile(
        "outb %0, %1\n\t"      /* Output byte to port */
        "jmp 1f\n\t"           /* Delay: jump forward */
        "1: jmp 1f\n\t"        /* Delay: jump forward again */
        "1: nop"               /* Delay: no-op */
        :                      /* No output operands */
        : "a"(value),          /* Input: AL register = value */
          "Nd"(port)           /* Input: Port (immediate or DX) */
        : "memory"             /* Clobber: Memory barrier */
    );
}

/**
 * safe_inb - Read byte from I/O port with delays and barriers
 * 
 * PARAMETERS:
 *   port - I/O port address
 * 
 * RETURN VALUE:
 *   Byte read from port
 * 
 * BEHAVIOR:
 *   1. Execute INB instruction (port → CPU)
 *   2. Execute delay sequence
 *   3. Memory barrier prevents reordering
 *   4. Return value in AL register
 * 
 * USAGE:
 *   Used to read interrupt masks before remapping.
 *   Preserves existing configuration.
 * 
 * OUTPUT OPERAND:
 *   "=a"(ret) means:
 *   - = : This is an output
 *   - a : Use AL/AX/EAX register
 *   - (ret) : Store in variable 'ret'
 */
static inline uint8_t safe_inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile(
        "inb %1, %0\n\t"       /* Input byte from port */
        "jmp 1f\n\t"           /* Delay: jump forward */
        "1: jmp 1f\n\t"        /* Delay: jump forward again */
        "1: nop"               /* Delay: no-op */
        : "=a"(ret)            /* Output: AL register → ret */
        : "Nd"(port)           /* Input: Port */
        : "memory"             /* Clobber: Memory barrier */
    );
    return ret;
}

/*=============================================================================
 * FUNCTION: pic_remap
 *=============================================================================
 * 
 * PURPOSE:
 *   Remap the PIC interrupt vectors from default (0x08-0x0F, 0x70-0x77)
 *   to new locations (0x20-0x2F) to avoid conflict with CPU exceptions.
 * 
 * PARAMETERS:
 *   None
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * WHAT IT DOES:
 *   1. Save current interrupt masks
 *   2. Initialize master PIC (IRQ 0-7 → vectors 0x20-0x27)
 *   3. Initialize slave PIC (IRQ 8-15 → vectors 0x28-0x2F)
 *   4. Restore interrupt masks
 * 
 * WHEN TO CALL:
 *   Early in kernel initialization, BEFORE enabling interrupts (STI).
 *   After setting up IDT.
 *   
 *   Typical boot sequence:
 *     idt_init();       // Set up IDT with handlers
 *     pic_remap();      // Remap PIC to avoid conflicts ← HERE!
 *     pic_mask_all();   // Mask all IRQs
 *     pic_unmask(0);    // Enable specific IRQs
 *     sti();            // Enable interrupts
 * 
 * RESULT:
 *   After this function:
 *   - IRQ 0 (timer) → Vector 0x20 (not 0x08)
 *   - IRQ 1 (keyboard) → Vector 0x21 (not 0x09)
 *   - ...
 *   - IRQ 15 (IDE) → Vector 0x2F (not 0x77)
 * 
 * SAFETY:
 *   Uses safe_outb/safe_inb with delays and barriers.
 *   Robust across different hardware and VMs.
 * 
 * PERFORMANCE:
 *   Called once during boot.
 *   Performance is not critical.
 *   Safety and correctness are paramount.
 */
void pic_remap(void) {
    uint8_t a1, a2;
    
    /*
     * STEP 1: SAVE CURRENT INTERRUPT MASKS
     * 
     * Read current masks from both PICs.
     * We'll restore these after remapping.
     * 
     * Why save?
     *   - Defensive programming
     *   - Preserves bootloader configuration (if any)
     *   - Good practice
     * 
     * In practice:
     *   Bootloader usually masks all IRQs.
     *   So a1 and a2 are typically 0xFF.
     *   But we save them anyway (just in case).
     */
    a1 = safe_inb(0x21);  /* Master PIC mask */
    a2 = safe_inb(0xA1);  /* Slave PIC mask */
    
    /*
     * STEP 2: SEND ICW1 TO BOTH PICS
     * 
     * ICW1 starts initialization sequence.
     * 
     * Value: 0x11 (00010001 binary)
     *   Bit 0 = 1: Need ICW4
     *   Bit 1 = 0: Cascaded mode (master + slave)
     *   Bit 3 = 0: Edge triggered
     *   Bit 4 = 1: This is ICW1 (required)
     * 
     * After ICW1:
     *   PIC enters initialization mode.
     *   Next write to data port will be ICW2.
     */
    safe_outb(0x20, 0x11);  /* Master: ICW1 */
    safe_outb(0xA0, 0x11);  /* Slave: ICW1 */
    
    /*
     * STEP 3: SEND ICW2 TO BOTH PICS
     * 
     * ICW2 sets the vector offset (remapping!).
     * 
     * Master: 0x20
     *   IRQ 0-7 → Vectors 0x20-0x27 (32-39)
     * 
     * Slave: 0x28
     *   IRQ 8-15 → Vectors 0x28-0x2F (40-47)
     * 
     * Why these values?
     *   - Avoids CPU exception range (0x00-0x1F)
     *   - Consecutive (master ends at 0x27, slave starts at 0x28)
     *   - Standard convention (Linux, most OSes use this)
     */
    safe_outb(0x21, 0x20);  /* Master: Vectors 0x20-0x27 */
    safe_outb(0xA1, 0x28);  /* Slave: Vectors 0x28-0x2F */
    
    /*
     * STEP 4: SEND ICW3 TO BOTH PICS
     * 
     * ICW3 configures cascading (master-slave connection).
     * 
     * Master: 0x04 (00000100 binary)
     *   Bit 2 = 1: Slave PIC is on IR2
     *   
     *   This tells master: "When IR2 fires, it's from the slave PIC"
     * 
     * Slave: 0x02 (00000010 binary)
     *   Slave ID = 2: "I'm connected to master's IR2"
     *   
     *   This tells slave: "I'm slave #2"
     * 
     * Why IR2?
     *   Historical IBM PC design.
     *   IRQ 0, 1 reserved for timer and keyboard.
     *   IRQ 2 chosen for cascade.
     */
    safe_outb(0x21, 0x04);  /* Master: Slave on IR2 */
    safe_outb(0xA1, 0x02);  /* Slave: Cascade identity = 2 */
    
    /*
     * STEP 5: SEND ICW4 TO BOTH PICS
     * 
     * ICW4 sets operating mode.
     * 
     * Value: 0x01 (00000001 binary)
     *   Bit 0 = 1: 8086/8088 mode (required for x86)
     *   Bit 1 = 0: Normal EOI (not auto EOI)
     *   Bit 3 = 0: Non-buffered mode
     * 
     * Why 8086 mode?
     *   We're on x86, not MCS-80/85.
     *   Must set this bit or PIC won't work correctly.
     * 
     * Why not auto EOI?
     *   Auto EOI is dangerous:
     *   - Clears ISR bit automatically when interrupt acknowledged
     *   - Can cause priority inversion issues
     *   - We prefer manual EOI (more control)
     */
    safe_outb(0x21, 0x01);  /* Master: 8086 mode */
    safe_outb(0xA1, 0x01);  /* Slave: 8086 mode */
    
    /*
     * STEP 6: RESTORE INTERRUPT MASKS
     * 
     * Write back the masks we saved earlier.
     * 
     * This preserves any configuration from the bootloader.
     * In practice, bootloader usually has all IRQs masked (0xFF).
     * 
     * After this, we typically call:
     *   pic_mask_all();   // Explicitly mask all
     *   pic_unmask(0);    // Enable only timer
     * 
     * So restoring masks here is somewhat redundant, but good practice.
     */
    safe_outb(0x21, a1);  /* Master: Restore mask */
    safe_outb(0xA1, a2);  /* Slave: Restore mask */
    
    /*
     * INITIALIZATION COMPLETE!
     * 
     * The PIC is now configured:
     *   - IRQs remapped to vectors 0x20-0x2F
     *   - Cascading enabled (slave on master's IR2)
     *   - 8086 mode, manual EOI
     *   - Ready to accept interrupts
     * 
     * Next steps (in kernel.c):
     *   - Mask all IRQs (pic_mask_all)
     *   - Set up devices (PIT, etc.)
     *   - Unmask specific IRQs (pic_unmask)
     *   - Enable interrupts (STI)
     */
}

/*=============================================================================
 * FUNCTION: pic_eoi
 *=============================================================================
 * 
 * PURPOSE:
 *   Send End-Of-Interrupt command to the PIC after handling an IRQ.
 *   This tells the PIC that interrupt handling is complete and it can
 *   accept new interrupts of the same or lower priority.
 * 
 * PARAMETERS:
 *   irq - IRQ number (0-15)
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * WHAT IT DOES:
 *   For IRQ 0-7 (master PIC):
 *     Send EOI to master only (port 0x20)
 *   
 *   For IRQ 8-15 (slave PIC):
 *     Send EOI to slave first (port 0xA0)
 *     Then send EOI to master (port 0x20)
 * 
 * WHY BOTH FOR SLAVE?
 *   Slave interrupts come through master's IR2 (cascade).
 *   Both PICs have ISR bits set:
 *     - Master: ISR bit 2 (cascade)
 *     - Slave: ISR bit N (actual IRQ)
 *   Both must be cleared.
 * 
 * EOI COMMAND:
 *   Value: 0x20 (non-specific EOI)
 *   Clears highest-priority ISR bit.
 * 
 * WHEN TO CALL:
 *   At the END of the interrupt handler, just before IRET.
 *   
 *   Example:
 *     void timer_handler() {
 *         tick_count++;           // Handle interrupt
 *         pic_eoi(0);             // Send EOI ← HERE!
 *         return;                 // IRET back to interrupted code
 *     }
 * 
 * CRITICAL:
 *   Must call pic_eoi() before returning from interrupt handler!
 *   Without EOI, that IRQ will never fire again.
 * 
 * ORDER:
 *   For slave IRQs, order matters:
 *     1. Send EOI to slave first (0xA0)
 *     2. Then send EOI to master (0x20)
 *   
 *   If reversed, master might accept new IR2 before slave is ready.
 * 
 * USAGE EXAMPLES:
 *   pic_eoi(0);   // Timer (master)
 *   pic_eoi(1);   // Keyboard (master)
 *   pic_eoi(12);  // Mouse (slave + master)
 *   pic_eoi(14);  // IDE disk (slave + master)
 */
void pic_eoi(uint8_t irq) {
    /*
     * CHECK IF SLAVE IRQ (8-15)
     * 
     * Slave IRQs need EOI to both PICs.
     * Master IRQs need EOI to master only.
     * 
     * IRQ 0-7: Master PIC (directly connected)
     * IRQ 8-15: Slave PIC (through master's IR2 cascade)
     */
    if (irq >= 8) {
        /*
         * SEND EOI TO SLAVE PIC
         * 
         * Port: 0xA0 (slave command register)
         * Value: 0x20 (non-specific EOI)
         * 
         * This clears the ISR bit in the slave PIC.
         * Example: IRQ 12 clears slave ISR bit 4.
         */
        safe_outb(0xA0, 0x20);
    }
    
    /*
     * SEND EOI TO MASTER PIC
     * 
     * Port: 0x20 (master command register)
     * Value: 0x20 (non-specific EOI)
     * 
     * This clears the ISR bit in the master PIC.
     * 
     * For master IRQs (0-7):
     *   Clears the actual IRQ's ISR bit.
     *   Example: IRQ 0 clears master ISR bit 0.
     * 
     * For slave IRQs (8-15):
     *   Clears the cascade ISR bit (bit 2).
     *   This is the master's IR2 line (connected to slave).
     * 
     * ALWAYS sent, regardless of master or slave IRQ.
     * Master is the final arbiter of all interrupts.
     */
    safe_outb(0x20, 0x20);
}

/*=============================================================================
 * END OF FILE: pic.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Implemented PIC remapping (avoid exception conflicts)
 *   ✅ Implemented EOI handling (master and slave)
 *   ✅ Safe I/O with memory barriers and delays
 *   ✅ Support for cascaded PIC (15 usable IRQs)
 *   ✅ Comprehensive documentation for learning
 * 
 * WHAT HAPPENS NEXT:
 *   → pic_remap() called during kernel initialization
 *   → pic_eoi() called at end of every IRQ handler
 *   → pic_mask_all() and pic_unmask() used to control IRQs
 *   → System can now handle hardware interrupts safely
 * 
 * KEY TAKEAWAYS:
 *   1. PIC manages hardware interrupts (IRQs) from devices
 *   2. Default vectors conflict with CPU exceptions (must remap!)
 *   3. Remapping moves IRQs from 0x08-0x0F to 0x20-0x2F
 *   4. Cascading gives 15 IRQs (master 0-7, slave 8-15)
 *   5. EOI is required after every interrupt handler
 *   6. Slave IRQs need EOI to both PICs
 *   7. Memory barriers prevent compiler reordering
 *   8. I/O delays give hardware time to respond
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - How hardware interrupt controllers work
 *   - The cascading PIC architecture
 *   - PIC initialization sequence (ICWs)
 *   - PIC operation (EOI, masking)
 *   - The critical remapping problem and solution
 *   - Safe I/O programming techniques
 * 
 *   You've mastered a fundamental piece of computer architecture! 🎉
 *============================================================================*/
