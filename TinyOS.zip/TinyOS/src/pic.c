/*=============================================================================
 *  pic.c — Ultra-safe PIC driver with memory barriers
 *============================================================================*/
#include "kernel.h"
#include "pic.h"

/* Safe I/O with memory barriers */
static inline void safe_outb(uint16_t port, uint8_t value) {
    __asm__ volatile(
        "outb %0, %1\n\t"
        "jmp 1f\n\t"
        "1: jmp 1f\n\t"
        "1: nop"
        : 
        : "a"(value), "Nd"(port)
        : "memory"
    );
}

static inline uint8_t safe_inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile(
        "inb %1, %0\n\t"
        "jmp 1f\n\t"
        "1: jmp 1f\n\t"
        "1: nop"
        : "=a"(ret)
        : "Nd"(port)
        : "memory"
    );
    return ret;
}

void pic_remap(void) {
    uint8_t a1, a2;
    
    /* Save masks */
    a1 = safe_inb(0x21);
    a2 = safe_inb(0xA1);
    
    /* ICW1: Start init */
    safe_outb(0x20, 0x11);
    safe_outb(0xA0, 0x11);
    
    /* ICW2: Set offsets */
    safe_outb(0x21, 0x20);
    safe_outb(0xA1, 0x28);
    
    /* ICW3: Cascade */
    safe_outb(0x21, 0x04);
    safe_outb(0xA1, 0x02);
    
    /* ICW4: Mode */
    safe_outb(0x21, 0x01);
    safe_outb(0xA1, 0x01);
    
    /* Restore masks */
    safe_outb(0x21, a1);
    safe_outb(0xA1, a2);
}

void pic_eoi(uint8_t irq) {
    if (irq >= 8) {
        safe_outb(0xA0, 0x20);
    }
    safe_outb(0x20, 0x20);
}
