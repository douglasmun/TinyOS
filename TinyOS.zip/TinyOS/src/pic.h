#pragma once
#include <stdint.h>

/* Low-level I/O port access */
static inline void outb(uint16_t p, uint8_t v) { 
    __asm__ volatile("outb %0,%1"::"a"(v),"Nd"(p)); 
}

static inline uint8_t inb(uint16_t p) { 
    uint8_t r; 
    __asm__ volatile("inb %1,%0":"=a"(r):"Nd"(p)); 
    return r; 
}

/* PIC functions - implemented in pic.c */
void pic_remap(void);           /* Remap PIC to IRQ 32-47 */
void pic_eoi(uint8_t irq);      /* Send End-Of-Interrupt */

/* Inline helper functions */
static inline void pic_mask_all(void) { 
    outb(0x21, 0xFF);  /* Mask all IRQs on master PIC */
    outb(0xA1, 0xFF);  /* Mask all IRQs on slave PIC */
}

static inline void pic_unmask(uint8_t irq) {
    uint16_t port = (irq < 8) ? 0x21 : 0xA1;
    uint8_t bit = (irq < 8) ? irq : (irq - 8);
    uint8_t mask = inb(port);
    mask &= ~(1u << bit);
    outb(port, mask);
}
