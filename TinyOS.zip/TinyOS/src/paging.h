/*=============================================================================
 *  paging.h — TinyOS Paging (identity map first 16–32 MiB)
 *============================================================================*/
#pragma once
#include <stdint.h>

/* Map [0, limit_bytes) identity and enable paging */
void paging_identity_map_early(uint32_t limit_bytes);
void paging_enable(void);
