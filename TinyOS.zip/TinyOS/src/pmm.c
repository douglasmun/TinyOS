/*=============================================================================
 *  pmm.c — TinyOS Physical Memory Manager (bitmap)
 *============================================================================*/
#include "kernel.h"
#include "pmm.h"

/* fixed 128 MiB model for now */
#define PMM_MAX_BYTES   (128u * 1024u * 1024u)
#define PMM_MAX_FRAMES  (PMM_MAX_BYTES / PMM_PAGE_SIZE)

static uint8_t  bitmap[PMM_MAX_FRAMES / 8] __attribute__((aligned(4096)));
static uint32_t frames_total = PMM_MAX_FRAMES;
static uint32_t frames_free  = 0;

/* provided by linker.ld */
extern uint8_t _kernel_start, _kernel_end;

static inline void bset(uint32_t i){ bitmap[i>>3] |=  (1u<<(i&7)); }
static inline void bclr(uint32_t i){ bitmap[i>>3] &= ~(1u<<(i&7)); }
static inline int  bget(uint32_t i){ return (bitmap[i>>3]>>(i&7))&1; }

static void mark_range(uint32_t phys, uint32_t size, int used) {
    uint32_t start = phys / PMM_PAGE_SIZE;
    uint32_t end   = (phys + size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE;
    if (end > PMM_MAX_FRAMES) end = PMM_MAX_FRAMES;
    for (uint32_t i = start; i < end; ++i) {
        int was = bget(i);
        if (used) { if (!was) { bset(i); if (frames_free) frames_free--; } }
        else      { if ( was) { bclr(i); frames_free++; } }
    }
}

void pmm_mark_used(uint32_t phys, uint32_t size){ mark_range(phys,size,1); }
void pmm_mark_free(uint32_t phys, uint32_t size){ mark_range(phys,size,0);  }

uint32_t pmm_total_frames(void){ return frames_total; }
uint32_t pmm_free_frames(void) { return frames_free;  }

void pmm_init_from_mb2(const void* info_ptr) {
    /* pessimistic: mark all used */
    for (uint32_t i=0;i<sizeof(bitmap);++i) bitmap[i]=0xFF;
    frames_free = 0;

    /* walk mb2 safely: base[0]=total_size, base[1]=reserved(0), then tags */
    const uint8_t* base = (const uint8_t*)info_ptr;
    const uint32_t total_size = *(const uint32_t*)(base + 0);
    const uint8_t* p   = base + 8;
    const uint8_t* end = base + total_size;

    while (p + sizeof(struct mb2_tag) <= end) {
        const struct mb2_tag* tag = (const struct mb2_tag*)p;
        if (tag->type == MB2_TAG_END) break;
        if (p + tag->size > end) break;

        if (tag->type == MB2_TAG_MMAP) {
            const struct mb2_tag_mmap* mm = (const struct mb2_tag_mmap*)tag;
            const uint8_t* q  = (const uint8_t*)(mm + 1);
            const uint8_t* qe = p + mm->size;

            while (q + mm->entry_size <= qe) {
                const struct mb2_mmap_entry* me = (const struct mb2_mmap_entry*)q;
                if (me->type == 1) { /* usable RAM */
                    uint64_t base64 = me->addr;
                    uint64_t len64  = me->len;
                    if (base64 < PMM_MAX_BYTES) {
                        uint64_t room = PMM_MAX_BYTES - base64;
                        uint64_t use  = (len64 < room) ? len64 : room;
                        if (use) pmm_mark_free((uint32_t)base64, (uint32_t)use);
                    }
                }
                q += mm->entry_size;
            }
        }

        uintptr_t next = ((uintptr_t)p + tag->size + 7u) & ~((uintptr_t)7u);
        p = (const uint8_t*)next;
    }

    /* ---- Reserve regions we must not hand out ---- */

    /* 1) Low 1 MiB (BIOS/GRUB/legacy real-mode area) */
    pmm_mark_used(0, 0x100000);

    /* 2) Kernel image (text+rodata+data+bss), page-aligned */
    uint32_t k_start = ((uint32_t)(uintptr_t)&_kernel_start) & ~0xFFFu;
    uint32_t k_end   = ((uint32_t)(uintptr_t)&_kernel_end   + 0xFFFu) & ~0xFFFu;
    if (k_end > k_start) pmm_mark_used(k_start, k_end - k_start);

    /* 3) PMM bitmap itself (it lives inside kernel .bss) */
    uint32_t bm_phys  = (uint32_t)(uintptr_t)bitmap;
    uint32_t bm_size  = sizeof(bitmap);
    pmm_mark_used(bm_phys & ~0xFFFu, ((bm_phys & 0xFFFu) + bm_size + 0xFFFu) & ~0xFFFu);
}


/* Very basic first-fit allocator */
uint32_t pmm_alloc(void) {
    for (uint32_t i=0; i<PMM_MAX_FRAMES; ++i) {
        if (!bget(i)) { bset(i); if (frames_free) frames_free--; return i * PMM_PAGE_SIZE; }
    }
    return 0;
}

void pmm_free(uint32_t phys) {
    uint32_t i = phys / PMM_PAGE_SIZE;
    if (i < PMM_MAX_FRAMES && bget(i)) { bclr(i); frames_free++; }
}
