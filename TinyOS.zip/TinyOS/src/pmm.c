/*=============================================================================
 *  pmm.c — TinyOS Physical Memory Manager (Bitmap Allocator)
 *=============================================================================
 *
 * PURPOSE:
 *   This file implements a physical memory manager (PMM) that tracks which
 *   4 KiB frames of RAM are free or in use. It uses a bitmap to efficiently
 *   represent the allocation state of each frame, and provides functions to
 *   allocate and free frames for use by the kernel and paging system.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - i386 (32-bit x86)
 *   - Frame size: 4096 bytes (4 KiB) — standard page size
 *   - Maximum addressable memory: 128 MiB (configurable)
 *   - Bitmap representation: 1 bit per frame
 *
 * PHYSICAL MEMORY MANAGEMENT BASICS:
 *   Physical memory is divided into fixed-size blocks called "frames" or
 *   "page frames". In x86 paging, the standard frame size is 4 KiB (4096 bytes).
 *   
 *   The PMM's job is to:
 *     1. Know which frames are usable (from bootloader memory map)
 *     2. Track which frames are allocated vs. free
 *     3. Provide an allocator: pmm_alloc() returns a free frame
 *     4. Provide a deallocator: pmm_free() returns a frame to the pool
 *
 * WHY BITMAP:
 *   A bitmap is the most memory-efficient way to track frame states:
 *     - 1 bit per frame: 0 = free, 1 = used
 *     - For 128 MiB RAM: 32,768 frames = 4,096 bytes of bitmap
 *     - Compare to free list: 8 bytes per node = 262,144 bytes minimum
 *   
 *   Tradeoff: Allocation is O(n) (scan for free bit), but for early boot
 *   and simple kernels, this is acceptable and extremely simple.
 *
 * MEMORY MAP STRUCTURE:
 *   The bootloader (GRUB via Multiboot2) provides a memory map describing
 *   all physical memory regions and their types:
 *   
 *   Type 1 (Usable):    Available RAM for OS use
 *   Type 2 (Reserved):  Hardware-reserved (BIOS, memory-mapped devices)
 *   Type 3 (ACPI):      ACPI reclaimable memory
 *   Type 4 (NVS):       ACPI non-volatile storage
 *   Type 5 (Bad):       Defective RAM (marked by POST)
 *   
 *   Example memory map from QEMU:
 *     0x00000000-0x0009FFFF  Type 1 (Usable)  — 640 KiB
 *     0x000A0000-0x000FFFFF  Type 2 (Reserved) — VGA buffer, BIOS ROM
 *     0x00100000-0x07FFFFFF  Type 1 (Usable)  — 127 MiB
 *
 * INITIALIZATION STRATEGY:
 *   1. Mark ALL frames as used (pessimistic start)
 *   2. Walk Multiboot2 memory map, mark usable regions as free
 *   3. Reserve special regions:
 *      a. Low 1 MiB (BIOS data, real-mode IVT, VGA buffer)
 *      b. Kernel image (_kernel_start to _kernel_end)
 *      c. PMM bitmap itself (lives in kernel .bss)
 *   4. Result: Safe allocator that never hands out reserved memory
 *
 * BITMAP REPRESENTATION:
 *   Array of uint8_t, each byte stores 8 frame states:
 *   
 *   Example: bitmap[0] = 0b10110100
 *     Frame 0 (bit 0): 0 = free
 *     Frame 1 (bit 1): 0 = free
 *     Frame 2 (bit 2): 1 = used
 *     Frame 3 (bit 3): 0 = free
 *     Frame 4 (bit 4): 1 = used
 *     Frame 5 (bit 5): 1 = used
 *     Frame 6 (bit 6): 0 = free
 *     Frame 7 (bit 7): 1 = used
 *   
 *   To access frame i:
 *     Byte index: i / 8 (or i >> 3)
 *     Bit index:  i % 8 (or i & 7)
 *
 * ALLOCATION ALGORITHM:
 *   pmm_alloc() uses first-fit strategy:
 *     - Scan bitmap from frame 0 to end
 *     - Find first frame with bit = 0 (free)
 *     - Set bit = 1 (mark used)
 *     - Return physical address (frame_number × 4096)
 *   
 *   Complexity: O(n) worst case (all frames used)
 *   Trade-off: Simple, no fragmentation tracking needed
 *
 * MEMORY OVERHEAD:
 *   For 128 MiB RAM (32,768 frames):
 *     - Bitmap size: 4,096 bytes (4 KiB) — 1 page
 *     - Overhead: 0.003% of total memory
 *     - Extremely efficient!
 *
 * LIMITATIONS:
 *   - Fixed maximum memory (128 MiB in current config)
 *   - No memory region priorities (first-fit always)
 *   - No defragmentation (not needed for physical frames)
 *   - Single-threaded (no locking for SMP)
 *   - No buddy allocator (future: reduce external fragmentation)
 *
 * MULTIBOOT2 INTEGRATION:
 *   GRUB loads the kernel and passes a pointer to a Multiboot2 info structure.
 *   This structure contains tags describing the system:
 *     - Memory map (MMAP tag, type 6)
 *     - Boot command line
 *     - Framebuffer info
 *     - Module locations
 *   
 *   We parse only the MMAP tag to initialize the PMM.
 *
 * DESIGN DECISIONS:
 *   - Pessimistic initialization: Safer than optimistic (prevents handing
 *     out reserved memory due to parsing bugs)
 *   - Page-aligned reservations: Align kernel/bitmap to 4 KiB boundaries
 *   - Low 1 MiB reserved: Protects legacy BIOS structures and VGA buffer
 *   - Static bitmap: Simple, no dynamic allocation needed at boot
 *
 * THREAD SAFETY:
 *   NOT thread-safe. No locks on bitmap or counters.
 *   Future: Add spinlock for SMP safety in pmm_alloc() / pmm_free().
 *
 * PERFORMANCE:
 *   Allocation: O(n) — scans up to 32,768 bits
 *   Deallocation: O(1) — direct bit clear
 *   Memory overhead: 4 KiB bitmap + 8 bytes counters
 *   Adequate for early boot and simple kernels
 *
 * FUTURE ENHANCEMENTS:
 *   - Buddy allocator: Reduce external fragmentation
 *   - Free list: O(1) allocation for common case
 *   - NUMA support: Per-node allocators
 *   - Hot/cold pages: Prioritize recently freed frames (cache-friendly)
 *   - Statistics: Track fragmentation, allocation patterns
 *   - Thread safety: Spinlocks for SMP
 *   - Large pages: Support 2 MiB / 4 MiB frames for efficiency
 *
 *============================================================================*/

#include "kernel.h"
#include "pmm.h"

/*=============================================================================
 * PHYSICAL MEMORY CONFIGURATION
 *=============================================================================
 * DESCRIPTION:
 *   Defines the maximum addressable physical memory and frame count.
 *   These are compile-time constants that determine bitmap size.
 *
 * PMM_MAX_BYTES: Maximum physical memory to manage
 *   Current: 128 MiB (0x08000000)
 *   Why: Keeps bitmap small (4 KiB), adequate for early boot
 *   Future: Could be 4 GiB (32-bit limit), but bitmap would be 128 KiB
 *
 * PMM_MAX_FRAMES: Number of 4 KiB frames in PMM_MAX_BYTES
 *   Calculation: 128 MiB / 4 KiB = 32,768 frames
 *   This is the array size for our bitmap (in bits)
 *
 * FRAME SIZE:
 *   Always 4096 bytes (4 KiB) — standard x86 page size
 *   Defined in pmm.h as PMM_PAGE_SIZE
 *
 * MEMORY LAYOUT EXAMPLE (128 MiB):
 *   Frame 0:     0x00000000-0x00000FFF (first 4 KiB)
 *   Frame 1:     0x00001000-0x00001FFF (second 4 KiB)
 *   ...
 *   Frame 32767: 0x07FFF000-0x07FFFFFF (last 4 KiB)
 *
 * WHY 128 MiB LIMIT:
 *   - Small bitmap (4 KiB = 1 page)
 *   - Enough for early kernel development
 *   - Easy to increase later (change PMM_MAX_BYTES)
 *   - Real systems have GiB of RAM, but TinyOS is educational
 *
 * BITMAP SIZE CALCULATION:
 *   Frames: 32,768
 *   Bits per frame: 1
 *   Total bits: 32,768
 *   Bytes needed: 32,768 / 8 = 4,096 bytes (4 KiB)
 *
 * INCREASING MAX MEMORY:
 *   To support 4 GiB (full 32-bit address space):
 *     PMM_MAX_BYTES = (4u * 1024u * 1024u * 1024u)  // 4 GiB
 *     PMM_MAX_FRAMES = (1048576)                    // 1M frames
 *     Bitmap size: 131,072 bytes (128 KiB)
 *   
 *   Trade-off: Larger bitmap, slower allocation scan
 *============================================================================*/
#define PMM_MAX_BYTES   (128u * 1024u * 1024u)      /* 128 MiB */
#define PMM_MAX_FRAMES  (PMM_MAX_BYTES / PMM_PAGE_SIZE)  /* 32,768 frames */

/*=============================================================================
 * BITMAP STORAGE
 *=============================================================================
 * DESCRIPTION:
 *   The bitmap array that tracks allocation state of all frames.
 *   Each bit represents one 4 KiB frame: 0 = free, 1 = used.
 *
 * TYPE: static uint8_t[]
 *   - static: File scope, not visible outside pmm.c
 *   - uint8_t: Single-byte elements (8 bits each)
 *   - Array size: PMM_MAX_FRAMES / 8 = 4,096 bytes
 *
 * ATTRIBUTE: __attribute__((aligned(4096)))
 *   Forces alignment to 4 KiB (page) boundary.
 *   Why: Easier to reserve in PMM (whole pages), may help cache performance.
 *
 * MEMORY LOCATION:
 *   This array lives in the kernel's .bss section (uninitialized data).
 *   The .bss is zeroed by boot.s before kernel_main() runs.
 *   Linker places .bss after .data, aligned to page boundary.
 *
 * INITIALIZATION:
 *   - Boot loader zeros .bss → bitmap starts as all 0s (all frames "free")
 *   - pmm_init_from_mb2() sets all to 0xFF (all "used")
 *   - Then marks usable regions as free (clear bits)
 *   
 *   This pessimistic approach ensures we never accidentally allocate
 *   reserved or non-existent memory.
 *
 * ACCESS PATTERN:
 *   Never accessed directly outside helper functions (bset/bclr/bget).
 *   All bit manipulation goes through inline functions for safety.
 *
 * CACHE CONSIDERATIONS:
 *   - Bitmap is 4 KiB = fits in 64 cache lines (64-byte lines)
 *   - Sequential scan has good spatial locality
 *   - First-fit allocation benefits from cache warmth
 *
 * EXAMPLE BITMAP STATE (first 16 frames):
 *   bitmap[0] = 0b11111111  // Frames 0-7 all used (low memory reserved)
 *   bitmap[1] = 0b11111111  // Frames 8-15 all used (still low memory)
 *   bitmap[2] = 0b00000000  // Frames 16-23 all free (usable RAM)
 *   bitmap[3] = 0b10000001  // Frames 24,31 used; 25-30 free
 *============================================================================*/
static uint8_t bitmap[PMM_MAX_FRAMES / 8] __attribute__((aligned(4096)));

/*=============================================================================
 * FRAME COUNTERS
 *=============================================================================
 * DESCRIPTION:
 *   Global counters tracking total and free frame counts.
 *   Used for statistics and allocation failure detection.
 *
 * frames_total: Total manageable frames (constant after init)
 *   Value: PMM_MAX_FRAMES = 32,768
 *   Never changes after pmm_init_from_mb2()
 *   Represents the size of our physical memory window
 *
 * frames_free: Currently available (unallocated) frames
 *   Changes on every pmm_alloc() / pmm_free() call
 *   Decremented on allocation, incremented on free
 *   Used to detect out-of-memory condition (frames_free == 0)
 *
 * INITIALIZATION:
 *   frames_total: Set to PMM_MAX_FRAMES (constant)
 *   frames_free:  Set to 0 at start (all marked used)
 *                 Incremented as usable regions marked free
 *                 Final value after init: ~31,000 frames (depends on memory map)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. No atomic operations on these counters.
 *   Concurrent alloc/free from multiple CPUs would corrupt these values.
 *   Future: Use atomic_add / atomic_sub for SMP safety.
 *
 * USAGE:
 *   Query via: pmm_total_frames() and pmm_free_frames()
 *   Display during boot: "PMM: 32768 total, 31744 free"
 *
 * TYPICAL VALUES (after init):
 *   Total: 32,768 frames (128 MiB)
 *   Free:  ~31,000 frames (~121 MiB usable)
 *   Used:  ~1,700 frames (~7 MiB reserved for kernel, BIOS, etc.)
 *
 * OUT-OF-MEMORY DETECTION:
 *   pmm_alloc() returns 0 when frames_free reaches 0
 *   Caller must check return value before using address
 *============================================================================*/
static uint32_t frames_total = PMM_MAX_FRAMES;  /* Total frames (constant) */
static uint32_t frames_free  = 0;               /* Free frames (dynamic) */

/*=============================================================================
 * KERNEL BOUNDARIES (from linker script)
 *=============================================================================
 * DESCRIPTION:
 *   External symbols provided by the linker script (linker.ld) marking
 *   the start and end of the kernel image in physical memory.
 *
 * _kernel_start: First byte of kernel (start of .text section)
 * _kernel_end:   Last byte of kernel (end of .bss section)
 *
 * LINKER SCRIPT SYMBOLS:
 *   These are NOT variables — they are symbols representing addresses.
 *   Taking their address (&_kernel_start) gives the actual memory location.
 *
 * TYPICAL VALUES:
 *   _kernel_start: 0x00100000 (1 MiB) — where GRUB loads the kernel
 *   _kernel_end:   0x0010XXXX (depends on kernel size, usually ~64-128 KiB later)
 *
 * USAGE:
 *   Get kernel start address: (uint32_t)(uintptr_t)&_kernel_start
 *   Get kernel end address:   (uint32_t)(uintptr_t)&_kernel_end
 *
 * WHY RESERVE KERNEL:
 *   The kernel code and data are loaded into RAM by GRUB.
 *   If we don't mark this memory as "used", pmm_alloc() could return
 *   a frame inside the kernel, causing catastrophic overwrites!
 *
 * SECTIONS INCLUDED:
 *   .text:     Executable code
 *   .rodata:   Read-only data (string literals, const data)
 *   .data:     Initialized global/static variables
 *   .bss:      Uninitialized global/static variables (zeroed at boot)
 *
 * PAGE ALIGNMENT:
 *   pmm_mark_used() rounds kernel_start DOWN and kernel_end UP to page
 *   boundaries (4 KiB). This ensures whole pages are reserved, not just
 *   the exact byte range (which would be unsafe for paging).
 *
 * EXAMPLE:
 *   kernel_start = 0x00100008  (not page-aligned)
 *   kernel_end   = 0x0010A034  (not page-aligned)
 *   
 *   After alignment:
 *   start = 0x00100000  (rounded down)
 *   end   = 0x0010B000  (rounded up)
 *   
 *   Entire range 0x00100000-0x0010B000 marked as used (45 frames)
 *============================================================================*/
extern uint8_t _kernel_start;   /* First byte of kernel (from linker) */
extern uint8_t _kernel_end;     /* Last byte of kernel (from linker) */

/*=============================================================================
 * BITMAP MANIPULATION HELPERS
 *=============================================================================
 * DESCRIPTION:
 *   Inline functions for setting, clearing, and reading individual bits
 *   in the bitmap. These provide safe, efficient access to frame states.
 *
 * WHY INLINE:
 *   These are called frequently (every alloc/free/mark operation).
 *   Inlining eliminates function call overhead (saves ~10 cycles per call).
 *   Compiler can optimize bit operations into single instructions.
 *
 * BIT INDEXING SCHEME:
 *   Frame index i maps to:
 *     Byte: bitmap[i / 8]  or  bitmap[i >> 3]  (divide by 8)
 *     Bit:  (i % 8)        or  (i & 7)         (modulo 8)
 *   
 *   Example: Frame 19
 *     Byte: 19 / 8 = 2  (bitmap[2])
 *     Bit:  19 % 8 = 3  (bit 3 within that byte)
 *   
 *   Visual:
 *     bitmap[2] = 0bXXXXXXXX
 *                         ^
 *                         bit 3 (frame 19)
 *
 * WHY SHIFT/MASK INSTEAD OF DIV/MOD:
 *   Modern compilers optimize / and % for powers of 2, but explicit
 *   shifts make intent clear and guarantee single-instruction code:
 *     i >> 3  compiles to  SHR eax, 3  (1 cycle)
 *     i & 7   compiles to  AND eax, 7  (1 cycle)
 *
 * RETURN VALUES:
 *   bset: void (no return)
 *   bclr: void (no return)
 *   bget: int (0 if free, non-zero if used)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Concurrent set/clear on same frame can race:
 *     CPU0: Read byte → modify → write back
 *     CPU1: Read byte → modify → write back
 *     Result: One update lost!
 *   
 *   Future: Use atomic OR/AND operations or locks.
 *============================================================================*/

/*-----------------------------------------------------------------------------
 * FUNCTION: bset
 *-----------------------------------------------------------------------------
 * DESCRIPTION:
 *   Sets bit i in the bitmap to 1, marking frame i as USED.
 *
 * PARAMETERS:
 *   i - Frame index (0 to PMM_MAX_FRAMES-1)
 *
 * RETURNS:
 *   void
 *
 * OPERATION:
 *   1. Calculate byte index: i >> 3  (divide by 8)
 *   2. Calculate bit index:  i & 7   (modulo 8)
 *   3. Create bit mask:      1 << (i & 7)
 *   4. OR mask into byte:    bitmap[i>>3] |= mask
 *
 * BITWISE EXPLANATION:
 *   To set bit 3 in a byte (mark frame 19 used):
 *     mask = 1 << 3 = 0b00001000
 *     bitmap[2] |= 0b00001000
 *   
 *   Before: bitmap[2] = 0b11010101
 *   After:  bitmap[2] = 0b11011101  (bit 3 now set)
 *
 * WHY OR (|=):
 *   OR preserves other bits while setting target bit.
 *   If bit already set, OR has no effect (idempotent).
 *
 * SAFETY:
 *   No bounds checking. Caller must ensure i < PMM_MAX_FRAMES.
 *   Out-of-bounds access causes undefined behavior (buffer overflow).
 *
 * PERFORMANCE:
 *   3 instructions: shift, and, or
 *   ~3 CPU cycles
 *
 * EXAMPLE:
 *   bset(0);      // Mark frame 0 (first 4 KiB) as used
 *   bset(32767);  // Mark frame 32767 (last 4 KiB in 128 MiB) as used
 *---------------------------------------------------------------------------*/
static inline void bset(uint32_t i) {
    bitmap[i >> 3] |= (1u << (i & 7));
}

/*-----------------------------------------------------------------------------
 * FUNCTION: bclr
 *-----------------------------------------------------------------------------
 * DESCRIPTION:
 *   Clears bit i in the bitmap to 0, marking frame i as FREE.
 *
 * PARAMETERS:
 *   i - Frame index (0 to PMM_MAX_FRAMES-1)
 *
 * RETURNS:
 *   void
 *
 * OPERATION:
 *   1. Calculate byte index: i >> 3
 *   2. Calculate bit index:  i & 7
 *   3. Create bit mask:      1 << (i & 7)
 *   4. Invert mask:          ~mask
 *   5. AND inverted mask:    bitmap[i>>3] &= ~mask
 *
 * BITWISE EXPLANATION:
 *   To clear bit 3 (mark frame 19 free):
 *     mask     = 1 << 3       = 0b00001000
 *     ~mask    = ~0b00001000  = 0b11110111
 *     bitmap[2] &= 0b11110111
 *   
 *   Before: bitmap[2] = 0b11011101
 *   After:  bitmap[2] = 0b11010101  (bit 3 now clear)
 *
 * WHY AND with ~mask:
 *   AND with inverted mask clears target bit, preserves others.
 *   If bit already clear, AND has no effect (idempotent).
 *
 * SAFETY:
 *   No bounds checking. Caller must ensure i < PMM_MAX_FRAMES.
 *
 * PERFORMANCE:
 *   4 instructions: shift, and, not, and
 *   ~4 CPU cycles
 *
 * EXAMPLE:
 *   bclr(256);    // Mark frame 256 (1 MiB) as free
 *   bclr(1024);   // Mark frame 1024 (4 MiB) as free
 *---------------------------------------------------------------------------*/
static inline void bclr(uint32_t i) {
    bitmap[i >> 3] &= ~(1u << (i & 7));
}

/*-----------------------------------------------------------------------------
 * FUNCTION: bget
 *-----------------------------------------------------------------------------
 * DESCRIPTION:
 *   Reads bit i from the bitmap, returning its state (0=free, 1=used).
 *
 * PARAMETERS:
 *   i - Frame index (0 to PMM_MAX_FRAMES-1)
 *
 * RETURNS:
 *   int: 0 if frame is free, non-zero (specifically 1) if used
 *
 * OPERATION:
 *   1. Read byte: bitmap[i >> 3]
 *   2. Shift right to bring target bit to LSB: >> (i & 7)
 *   3. Mask LSB: & 1
 *   4. Return result (0 or 1)
 *
 * BITWISE EXPLANATION:
 *   To get bit 3 from byte (check frame 19):
 *     bitmap[2] = 0b11010101
 *     Step 1: Read 0b11010101
 *     Step 2: Shift right 3: 0b11010101 >> 3 = 0b00011010
 *     Step 3: Mask LSB: 0b00011010 & 1 = 0
 *   
 *   Result: Frame 19 is free (bit was 0)
 *
 * RETURN VALUE:
 *   Technically returns 0 or 1 (single bit value).
 *   In C, 0 = false, non-zero = true.
 *   
 *   Usage:
 *     if (bget(i)) - frame is used
 *     if (!bget(i)) - frame is free
 *
 * PERFORMANCE:
 *   3 instructions: shift, shift, and
 *   ~3 CPU cycles
 *
 * SAFETY:
 *   No bounds checking. Caller must ensure i < PMM_MAX_FRAMES.
 *
 * EXAMPLE:
 *   Check if frame 512 is free:
 *     if (!bget(512)) - Frame 512 (2 MiB) is free, can allocate
 *---------------------------------------------------------------------------*/
static inline int bget(uint32_t i) {
    return (bitmap[i >> 3] >> (i & 7)) & 1;
}

/*=============================================================================
 * FUNCTION: mark_range
 *=============================================================================
 * DESCRIPTION:
 *   Marks a range of physical memory as used or free in the bitmap.
 *   This is the core function for reserving/freeing memory regions.
 *   Used during initialization and by pmm_mark_used/pmm_mark_free wrappers.
 *
 * PARAMETERS:
 *   phys - Starting physical address of the range (byte address)
 *          Need not be page-aligned (function handles alignment)
 *   
 *   size - Size of the range in bytes
 *          Need not be page-aligned (function handles alignment)
 *   
 *   used - Boolean: 1 = mark as used, 0 = mark as free
 *
 * RETURNS:
 *   void
 *
 * ALGORITHM:
 *   1. Convert physical address to frame index (divide by 4096)
 *   2. Calculate end frame (round up to cover partial pages)
 *   3. Clamp end frame to PMM_MAX_FRAMES (stay within bitmap)
 *   4. For each frame in range:
 *      a. Check current state (used or free)
 *      b. If changing state, update bit and adjust frames_free counter
 *
 * ALIGNMENT HANDLING:
 *   Input addresses need not be page-aligned. The function automatically:
 *     - Rounds start DOWN to frame boundary (phys / 4096)
 *     - Rounds end UP to frame boundary ((phys+size+4095) / 4096)
 *   
 *   Example: phys=0x1008, size=0x2000
 *     start frame = 0x1008 / 0x1000 = 1 (covers partial frame 1)
 *     end frame = (0x1008 + 0x2000 + 0xFFF) / 0x1000 = 4
 *     Frames 1, 2, 3 are affected (3 frames total)
 *
 * ROUNDING TRICK:
 *   To round up division: (x + divisor - 1) / divisor
 *   Example: Round 0x3008 up to next 4 KiB:
 *     (0x3008 + 0xFFF) / 0x1000 = 0x4007 / 0x1000 = 4
 *     Result: Frame 4 (address 0x4000)
 *
 * COUNTER UPDATES:
 *   frames_free is adjusted only when state actually changes:
 *     - Marking free → used: Decrement frames_free (if not underflow)
 *     - Marking used → free: Increment frames_free
 *     - No state change: Counter unchanged (idempotent)
 *
 * IDEMPOTENCY:
 *   Safe to call multiple times with same range:
 *     mark_range(0x1000, 0x1000, 1);  // Mark used
 *     mark_range(0x1000, 0x1000, 1);  // No-op (already used)
 *   
 *   Counter remains consistent because we check current state first.
 *
 * BOUNDARY CLAMPING:
 *   If range extends beyond PMM_MAX_FRAMES, end is clamped:
 *     if (end > PMM_MAX_FRAMES) end = PMM_MAX_FRAMES;
 *   
 *   This prevents bitmap overflow and silently ignores out-of-range memory.
 *   Useful when bootloader reports more RAM than we can manage (>128 MiB).
 *
 * PERFORMANCE:
 *   O(n) where n = number of frames in range
 *   For small ranges (kernel, bitmap): ~10-100 frames = fast
 *   For large ranges (mark all RAM free): ~32,000 frames = slower
 *   
 *   Typical cost: ~10 cycles per frame = 320K cycles for full scan
 *   On 1 GHz CPU: ~0.3 milliseconds (acceptable during boot)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. No locking on bitmap or counter updates.
 *   Concurrent calls can corrupt bitmap and counters.
 *
 * USAGE EXAMPLES:
 *   // Reserve low 1 MiB for BIOS
 *   mark_range(0x00000000, 0x00100000, 1);
 *   
 *   // Free a 2 MiB region starting at 4 MiB
 *   mark_range(0x00400000, 0x00200000, 0);
 *   
 *   // Reserve single page at 16 MiB
 *   mark_range(0x01000000, 0x1000, 1);
 *
 * EDGE CASES:
 *   - size=0: No frames affected (start==end)
 *   - phys >= PMM_MAX_BYTES: No frames affected (start >= max)
 *   - Overlapping ranges: Last call wins (no merging/tracking)
 *============================================================================*/
static void mark_range(uint32_t phys, uint32_t size, int used) {
    /*=========================================================================
     * STEP 1: Convert byte address to frame index
     *=========================================================================
     * Physical address → Frame number
     * Frame 0 = 0x00000000-0x00000FFF
     * Frame 1 = 0x00001000-0x00001FFF
     * ...
     * 
     * Division by 4096 (0x1000) gives frame number.
     * Integer division automatically rounds down.
     *=======================================================================*/
    uint32_t start = phys / PMM_PAGE_SIZE;
    
    /*=========================================================================
     * STEP 2: Calculate end frame (inclusive range)
     *=========================================================================
     * Add size to phys, round up to next frame boundary, convert to frame.
     * 
     * Formula: ((phys + size + 4095) / 4096)
     * The +4095 ensures we round UP to cover partial last page.
     * 
     * Example: phys=0x1008, size=0x2000
     *   end = (0x1008 + 0x2000 + 0xFFF) / 0x1000
     *       = (0x3007 + 0xFFF) / 0x1000
     *       = 0x4006 / 0x1000
     *       = 4
     *   
     *   Covers frames 1, 2, 3 (frame 4 is the upper bound, exclusive)
     *=======================================================================*/
    uint32_t end = (phys + size + PMM_PAGE_SIZE - 1) / PMM_PAGE_SIZE;
    
    /*=========================================================================
     * STEP 3: Clamp end to maximum frame count
     *=========================================================================
     * If bootloader reports more memory than we can manage, silently ignore
     * the excess. This prevents bitmap overflow.
     * 
     * Example: Bootloader reports 256 MiB, but PMM_MAX_BYTES = 128 MiB
     *   Frames 0-32767 are managed (128 MiB)
     *   Frames 32768+ are ignored (can't track in bitmap)
     *=======================================================================*/
    if (end > PMM_MAX_FRAMES) end = PMM_MAX_FRAMES;
    
    /*=========================================================================
     * STEP 4: Update bitmap and counter for each frame
     *=========================================================================
     * Iterate through all frames in the range [start, end).
     * For each frame:
     *   1. Check current state (was_used = bget(i))
     *   2. If marking used and wasn't used: set bit, decrement counter
     *   3. If marking free and was used: clear bit, increment counter
     *   4. If no state change: skip (idempotent)
     *=======================================================================*/
    for (uint32_t i = start; i < end; ++i) {
        /*---------------------------------------------------------------------
         * Read current state of this frame
         *---------------------------------------------------------------------
         * was = 1 if frame currently marked used
         * was = 0 if frame currently marked free
         *-------------------------------------------------------------------*/
        int was = bget(i);
        
        if (used) {
            /*-----------------------------------------------------------------
             * Marking frame as USED
             *-----------------------------------------------------------------
             * Only update if frame was previously free (!was).
             * If already used, no-op (idempotent).
             *---------------------------------------------------------------*/
            if (!was) {
                bset(i);                    /* Set bit to 1 */
                if (frames_free) 
                    frames_free--;          /* Decrease free count */
            }
        } else {
            /*-----------------------------------------------------------------
             * Marking frame as FREE
             *-----------------------------------------------------------------
             * Only update if frame was previously used (was).
             * If already free, no-op (idempotent).
             *---------------------------------------------------------------*/
            if (was) {
                bclr(i);                    /* Clear bit to 0 */
                frames_free++;              /* Increase free count */
            }
        }
    }
    
    /*=========================================================================
     * POST-CONDITIONS:
     *   - All frames in [start, end) have correct bitmap state
     *   - frames_free counter accurately reflects free frame count
     *   - Function is idempotent (safe to call multiple times)
     *=========================================================================*/
}

/*=============================================================================
 * FUNCTION: pmm_mark_used
 *=============================================================================
 * DESCRIPTION:
 *   Public wrapper that marks a physical memory range as USED (allocated).
 *   Reserves the range so pmm_alloc() won't return frames from it.
 *
 * PARAMETERS:
 *   phys - Starting physical address (need not be page-aligned)
 *   size - Size in bytes (need not be page-aligned)
 *
 * RETURNS:
 *   void
 *
 * USAGE:
 *   Called during initialization to reserve critical regions:
 *     - Low 1 MiB (BIOS data structures)
 *     - Kernel image (code, data, bss)
 *     - Memory-mapped devices (VGA buffer, etc.)
 *
 * EXAMPLES:
 *   pmm_mark_used(0, 0x100000);              // Reserve low 1 MiB
 *   pmm_mark_used(0x100000, 0x50000);        // Reserve 320 KiB at 1 MiB
 *   pmm_mark_used((uint32_t)&bitmap, 4096);  // Reserve PMM bitmap
 *============================================================================*/
void pmm_mark_used(uint32_t phys, uint32_t size) {
    mark_range(phys, size, 1);  /* 1 = mark as used */
}

/*=============================================================================
 * FUNCTION: pmm_mark_free
 *=============================================================================
 * DESCRIPTION:
 *   Public wrapper that marks a physical memory range as FREE (available).
 *   Makes the range available for allocation by pmm_alloc().
 *
 * PARAMETERS:
 *   phys - Starting physical address (need not be page-aligned)
 *   size - Size in bytes (need not be page-aligned)
 *
 * RETURNS:
 *   void
 *
 * USAGE:
 *   Called during initialization to mark usable RAM regions.
 *   Bootloader provides memory map with usable regions (Type 1).
 *   We mark these as free so they can be allocated.
 *
 * EXAMPLES:
 *   pmm_mark_free(0x100000, 0x7F00000);  // Free 127 MiB at 1 MiB
 *============================================================================*/
void pmm_mark_free(uint32_t phys, uint32_t size) {
    mark_range(phys, size, 0);  /* 0 = mark as free */
}

/*=============================================================================
 * FUNCTION: pmm_total_frames
 *=============================================================================
 * DESCRIPTION:
 *   Returns the total number of manageable frames (constant after init).
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   uint32_t: Total frame count (always PMM_MAX_FRAMES = 32768)
 *
 * USAGE:
 *   Display during boot: "PMM: %u total frames\n"
 *   Calculate total memory: total_frames * 4096 bytes
 *============================================================================*/
uint32_t pmm_total_frames(void) {
    return frames_total;
}

/*=============================================================================
 * FUNCTION: pmm_free_frames
 *=============================================================================
 * DESCRIPTION:
 *   Returns the current number of free (unallocated) frames.
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   uint32_t: Current free frame count (changes with alloc/free)
 *
 * USAGE:
 *   Check available memory: "PMM: %u free frames\n"
 *   Detect low memory: if (pmm_free_frames() < 100) panic("OOM");
 *   Calculate free memory: free_frames * 4096 bytes
 *
 * TYPICAL VALUE:
 *   After init: ~31,000 frames (~121 MiB) for 128 MiB system
 *============================================================================*/
uint32_t pmm_free_frames(void) {
    return frames_free;
}

/*=============================================================================
 * FUNCTION: pmm_init_from_mb2
 *=============================================================================
 * DESCRIPTION:
 *   Initializes the PMM from Multiboot2 information structure.
 *   Parses the memory map, marks usable RAM as free, and reserves
 *   critical regions (BIOS, kernel, bitmap). This is the main initialization
 *   function called once during kernel boot.
 *
 * PARAMETERS:
 *   info_ptr - Pointer to Multiboot2 info structure (provided by bootloader)
 *              This structure contains tags describing system configuration
 *
 * RETURNS:
 *   void
 *
 * ALGORITHM:
 *   PHASE 1: Pessimistic initialization
 *     - Mark ALL frames as used (set all bitmap bits to 1)
 *     - Set frames_free = 0
 *     - Rationale: Safe default, prevents allocating bad memory
 *   
 *   PHASE 2: Parse Multiboot2 memory map
 *     - Walk through Multiboot2 tags
 *     - Find MMAP tag (type 6)
 *     - For each usable region (type 1), call pmm_mark_free()
 *     - Result: Usable RAM is now free in bitmap
 *   
 *   PHASE 3: Reserve critical regions
 *     - Low 1 MiB (BIOS, IVT, VGA buffer)
 *     - Kernel image (_kernel_start to _kernel_end)
 *     - PMM bitmap array
 *     - Result: Safe allocator that never overwrites critical memory
 *
 * MULTIBOOT2 STRUCTURE:
 *   The info structure format:
 *     Offset 0: total_size (uint32_t) — size of entire structure
 *     Offset 4: reserved (uint32_t) — always 0
 *     Offset 8: First tag
 *   
 *   Each tag format:
 *     Offset 0: type (uint32_t) — tag identifier
 *     Offset 4: size (uint32_t) — tag size including header
 *     Offset 8: Data (variable length)
 *   
 *   Tags are 8-byte aligned. To get next tag:
 *     next_ptr = (current_ptr + size + 7) & ~7
 *
 * MEMORY MAP TAG (type 6):
 *   Contains array of memory region entries.
 *   Each entry describes a contiguous physical memory region.
 *   
 *   Entry format (struct mb2_mmap_entry):
 *     uint64_t addr - Base physical address
 *     uint64_t len  - Length in bytes
 *     uint32_t type - Region type (1=usable, 2=reserved, etc.)
 *     uint32_t zero - Reserved (always 0)
 *
 * REGION TYPES:
 *   Type 1: Usable RAM — Safe for OS use
 *   Type 2: Reserved — Hardware reserved (don't touch!)
 *   Type 3: ACPI reclaimable — Can use after parsing ACPI tables
 *   Type 4: ACPI NVS — Don't touch (non-volatile storage)
 *   Type 5: Bad RAM — Defective, marked during POST
 *
 * WHY PESSIMISTIC START:
 *   If memory map parsing fails or is buggy, we don't want to allocate
 *   random memory. Starting with all-used ensures safety:
 *     - Bug in parsing? → All memory stays marked used → allocation fails safely
 *     - Missing regions? → Only explicitly freed memory is allocatable
 *   
 *   Trade-off: If parsing completely fails, no memory available.
 *   But better than corrupting random memory!
 *
 * LOW 1 MiB RESERVATION:
 *   Always reserved, even if memory map says usable. Contains:
 *     0x00000-0x003FF: Real Mode IVT (Interrupt Vector Table)
 *     0x00400-0x004FF: BIOS Data Area
 *     0x00500-0x07BFF: Conventional memory (may be used by bootloader)
 *     0x07C00-0x07DFF: Boot sector (MBR or VBR)
 *     0x07E00-0x9FFFF: Conventional memory
 *     0xA0000-0xBFFFF: VGA framebuffer
 *     0xC0000-0xFFFFF: BIOS ROM
 *   
 *   Some regions might be safe to use, but entire 1 MiB is reserved for
 *   simplicity and safety.
 *
 * KERNEL RESERVATION:
 *   The kernel is loaded at 1 MiB (0x100000) by GRUB.
 *   Size varies (typically 64-256 KiB for TinyOS).
 *   We must not allocate frames inside the kernel image!
 *   
 *   Linker symbols:
 *     _kernel_start: First byte of .text
 *     _kernel_end:   Last byte of .bss
 *   
 *   Reservation: Round start down, end up to page boundaries.
 *
 * BITMAP RESERVATION:
 *   The bitmap array lives in kernel .bss (uninitialized data).
 *   It's 4 KiB, page-aligned.
 *   Must reserve it even though it's inside kernel range (belt & suspenders).
 *
 * 64-BIT ADDRESS HANDLING:
 *   Memory map uses 64-bit addresses (uint64_t).
 *   PMM is 32-bit (can only manage up to 4 GiB).
 *   We ignore regions above PMM_MAX_BYTES (128 MiB).
 *   
 *   Clamping:
 *     if (base64 >= PMM_MAX_BYTES) skip region
 *     if (base64 + len64 > PMM_MAX_BYTES) truncate len64
 *
 * SAFETY CHECKS:
 *   - Bounds check tags: Ensure tag doesn't exceed total_size
 *   - Bounds check entries: Ensure entry doesn't exceed tag size
 *   - Type check: Only process type 1 (usable) regions
 *   - 64-bit overflow: Clamp regions to 32-bit addressable space
 *
 * PERFORMANCE:
 *   Runs once during boot.
 *   Typical time: ~1-2 milliseconds (depends on memory map size).
 *   Not performance-critical.
 *
 * THREAD SAFETY:
 *   Called once during single-threaded kernel init.
 *   Not designed for concurrent access (no locking).
 *
 * FAILURE MODES:
 *   - Malformed Multiboot2 structure: Parsing stops at first error
 *   - No MMAP tag: All memory stays marked used (safe failure)
 *   - Zero usable regions: frames_free remains 0, alloc fails
 *
 * EXAMPLE MEMORY MAP (QEMU):
 *   Entry 0: addr=0x00000000 len=0x0009FC00 type=1  (639 KiB usable)
 *   Entry 1: addr=0x0009FC00 len=0x00000400 type=2  (1 KiB reserved)
 *   Entry 2: addr=0x000F0000 len=0x00010000 type=2  (64 KiB reserved, BIOS)
 *   Entry 3: addr=0x00100000 len=0x07F00000 type=1  (127 MiB usable)
 *
 * DEBUGGING:
 *   To verify PMM init:
 *     1. Check total_frames matches PMM_MAX_FRAMES
 *     2. Check free_frames is reasonable (~90% of total)
 *     3. Allocate frame, verify it's in expected range
 *     4. Free frame, verify free count increases
 *============================================================================*/
void pmm_init_from_mb2(const void* info_ptr) {
    /*=========================================================================
     * PHASE 1: PESSIMISTIC INITIALIZATION
     *=========================================================================
     * GOAL: Start with all memory marked as used (safe default)
     *
     * OPERATION:
     *   Set every byte in bitmap to 0xFF (all bits = 1 = used).
     *   This marks all 32,768 frames as allocated/reserved.
     *
     * WHY:
     *   If memory map parsing fails, we don't want to accidentally allocate
     *   non-existent or reserved memory. Starting used is safe.
     *
     * LOOP:
     *   Iterate through all bytes in bitmap (4096 bytes).
     *   Set each byte to 0xFF = 0b11111111 (all 8 frames marked used).
     *=======================================================================*/
    for (uint32_t i = 0; i < sizeof(bitmap); ++i) {
        bitmap[i] = 0xFF;  /* Mark all frames as used */
    }
    frames_free = 0;       /* No free frames yet */
    
    /*=========================================================================
     * PHASE 2: PARSE MULTIBOOT2 MEMORY MAP
     *=========================================================================
     * GOAL: Find usable RAM regions and mark them as free
     *
     * MULTIBOOT2 STRUCTURE:
     *   base[0..3]:   total_size (uint32_t)
     *   base[4..7]:   reserved (uint32_t, always 0)
     *   base[8..]:    Tags (variable length, 8-byte aligned)
     *
     * TAG ITERATION:
     *   Start at base+8 (first tag).
     *   Read tag type and size.
     *   If type == 0 (END tag), stop.
     *   If type == 6 (MMAP tag), parse memory map entries.
     *   Advance to next tag: (ptr + size + 7) & ~7 (8-byte align).
     *=======================================================================*/
    const uint8_t* base = (const uint8_t*)info_ptr;
    const uint32_t total_size = *(const uint32_t*)(base + 0);
    const uint8_t* p   = base + 8;    /* Skip total_size and reserved */
    const uint8_t* end = base + total_size;
    
    /*-------------------------------------------------------------------------
     * Walk through all tags until END tag or bounds exceeded
     *-----------------------------------------------------------------------*/
    while (p + sizeof(struct mb2_tag) <= end) {
        const struct mb2_tag* tag = (const struct mb2_tag*)p;
        
        /*---------------------------------------------------------------------
         * Check for END tag (type 0)
         *-------------------------------------------------------------------*/
        if (tag->type == MB2_TAG_END) break;
        
        /*---------------------------------------------------------------------
         * Bounds check: Ensure tag doesn't exceed total_size
         *-------------------------------------------------------------------*/
        if (p + tag->size > end) break;
        
        /*---------------------------------------------------------------------
         * Process MMAP tag (type 6) — Memory Map
         *-------------------------------------------------------------------*/
        if (tag->type == MB2_TAG_MMAP) {
            const struct mb2_tag_mmap* mm = (const struct mb2_tag_mmap*)tag;
            const uint8_t* q  = (const uint8_t*)(mm + 1);  /* First entry */
            const uint8_t* qe = p + mm->size;              /* End of tag */
            
            /*-----------------------------------------------------------------
             * Iterate through memory map entries
             *-----------------------------------------------------------------
             * Each entry is mm->entry_size bytes (typically 24 bytes).
             * Contains: base address, length, type, reserved.
             *---------------------------------------------------------------*/
            while (q + mm->entry_size <= qe) {
                const struct mb2_mmap_entry* me = (const struct mb2_mmap_entry*)q;
                
                /*-------------------------------------------------------------
                 * Check if region is usable (type 1)
                 *-----------------------------------------------------------*/
                if (me->type == 1) {
                    /* Usable RAM */
                    uint64_t base64 = me->addr;
                    uint64_t len64  = me->len;
                    
                    /*---------------------------------------------------------
                     * Clamp to 32-bit addressable space (PMM_MAX_BYTES)
                     *---------------------------------------------------------
                     * We can only manage up to 128 MiB (PMM_MAX_BYTES).
                     * Ignore regions starting above this limit.
                     * Truncate regions extending beyond this limit.
                     *-------------------------------------------------------*/
                    if (base64 < PMM_MAX_BYTES) {
                        /* Calculate how much room left before PMM_MAX_BYTES */
                        uint64_t room = PMM_MAX_BYTES - base64;
                        
                        /* Use min(region length, remaining room) */
                        uint64_t use = (len64 < room) ? len64 : room;
                        
                        /* Mark this region as free (cast to 32-bit addresses) */
                        if (use) {
                            pmm_mark_free((uint32_t)base64, (uint32_t)use);
                        }
                    }
                }
                
                /* Advance to next entry */
                q += mm->entry_size;
            }
        }
        
        /*---------------------------------------------------------------------
         * Advance to next tag (8-byte aligned)
         *---------------------------------------------------------------------
         * Formula: (ptr + size + 7) & ~7
         * The +7 and &~7 rounds up to next 8-byte boundary.
         *-------------------------------------------------------------------*/
        uintptr_t next = ((uintptr_t)p + tag->size + 7u) & ~((uintptr_t)7u);
        p = (const uint8_t*)next;
    }
    
    /*=========================================================================
     * PHASE 3: RESERVE CRITICAL REGIONS
     *=========================================================================
     * GOAL: Prevent allocator from handing out reserved memory
     *
     * We must mark as used:
     *   1. Low 1 MiB (BIOS, IVT, VGA buffer)
     *   2. Kernel image (code, data, bss)
     *   3. PMM bitmap array
     *=======================================================================*/
    
    /*-------------------------------------------------------------------------
     * RESERVATION 1: Low 1 MiB
     *-------------------------------------------------------------------------
     * Reserve address range 0x00000000-0x000FFFFF (first 256 frames).
     * Contains BIOS data structures, real mode IVT, and VGA buffer.
     * Always reserved regardless of memory map.
     *-----------------------------------------------------------------------*/
    pmm_mark_used(0, 0x100000);  /* 0 to 1 MiB */
    
    /*-------------------------------------------------------------------------
     * RESERVATION 2: Kernel image
     *-------------------------------------------------------------------------
     * Reserve the memory occupied by kernel code and data.
     * Linker provides symbols marking start and end of kernel.
     * Round down start, round up end to page boundaries.
     *
     * ALIGNMENT:
     *   start: & ~0xFFF (round down to page boundary)
     *   end:   + 0xFFF, then & ~0xFFF (round up to page boundary)
     *
     * EXAMPLE:
     *   _kernel_start = 0x00100008
     *   _kernel_end   = 0x0010A034
     *   
     *   k_start = 0x00100008 & ~0xFFF = 0x00100000
     *   k_end   = (0x0010A034 + 0xFFF) & ~0xFFF = 0x0010B000
     *   
     *   Reserved: 0x00100000-0x0010B000 (44 KiB, 11 frames)
     *-----------------------------------------------------------------------*/
    uint32_t k_start = ((uint32_t)(uintptr_t)&_kernel_start) & ~0xFFFu;
    uint32_t k_end   = ((uint32_t)(uintptr_t)&_kernel_end   + 0xFFFu) & ~0xFFFu;
    if (k_end > k_start) {
        pmm_mark_used(k_start, k_end - k_start);
    }
    
    /*-------------------------------------------------------------------------
     * RESERVATION 3: PMM bitmap
     *-------------------------------------------------------------------------
     * The bitmap array lives in kernel .bss section.
     * Size: 4096 bytes (4 KiB), page-aligned.
     * Reserve it to prevent allocating over our own data structure!
     *
     * NOTE:
     *   Bitmap is inside kernel .bss, so already covered by kernel
     *   reservation above. This is belt-and-suspenders safety.
     *
     * ALIGNMENT:
     *   Base address rounded down to page boundary.
     *   Size rounded up to page boundary.
     *-----------------------------------------------------------------------*/
    uint32_t bm_phys = (uint32_t)(uintptr_t)bitmap;
    uint32_t bm_size = sizeof(bitmap);
    pmm_mark_used(bm_phys & ~0xFFFu, 
                  ((bm_phys & 0xFFFu) + bm_size + 0xFFFu) & ~0xFFFu);
    
    /*=========================================================================
     * POST-INITIALIZATION STATE:
     *   - Bitmap reflects actual memory layout
     *   - frames_free contains accurate count of available frames
     *   - pmm_alloc() can now safely allocate frames
     *   - Reserved memory protected from allocation
     *
     * TYPICAL RESULTS (128 MiB system):
     *   frames_total: 32,768
     *   frames_free:  ~31,000 (varies based on kernel size)
     *   frames_used:  ~1,700 (low 1 MiB + kernel + reserved regions)
     *=========================================================================*/
}

/*=============================================================================
 * FUNCTION: pmm_alloc
 *=============================================================================
 * DESCRIPTION:
 *   Allocates a single 4 KiB frame of physical memory.
 *   Uses first-fit algorithm: scans bitmap for first free frame.
 *   Returns physical address of allocated frame, or 0 on failure.
 *
 * PARAMETERS:
 *   None
 *
 * RETURNS:
 *   uint32_t: Physical address of allocated frame (page-aligned)
 *             Returns 0 if no free frames available (out of memory)
 *
 * ALGORITHM:
 *   1. Scan bitmap from frame 0 to PMM_MAX_FRAMES-1
 *   2. Find first frame with bit = 0 (free)
 *   3. Set bit = 1 (mark as used)
 *   4. Decrement frames_free counter
 *   5. Calculate physical address: frame_number × 4096
 *   6. Return physical address
 *
 * FIRST-FIT STRATEGY:
 *   Always starts scan from frame 0.
 *   Returns first available frame found.
 *   
 *   Advantages:
 *     - Simple to implement
 *     - No fragmentation (all frames identical)
 *     - Predictable behavior
 *   
 *   Disadvantages:
 *     - O(n) worst case (scan all frames if none free)
 *     - No locality optimization (frames scattered)
 *     - Repeatedly allocates low addresses (less cache-friendly)
 *
 * PERFORMANCE:
 *   Best case:  O(1) — first frame is free (1 iteration)
 *   Worst case: O(n) — no frames free (32,768 iterations)
 *   Average:    O(n/2) — scan half the bitmap
 *   
 *   Typical allocation time:
 *     Early boot (many free): ~10-100 iterations = ~100-1000 cycles
 *     Low memory: ~10,000-30,000 iterations = ~100K-300K cycles
 *   
 *   On 1 GHz CPU:
 *     Fast: 0.1-1 microsecond
 *     Slow: 100-300 microseconds
 *
 * RETURN VALUE:
 *   Physical address (uint32_t):
 *     Success: 0x00001000, 0x00002000, etc. (always page-aligned)
 *     Failure: 0x00000000 (NULL, indicates out of memory)
 *   
 *   CRITICAL: Caller MUST check return value!
 *     Example:
 *       uint32_t frame = pmm_alloc();
 *       if (frame == 0) {
 *           Out of memory! Handle error
 *       }
 *
 * OUT-OF-MEMORY CONDITION:
 *   Returns 0 when:
 *     - All frames marked used (frames_free == 0)
 *     - Entire bitmap scan found no free frames
 *   
 *   This is NOT a panic condition (caller handles).
 *   Example: Paging system might fall back to other strategies.
 *
 * ALIGNMENT GUARANTEE:
 *   Returned address is ALWAYS page-aligned (multiple of 4096).
 *   Formula: frame_number * 4096
 *   
 *   Examples:
 *     Frame 0 -> 0x00000000 (0 * 4096)
 *     Frame 1 -> 0x00001000 (1 * 4096)
 *     Frame 256 -> 0x00100000 (256 * 4096 = 1 MiB)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Race conditions possible:
 *     CPU0: Find frame i free -> interrupted
 *     CPU1: Find frame i free -> allocate frame i
 *     CPU0: Resume -> allocate frame i again (double allocation!)
 *   
 *   Result: Two callers get same frame -> memory corruption
 *   Future: Use atomic compare-and-swap or spinlock.
 *
 * USAGE EXAMPLES:
 *   Allocate frame for page table:
 *     uint32_t pt_frame = pmm_alloc();
 *     if (pt_frame == 0) {
 *         kprintf("OOM: Cannot allocate page table\n");
 *         return ERROR;
 *     }
 *   
 *   Allocate frame for DMA buffer:
 *     uint32_t dma_frame = pmm_alloc();
 *     if (dma_frame == 0) {
 *         kprintf("OOM: Cannot allocate DMA buffer\n");
 *         return ERROR;
 *     }
 *
 * OPTIMIZATIONS (future):
 *   - Bitmap hints: Remember last allocated frame, start scan there
 *   - Free list: Maintain list of free frames (O(1) allocation)
 *   - Buddy allocator: Reduce fragmentation, faster coalescing
 *   - Per-CPU pools: Reduce contention in SMP systems
 *============================================================================*/
uint32_t pmm_alloc(void) {
    /*=========================================================================
     * Scan bitmap for first free frame
     *=========================================================================
     * Iterate through all frames from 0 to PMM_MAX_FRAMES-1.
     * Check each frame's bit in the bitmap.
     * First frame with bit=0 (free) is allocated.
     *=======================================================================*/
    for (uint32_t i = 0; i < PMM_MAX_FRAMES; ++i) {
        /*---------------------------------------------------------------------
         * Check if this frame is free
         *---------------------------------------------------------------------
         * bget(i) returns 0 if frame i is free, non-zero if used.
         * Invert with ! to get: true if free, false if used.
         *-------------------------------------------------------------------*/
        if (!bget(i)) {
            /*-----------------------------------------------------------------
             * Frame is free — allocate it
             *-----------------------------------------------------------------
             * 1. Set bit to 1 (mark as used)
             * 2. Decrement free counter (if not already zero, safety check)
             * 3. Calculate physical address
             * 4. Return address
             *---------------------------------------------------------------*/
            bset(i);                        /* Mark frame as used */
            
            if (frames_free) 
                frames_free--;              /* Decrement free count */
            
            /*-----------------------------------------------------------------
             * Convert frame index to physical address
             *-----------------------------------------------------------------
             * Each frame is 4096 bytes (PMM_PAGE_SIZE).
             * Frame 0 → 0x00000000
             * Frame 1 → 0x00001000
             * Frame i → i × 4096
             *---------------------------------------------------------------*/
            return i * PMM_PAGE_SIZE;
        }
    }
    
    /*=========================================================================
     * No free frames found — out of memory
     *=========================================================================
     * Scanned entire bitmap without finding a free frame.
     * Return 0 to indicate allocation failure.
     * 
     * Caller MUST check for 0 and handle error appropriately.
     *=======================================================================*/
    return 0;
}

/*=============================================================================
 * FUNCTION: pmm_free
 *=============================================================================
 * DESCRIPTION:
 *   Frees a previously allocated 4 KiB frame, returning it to the pool.
 *   Marks the frame as free in the bitmap so it can be allocated again.
 *
 * PARAMETERS:
 *   phys - Physical address of frame to free (must be page-aligned)
 *          Should be an address returned by pmm_alloc()
 *
 * RETURNS:
 *   void
 *
 * ALGORITHM:
 *   1. Convert physical address to frame index (divide by 4096)
 *   2. Validate frame index (0 ≤ i < PMM_MAX_FRAMES)
 *   3. Check if frame is currently used (bit = 1)
 *   4. If used: Clear bit (mark as free), increment frames_free
 *   5. If already free: No-op (idempotent)
 *
 * SAFETY CHECKS:
 *   - Bounds check: Ensure frame index within valid range
 *   - State check: Only free frames currently marked used
 *   - Idempotent: Safe to call multiple times (won't double-free)
 *
 * DOUBLE-FREE PROTECTION:
 *   Freeing an already-free frame is safe (no-op):
 *     pmm_free(0x1000);  // Free frame 1
 *     pmm_free(0x1000);  // No-op (already free)
 *   
 *   Counter remains consistent because we check current state first.
 *
 * ALIGNMENT REQUIREMENT:
 *   Physical address MUST be page-aligned (multiple of 4096).
 *   If address is not aligned, behavior is undefined:
 *     - May free wrong frame
 *     - May corrupt bitmap
 *   
 *   Caller's responsibility to pass valid addresses.
 *
 * INVALID ADDRESS HANDLING:
 *   Out-of-bounds addresses are silently ignored:
 *     pmm_free(0xFFFFFFFF);  // Frame 1048575, beyond PMM_MAX_FRAMES → no-op
 *     pmm_free(0);           // Frame 0, usually reserved → would free if not
 *   
 *   No panic or error indication. Caller should track allocations carefully.
 *
 * PERFORMANCE:
 *   O(1) — constant time operation
 *   ~10 CPU cycles (bounds check + bit clear + counter increment)
 *   Much faster than allocation (no scanning required)
 *
 * THREAD SAFETY:
 *   NOT thread-safe. Race conditions possible:
 *     CPU0: Free frame i (read bit) → interrupted
 *     CPU1: Allocate frame i
 *     CPU0: Resume → clear bit (frame i now free, but CPU1 using it!)
 *   
 *   Result: Frame used by two callers simultaneously → corruption
 *   Future: Use atomic operations or spinlocks.
 *
 * MEMORY LEAKS:
 *   Forgetting to free frames causes memory leaks:
 *     uint32_t frame = pmm_alloc();
 *     // Use frame...
 *     // Oops, forgot to call pmm_free(frame)!
 *   
 *   Frame stays marked used forever (until kernel reboot).
 *   With only 32K frames, leaks quickly exhaust memory.
 *
 * USAGE EXAMPLES:
 *   // Allocate and free a page table
 *   uint32_t pt_frame = pmm_alloc();
 *   if (pt_frame) {
 *       // Use page table...
 *       pmm_free(pt_frame);  // Done, return to pool
 *   }
 *   
 *   // Free DMA buffer
 *   pmm_free(dma_buffer_addr);
 *
 * TYPICAL USE WITH PAGING:
 *   // Map a page
 *   uint32_t frame = pmm_alloc();
 *   paging_map_page(virtual_addr, frame, flags);
 *   
 *   // Later: Unmap and free
 *   paging_unmap_page(virtual_addr);
 *   pmm_free(frame);
 *
 * VALIDATION (debug builds):
 *   In production, consider adding assertions:
 *     assert(phys % PMM_PAGE_SIZE == 0);  // Verify alignment
 *     assert(phys < PMM_MAX_BYTES);       // Verify bounds
 *============================================================================*/
void pmm_free(uint32_t phys) {
    /*=========================================================================
     * Convert physical address to frame index
     *=========================================================================
     * Divide address by frame size (4096) to get frame number.
     * Example: 0x00001000 / 0x1000 = 1 (frame 1)
     *=======================================================================*/
    uint32_t i = phys / PMM_PAGE_SIZE;
    
    /*=========================================================================
     * Validate and free frame
     *=========================================================================
     * Check two conditions before freeing:
     *   1. Frame index in valid range (i < PMM_MAX_FRAMES)
     *   2. Frame is currently used (bget(i) != 0)
     * 
     * If both true: Clear bit and increment counter.
     * Otherwise: No-op (silently ignore invalid/already-free frames).
     *=======================================================================*/
    if (i < PMM_MAX_FRAMES && bget(i)) {
        bclr(i);            /* Clear bit (mark as free) */
        frames_free++;      /* Increment free count */
    }
    
    /*=========================================================================
     * POST-CONDITIONS:
     *   - If frame was valid and used: Now free, available for reallocation
     *   - If frame was invalid or already free: No state change
     *   - frames_free accurately reflects free frame count
     *=========================================================================*/
}

/*=============================================================================
 * PMM SUMMARY AND FUTURE DIRECTIONS
 *=============================================================================
 *
 * CURRENT IMPLEMENTATION:
 *   - Bitmap allocator: 1 bit per frame (4 KiB overhead for 128 MiB)
 *   - First-fit allocation: Simple but O(n) worst case
 *   - Multiboot2 integration: Parses memory map at boot
 *   - Safe reservations: Protects kernel, BIOS, and internal structures
 *   - Basic counters: Total and free frame tracking
 *
 * STRENGTHS:
 *   ✅ Simple and easy to understand
 *   ✅ Minimal memory overhead (0.003% of RAM)
 *   ✅ Safe initialization (pessimistic approach)
 *   ✅ Idempotent operations (safe to call multiple times)
 *   ✅ No external fragmentation (all frames identical)
 *
 * LIMITATIONS:
 *   ❌ O(n) allocation (slow when many frames used)
 *   ❌ Not thread-safe (no SMP support)
 *   ❌ Fixed maximum memory (128 MiB)
 *   ❌ No allocation hints (always starts from frame 0)
 *   ❌ No NUMA awareness (single global pool)
 *   ❌ No large page support (only 4 KiB frames)
 *
 * PERFORMANCE CHARACTERISTICS:
 *   Allocation: O(n) worst case, O(1) best case
 *   Deallocation: O(1) always
 *   Memory overhead: 4 KiB bitmap + 8 bytes counters
 *   Initialization: O(n) — scans memory map and sets all bits
 *
 * FUTURE ENHANCEMENTS:
 *
 *   1. FREE LIST (O(1) Allocation):
 *      Maintain linked list of free frames.
 *      Allocation: Pop from list (O(1))
 *      Deallocation: Push to list (O(1))
 *      Trade-off: More memory overhead, more complex
 *
 *   2. BUDDY ALLOCATOR:
 *      Allocate power-of-2 blocks (4K, 8K, 16K, etc.)
 *      Fast allocation and coalescing
 *      Reduces external fragmentation
 *      Used by Linux kernel
 *
 *   3. SLAB ALLOCATOR (on top of PMM):
 *      Cache frequently used objects (page tables, process descriptors)
 *      Reduces allocation overhead
 *      Better cache performance
 *      Also used by Linux kernel
 *
 *   4. THREAD SAFETY (SMP Support):
 *      Add spinlock to protect bitmap and counters
 *      Or: Per-CPU pools with fallback to global pool
 *      Atomic operations for counters
 *
 *   5. ALLOCATION HINTS:
 *      Remember last allocated frame, start scan there
 *      Reduces average scan time
 *      Better cache locality (recently freed frames)
 *
 *   6. MEMORY ZONES:
 *      Separate pools for different memory types:
 *        - DMA zone (low 16 MiB for ISA DMA)
 *        - Normal zone (16 MiB - 896 MiB)
 *        - High memory (above 896 MiB on 32-bit)
 *      Allows prioritizing allocations
 *
 *   7. LARGE PAGE SUPPORT:
 *      Support 2 MiB / 4 MiB pages (PSE)
 *      Reduces TLB pressure
 *      Better for large mappings (kernel image, framebuffer)
 *
 *   8. STATISTICS AND DEBUGGING:
 *      Track allocation patterns
 *      Detect leaks (frames never freed)
 *      Fragmentation metrics
 *      Per-module accounting
 *
 * TYPICAL USAGE PATTERN:
 *   // Boot time
 *   pmm_init_from_mb2(multiboot_info);  // Parse memory map
 *   
 *   // Later: Allocate for paging
 *   uint32_t frame = pmm_alloc();       // Get frame
 *   if (frame == 0) panic("OOM");
 *   paging_map_page(virt_addr, frame);  // Use frame
 *   
 *   // Eventually: Free when done
 *   paging_unmap_page(virt_addr);
 *   pmm_free(frame);                    // Return to pool
 *
 * MEMORY MAP RESOURCES:
 *   - Intel Software Developer Manual, Vol. 3A, Chapter 3
 *   - Multiboot2 Specification (GNU GRUB documentation)
 *   - OSDev Wiki: Memory Management, Physical Memory Manager
 *   - Linux kernel: mm/page_alloc.c (buddy allocator reference)
 *
 *=============================================================================
 * END OF FILE: pmm.c
 *============================================================================*/
