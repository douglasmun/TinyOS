/*=============================================================================
 *  pit.c — Ultra-safe PIT driver with memory barriers
 *============================================================================*/
#include "kernel.h"
#include "pit.h"

static inline void safe_outb(uint16_t port, uint8_t value) {
    __asm__ volatile(
        "outb %0, %1\n\t"
        "jmp 1f\n\t"
        "1: jmp 1f\n\t"
        "1: nop"
        : 
        : "a"(value), "Nd"(port)
        : "memory"
    );
}

void pit_init(uint32_t hz) {
    if (hz == 0 || hz > 1000) {
        hz = 100;
    }
    
    uint32_t divisor = 1193182u / hz;
    if (divisor > 0xFFFF) divisor = 0xFFFF;
    if (divisor < 1) divisor = 1;
    
    uint8_t low = (uint8_t)(divisor & 0xFF);
    uint8_t high = (uint8_t)((divisor >> 8) & 0xFF);
    
    /* Disable interrupts during programming */
    __asm__ volatile("cli" ::: "memory");
    
    /* Mode 2, binary, lobyte/hibyte */
    safe_outb(0x43, 0x34);
    safe_outb(0x40, low);
    safe_outb(0x40, high);
    
    /* Memory barrier */
    __asm__ volatile("" ::: "memory");
}

void pit_on_tick(void) {
    /* Do nothing */
}

uint32_t pit_get_ticks(void) {
    return 0;
}
