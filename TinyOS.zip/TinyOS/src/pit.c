/*=============================================================================
 *  pit.c — Programmable Interval Timer Driver for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file implements a driver for the Intel 8253/8254 Programmable
 *   Interval Timer (PIT). The PIT generates periodic timer interrupts,
 *   providing the heartbeat of the operating system for scheduling,
 *   timekeeping, and delays.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Chip: Intel 8253/8254 (or compatible)
 *   - Channel: Channel 0 (system timer, IRQ 0)
 *   - Mode: Mode 2 (rate generator)
 *   - Frequency: Configurable (typically 100-1000 Hz)
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is the PIT?
 * 2. Why Operating Systems Need Timers
 * 3. The 8253/8254 Hardware
 * 4. PIT Channels and Modes
 * 5. The Base Frequency (1.193182 MHz)
 * 6. Frequency Calculation and Divisors
 * 7. Programming the PIT
 * 8. Timer Interrupts (IRQ 0)
 * 9. Tick Counting and Timekeeping
 * 10. Choosing the Right Frequency
 * 11. Design Decisions and Trade-offs
 * 12. Common Pitfalls and Solutions
 * 13. Modern Timer Alternatives
 * 14. Integration with the Kernel
 *
 *=============================================================================
 * SECTION 1: WHAT IS THE PIT?
 *=============================================================================
 * 
 * PIT = Programmable Interval Timer
 * 
 * THE PROBLEM:
 * 
 * Operating systems need a reliable source of periodic interrupts:
 *   - Task scheduling (switch between processes)
 *   - Timekeeping (track seconds, minutes, hours)
 *   - Timeouts (network, I/O operations)
 *   - Delays (sleep, wait functions)
 *   - Profiling (measure CPU usage)
 * 
 * Without a timer:
 *   ❌ Can't implement preemptive multitasking
 *   ❌ Can't track time (no clock!)
 *   ❌ Can't implement sleep() or timeouts
 *   ❌ System would be "frozen" in current task
 * 
 * SOLUTION: THE PIT
 * 
 * The PIT is a hardware chip that:
 *   1. Counts down from a programmed value to zero
 *   2. Generates an interrupt when it reaches zero (IRQ 0)
 *   3. Automatically reloads and continues counting
 *   4. Creates a steady, periodic interrupt "heartbeat"
 * 
 * ANALOGY:
 * 
 * Think of the PIT like a metronome or clock:
 *   - Musicians use metronomes to keep steady rhythm
 *   - PIT provides steady "tick" for the OS
 *   - Each tick: OS can do housekeeping (schedule, update time)
 *   - Frequency: How many ticks per second
 * 
 * HISTORICAL CONTEXT:
 * 
 * The 8253 was introduced by Intel in 1981 for the original IBM PC.
 * Updated to 8254 in 1985 (improved version, backwards compatible).
 * Still present in modern systems (though often emulated by chipset).
 * 
 * MODERN ALTERNATIVES:
 * 
 * Modern systems have better timers:
 *   - APIC Timer (part of Advanced PIC)
 *   - HPET (High Precision Event Timer)
 *   - TSC (Time Stamp Counter)
 *   - ACPI PM Timer
 * 
 * But PIT is still used because:
 *   ✅ Always present (guaranteed availability)
 *   ✅ Simple to program
 *   ✅ Well-documented
 *   ✅ Sufficient for basic OS timing needs
 *
 *=============================================================================
 * SECTION 2: WHY OPERATING SYSTEMS NEED TIMERS
 *=============================================================================
 * 
 * PREEMPTIVE MULTITASKING:
 * 
 * Without timer:
 *   Process A runs → Waits for I/O → System blocked
 *   Process B can't run (no way to interrupt A)
 *   
 * With timer:
 *   Process A runs → Timer interrupt fires → Scheduler runs
 *   Scheduler: "A's time is up, switch to B"
 *   Process B runs → Timer fires → Switch back to A
 *   Result: Both processes make progress!
 * 
 * Typical time slice: 10-100 milliseconds per process
 * 
 * TIMEKEEPING:
 * 
 * Track wall-clock time:
 *   - Count timer ticks since boot
 *   - Convert ticks to seconds, minutes, hours
 *   - Implement time() system call
 * 
 * Example (100 Hz timer):
 *   100 ticks = 1 second
 *   6000 ticks = 1 minute
 *   360000 ticks = 1 hour
 * 
 * TIMEOUTS:
 * 
 * Network operations:
 *   - Send packet, wait for response
 *   - If no response in 5 seconds, retry or fail
 *   - Timer interrupt checks elapsed time
 * 
 * I/O operations:
 *   - Read from disk, wait for data
 *   - If disk doesn't respond in 30 seconds, error
 *   - Timer interrupt tracks timeout
 * 
 * DELAYS:
 * 
 * sleep() function:
 *   sleep(5);  // Sleep for 5 seconds
 *   
 *   Implementation:
 *     desired_wake = current_ticks + (5 * ticks_per_second)
 *     while (current_ticks < desired_wake) {
 *         // Wait (scheduler runs other processes)
 *     }
 * 
 * PROFILING:
 * 
 * CPU usage tracking:
 *   - Timer interrupt fires
 *   - OS checks: Which process is running?
 *   - Increment that process's CPU time counter
 *   - Result: Can measure "Process A used 23% CPU"
 * 
 * WATCHDOG TIMERS:
 * 
 * Detect hung processes:
 *   - Process should respond to timer
 *   - If no response in N seconds, kill it
 *   - Prevents one process from hanging entire system
 * 
 * ANIMATION AND GAMES:
 * 
 * Game loop:
 *   - Update game state every frame
 *   - Render at 60 FPS = 60 Hz
 *   - Timer ensures consistent frame rate
 * 
 * THE TICK:
 * 
 * Each timer interrupt is called a "tick"
 *   - Tick rate = Timer frequency (e.g., 100 Hz)
 *   - Each tick: OS does housekeeping
 *   - Higher frequency = More responsive (but more overhead)
 *   - Lower frequency = Less overhead (but less responsive)
 *
 *=============================================================================
 * SECTION 3: THE 8253/8254 HARDWARE
 *=============================================================================
 * 
 * CHIP SPECIFICATIONS:
 * 
 * - Manufacturer: Intel (originally), many clones
 * - Part numbers:
 *   * 8253: Original version (1981)
 *   * 8254: Improved version (1985)
 *   * 82C54: CMOS version (low power)
 * - Package: 24-pin DIP (Dual Inline Package)
 * - Power: +5V
 * - Channels: 3 independent 16-bit counters
 * - Maximum count: 65536 (0 means 65536)
 * 
 * THREE CHANNELS:
 * 
 * Channel 0:
 *   - Connected to IRQ 0 (PIC line)
 *   - System timer (used by OS)
 *   - TinyOS uses this channel
 * 
 * Channel 1:
 *   - Originally: DRAM refresh (obsolete)
 *   - Modern: Usually unused or for legacy support
 * 
 * Channel 2:
 *   - PC speaker tone generation
 *   - Can generate beeps and tones
 *   - Connected to speaker circuit
 * 
 * I/O PORTS:
 * 
 * Each channel has its own data port:
 *   - Port 0x40: Channel 0 data (system timer)
 *   - Port 0x41: Channel 1 data (DRAM refresh)
 *   - Port 0x42: Channel 2 data (speaker)
 * 
 * One command port for all channels:
 *   - Port 0x43: Mode/Command register
 * 
 * THE COUNTER:
 * 
 * Each channel has a 16-bit counter:
 *   - Counts down from initial value to 0
 *   - Decrements on each clock pulse
 *   - What happens at 0 depends on mode
 * 
 * Clock input:
 *   - 1.193182 MHz (approximately 1.19 MHz)
 *   - This is the base frequency
 *   - Cannot be changed (fixed by hardware)
 * 
 * Example:
 *   Initial count: 1193182
 *   Clock: 1.193182 MHz
 *   Time to reach 0: 1193182 / 1193182 = 1 second
 *   Interrupt rate: 1 Hz (once per second)
 * 
 * OPERATING MODES:
 * 
 * The PIT supports 6 modes (0-5):
 *   - Mode 0: Interrupt on terminal count
 *   - Mode 1: Hardware retriggerable one-shot
 *   - Mode 2: Rate generator (most common for OS timer)
 *   - Mode 3: Square wave generator
 *   - Mode 4: Software triggered strobe
 *   - Mode 5: Hardware triggered strobe
 * 
 * TinyOS uses Mode 2 (explained in Section 4).
 * 
 * THE BASE FREQUENCY: 1.193182 MHz
 * 
 * Why this odd number?
 * 
 * Historical reason:
 *   - IBM PC used 14.31818 MHz crystal (for color TV compatibility)
 *   - PIT input = Crystal / 12 = 1.193181666... MHz
 *   - Rounded to 1.193182 MHz
 * 
 * Why divide by 12?
 *   - Simple divider circuit (3 flip-flops)
 *   - 12 = 2^2 × 3 (easy to divide in hardware)
 * 
 * This frequency is used worldwide:
 *   - Part of PC standard
 *   - All compatible systems use same frequency
 *   - Modern systems emulate it for compatibility
 *
 *=============================================================================
 * SECTION 4: PIT CHANNELS AND MODES
 *=============================================================================
 * 
 * CHANNEL 0: SYSTEM TIMER
 * 
 * Port: 0x40
 * Output: Connected to IRQ 0 (PIC interrupt line)
 * Use: Operating system timer
 * 
 * Typical configuration:
 *   - Mode 2 (rate generator)
 *   - Frequency: 100-1000 Hz
 *   - Generates periodic interrupts
 * 
 * This is what TinyOS uses!
 * 
 * CHANNEL 1: DRAM REFRESH (OBSOLETE)
 * 
 * Port: 0x41
 * Original use: Trigger DRAM refresh cycles
 * 
 * Why obsolete?
 *   - Old DRAM needed periodic refresh
 *   - Modern DRAM has built-in refresh
 *   - Channel 1 is usually disabled or ignored
 * 
 * CHANNEL 2: PC SPEAKER
 * 
 * Port: 0x42
 * Output: Connected to PC speaker circuit
 * Use: Generate beeps and tones
 * 
 * Typical use:
 *   - Mode 3 (square wave)
 *   - Frequency: 440 Hz (musical note A)
 *   - Can create beeps for alerts
 * 
 * Not used by TinyOS (no sound support yet).
 * 
 * MODE 2: RATE GENERATOR (MOST IMPORTANT)
 * 
 * This is the mode TinyOS uses for the system timer.
 * 
 * How it works:
 *   1. Load counter with initial value (divisor)
 *   2. Counter decrements on each clock pulse
 *   3. When counter reaches 1: Output goes LOW (interrupt fires)
 *   4. Counter automatically reloads to initial value
 *   5. Repeat forever (periodic interrupts)
 * 
 * Timing diagram:
 *   Counter: 5, 4, 3, 2, 1, (reload) 5, 4, 3, 2, 1, (reload) ...
 *   Output:  HIGH  HIGH  HIGH  LOW  HIGH ...
 *   IRQ:                        ↑ Interrupt fires here
 * 
 * Why Mode 2?
 *   ✅ Automatic reload (no reprogramming needed)
 *   ✅ Periodic interrupts (perfect for OS timer)
 *   ✅ Stable frequency (accurate timing)
 *   ✅ Standard mode for system timers
 * 
 * MODE 3: SQUARE WAVE (FOR SPEAKER)
 * 
 * How it works:
 *   - Output toggles HIGH/LOW at half the frequency
 *   - Creates square wave (50% duty cycle)
 *   - Used for PC speaker tone generation
 * 
 * Example:
 *   Divisor: 2000
 *   Base frequency: 1193182 Hz
 *   Output frequency: 1193182 / 2000 = 596.6 Hz
 *   Square wave: 596.6 Hz (musical note D)
 * 
 * NOT used for system timer (use Mode 2 instead).
 * 
 * OTHER MODES (RARELY USED):
 * 
 * Mode 0: Interrupt on terminal count
 *   - One-shot timer (fires once, stops)
 *   - Used for precise delays
 * 
 * Mode 1: Hardware retriggerable one-shot
 *   - Triggered by external gate signal
 *   - Used for measuring pulse widths
 * 
 * Mode 4/5: Strobes
 *   - Single pulse output
 *   - Used for specialized timing applications
 * 
 * TinyOS only uses Mode 2 (simplest and most common).
 *
 *=============================================================================
 * SECTION 5: THE BASE FREQUENCY (1.193182 MHz)
 *=============================================================================
 * 
 * WHAT IS THE BASE FREQUENCY?
 * 
 * The PIT counter decrements at 1.193182 MHz.
 * This is the "clock rate" of the PIT.
 * 
 * It means:
 *   - Counter decrements 1,193,182 times per second
 *   - Each decrement takes 1/1,193,182 second ≈ 0.838 microseconds
 * 
 * WHY 1.193182 MHz?
 * 
 * Historical IBM PC design:
 * 
 * 1. Start with color TV crystal: 14.31818 MHz
 *    (This frequency chosen for NTSC TV compatibility)
 * 
 * 2. Divide by 3: 14.31818 / 3 = 4.77273 MHz
 *    (This became the CPU clock for 8088 processor)
 * 
 * 3. Divide by 4: 4.77273 / 4 = 1.193182 MHz
 *    (This became the PIT clock)
 * 
 * Combined: 14.31818 / 12 = 1.193181666... MHz
 * Rounded: 1.193182 MHz
 * 
 * PRECISE VALUE:
 * 
 * Actual: 1,193,181.666... Hz (repeating decimal)
 * TinyOS uses: 1,193,182 Hz (rounded)
 * 
 * Error: 0.333... Hz (negligible for most purposes)
 * 
 * IMPLICATIONS:
 * 
 * 1. This is FIXED (cannot be changed)
 *    - Hardware limitation
 *    - Same on all PC-compatible systems
 * 
 * 2. Maximum frequency: 1.193182 MHz
 *    - If divisor = 1, interrupt every 0.838 microseconds
 *    - Too fast! CPU would do nothing but handle interrupts
 * 
 * 3. Minimum frequency: 18.2 Hz
 *    - If divisor = 65536 (maximum), interrupt every 54.9 milliseconds
 *    - This was the default on old DOS systems
 * 
 * 4. Desired frequency = Base / Divisor
 *    - Want 100 Hz? Divisor = 1193182 / 100 = 11931.82 ≈ 11932
 *    - Want 1000 Hz? Divisor = 1193182 / 1000 = 1193.182 ≈ 1193
 * 
 * FREQUENCY RANGE:
 * 
 * Practical range: 18 Hz to 596591 Hz
 *   - Minimum divisor: 2 (max 596591 Hz, impractical)
 *   - Maximum divisor: 65536 (min 18.2 Hz)
 * 
 * Recommended range for OS timer: 50-1000 Hz
 *   - 50 Hz: Low overhead, 20 ms resolution
 *   - 100 Hz: Standard (Linux default), 10 ms resolution
 *   - 250 Hz: Desktop systems, 4 ms resolution
 *   - 1000 Hz: Low-latency systems, 1 ms resolution
 * 
 * TinyOS uses 100 Hz (good balance).
 *
 *=============================================================================
 * SECTION 6: FREQUENCY CALCULATION AND DIVISORS
 *=============================================================================
 * 
 * THE FUNDAMENTAL EQUATION:
 * 
 * Desired Frequency (Hz) = Base Frequency / Divisor
 * 
 * Or rearranged:
 * 
 * Divisor = Base Frequency / Desired Frequency
 * 
 * BASE FREQUENCY: 1,193,182 Hz (fixed by hardware)
 * DIVISOR: 16-bit value we program (1 to 65536)
 * DESIRED FREQUENCY: What we want (e.g., 100 Hz)
 * 
 * EXAMPLES:
 * 
 * Example 1: 100 Hz timer (TinyOS default)
 *   Divisor = 1,193,182 / 100 = 11,931.82
 *   Round to: 11,932
 *   Actual frequency: 1,193,182 / 11,932 = 99.9983 Hz
 *   Error: 0.0017 Hz (negligible!)
 * 
 * Example 2: 1000 Hz timer (1 millisecond resolution)
 *   Divisor = 1,193,182 / 1000 = 1,193.182
 *   Round to: 1,193
 *   Actual frequency: 1,193,182 / 1,193 = 1000.152 Hz
 *   Error: 0.152 Hz (0.015% error)
 * 
 * Example 3: 18.2 Hz timer (old DOS default)
 *   Divisor = 65536 (maximum)
 *   Actual frequency: 1,193,182 / 65536 = 18.2065 Hz
 *   Period: 54.925 milliseconds per tick
 * 
 * Example 4: 60 Hz timer (for 60 FPS games)
 *   Divisor = 1,193,182 / 60 = 19,886.37
 *   Round to: 19,886
 *   Actual frequency: 1,193,182 / 19,886 = 59.9992 Hz
 *   Perfect for 60 FPS!
 * 
 * ROUNDING:
 * 
 * Divisor must be an integer (16-bit).
 * 
 * Should we round up or down?
 *   - Round to nearest (standard rounding)
 *   - For most frequencies, error is tiny
 * 
 * Example:
 *   100 Hz: 11931.82 → 11932 (round to nearest)
 *   250 Hz: 4772.728 → 4773 (round to nearest)
 * 
 * LIMITS:
 * 
 * Divisor range: 1 to 65536
 *   - 0 is interpreted as 65536 (special case)
 *   - Cannot be larger than 16 bits
 * 
 * Frequency limits:
 *   - Maximum: 1,193,182 Hz (divisor = 1, impractical)
 *   - Minimum: 18.2 Hz (divisor = 65536)
 * 
 * TinyOS safety check:
 *   if (divisor > 0xFFFF) divisor = 0xFFFF;  // Clamp to maximum
 *   if (divisor < 1) divisor = 1;            // Clamp to minimum
 * 
 * ERROR ANALYSIS:
 * 
 * For integer divisor, actual frequency will differ slightly:
 * 
 * Error (Hz) = Desired - Actual
 * Error (%) = (Error / Desired) × 100
 * 
 * Example (100 Hz):
 *   Desired: 100.0000 Hz
 *   Actual: 99.9983 Hz
 *   Error: 0.0017 Hz (0.0017%)
 * 
 * For most purposes, this error is negligible.
 * Over 1 hour at 100 Hz:
 *   Expected ticks: 360,000
 *   Actual ticks: 359,994
 *   Difference: 6 ticks = 60 milliseconds
 * 
 * For precise timekeeping, use RTC or TSC instead.
 * 
 * FREQUENCY VALIDATION:
 * 
 * TinyOS validates input frequency:
 * 
 * if (hz == 0 || hz > 1000) {
 *     hz = 100;  // Default to 100 Hz
 * }
 * 
 * Why limit to 1000 Hz?
 *   - Higher frequencies waste CPU on interrupt handling
 *   - 1000 Hz = 1 ms resolution (sufficient for most uses)
 *   - Linux desktop default is 250 Hz
 *   - TinyOS default is 100 Hz (lower overhead)
 * 
 * CALCULATING PERIOD:
 * 
 * Period = 1 / Frequency
 * 
 * Examples:
 *   100 Hz: Period = 1/100 = 10 milliseconds per tick
 *   250 Hz: Period = 1/250 = 4 milliseconds per tick
 *   1000 Hz: Period = 1/1000 = 1 millisecond per tick
 * 
 * This is the time between timer interrupts.
 *
 *=============================================================================
 * SECTION 7: PROGRAMMING THE PIT
 *=============================================================================
 * 
 * PROGRAMMING SEQUENCE:
 * 
 * To set the timer frequency:
 *   1. Calculate divisor from desired frequency
 *   2. Disable interrupts (CLI) to prevent race conditions
 *   3. Send command byte to port 0x43
 *   4. Send low byte of divisor to port 0x40
 *   5. Send high byte of divisor to port 0x40
 *   6. Re-enable interrupts (if desired)
 * 
 * COMMAND BYTE FORMAT (PORT 0x43):
 * 
 * Bits 7-6: Channel select
 *   00 = Channel 0 (system timer)
 *   01 = Channel 1 (DRAM refresh)
 *   10 = Channel 2 (PC speaker)
 *   11 = Read-back command (8254 only)
 * 
 * Bits 5-4: Access mode
 *   00 = Latch count value
 *   01 = Low byte only
 *   10 = High byte only
 *   11 = Low byte then high byte
 * 
 * Bits 3-1: Operating mode
 *   000 = Mode 0 (interrupt on terminal count)
 *   001 = Mode 1 (hardware retriggerable one-shot)
 *   X10 = Mode 2 (rate generator) ← TinyOS uses this
 *   X11 = Mode 3 (square wave generator)
 *   100 = Mode 4 (software triggered strobe)
 *   101 = Mode 5 (hardware triggered strobe)
 * 
 * Bit 0: BCD/Binary mode
 *   0 = Binary (16-bit binary counter)
 *   1 = BCD (4-decade BCD counter)
 * 
 * TINYOS COMMAND BYTE: 0x34
 * 
 * Binary: 00110100
 * Breakdown:
 *   Bits 7-6 = 00: Channel 0 (system timer)
 *   Bits 5-4 = 11: Low byte then high byte
 *   Bits 3-1 = 010: Mode 2 (rate generator)
 *   Bit 0 = 0: Binary mode
 * 
 * Why these choices?
 *   - Channel 0: System timer (IRQ 0)
 *   - Low/high byte: Full 16-bit divisor (maximum range)
 *   - Mode 2: Periodic interrupts (automatic reload)
 *   - Binary: Standard mode (not BCD)
 * 
 * SENDING THE DIVISOR:
 * 
 * Divisor is 16-bit, but port is 8-bit.
 * Must send in two parts:
 * 
 * uint16_t divisor = 11932;  // For 100 Hz
 * uint8_t low = divisor & 0xFF;        // Low byte: 0x8C (140)
 * uint8_t high = (divisor >> 8) & 0xFF; // High byte: 0x2E (46)
 * 
 * outb(0x40, low);   // Send low byte first
 * outb(0x40, high);  // Send high byte second
 * 
 * Order matters! Low byte first, then high byte.
 * (This is what "low byte then high byte" access mode means)
 * 
 * COMPLETE EXAMPLE:
 * 
 * // Set timer to 100 Hz
 * uint32_t divisor = 1193182 / 100;  // 11932
 * uint8_t low = divisor & 0xFF;
 * uint8_t high = (divisor >> 8) & 0xFF;
 * 
 * cli();                // Disable interrupts
 * outb(0x43, 0x34);    // Command: Channel 0, Mode 2, Binary
 * outb(0x40, low);     // Send low byte
 * outb(0x40, high);    // Send high byte
 * // Timer is now running at 100 Hz!
 * 
 * TIMING CONSIDERATIONS:
 * 
 * PIT programming is time-sensitive:
 *   - Disable interrupts during programming (CLI)
 *   - Use safe_outb() with delays between writes
 *   - Ensure atomic operation (no interruption)
 * 
 * Why disable interrupts?
 *   - If interrupted between command and data write:
 *   - PIT might be in inconsistent state
 *   - Could cause spurious interrupts or wrong frequency
 * 
 * Why delays?
 *   - Old hardware was slow
 *   - Modern emulators can be slow
 *   - Delays ensure PIT has time to process each byte
 * 
 * READING THE COUNTER:
 * 
 * Can read current counter value (for precise timing):
 * 
 * // Latch counter value
 * outb(0x43, 0x00);  // Latch channel 0
 * 
 * // Read latched value
 * uint8_t low = inb(0x40);
 * uint8_t high = inb(0x40);
 * uint16_t count = (high << 8) | low;
 * 
 * This shows how many counts remain until next interrupt.
 * TinyOS doesn't use this (not needed for basic timer).
 *
 *=============================================================================
 * SECTION 8: TIMER INTERRUPTS (IRQ 0)
 *=============================================================================
 * 
 * HOW TIMER INTERRUPTS WORK:
 * 
 * 1. PIT counter decrements on each clock pulse (1.193182 MHz)
 * 2. When counter reaches 1, PIT output goes LOW
 * 3. PIT output connected to IRQ 0 line on PIC
 * 4. PIC signals CPU: "Interrupt on IRQ 0"
 * 5. CPU looks up vector 0x20 in IDT (after PIC remap)
 * 6. CPU calls interrupt handler
 * 7. Handler increments tick counter
 * 8. Handler sends EOI to PIC
 * 9. Handler returns (IRET)
 * 10. PIT counter reloads and continues (Mode 2 auto-reload)
 * 
 * INTERRUPT HANDLER FLOW:
 * 
 * void timer_interrupt_handler() {
 *     // 1. Increment tick counter
 *     tick_count++;
 *     
 *     // 2. Update time-of-day (if tracking wall clock)
 *     if (tick_count % TICKS_PER_SECOND == 0) {
 *         seconds++;
 *     }
 *     
 *     // 3. Check for timeouts
 *     check_timeouts();
 *     
 *     // 4. Scheduler decision (if preemptive multitasking)
 *     if (need_reschedule()) {
 *         schedule();  // Switch to another process
 *     }
 *     
 *     // 5. Send EOI to PIC
 *     pic_eoi(0);
 *     
 *     // 6. Return (IRET back to interrupted code)
 * }
 * 
 * TINYOS TIMER HANDLER:
 * 
 * Currently simple (in interrupts.c):
 *   - Increment tick counter
 *   - Every 100 ticks (1 second at 100 Hz): Print a dot
 *   - Send EOI
 * 
 * Future enhancements:
 *   - Process scheduling
 *   - Timeout handling
 *   - Profiling
 *   - Watchdog
 * 
 * TICK COUNTER:
 * 
 * Global variable tracking ticks since boot:
 * 
 * volatile uint32_t tick_count = 0;
 * 
 * Why volatile?
 *   - Modified by interrupt handler
 *   - Compiler must not cache value
 *   - Always read from memory
 * 
 * Why 32-bit?
 *   At 1000 Hz: 2^32 ticks = 4,294,967,296 ticks
 *                           = 4,294,967 seconds
 *                           = 49.7 days
 *   
 *   System will overflow after 49 days.
 *   For production: Use 64-bit counter.
 * 
 * INTERRUPT FREQUENCY TRADE-OFFS:
 * 
 * Higher frequency (1000 Hz):
 *   ✅ Better responsiveness (1 ms resolution)
 *   ✅ Smoother multitasking
 *   ✅ More accurate timeouts
 *   ❌ More CPU overhead (1000 interrupts/sec)
 *   ❌ More power consumption
 * 
 * Lower frequency (100 Hz):
 *   ✅ Less CPU overhead (100 interrupts/sec)
 *   ✅ Better for embedded/low-power systems
 *   ❌ Coarser resolution (10 ms)
 *   ❌ Less responsive
 * 
 * Very low frequency (18.2 Hz, old DOS):
 *   ✅ Minimal overhead
 *   ❌ Very coarse (54.9 ms resolution)
 *   ❌ Poor for multitasking
 * 
 * INTERRUPT LATENCY:
 * 
 * Time from interrupt signal to handler execution:
 *   - PIC latency: ~1-2 microseconds
 *   - CPU interrupt acknowledgment: ~10-50 cycles
 *   - Context save (PUSHA): ~50-100 cycles
 *   - Total: ~5-10 microseconds on modern CPU
 * 
 * This is negligible compared to tick period:
 *   At 100 Hz: 10,000 microseconds per tick
 *   Latency: ~10 microseconds (0.1%)
 * 
 * JITTER:
 * 
 * Variation in interrupt timing:
 *   - Ideally: Exactly every 10.00000 ms (100 Hz)
 *   - Reality: 9.99 to 10.01 ms (jitter)
 * 
 * Sources of jitter:
 *   - Interrupt disabled periods (CLI)
 *   - Other interrupt handlers running
 *   - CPU power management
 *   - Cache misses
 * 
 * For most OS tasks, jitter is acceptable.
 * For real-time systems, use HPET or dedicated timer.
 *
 *=============================================================================
 * SECTION 9: TICK COUNTING AND TIMEKEEPING
 *=============================================================================
 * 
 * TICK COUNTER:
 * 
 * The tick counter is a global variable incremented on each timer interrupt.
 * 
 * volatile uint32_t tick_count = 0;
 * 
 * In interrupt handler:
 *   tick_count++;
 * 
 * This tracks "ticks since boot"
 * 
 * CONVERTING TICKS TO TIME:
 * 
 * At 100 Hz:
 *   - 1 tick = 10 milliseconds
 *   - 100 ticks = 1 second
 *   - 6,000 ticks = 1 minute
 *   - 360,000 ticks = 1 hour
 * 
 * Formula:
 *   seconds = tick_count / TICKS_PER_SECOND
 *   milliseconds = (tick_count * 1000) / TICKS_PER_SECOND
 * 
 * Example:
 *   tick_count = 12345
 *   TICKS_PER_SECOND = 100
 *   seconds = 12345 / 100 = 123 seconds = 2 minutes 3 seconds
 * 
 * IMPLEMENTING sleep():
 * 
 * void sleep(uint32_t seconds) {
 *     uint32_t start = tick_count;
 *     uint32_t target = start + (seconds * TICKS_PER_SECOND);
 *     
 *     while (tick_count < target) {
 *         // Wait (could use HLT to save power)
 *         __asm__ volatile("hlt");
 *     }
 * }
 * 
 * IMPLEMENTING sleep_ms():
 * 
 * void sleep_ms(uint32_t milliseconds) {
 *     uint32_t start = tick_count;
 *     uint32_t ticks_to_wait = (milliseconds * TICKS_PER_SECOND) / 1000;
 *     uint32_t target = start + ticks_to_wait;
 *     
 *     while (tick_count < target) {
 *         __asm__ volatile("hlt");
 *     }
 * }
 * 
 * UPTIME CALCULATION:
 * 
 * void get_uptime(uint32_t* hours, uint32_t* minutes, uint32_t* seconds) {
 *     uint32_t total_seconds = tick_count / TICKS_PER_SECOND;
 *     
 *     *hours = total_seconds / 3600;
 *     *minutes = (total_seconds % 3600) / 60;
 *     *seconds = total_seconds % 60;
 * }
 * 
 * Usage:
 *   uint32_t h, m, s;
 *   get_uptime(&h, &m, &s);
 *   kprintf("Uptime: %u:%02u:%02u\n", h, m, s);
 *   // Output: "Uptime: 2:34:56"
 * 
 * TIMEOUT IMPLEMENTATION:
 * 
 * struct timeout {
 *     uint32_t expire_tick;
 *     void (*callback)();
 * };
 * 
 * void set_timeout(struct timeout* t, uint32_t milliseconds, void (*cb)()) {
 *     t->expire_tick = tick_count + (milliseconds * TICKS_PER_SECOND / 1000);
 *     t->callback = cb;
 * }
 * 
 * // In timer interrupt handler:
 * void check_timeouts() {
 *     for (each timeout t) {
 *         if (tick_count >= t->expire_tick) {
 *             t->callback();  // Execute timeout callback
 *         }
 *     }
 * }
 * 
 * OVERFLOW HANDLING:
 * 
 * 32-bit counter overflows after:
 *   At 100 Hz: 2^32 / 100 / 86400 = 497 days
 *   At 1000 Hz: 2^32 / 1000 / 86400 = 49.7 days
 * 
 * Solutions:
 *   1. Use 64-bit counter (overflows after billions of years)
 *   2. Handle wraparound carefully in comparisons
 *   3. Reset counter periodically (loses accuracy)
 * 
 * Wraparound-safe comparison:
 *   int32_t diff = (int32_t)(target - current);
 *   if (diff <= 0) {
 *       // Timeout reached
 *   }
 * 
 * WALL-CLOCK TIME:
 * 
 * PIT tick counter is not a real-time clock:
 *   - Tracks time since boot
 *   - Doesn't know actual date/time
 *   - Resets to 0 on reboot
 * 
 * For real date/time:
 *   - Read RTC (Real-Time Clock) chip at boot
 *   - Use RTC time as base
 *   - Add PIT elapsed time
 *   - Result: Current date/time
 * 
 * Example:
 *   boot_time = read_rtc();  // "2025-01-15 10:30:00"
 *   elapsed = tick_count / TICKS_PER_SECOND;
 *   current_time = boot_time + elapsed;
 *
 *=============================================================================
 * SECTION 10: CHOOSING THE RIGHT FREQUENCY
 *=============================================================================
 * 
 * COMMON FREQUENCIES:
 * 
 * 18.2 Hz (DOS default):
 *   - Divisor: 65536 (maximum)
 *   - Period: 54.925 ms
 *   - Use case: Minimal overhead, legacy systems
 *   - Problem: Too slow for modern multitasking
 * 
 * 50 Hz:
 *   - Period: 20 ms
 *   - Use case: Low-power embedded systems
 *   - Overhead: Minimal
 *   - Latency: Acceptable for non-interactive systems
 * 
 * 100 Hz (TinyOS default, Linux historical):
 *   - Period: 10 ms
 *   - Use case: General-purpose OS, good balance
 *   - Overhead: Low (~0.5% CPU)
 *   - Latency: Good enough for most applications
 * 
 * 250 Hz (Linux desktop default):
 *   - Period: 4 ms
 *   - Use case: Desktop systems, interactive workloads
 *   - Overhead: Moderate (~1% CPU)
 *   - Latency: Very responsive
 * 
 * 1000 Hz (Linux tickless/low-latency):
 *   - Period: 1 ms
 *   - Use case: Low-latency audio, gaming, real-time
 *   - Overhead: Higher (~2-5% CPU)
 *   - Latency: Excellent
 * 
 * FACTORS TO CONSIDER:
 * 
 * 1. CPU Overhead:
 *    Each interrupt costs ~5-10 microseconds
 *    At 100 Hz: 100 × 10 µs = 1 ms per second = 0.1% CPU
 *    At 1000 Hz: 1000 × 10 µs = 10 ms per second = 1% CPU
 *    
 *    For desktop: 1% is acceptable
 *    For embedded: Every % matters
 * 
 * 2. Latency:
 *    Maximum scheduling latency = 1 tick period
 *    At 100 Hz: 10 ms worst case
 *    At 1000 Hz: 1 ms worst case
 *    
 *    For audio (48 kHz): Need <1 ms latency → 1000 Hz
 *    For file server: 10 ms is fine → 100 Hz
 * 
 * 3. Power Consumption:
 *    More interrupts = More wakeups = More power
 *    Critical for laptops and mobile devices
 *    
 *    Modern solution: Dynamic tick (tickless kernel)
 *    Only fire timer when actually needed
 * 
 * 4. Resolution:
 *    Timer resolution = Period
 *    At 100 Hz: 10 ms resolution
 *    At 1000 Hz: 1 ms resolution
 *    
 *    sleep(1) might actually sleep 0-10 ms at 100 Hz
 *    sleep(1) might actually sleep 0-1 ms at 1000 Hz
 * 
 * RECOMMENDATIONS:
 * 
 * Embedded system (battery powered):
 *   → 50-100 Hz
 * 
 * Server (file, web):
 *   → 100-250 Hz
 * 
 * Desktop (general use):
 *   → 250 Hz
 * 
 * Workstation (audio, video):
 *   → 1000 Hz
 * 
 * Real-time system:
 *   → 1000 Hz + dedicated real-time timer (HPET)
 * 
 * Learning OS (TinyOS):
 *   → 100 Hz (good balance, easy to understand)
 * 
 * DYNAMIC TICK (TICKLESS KERNEL):
 * 
 * Modern approach:
 *   - Don't fire timer at fixed rate
 *   - Calculate: When is next event?
 *   - Program timer for that time only
 *   - Result: Fewer interrupts, better power efficiency
 * 
 * Example:
 *   Current time: 1000 ms
 *   Next timeout: 1500 ms (500 ms from now)
 *   No other events scheduled
 *   → Set timer for 500 ms, not 10 ms
 *   → Save 49 interrupts!
 * 
 * Linux uses this (CONFIG_NO_HZ).
 * Not implemented in TinyOS (too complex for learning).
 *
 *=============================================================================
 * SECTION 11: DESIGN DECISIONS AND TRADE-OFFS
 *=============================================================================
 * 
 * DECISION 1: 100 Hz DEFAULT FREQUENCY
 * 
 * TinyOS uses 100 Hz by default.
 * 
 * Alternatives:
 *   - 18.2 Hz: DOS default (too slow)
 *   - 250 Hz: Linux desktop (more overhead)
 *   - 1000 Hz: Low latency (highest overhead)
 * 
 * Why 100 Hz?
 *   ✅ Good balance (not too fast, not too slow)
 *   ✅ 10 ms resolution (adequate for learning OS)
 *   ✅ Low overhead (~0.1% CPU)
 *   ✅ Easy to reason about (100 ticks = 1 second)
 *   ✅ Standard for many systems
 * 
 * User can override:
 *   pit_init(250);  // 250 Hz
 *   pit_init(1000); // 1000 Hz
 * 
 * 
 * DECISION 2: MODE 2 (RATE GENERATOR)
 * 
 * TinyOS uses Mode 2.
 * 
 * Alternatives:
 *   - Mode 0: One-shot (not periodic)
 *   - Mode 3: Square wave (for speaker, not timer)
 * 
 * Why Mode 2?
 *   ✅ Automatic reload (no reprogramming needed)
 *   ✅ Periodic interrupts (OS timer requirement)
 *   ✅ Standard mode for system timers
 *   ✅ Simplest for learning
 * 
 * 
 * DECISION 3: BINARY MODE (NOT BCD)
 * 
 * TinyOS uses binary mode (16-bit counter).
 * 
 * Alternative:
 *   - BCD mode: 4-decade BCD counter (max 9999)
 * 
 * Why binary?
 *   ✅ Full 16-bit range (1 to 65536)
 *   ✅ Simpler arithmetic (no BCD conversion)
 *   ✅ Standard mode
 *   ✅ BCD mode is rarely used
 * 
 * 
 * DECISION 4: FREQUENCY VALIDATION
 * 
 * TinyOS validates input frequency:
 *   if (hz == 0 || hz > 1000) hz = 100;
 * 
 * Alternative:
 *   - Accept any frequency (1 to 1193182 Hz)
 * 
 * Why validate?
 *   ✅ Prevents accidental misconfiguration
 *   ✅ 0 Hz would cause divide by zero
 *   ✅ >1000 Hz wastes CPU unnecessarily
 *   ✅ Safe defaults
 * 
 * 
 * DECISION 5: SAFE_OUTB WITH DELAYS
 * 
 * TinyOS uses safe_outb() with I/O delays.
 * 
 * Alternative:
 *   - Plain outb() without delays
 * 
 * Why safe?
 *   ✅ Works on all hardware (real and virtual)
 *   ✅ Old hardware needs delays
 *   ✅ Emulators (QEMU, VirtualBox) can be slow
 *   ✅ Initialization is one-time (speed doesn't matter)
 * 
 * 
 * DECISION 6: CLI DURING PROGRAMMING
 * 
 * TinyOS disables interrupts while programming PIT:
 *   __asm__ volatile("cli");
 *   // Program PIT
 *   // (interrupts re-enabled by kernel later)
 * 
 * Why?
 *   ✅ Atomic operation (no interruption)
 *   ✅ Prevents race conditions
 *   ✅ Standard practice
 * 
 * Note: TinyOS doesn't re-enable (STI) in pit_init.
 * Kernel enables interrupts after all hardware is ready.
 * 
 * 
 * DECISION 7: 32-BIT TICK COUNTER
 * 
 * TinyOS uses uint32_t for tick counter.
 * 
 * Alternative:
 *   - uint64_t: Never overflows (billions of years)
 * 
 * Why 32-bit?
 *   ✅ Sufficient for learning OS (49 days at 1000 Hz)
 *   ✅ Simpler (no 64-bit math on 32-bit CPU)
 *   ✅ Standard for many embedded systems
 * 
 * For production OS: Use 64-bit.
 * 
 * 
 * DECISION 8: NO COUNTER READBACK
 * 
 * TinyOS doesn't read current counter value.
 * 
 * Could implement:
 *   uint16_t pit_read_count();  // Read current count
 * 
 * Why not?
 *   - Not needed for basic timer
 *   - Adds complexity
 *   - Counter value changes rapidly (hard to use correctly)
 * 
 * For precise sub-tick timing, use TSC instead.
 *
 *=============================================================================
 * SECTION 12: COMMON PITFALLS AND SOLUTIONS
 *=============================================================================
 * 
 * PITFALL 1: DIVIDE BY ZERO
 * 
 * Problem:
 *   pit_init(0);  // 0 Hz!
 *   divisor = 1193182 / 0;  // CRASH!
 * 
 * Solution:
 *   if (hz == 0 || hz > 1000) {
 *       hz = 100;  // Default
 *   }
 * 
 * 
 * PITFALL 2: DIVISOR OVERFLOW
 * 
 * Problem:
 *   pit_init(1);  // 1 Hz, very slow
 *   divisor = 1193182 / 1 = 1193182  // > 65535!
 * 
 * Result:
 *   Divisor truncated to 16 bits
 *   Actual frequency wrong
 * 
 * Solution:
 *   if (divisor > 0xFFFF) divisor = 0xFFFF;
 * 
 * 
 * PITFALL 3: INTERRUPTS NOT ENABLED
 * 
 * Problem:
 *   pit_init(100);
 *   // Forgot to unmask IRQ 0
 *   // Forgot to enable interrupts (STI)
 * 
 * Result:
 *   Timer runs but no interrupts
 *   System appears frozen
 * 
 * Solution:
 *   pit_init(100);
 *   pic_unmask(0);       // Enable IRQ 0
 *   __asm__("sti");      // Enable interrupts
 * 
 * 
 * PITFALL 4: WRONG BYTE ORDER
 * 
 * Problem:
 *   outb(0x40, high);  // High byte first (WRONG!)
 *   outb(0x40, low);   // Low byte second
 * 
 * Result:
 *   Wrong divisor programmed
 *   Wrong frequency
 * 
 * Solution:
 *   outb(0x40, low);   // Low byte first
 *   outb(0x40, high);  // High byte second
 * 
 * 
 * PITFALL 5: FORGOT COMMAND BYTE
 * 
 * Problem:
 *   outb(0x40, low);   // No command byte sent!
 *   outb(0x40, high);
 * 
 * Result:
 *   PIT doesn't know what to do
 *   Timer doesn't work
 * 
 * Solution:
 *   outb(0x43, 0x34);  // Command byte FIRST
 *   outb(0x40, low);
 *   outb(0x40, high);
 * 
 * 
 * PITFALL 6: RACE CONDITION
 * 
 * Problem:
 *   // Interrupt fires here!
 *   outb(0x43, 0x34);
 *   // Interrupt handler runs, reads PIT
 *   outb(0x40, low);
 *   // PIT in inconsistent state!
 * 
 * Solution:
 *   cli();             // Disable interrupts
 *   outb(0x43, 0x34);
 *   outb(0x40, low);
 *   outb(0x40, high);
 *   // sti() called later in kernel
 * 
 * 
 * PITFALL 7: FREQUENCY TOO HIGH
 * 
 * Problem:
 *   pit_init(100000);  // 100 kHz!
 * 
 * Result:
 *   Interrupt every 10 microseconds
 *   CPU does nothing but handle interrupts
 *   System unusable
 * 
 * Solution:
 *   if (hz > 1000) hz = 100;  // Limit to 1000 Hz
 * 
 * 
 * PITFALL 8: TICK COUNTER OVERFLOW
 * 
 * Problem:
 *   uint32_t tick_count;
 *   // After 49 days at 1000 Hz: overflow!
 *   
 *   if (tick_count > target) {
 *       // This breaks when tick_count wraps
 *   }
 * 
 * Solution:
 *   Use signed comparison:
 *   if ((int32_t)(tick_count - target) >= 0) {
 *       // Works even after wraparound
 *   }
 *   
 *   Or use 64-bit counter (preferred).
 * 
 * 
 * PITFALL 9: FORGETTING EOI
 * 
 * Problem:
 *   void timer_handler() {
 *       tick_count++;
 *       // Forgot pic_eoi(0)!
 *   }
 * 
 * Result:
 *   Timer fires once, then stops
 *   PIC thinks IRQ 0 is still in service
 * 
 * Solution:
 *   void timer_handler() {
 *       tick_count++;
 *       pic_eoi(0);  // MUST send EOI!
 *   }
 * 
 * 
 * PITFALL 10: WRONG CHANNEL
 * 
 * Problem:
 *   outb(0x43, 0x74);  // Channel 1 (WRONG!)
 *   outb(0x41, low);   // Port 0x41 (channel 1)
 * 
 * Result:
 *   Programming channel 1 (DRAM refresh)
 *   Channel 0 (system timer) unchanged
 *   No timer interrupts
 * 
 * Solution:
 *   outb(0x43, 0x34);  // Channel 0
 *   outb(0x40, low);   // Port 0x40 (channel 0)
 *
 *=============================================================================
 * SECTION 13: MODERN TIMER ALTERNATIVES
 *=============================================================================
 * 
 * PIT (8253/8254):
 *   ✅ Always present
 *   ✅ Simple to program
 *   ✅ Sufficient for basic timing
 *   ❌ Limited precision (1.19 MHz base)
 *   ❌ Only 3 channels
 *   ❌ Shared across all CPUs
 * 
 * APIC TIMER (Local APIC):
 *   ✅ One per CPU core
 *   ✅ Higher precision
 *   ✅ Better for multiprocessor
 *   ❌ More complex setup
 *   ❌ Requires APIC initialization
 *   ❌ Not present on very old systems
 * 
 * HPET (High Precision Event Timer):
 *   ✅ Very high precision (10+ MHz)
 *   ✅ Multiple channels (up to 32)
 *   ✅ 64-bit counters
 *   ❌ Complex programming
 *   ❌ Must discover via ACPI
 *   ❌ Not on older hardware
 * 
 * TSC (Time Stamp Counter):
 *   ✅ Extremely high precision (GHz)
 *   ✅ Simple to read (RDTSC instruction)
 *   ✅ Per-CPU
 *   ❌ Not an interrupt source
 *   ❌ Rate varies (CPU frequency scaling)
 *   ❌ Requires calibration
 * 
 * RTC (Real-Time Clock):
 *   ✅ Keeps time when power off
 *   ✅ Can generate interrupts (IRQ 8)
 *   ✅ Good for wall-clock time
 *   ❌ Low precision (1024 Hz max)
 *   ❌ Not for high-frequency timing
 * 
 * ACPI PM TIMER:
 *   ✅ Always running
 *   ✅ Fixed 3.579545 MHz
 *   ✅ Good for timekeeping
 *   ❌ No interrupts (polling only)
 *   ❌ Requires ACPI support
 * 
 * WHEN TO USE EACH:
 * 
 * PIT:
 *   - Initial kernel timer (always available)
 *   - Legacy support
 *   - Simple systems
 * 
 * APIC Timer:
 *   - Multiprocessor systems
 *   - Per-CPU scheduling
 *   - After APIC initialized
 * 
 * HPET:
 *   - High-precision timeouts
 *   - Audio/video synchronization
 *   - Profiling
 * 
 * TSC:
 *   - Cycle-accurate timing
 *   - Performance measurement
 *   - Profiling
 * 
 * RTC:
 *   - Wall-clock time at boot
 *   - Periodic wakeup from sleep
 *   - Battery-backed timing
 * 
 * TYPICAL OS APPROACH:
 * 
 * 1. Boot: Use PIT (always available)
 * 2. Discover APIC, HPET via ACPI
 * 3. Switch to APIC Timer (better for SMP)
 * 4. Use HPET for high-precision timing
 * 5. Use TSC for profiling
 * 6. Use RTC for wall-clock time
 * 
 * TinyOS: Only uses PIT (simplicity).
 *
 *=============================================================================
 * SECTION 14: INTEGRATION WITH THE KERNEL
 *=============================================================================
 * 
 * WHERE PIT IS USED IN TINYOS:
 * 
 * 1. INITIALIZATION (kernel.c)
 *    pit_init(100);  // Set timer to 100 Hz
 * 
 * 2. INTERRUPT HANDLER (interrupts.c)
 *    IRQ 0 fires → Increment tick counter
 * 
 * INITIALIZATION ORDER:
 * 
 * Critical order (from kernel.c):
 *   1. IDT setup
 *   2. PIC remap
 *   3. PIC mask all
 *   4. PIT init ← HERE!
 *   5. PIC unmask IRQ 0
 *   6. STI
 * 
 * Why this order?
 *   - IDT first: Handler must exist
 *   - PIC remap: IRQ 0 → vector 0x20
 *   - PIC mask: Start with clean slate
 *   - PIT init: Configure timer BEFORE enabling
 *   - PIC unmask: Enable timer interrupt
 *   - STI last: Everything ready
 * 
 * DEPENDENCY GRAPH:
 * 
 *   pit.c (THIS FILE)
 *     ↑
 *     ├── kernel.h (types)
 *     └── pit.h (function prototypes)
 *     ↓
 *   Used by:
 *     ├── kernel.c (initialization)
 *     └── interrupts.c (tick counting)
 * 
 * FUNCTIONS EXPORTED:
 * 
 * pit_init(hz):
 *   - Called once during boot
 *   - Sets timer frequency
 *   - Timer starts immediately
 * 
 * pit_on_tick():
 *   - Called by IRQ 0 handler
 *   - Currently does nothing
 *   - Future: Could do per-tick housekeeping
 * 
 * pit_get_ticks():
 *   - Returns tick counter
 *   - Currently returns 0 (not implemented)
 *   - Future: Return actual tick count
 * 
 * FUTURE ENHANCEMENTS:
 * 
 * 1. Tick counter:
 *    volatile uint32_t pit_ticks = 0;
 *    void pit_on_tick() { pit_ticks++; }
 *    uint32_t pit_get_ticks() { return pit_ticks; }
 * 
 * 2. sleep() functions:
 *    void pit_sleep_ms(uint32_t ms);
 *    void pit_sleep_ticks(uint32_t ticks);
 * 
 * 3. Uptime:
 *    void pit_get_uptime(uint32_t* sec, uint32_t* ms);
 * 
 * 4. Timeouts:
 *    void pit_set_timeout(uint32_t ms, void (*callback)());
 * 
 * 5. Statistics:
 *    uint32_t pit_get_frequency();
 *    uint32_t pit_get_interrupts_per_second();
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "kernel.h"
#include "pit.h"

/*=============================================================================
 * SAFE I/O FUNCTION WITH MEMORY BARRIERS AND DELAYS
 *=============================================================================
 */

/**
 * safe_outb - Write byte to I/O port with delays and barriers
 * 
 * See pic.c for detailed explanation.
 * Same implementation used for PIT programming.
 */
static inline void safe_outb(uint16_t port, uint8_t value) {
    __asm__ volatile(
        "outb %0, %1\n\t"      /* Output byte to port */
        "jmp 1f\n\t"           /* Delay: jump forward */
        "1: jmp 1f\n\t"        /* Delay: jump forward again */
        "1: nop"               /* Delay: no-op */
        :                      /* No output operands */
        : "a"(value),          /* Input: AL register = value */
          "Nd"(port)           /* Input: Port (immediate or DX) */
        : "memory"             /* Clobber: Memory barrier */
    );
}

/*=============================================================================
 * FUNCTION: pit_init
 *=============================================================================
 * 
 * PURPOSE:
 *   Initialize the Programmable Interval Timer to generate periodic
 *   interrupts at the specified frequency.
 * 
 * PARAMETERS:
 *   hz - Desired interrupt frequency in Hertz (1-1000 recommended)
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * WHAT IT DOES:
 *   1. Validate input frequency (default to 100 Hz if invalid)
 *   2. Calculate divisor from frequency
 *   3. Clamp divisor to valid range (1-65535)
 *   4. Split divisor into low and high bytes
 *   5. Disable interrupts (atomic operation)
 *   6. Send command byte (Mode 2, Channel 0, Binary)
 *   7. Send divisor low byte
 *   8. Send divisor high byte
 *   9. Memory barrier (ensure completion)
 * 
 * RESULT:
 *   Timer begins generating interrupts at ~hz Hz
 *   Each interrupt fires IRQ 0 (vector 0x20 after PIC remap)
 * 
 * WHEN TO CALL:
 *   During kernel initialization, after PIC remap, before STI.
 *   
 *   Typical sequence:
 *     idt_init();
 *     pic_remap();
 *     pic_mask_all();
 *     pit_init(100);    ← HERE!
 *     pic_unmask(0);
 *     sti();
 * 
 * EXAMPLE USAGE:
 *   pit_init(100);   // 100 Hz (10 ms period)
 *   pit_init(250);   // 250 Hz (4 ms period)
 *   pit_init(1000);  // 1000 Hz (1 ms period)
 * 
 * SAFETY:
 *   - Validates input (prevents divide by zero, overflow)
 *   - Disables interrupts during programming (atomic)
 *   - Uses safe_outb() with delays (hardware compatibility)
 *   - Memory barrier ensures completion
 * 
 * NOTES:
 *   - Timer starts immediately after programming
 *   - Interrupts remain disabled (kernel enables later)
 *   - Frequency might differ slightly due to divisor rounding
 */
void pit_init(uint32_t hz) {
    /*
     * STEP 1: VALIDATE INPUT FREQUENCY
     * 
     * Frequency must be positive and reasonable.
     * 
     * Invalid values:
     *   - 0: Would cause divide by zero
     *   - >1000: Wastes CPU, diminishing returns
     * 
     * Default: 100 Hz (good balance)
     */
    if (hz == 0 || hz > 1000) {
        hz = 100;  /* Default to 100 Hz */
    }
    
    /*
     * STEP 2: CALCULATE DIVISOR
     * 
     * Formula: Divisor = Base Frequency / Desired Frequency
     * Base frequency: 1,193,182 Hz (fixed by hardware)
     * 
     * Example (100 Hz):
     *   divisor = 1193182 / 100 = 11931.82 ≈ 11932
     * 
     * Actual frequency:
     *   1193182 / 11932 = 99.9983 Hz
     * 
     * Error: 0.0017 Hz (negligible!)
     */
    uint32_t divisor = 1193182u / hz;
    
    /*
     * STEP 3: CLAMP DIVISOR TO VALID RANGE
     * 
     * PIT counter is 16-bit: 1 to 65536
     * (0 is special case meaning 65536)
     * 
     * If divisor too large:
     *   - Clamp to 0xFFFF (65535)
     *   - Minimum frequency: 1193182 / 65535 = 18.2 Hz
     * 
     * If divisor too small:
     *   - Clamp to 1
     *   - Maximum frequency: 1193182 Hz (impractical!)
     * 
     * For requested frequencies in range 1-1000 Hz,
     * divisor will always be valid. These checks are defensive.
     */
    if (divisor > 0xFFFF) divisor = 0xFFFF;
    if (divisor < 1) divisor = 1;
    
    /*
     * STEP 4: SPLIT DIVISOR INTO BYTES
     * 
     * PIT data port is 8-bit, but divisor is 16-bit.
     * Must send in two parts: low byte, then high byte.
     * 
     * Example (divisor = 11932 = 0x2E9C):
     *   low  = 0x9C (156 decimal)
     *   high = 0x2E (46 decimal)
     * 
     * Bit manipulation:
     *   low  = divisor & 0xFF         (mask lower 8 bits)
     *   high = (divisor >> 8) & 0xFF  (shift right, mask lower 8 bits)
     */
    uint8_t low = (uint8_t)(divisor & 0xFF);
    uint8_t high = (uint8_t)((divisor >> 8) & 0xFF);
    
    /*
     * STEP 5: DISABLE INTERRUPTS
     * 
     * CLI (Clear Interrupt Flag) disables maskable interrupts.
     * 
     * Why?
     *   - PIT programming must be atomic
     *   - If interrupted between command and data:
     *     * PIT in inconsistent state
     *     * Might cause wrong frequency or spurious interrupts
     * 
     * Note: TinyOS doesn't re-enable (STI) here.
     * Kernel enables interrupts later, after all hardware ready.
     * 
     * Memory clobber: Tells compiler this has side effects.
     */
    __asm__ volatile("cli" ::: "memory");
    
    /*
     * STEP 6: SEND COMMAND BYTE
     * 
     * Command byte: 0x34 (00110100 binary)
     * Port: 0x43 (PIT command register)
     * 
     * Bit breakdown:
     *   Bits 7-6 = 00: Channel 0 (system timer)
     *   Bits 5-4 = 11: Access mode: low byte, then high byte
     *   Bits 3-1 = 010: Mode 2 (rate generator, periodic)
     *   Bit 0 = 0: Binary mode (not BCD)
     * 
     * This tells PIT:
     *   "I'm going to program channel 0 in mode 2.
     *    I'll send two bytes (low then high).
     *    Use binary counting (not BCD)."
     * 
     * After this command, PIT expects:
     *   - Next write to 0x40: Low byte of divisor
     *   - Following write to 0x40: High byte of divisor
     */
    safe_outb(0x43, 0x34);  /* Command: Ch0, Mode 2, Binary, Lo/Hi */
    
    /*
     * STEP 7: SEND DIVISOR LOW BYTE
     * 
     * Port: 0x40 (Channel 0 data register)
     * Value: Low 8 bits of divisor
     * 
     * PIT receives this as the lower half of the count value.
     * After this, PIT expects high byte next.
     */
    safe_outb(0x40, low);   /* Send low byte of divisor */
    
    /*
     * STEP 8: SEND DIVISOR HIGH BYTE
     * 
     * Port: 0x40 (Channel 0 data register)
     * Value: High 8 bits of divisor
     * 
     * PIT receives this as the upper half of the count value.
     * After this, divisor is complete and PIT starts counting!
     * 
     * PIT now:
     *   - Loads divisor into counter
     *   - Begins decrementing on each clock pulse (1.193182 MHz)
     *   - When counter reaches 1, output goes low (IRQ 0 fires)
     *   - Counter reloads to divisor (Mode 2 auto-reload)
     *   - Repeats forever (periodic interrupts)
     */
    safe_outb(0x40, high);  /* Send high byte of divisor */
    
    /*
     * STEP 9: MEMORY BARRIER
     * 
     * Empty asm volatile with memory clobber.
     * 
     * Ensures compiler doesn't reorder subsequent code before PIT programming.
     * All PIT setup is complete before function returns.
     * 
     * Without this, compiler might move code after function return
     * before PIT setup completes (incorrect optimization).
     */
    __asm__ volatile("" ::: "memory");
    
    /*
     * INITIALIZATION COMPLETE!
     * 
     * Timer is now running at the specified frequency.
     * Each tick, IRQ 0 fires (vector 0x20 after PIC remap).
     * 
     * However, interrupts are still disabled (CLI above).
     * Kernel will:
     *   1. Unmask IRQ 0 (pic_unmask(0))
     *   2. Enable interrupts globally (STI)
     * 
     * Then timer interrupts will start flowing!
     */
}

/*=============================================================================
 * FUNCTION: pit_on_tick
 *=============================================================================
 * 
 * PURPOSE:
 *   Called by the IRQ 0 interrupt handler on each timer tick.
 *   Currently a placeholder for future functionality.
 * 
 * PARAMETERS:
 *   None
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * CURRENT BEHAVIOR:
 *   Does nothing (empty function)
 * 
 * FUTURE USE:
 *   Could implement:
 *   - Increment tick counter
 *   - Update timekeeping
 *   - Check timeouts
 *   - Trigger scheduled events
 * 
 * CALLED FROM:
 *   IRQ 0 interrupt handler (in interrupts.c)
 *   Currently not called (TinyOS increments tick counter directly)
 * 
 * EXAMPLE FUTURE IMPLEMENTATION:
 *   static volatile uint32_t pit_ticks = 0;
 *   
 *   void pit_on_tick(void) {
 *       pit_ticks++;
 *       
 *       // Update seconds counter
 *       if (pit_ticks % 100 == 0) {
 *           seconds_since_boot++;
 *       }
 *       
 *       // Check for expired timeouts
 *       check_timeouts();
 *   }
 */
void pit_on_tick(void) {
    /* Do nothing (placeholder for future functionality) */
}

/*=============================================================================
 * FUNCTION: pit_get_ticks
 *=============================================================================
 * 
 * PURPOSE:
 *   Return the number of timer ticks since system boot.
 *   Currently a placeholder returning 0.
 * 
 * PARAMETERS:
 *   None
 * 
 * RETURN VALUE:
 *   uint32_t - Number of ticks (currently always 0)
 * 
 * CURRENT BEHAVIOR:
 *   Returns 0 (not implemented)
 * 
 * FUTURE USE:
 *   Should return actual tick counter value.
 *   Tick counter incremented by pit_on_tick().
 * 
 * USAGE:
 *   uint32_t ticks = pit_get_ticks();
 *   uint32_t seconds = ticks / 100;  // At 100 Hz
 * 
 * EXAMPLE FUTURE IMPLEMENTATION:
 *   static volatile uint32_t pit_ticks = 0;
 *   
 *   uint32_t pit_get_ticks(void) {
 *       return pit_ticks;
 *   }
 * 
 * NOTE:
 *   TinyOS currently tracks ticks in interrupts.c,
 *   not in this file. This function is for future use
 *   when tick counting is moved to PIT driver.
 */
uint32_t pit_get_ticks(void) {
    return 0;  /* Placeholder: return 0 (not implemented) */
}

/*=============================================================================
 * END OF FILE: pit.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Implemented PIT initialization (configurable frequency)
 *   ✅ Support for Mode 2 (rate generator, periodic interrupts)
 *   ✅ Frequency validation and divisor calculation
 *   ✅ Safe I/O with memory barriers and delays
 *   ✅ Comprehensive documentation for learning
 * 
 * WHAT HAPPENS NEXT:
 *   → pit_init() called during kernel initialization
 *   → Timer begins generating IRQ 0 interrupts
 *   → Interrupt handler increments tick counter
 *   → System has heartbeat for scheduling and timekeeping
 * 
 * KEY TAKEAWAYS:
 *   1. PIT provides the "heartbeat" for the operating system
 *   2. Base frequency is fixed (1.193182 MHz)
 *   3. Divisor controls interrupt frequency (freq = base / divisor)
 *   4. Mode 2 provides automatic reload (periodic interrupts)
 *   5. Timer must be initialized before enabling interrupts
 *   6. 100 Hz is a good default balance (10 ms resolution)
 *   7. Higher frequency = Better responsiveness, more overhead
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - How hardware timers work
 *   - The relationship between frequency and divisor
 *   - PIT programming sequence
 *   - Why operating systems need periodic interrupts
 *   - How to choose appropriate timer frequency
 *   - The trade-offs between responsiveness and overhead
 * 
 *   You've mastered the heartbeat of the operating system! 🎉
 *============================================================================*/
