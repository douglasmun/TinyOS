/*=============================================================================
 *  idt.c — IDT with CORRECT selector (0x10, not 0x08)
 *============================================================================*/
#include "idt.h"

/* ISR stubs from isr.S */
extern void isr0(void);  extern void isr1(void);  extern void isr2(void);  extern void isr3(void);
extern void isr4(void);  extern void isr5(void);  extern void isr6(void);  extern void isr7(void);
extern void isr8(void);  extern void isr9(void);  extern void isr10(void); extern void isr11(void);
extern void isr12(void); extern void isr13(void); extern void isr14(void); extern void isr15(void);
extern void isr16(void); extern void isr17(void); extern void isr18(void); extern void isr19(void);
extern void isr20(void); extern void isr21(void); extern void isr22(void); extern void isr23(void);
extern void isr24(void); extern void isr25(void); extern void isr26(void); extern void isr27(void);
extern void isr28(void); extern void isr29(void); extern void isr30(void); extern void isr31(void);

/* IRQ stubs from isr.S */
extern void irq32(void); extern void irq33(void); extern void irq34(void); extern void irq35(void);
extern void irq36(void); extern void irq37(void); extern void irq38(void); extern void irq39(void);
extern void irq40(void); extern void irq41(void); extern void irq42(void); extern void irq43(void);
extern void irq44(void); extern void irq45(void); extern void irq46(void); extern void irq47(void);

static struct idt_entry idt[256];
static struct idt_ptr   idtr;

/* CRITICAL FIX: Use 0x10, not 0x08! GRUB uses 0x10 for code segment */
static void idt_set_gate(int vec, void (*fn)(void), uint8_t flags) {
    uint32_t addr = (uint32_t)fn;
    idt[vec].offset_low  = (uint16_t)(addr & 0xFFFF);
    idt[vec].selector    = 0x10;    /* ← FIX: Was 0x08, should be 0x10 */
    idt[vec].ist         = 0;
    idt[vec].type_attr   = flags;
    idt[vec].offset_high = (uint16_t)((addr >> 16) & 0xFFFF);
}

void idt_init(void) {
    for (int i = 0; i < 256; ++i) {
        idt[i].offset_low = idt[i].selector = idt[i].ist = idt[i].type_attr = idt[i].offset_high = 0;
    }

    idt_set_gate( 0, isr0,  0x8E);
    idt_set_gate( 1, isr1,  0x8E);
    idt_set_gate( 2, isr2,  0x8E);
    idt_set_gate( 3, isr3,  0x8E);
    idt_set_gate( 4, isr4,  0x8E);
    idt_set_gate( 5, isr5,  0x8E);
    idt_set_gate( 6, isr6,  0x8E);
    idt_set_gate( 7, isr7,  0x8E);
    idt_set_gate( 8, isr8,  0x8E);
    idt_set_gate( 9, isr9,  0x8E);
    idt_set_gate(10, isr10, 0x8E);
    idt_set_gate(11, isr11, 0x8E);
    idt_set_gate(12, isr12, 0x8E);
    idt_set_gate(13, isr13, 0x8E);
    idt_set_gate(14, isr14, 0x8E);
    idt_set_gate(15, isr15, 0x8E);
    idt_set_gate(16, isr16, 0x8E);
    idt_set_gate(17, isr17, 0x8E);
    idt_set_gate(18, isr18, 0x8E);
    idt_set_gate(19, isr19, 0x8E);
    idt_set_gate(20, isr20, 0x8E);
    idt_set_gate(21, isr21, 0x8E);
    idt_set_gate(22, isr22, 0x8E);
    idt_set_gate(23, isr23, 0x8E);
    idt_set_gate(24, isr24, 0x8E);
    idt_set_gate(25, isr25, 0x8E);
    idt_set_gate(26, isr26, 0x8E);
    idt_set_gate(27, isr27, 0x8E);
    idt_set_gate(28, isr28, 0x8E);
    idt_set_gate(29, isr29, 0x8E);
    idt_set_gate(30, isr30, 0x8E);
    idt_set_gate(31, isr31, 0x8E);
    idt_set_gate(32, irq32, 0x8E);
    idt_set_gate(33, irq33, 0x8E);
    idt_set_gate(34, irq34, 0x8E);
    idt_set_gate(35, irq35, 0x8E);
    idt_set_gate(36, irq36, 0x8E);
    idt_set_gate(37, irq37, 0x8E);
    idt_set_gate(38, irq38, 0x8E);
    idt_set_gate(39, irq39, 0x8E);
    idt_set_gate(40, irq40, 0x8E);
    idt_set_gate(41, irq41, 0x8E);
    idt_set_gate(42, irq42, 0x8E);
    idt_set_gate(43, irq43, 0x8E);
    idt_set_gate(44, irq44, 0x8E);
    idt_set_gate(45, irq45, 0x8E);
    idt_set_gate(46, irq46, 0x8E);
    idt_set_gate(47, irq47, 0x8E);

    idtr.limit = (uint16_t)(sizeof(idt) - 1);
    idtr.base  = (uint32_t)&idt[0];

    __asm__ volatile ("lidt %0" : : "m"(idtr));
}
