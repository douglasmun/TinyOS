/*=============================================================================
 *  idt.c — Interrupt Descriptor Table (IDT) Setup for TinyOS
 *=============================================================================
 * 
 * PURPOSE:
 *   This file implements the Interrupt Descriptor Table (IDT), which is the
 *   central mechanism for handling CPU exceptions and hardware interrupts in
 *   protected mode x86 systems. Think of the IDT as a "phone book" that tells
 *   the CPU where to jump when something important happens.
 *
 * AUTHOR:
 *   Douglas Mun
 *
 * ARCHITECTURE:
 *   - Target: i386 (32-bit x86) protected mode
 *   - Ring: 0 (kernel privilege level)
 *   - Paging: Works with or without paging enabled
 *   - Integration: Works with GRUB's GDT (Global Descriptor Table)
 *
 *=============================================================================
 * TABLE OF CONTENTS
 *=============================================================================
 * 1. What is the IDT?
 * 2. Why Do We Need It?
 * 3. IDT Entry Format (Hardware Structure)
 * 4. Interrupt Vectors (What Each Number Means)
 * 5. The Critical 0x10 vs 0x08 Bug
 * 6. Implementation Details
 * 7. Common Pitfalls and Solutions
 * 8. Testing and Debugging
 *
 *=============================================================================
 * SECTION 1: WHAT IS THE IDT?
 *=============================================================================
 * 
 * The Interrupt Descriptor Table (IDT) is a data structure used by the x86
 * CPU to determine where to jump when an interrupt or exception occurs.
 * 
 * ANALOGY:
 *   Imagine you're in a large office building (your computer):
 *   - The fire alarm goes off (interrupt/exception)
 *   - You need to know where the exits are (interrupt handlers)
 *   - The IDT is like the emergency evacuation map on the wall
 *   - Each room number (vector) points to an exit route (handler function)
 * 
 * PHYSICAL REPRESENTATION:
 *   - The IDT is an array of 256 entries
 *   - Each entry is 8 bytes (64 bits) on i386
 *   - Total size: 256 × 8 = 2048 bytes = 2 KiB
 *   - Lives in kernel memory (our array: "idt[256]")
 *   - CPU finds it via the IDTR register (loaded with LIDT instruction)
 * 
 * ENTRY CONTENTS:
 *   Each IDT entry contains:
 *   1. Handler address (32 bits split into two 16-bit pieces)
 *   2. Code segment selector (which segment contains the handler)
 *   3. Flags (present bit, privilege level, gate type)
 *   4. Reserved bits (must be zero on i386)
 * 
 * WHY SPLIT THE ADDRESS?
 *   Historical reasons! The x86 evolved from 16-bit to 32-bit:
 *   - Original 16-bit design had limited space
 *   - When moving to 32-bit, Intel kept backward compatibility
 *   - Result: 32-bit address split into offset_low and offset_high
 *   - Modern x86-64 uses even more complex structures
 *
 *=============================================================================
 * SECTION 2: WHY DO WE NEED THE IDT?
 *=============================================================================
 * 
 * WITHOUT IDT:
 *   1. CPU encounters exception (e.g., divide by zero)
 *   2. CPU looks up handler in IDT
 *   3. IDT not loaded → CPU generates Double Fault (#DF)
 *   4. CPU tries to handle Double Fault
 *   5. Double Fault handler also not in IDT
 *   6. CPU generates Triple Fault
 *   7. Triple Fault → CPU RESET (computer reboots)
 *   8. You see: Endless reboot loop, no error messages
 * 
 * WITH IDT:
 *   1. CPU encounters exception (e.g., divide by zero)
 *   2. CPU looks up handler in IDT → Finds our handler
 *   3. CPU jumps to our handler function
 *   4. Our handler prints: "ERROR: Divide by zero at EIP=0x12345678"
 *   5. Our handler halts cleanly
 *   6. You see: Clear error message, can debug the problem!
 * 
 * CRITICAL TIMING:
 *   The IDT must be installed BEFORE:
 *   - Enabling paging (can cause page faults)
 *   - Enabling interrupts (hardware interrupts will fire)
 *   - Any code that might fault (almost everything!)
 * 
 *   In TinyOS initialization order:
 *   1. Serial port init (for debugging output)
 *   2. VGA init (for visual output)
 *   3. IDT setup ← YOU ARE HERE (CRITICAL SAFETY NET)
 *   4. PMM init (physical memory manager)
 *   5. Paging init (can fault if bugs exist)
 *   6. PIC/PIT setup (hardware interrupts)
 *   7. STI (enable interrupts)
 * 
 *   Installing IDT first is like putting on a seatbelt before driving.
 *
 *=============================================================================
 * SECTION 3: IDT ENTRY FORMAT (HARDWARE STRUCTURE)
 *=============================================================================
 * 
 * Each IDT entry is 64 bits (8 bytes) with this exact layout:
 * 
 * Bits 0-15:   offset_low   (Lower 16 bits of handler address)
 * Bits 16-31:  selector     (Code segment selector, e.g., 0x10)
 * Bits 32-39:  ist          (Interrupt Stack Table index, unused on i386)
 * Bits 40-47:  type_attr    (Present, DPL, gate type flags)
 * Bits 48-63:  offset_high  (Upper 16 bits of handler address)
 * 
 * DETAILED BREAKDOWN:
 * 
 * offset_low and offset_high (32 bits total):
 *   - Combined to form the complete handler address
 *   - Example: Handler at 0x00103456
 *     → offset_low  = 0x3456
 *     → offset_high = 0x0010
 *   - Why split? Backward compatibility with 16-bit x86
 * 
 * selector (16 bits):
 *   - Points to a GDT (Global Descriptor Table) entry
 *   - Identifies which code segment contains the handler
 *   - Must be a valid code segment with kernel privileges
 *   - **CRITICAL**: For TinyOS with GRUB, this MUST be 0x10!
 *   - Common mistake: Using 0x08 (wrong segment, causes #GP fault)
 * 
 * ist (8 bits):
 *   - Interrupt Stack Table index (x86-64 feature)
 *   - Not used on i386, must be set to 0
 *   - On x86-64, allows switching to different stacks for interrupts
 * 
 * type_attr (8 bits):
 *   Bit layout:
 *     Bit 7:    P (Present) — Must be 1 for valid entries
 *     Bits 6-5: DPL (Descriptor Privilege Level) — Usually 0 (kernel)
 *     Bit 4:    S (Storage Segment) — Must be 0 for gates
 *     Bits 3-0: Gate Type
 *               - 0x0E (1110) = 32-bit Interrupt Gate
 *               - 0x0F (1111) = 32-bit Trap Gate
 * 
 *   Common value: 0x8E (10001110 binary)
 *     → P=1 (present)
 *     → DPL=00 (kernel privilege)
 *     → S=0 (gate descriptor)
 *     → Type=1110 (interrupt gate)
 * 
 * INTERRUPT GATE vs TRAP GATE:
 *   - Interrupt Gate (0x8E): CPU automatically clears IF flag (disables interrupts)
 *   - Trap Gate (0x8F): CPU does NOT clear IF flag (interrupts stay enabled)
 *   - TinyOS uses Interrupt Gates (0x8E) for safety (no nested interrupts)
 * 
 * WHY DISABLE INTERRUPTS AUTOMATICALLY?
 *   - Prevents interrupt handler from being interrupted
 *   - Avoids stack overflow from nested interrupts
 *   - Simplifies handler code (no need for complex locking)
 *   - Can re-enable with STI if needed (advanced usage)
 *
 *=============================================================================
 * SECTION 4: INTERRUPT VECTORS (WHAT EACH NUMBER MEANS)
 *=============================================================================
 * 
 * The x86 architecture defines 256 possible interrupt vectors (0-255).
 * Each vector has a specific meaning or purpose:
 * 
 * VECTORS 0-31: CPU EXCEPTIONS (Reserved by Intel)
 * ------------------------------------------------
 *   These are synchronous events triggered by the CPU when something goes
 *   wrong during instruction execution. They are NOT hardware interrupts.
 * 
 *   Vector  Name                    Description
 *   ------  ----------------------  ------------------------------------------
 *   0       #DE Divide Error        Division by zero or invalid division
 *   1       #DB Debug               Debug exception (breakpoints, single-step)
 *   2       NMI                     Non-Maskable Interrupt (hardware critical)
 *   3       #BP Breakpoint          INT3 instruction (debugger breakpoint)
 *   4       #OF Overflow            INTO instruction detected overflow
 *   5       #BR Bound Range         BOUND instruction exceeded array bounds
 *   6       #UD Invalid Opcode      CPU encountered invalid instruction
 *   7       #NM Device Not Avail    FPU instruction but no FPU (CR0.EM=1)
 *   8       #DF Double Fault        Exception while handling another exception
 *   9       Coprocessor Overrun     Legacy (not used on modern CPUs)
 *   10      #TS Invalid TSS         Task State Segment invalid or not present
 *   11      #NP Segment Not Present Segment marked not present
 *   12      #SS Stack Segment Fault Stack segment invalid or stack overflow
 *   13      #GP General Protection  Memory protection violation or bad segment
 *   14      #PF Page Fault          Page not present or protection violation
 *   15      Reserved                Intel reserved (shouldn't fire)
 *   16      #MF FPU Exception       x87 FPU floating-point math error
 *   17      #AC Alignment Check     Unaligned memory access (if AC flag set)
 *   18      #MC Machine Check       CPU/bus/cache error detected (serious!)
 *   19      #XF SIMD Exception      SSE/AVX floating-point exception
 *   20      #VE Virtualization      Virtualization exception (EPT violation)
 *   21      #CP Control Protection  Control-flow enforcement violation (CET)
 *   22-31   Reserved                Intel reserved for future use
 * 
 * IMPORTANT NOTES ON EXCEPTIONS:
 *   - Some push an error code, some don't (see ERROR CODES section)
 *   - CR2 register contains faulting address for #PF (page fault)
 *   - CR3 register contains page directory address
 *   - Error code format varies by exception type
 * 
 * VECTORS 32-47: HARDWARE IRQs (After PIC Remap)
 * -----------------------------------------------
 *   These are asynchronous events triggered by hardware devices.
 *   Originally IRQs mapped to 0-15, but we remap them to 32-47 to avoid
 *   conflicts with CPU exceptions.
 * 
 *   Vector  IRQ   Device              Description
 *   ------  ----  ------------------  ------------------------------------------
 *   32      0     PIT (Timer)         Programmable Interval Timer (100 Hz)
 *   33      1     Keyboard            PS/2 keyboard interrupt
 *   34      2     Cascade             Cascaded from slave PIC (internal)
 *   35      3     COM2/COM4           Serial port 2 or 4
 *   36      4     COM1/COM3           Serial port 1 or 3
 *   37      5     LPT2                Parallel port 2 (or sound card)
 *   38      6     Floppy Disk         Floppy disk controller
 *   39      7     LPT1                Parallel port 1 (or spurious IRQ)
 *   40      8     RTC                 Real-Time Clock (CMOS)
 *   41      9     ACPI                ACPI or free for PCI devices
 *   42      10    Free                Available for PCI devices
 *   43      11    Free                Available for PCI devices
 *   44      12    Mouse               PS/2 mouse interrupt
 *   45      13    FPU                 Math coprocessor (legacy)
 *   46      14    Primary IDE         Primary ATA/IDE hard disk
 *   47      15    Secondary IDE       Secondary ATA/IDE hard disk
 * 
 * VECTORS 48-255: USER-DEFINED
 * -----------------------------
 *   Vectors 48-255 are available for:
 *   - Additional hardware devices (beyond standard PC hardware)
 *   - Software interrupts (INT instruction for system calls)
 *   - Future expansion
 * 
 *   TinyOS currently leaves these unused (all set to 0).
 * 
 * WHY REMAP IRQS TO 32-47?
 *   By default, the 8259 PIC (Programmable Interrupt Controller) maps
 *   hardware IRQs to vectors 0-15. This conflicts with CPU exceptions!
 * 
 *   Problem without remapping:
 *   - IRQ0 (timer) → Vector 8 (Double Fault exception)
 *   - IRQ1 (keyboard) → Vector 9 (Coprocessor Overrun)
 *   - Result: System confusion and crashes
 * 
 *   Solution: Remap IRQs to 32-47 (done in pic.c before enabling interrupts)
 *
 *=============================================================================
 * SECTION 5: THE CRITICAL 0x10 vs 0x08 BUG
 *=============================================================================
 * 
 * This is the most common mistake when writing an IDT implementation!
 * 
 * THE BUG:
 *   Many OS tutorials and examples use selector 0x08 for interrupt gates.
 *   This works on SOME systems but fails catastrophically on others.
 * 
 * WHY IT FAILS WITH GRUB:
 *   GRUB (our bootloader) sets up its own GDT with this layout:
 * 
 *   Offset  Segment Type
 *   ------  ------------
 *   0x00    Null segment (required by x86 spec)
 *   0x08    Kernel DATA segment (read/write)
 *   0x10    Kernel CODE segment (read/execute) ← CORRECT FOR IDT
 *   0x18    Kernel STACK segment
 * 
 *   If we use selector 0x08 in the IDT:
 *   1. Interrupt fires (e.g., timer interrupt)
 *   2. CPU looks up handler in IDT
 *   3. CPU sees selector 0x08 (data segment)
 *   4. CPU tries to execute code from data segment
 *   5. CPU generates General Protection Fault (#GP, vector 13)
 *   6. CPU tries to handle #GP using IDT
 *   7. #GP handler also has selector 0x08 (still wrong!)
 *   8. CPU generates Double Fault (#DF, vector 8)
 *   9. #DF handler also broken
 *   10. CPU generates Triple Fault
 *   11. System reboots (no error message)
 * 
 * THE FIX:
 *   Use selector 0x10 (code segment) instead of 0x08 (data segment).
 * 
 * HOW TO VERIFY YOUR GDT LAYOUT:
 *   In QEMU monitor (Ctrl+Alt+2), type: info registers
 *   Look for: CS (Code Segment register)
 *   Example output: CS=0010 ... DPL=0 ... Code ...
 *   
 *   If CS=0x0010, then use 0x10 in idt_set_gate().
 *   If CS=0x0008, then use 0x08 in idt_set_gate().
 * 
 * WHY DO TUTORIALS USE 0x08?
 *   Many tutorials assume you're writing your own bootloader that sets up
 *   a GDT with code segment at 0x08. GRUB uses a different layout.
 * 
 * DEBUGGING SYMPTOMS:
 *   - System reboots in a loop (triple fault)
 *   - No error messages (CPU reset before handler runs)
 *   - Works in one emulator but not another (different BIOS behavior)
 *   - Works with one bootloader but not GRUB
 * 
 * REAL-WORLD DEBUGGING STORY:
 *   During TinyOS development, this bug caused 3 days of frustration:
 *   - System would boot, print "Enabling interrupts...", then reboot
 *   - QEMU's -d int showed #GP → #DF → Triple Fault
 *   - Eventually discovered GRUB's GDT layout documentation
 *   - Changed 0x08 to 0x10 → Everything worked!
 *   - Lesson: Always verify your bootloader's GDT layout
 *
 *=============================================================================
 * SECTION 6: ERROR CODES
 *=============================================================================
 * 
 * Some CPU exceptions automatically push an error code onto the stack.
 * Others don't. Our assembly stubs in isr.S handle this inconsistency by
 * pushing a dummy error code (0) for exceptions that don't provide one.
 * 
 * EXCEPTIONS THAT PUSH ERROR CODES:
 *   Vector  Exception         Error Code Format
 *   ------  ----------------  -------------------------------------------------
 *   8       Double Fault      Always 0 (reserved)
 *   10      Invalid TSS       Segment selector that caused the fault
 *   11      Segment Not Pres  Segment selector that caused the fault
 *   12      Stack Fault       Segment selector or 0 if limit exceeded
 *   13      General Protec    Segment selector or 0 (various causes)
 *   14      Page Fault        Error code bits:
 *                             Bit 0: P (0=not present, 1=protection violation)
 *                             Bit 1: W/R (0=read, 1=write)
 *                             Bit 2: U/S (0=supervisor, 1=user)
 *                             Bit 3: RSVD (1=reserved bit violation)
 *                             Bit 4: I/D (1=instruction fetch)
 *   17      Alignment Check   Always 0 (reserved)
 *   30      Security Exception Various security violation details
 * 
 * ALL OTHER EXCEPTIONS:
 *   No error code pushed by CPU. Our ISR stubs push dummy code 0.
 * 
 * WHY THE INCONSISTENCY?
 *   Intel added error codes over time as new exceptions were defined.
 *   Early exceptions (0-7) don't have error codes.
 *   Later exceptions (8+) sometimes do.
 *   Result: Confusing and error-prone for OS developers!
 * 
 * HOW OUR CODE HANDLES THIS:
 *   See isr.S (assembly interrupt stubs):
 *   - isr0-isr7, isr9, isr15-isr31: Push dummy 0, then vector number
 *   - isr8, isr10-isr14, isr17, isr30: Push ONLY vector number (CPU pushed error code)
 *   - Result: Stack layout is consistent for our C handler
 *
 *=============================================================================
 * SECTION 7: STACK LAYOUT DURING INTERRUPT
 *=============================================================================
 * 
 * When an interrupt occurs, the CPU and our assembly code build a stack
 * frame that our C handler (isr_common_handler) can access.
 * 
 * STACK GROWTH REMINDER:
 *   On x86, the stack grows DOWNWARD (toward lower addresses):
 *   - Push: ESP -= 4, then write to [ESP]
 *   - Pop: Read from [ESP], then ESP += 4
 *   - Top of stack = lowest address = ESP
 * 
 * COMPLETE STACK LAYOUT (from top/lowest address to bottom/highest address):
 * 
 *   [ESP+0]  EAX    ┐
 *   [ESP+4]  ECX    │
 *   [ESP+8]  EDX    │
 *   [ESP+12] EBX    │ Pushed by PUSHA in isr_common (isr.S)
 *   [ESP+16] ESP    │ (Original ESP before PUSHA)
 *   [ESP+20] EBP    │
 *   [ESP+24] ESI    │
 *   [ESP+28] EDI    ┘
 *   [ESP+32] Error Code (pushed by CPU or dummy 0 pushed by ISR stub)
 *   [ESP+36] Vector Number (pushed by ISR stub)
 *   [ESP+40] EIP (return address, pushed by CPU)
 *   [ESP+44] CS (code segment, pushed by CPU)
 *   [ESP+48] EFLAGS (flags register, pushed by CPU)
 *   [ESP+52] ESP (user-mode ESP, pushed by CPU only if privilege change)
 *   [ESP+56] SS (user-mode SS, pushed by CPU only if privilege change)
 * 
 * CDECL CALLING CONVENTION:
 *   Our isr_common (assembly) calls our C handler like this:
 * 
 *   push [ESP+36]    ; Push vector number as second argument
 *   push [ESP+36]    ; Push error code as first argument
 *   call isr_common_handler
 *   add esp, 8       ; Clean up arguments
 * 
 *   In C: void isr_common_handler(uint32_t vector, uint32_t err)
 *   - First argument (err) at [ESP+4]
 *   - Second argument (vector) at [ESP+8]
 *
 *=============================================================================
 * SECTION 8: DESIGN PATTERNS AND BEST PRACTICES
 *=============================================================================
 * 
 * STATIC DATA:
 *   The IDT array and IDTR structure are declared static:
 *   - static struct idt_entry idt[256];
 *   - static struct idt_ptr idtr;
 * 
 *   Benefits:
 *   - Lives in .bss section (zero-initialized by bootloader)
 *   - Not visible outside this file (encapsulation)
 *   - Persists for entire kernel lifetime (no dynamic allocation)
 *   - Faster access (no indirection through pointers)
 * 
 * INITIALIZATION PATTERN:
 *   1. Zero all entries (paranoid safety)
 *   2. Install exception handlers (vectors 0-31)
 *   3. Install IRQ handlers (vectors 32-47)
 *   4. Set up IDTR structure
 *   5. Load IDTR with LIDT instruction
 * 
 * EXTENSIBILITY:
 *   Future enhancements could include:
 *   - idt_set_gate_user() for user-mode interrupts (DPL=3)
 *   - idt_get_gate() to read current handler
 *   - idt_enable_vector() / idt_disable_vector()
 *   - Per-IRQ handler registration (function pointer arrays)
 * 
 * TESTING STRATEGY:
 *   1. Test with intentional divide-by-zero (INT 0 or DIV)
 *   2. Test with page fault (access unmapped address)
 *   3. Test with general protection fault (bad segment selector)
 *   4. Test with timer interrupt (verify IRQ0 fires at correct rate)
 *   5. Test with double fault (intentionally corrupt stack)
 * 
 * COMMON BUGS TO AVOID:
 *   ❌ Forgetting to load IDTR (LIDT never called)
 *   ❌ Wrong selector (0x08 instead of 0x10 with GRUB)
 *   ❌ Forgetting to set Present bit (P=0 causes #GP)
 *   ❌ Wrong gate type (using trap gate when interrupt gate needed)
 *   ❌ Handlers not in kernel code segment
 *   ❌ Installing IDT after enabling paging (can fault before handlers ready)
 *   ❌ Not handling all 32 exceptions (missing handlers cause triple fault)
 *
 *=============================================================================
 * SECTION 9: ASSEMBLY STUB INTEGRATION
 *=============================================================================
 * 
 * This C file works in tandem with isr.S (assembly interrupt stubs).
 * 
 * DIVISION OF LABOR:
 *   isr.S (Assembly):
 *   - Minimal, fast interrupt entry/exit code
 *   - Saves/restores registers (PUSHA/POPA)
 *   - Pushes vector number and error code
 *   - Calls our C handler (isr_common_handler)
 *   - Returns with IRET instruction
 * 
 *   idt.c (This file):
 *   - Sets up IDT entries pointing to assembly stubs
 *   - Provides C handler for processing interrupts
 *   - Higher-level logic (error reporting, IRQ dispatch)
 * 
 * WHY USE ASSEMBLY STUBS?
 *   - C calling convention doesn't match CPU interrupt frame
 *   - Need to save ALL registers (not just caller-saved)
 *   - Need to handle error code inconsistency
 *   - IRET instruction requires assembly (no C equivalent)
 *   - Performance: Assembly is faster for register operations
 * 
 * STUB NAMING CONVENTION:
 *   Exception stubs: isr0, isr1, ..., isr31
 *   IRQ stubs: irq32, irq33, ..., irq47
 *   All stubs eventually call isr_common → isr_common_handler (C)
 *
 *=============================================================================
 * END OF DOCUMENTATION - CODE BEGINS BELOW
 *=============================================================================
 */

#include "idt.h"

/*=============================================================================
 * EXTERNAL REFERENCES TO ASSEMBLY STUBS
 *=============================================================================
 * These functions are defined in isr.S and are written in assembly.
 * Each one corresponds to a specific interrupt vector.
 */

/* CPU Exception Handlers (Vectors 0-31) */
extern void isr0(void);   /* #DE - Divide Error */
extern void isr1(void);   /* #DB - Debug Exception */
extern void isr2(void);   /* NMI - Non-Maskable Interrupt */
extern void isr3(void);   /* #BP - Breakpoint */
extern void isr4(void);   /* #OF - Overflow */
extern void isr5(void);   /* #BR - Bound Range Exceeded */
extern void isr6(void);   /* #UD - Invalid Opcode */
extern void isr7(void);   /* #NM - Device Not Available (FPU) */
extern void isr8(void);   /* #DF - Double Fault (PANIC!) */
extern void isr9(void);   /* Coprocessor Segment Overrun (legacy) */
extern void isr10(void);  /* #TS - Invalid TSS */
extern void isr11(void);  /* #NP - Segment Not Present */
extern void isr12(void);  /* #SS - Stack Segment Fault */
extern void isr13(void);  /* #GP - General Protection Fault */
extern void isr14(void);  /* #PF - Page Fault */
extern void isr15(void);  /* Reserved by Intel */
extern void isr16(void);  /* #MF - x87 FPU Floating-Point Error */
extern void isr17(void);  /* #AC - Alignment Check */
extern void isr18(void);  /* #MC - Machine Check (CPU/bus error) */
extern void isr19(void);  /* #XF - SIMD Floating-Point Exception */
extern void isr20(void);  /* #VE - Virtualization Exception */
extern void isr21(void);  /* #CP - Control Protection Exception */
extern void isr22(void);  /* Reserved by Intel */
extern void isr23(void);  /* Reserved by Intel */
extern void isr24(void);  /* Reserved by Intel */
extern void isr25(void);  /* Reserved by Intel */
extern void isr26(void);  /* Reserved by Intel */
extern void isr27(void);  /* Reserved by Intel */
extern void isr28(void);  /* Reserved by Intel */
extern void isr29(void);  /* Reserved by Intel */
extern void isr30(void);  /* #SX - Security Exception */
extern void isr31(void);  /* Reserved by Intel */

/* Hardware IRQ Handlers (Vectors 32-47, after PIC remap) */
extern void irq32(void);  /* IRQ0  - PIT Timer */
extern void irq33(void);  /* IRQ1  - Keyboard */
extern void irq34(void);  /* IRQ2  - Cascade (internal to PIC) */
extern void irq35(void);  /* IRQ3  - COM2/COM4 */
extern void irq36(void);  /* IRQ4  - COM1/COM3 */
extern void irq37(void);  /* IRQ5  - LPT2 */
extern void irq38(void);  /* IRQ6  - Floppy Disk */
extern void irq39(void);  /* IRQ7  - LPT1 */
extern void irq40(void);  /* IRQ8  - RTC (Real-Time Clock) */
extern void irq41(void);  /* IRQ9  - ACPI/Free */
extern void irq42(void);  /* IRQ10 - Free */
extern void irq43(void);  /* IRQ11 - Free */
extern void irq44(void);  /* IRQ12 - PS/2 Mouse */
extern void irq45(void);  /* IRQ13 - FPU (legacy) */
extern void irq46(void);  /* IRQ14 - Primary ATA/IDE */
extern void irq47(void);  /* IRQ15 - Secondary ATA/IDE */

/*=============================================================================
 * STATIC DATA STRUCTURES
 *=============================================================================
 */

/**
 * The IDT itself: 256 entries, each 8 bytes.
 * Total size: 2048 bytes (2 KiB)
 * 
 * Layout: [0-31] CPU exceptions
 *         [32-47] Hardware IRQs (after PIC remap)
 *         [48-255] Unused (available for expansion)
 * 
 * Memory location: .bss section (zero-initialized by bootloader)
 * Lifetime: Entire kernel runtime (never freed)
 */
static struct idt_entry idt[256];

/**
 * IDT Pointer (IDTR) structure.
 * This is what we load into the CPU with the LIDT instruction.
 * 
 * Format:
 *   limit: Size of IDT in bytes - 1 (here: 2048 - 1 = 2047 = 0x7FF)
 *   base:  Linear address of idt[0] (32-bit pointer)
 * 
 * Why "limit - 1"? Historical x86 quirk for compatibility.
 */
static struct idt_ptr idtr;

/*=============================================================================
 * HELPER FUNCTION: idt_set_gate
 *=============================================================================
 * 
 * PURPOSE:
 *   Populate a single IDT entry with a handler function and attributes.
 * 
 * PARAMETERS:
 *   vec   - Interrupt vector number (0-255)
 *   fn    - Pointer to the handler function (from isr.S)
 *   flags - Type and attribute byte (typically 0x8E for kernel interrupt gate)
 * 
 * FLAGS BREAKDOWN (for 0x8E):
 *   Bit 7:    P = 1 (Present, entry is valid)
 *   Bits 6-5: DPL = 00 (Descriptor Privilege Level = kernel/ring 0)
 *   Bit 4:    S = 0 (System segment, not code/data)
 *   Bits 3-0: Type = 1110 (32-bit Interrupt Gate)
 * 
 * CRITICAL NOTE ON SELECTOR:
 *   We use 0x10 (not 0x08) because GRUB's GDT layout is:
 *   - 0x00: Null descriptor
 *   - 0x08: Kernel data segment
 *   - 0x10: Kernel code segment ← THIS ONE!
 * 
 *   Using 0x08 would point to a data segment, causing #GP when interrupt fires!
 * 
 * ASSEMBLY EQUIVALENT:
 *   This function does in C what you might do manually in assembly:
 *   mov eax, [handler_address]
 *   mov [idt_base + vec*8 + 0], ax     ; offset_low
 *   mov [idt_base + vec*8 + 2], 0x10   ; selector
 *   mov [idt_base + vec*8 + 4], 0      ; ist
 *   mov [idt_base + vec*8 + 5], 0x8E   ; type_attr
 *   shr eax, 16
 *   mov [idt_base + vec*8 + 6], ax     ; offset_high
 */
static void idt_set_gate(int vec, void (*fn)(void), uint8_t flags) {
    /* Get 32-bit address of handler function */
    uint32_t addr = (uint32_t)fn;
    
    /* Split address into low 16 bits and high 16 bits */
    idt[vec].offset_low  = (uint16_t)(addr & 0xFFFF);         /* Bits 0-15 */
    idt[vec].offset_high = (uint16_t)((addr >> 16) & 0xFFFF); /* Bits 16-31 */
    
    /* 
     * CRITICAL FIX: Use 0x10 (GRUB's kernel code segment)
     * 
     * This was 0x08 in early versions and caused General Protection Fault.
     * Three days of debugging led to this fix. Always verify your bootloader's
     * GDT layout before hardcoding segment selectors!
     * 
     * How to verify: In QEMU monitor, type "info registers" and check CS.
     */
    idt[vec].selector = 0x10;
    
    /* IST (Interrupt Stack Table) - Not used on i386, must be 0 */
    idt[vec].ist = 0;
    
    /* Type and attributes (Present, DPL, Gate Type) */
    idt[vec].type_attr = flags;
}

/*=============================================================================
 * PUBLIC FUNCTION: idt_init
 *=============================================================================
 * 
 * PURPOSE:
 *   Initialize the entire IDT and load it into the CPU.
 *   This is the main entry point called from kernel_main().
 * 
 * INITIALIZATION STEPS:
 *   1. Zero all 256 IDT entries (paranoid safety)
 *   2. Install handlers for CPU exceptions (vectors 0-31)
 *   3. Install handlers for hardware IRQs (vectors 32-47)
 *   4. Vectors 48-255 remain zeroed (unused)
 *   5. Set up IDTR structure (limit and base address)
 *   6. Load IDTR into CPU with LIDT instruction
 * 
 * WHEN TO CALL:
 *   Call this EARLY in kernel initialization, BEFORE:
 *   - Enabling paging (can cause page faults)
 *   - Enabling interrupts (hardware IRQs will fire)
 *   - Any risky operations (division, memory access, etc.)
 * 
 * WHAT THIS ENABLES:
 *   After this function completes:
 *   ✅ CPU exceptions print error messages (no more triple faults!)
 *   ✅ Hardware interrupts can be safely enabled (STI)
 *   ✅ Timer interrupts work (for scheduling, timing)
 *   ✅ Keyboard interrupts work (for input)
 *   ✅ Page faults are caught and reported (critical for debugging)
 * 
 * RETURN VALUE:
 *   None (void function)
 * 
 * SIDE EFFECTS:
 *   - Modifies global idt[] array
 *   - Modifies global idtr structure
 *   - Loads IDTR into CPU (affects hardware state)
 * 
 * THREAD SAFETY:
 *   Not applicable (single-threaded kernel, no preemption yet)
 * 
 * EXAMPLE USAGE:
 *   void kernel_main(uint32_t magic, uint32_t info_ptr) {
 *       serial_init();        // 1. Enable debugging output
 *       vga_init();           // 2. Enable screen output
 *       idt_init();           // 3. Install interrupt handlers (THIS FUNCTION)
 *       pmm_init(...);        // 4. Initialize memory manager
 *       paging_enable();      // 5. Enable virtual memory (can now fault safely!)
 *       pic_remap();          // 6. Remap IRQs to 32-47
 *       pit_init(100);        // 7. Set timer to 100 Hz
 *       __asm__("sti");       // 8. Enable interrupts (they're now safe!)
 *       for(;;) __asm__("hlt"); // 9. Idle loop
 *   }
 */
void idt_init(void) {
    /*-------------------------------------------------------------------------
     * STEP 1: ZERO ALL ENTRIES (Paranoid Safety)
     *-------------------------------------------------------------------------
     * Although the .bss section should be zero-initialized by the bootloader,
     * we explicitly zero all entries as a defensive programming practice.
     * This ensures no garbage data causes undefined behavior.
     * 
     * Alternative implementation (more explicit):
     *   memset(idt, 0, sizeof(idt));
     * 
     * But we do it manually to avoid depending on libc functions.
     */
    for (int i = 0; i < 256; ++i) {
        idt[i].offset_low  = 0;
        idt[i].selector    = 0;
        idt[i].ist         = 0;
        idt[i].type_attr   = 0;
        idt[i].offset_high = 0;
    }

    /*-------------------------------------------------------------------------
     * STEP 2: INSTALL CPU EXCEPTION HANDLERS (Vectors 0-31)
     *-------------------------------------------------------------------------
     * These are the standard x86 CPU exceptions defined by Intel.
     * All use 0x8E flags:
     *   P=1 (present), DPL=00 (kernel), Type=1110 (interrupt gate)
     * 
     * Note: We install handlers for all 32 vectors, even "Reserved" ones,
     * because undefined behavior might trigger them (better safe than sorry).
     */
    idt_set_gate( 0, isr0,  0x8E);  /* #DE - Divide by Zero */
    idt_set_gate( 1, isr1,  0x8E);  /* #DB - Debug Exception */
    idt_set_gate( 2, isr2,  0x8E);  /* NMI - Non-Maskable Interrupt */
    idt_set_gate( 3, isr3,  0x8E);  /* #BP - Breakpoint (INT 3) */
    idt_set_gate( 4, isr4,  0x8E);  /* #OF - Overflow (INTO) */
    idt_set_gate( 5, isr5,  0x8E);  /* #BR - Bound Range Exceeded */
    idt_set_gate( 6, isr6,  0x8E);  /* #UD - Invalid Opcode */
    idt_set_gate( 7, isr7,  0x8E);  /* #NM - Device Not Available (FPU) */
    idt_set_gate( 8, isr8,  0x8E);  /* #DF - Double Fault (CRITICAL!) */
    idt_set_gate( 9, isr9,  0x8E);  /* Coprocessor Segment Overrun (obsolete) */
    idt_set_gate(10, isr10, 0x8E);  /* #TS - Invalid TSS */
    idt_set_gate(11, isr11, 0x8E);  /* #NP - Segment Not Present */
    idt_set_gate(12, isr12, 0x8E);  /* #SS - Stack Segment Fault */
    idt_set_gate(13, isr13, 0x8E);  /* #GP - General Protection Fault */
    idt_set_gate(14, isr14, 0x8E);  /* #PF - Page Fault (VERY COMMON!) */
    idt_set_gate(15, isr15, 0x8E);  /* Reserved by Intel */
    idt_set_gate(16, isr16, 0x8E);  /* #MF - x87 FPU Exception */
    idt_set_gate(17, isr17, 0x8E);  /* #AC - Alignment Check */
    idt_set_gate(18, isr18, 0x8E);  /* #MC - Machine Check (CPU error) */
    idt_set_gate(19, isr19, 0x8E);  /* #XF - SIMD FP Exception */
    idt_set_gate(20, isr20, 0x8E);  /* #VE - Virtualization Exception */
    idt_set_gate(21, isr21, 0x8E);  /* #CP - Control Protection */
    idt_set_gate(22, isr22, 0x8E);  /* Reserved by Intel */
    idt_set_gate(23, isr23, 0x8E);  /* Reserved by Intel */
    idt_set_gate(24, isr24, 0x8E);  /* Reserved by Intel */
    idt_set_gate(25, isr25, 0x8E);  /* Reserved by Intel */
    idt_set_gate(26, isr26, 0x8E);  /* Reserved by Intel */
    idt_set_gate(27, isr27, 0x8E);  /* Reserved by Intel */
    idt_set_gate(28, isr28, 0x8E);  /* Reserved by Intel */
    idt_set_gate(29, isr29, 0x8E);  /* Reserved by Intel */
    idt_set_gate(30, isr30, 0x8E);  /* #SX - Security Exception */
    idt_set_gate(31, isr31, 0x8E);  /* Reserved by Intel */

    /*-------------------------------------------------------------------------
     * STEP 3: INSTALL HARDWARE IRQ HANDLERS (Vectors 32-47)
     *-------------------------------------------------------------------------
     * These handle hardware interrupts from the 8259 PIC (Programmable
     * Interrupt Controller) after it has been remapped (see pic.c).
     * 
     * Without PIC remapping, these would conflict with CPU exceptions!
     * pic_remap() moves IRQ 0-15 from vectors 0-15 to vectors 32-47.
     * 
     * IRQ MAPPING:
     *   IRQ 0  → Vector 32  (Timer - fires at 100 Hz)
     *   IRQ 1  → Vector 33  (Keyboard)
     *   IRQ 2  → Vector 34  (Cascade from slave PIC)
     *   IRQ 3  → Vector 35  (COM2/COM4)
     *   IRQ 4  → Vector 36  (COM1/COM3)
     *   IRQ 5  → Vector 37  (LPT2)
     *   IRQ 6  → Vector 38  (Floppy Disk)
     *   IRQ 7  → Vector 39  (LPT1)
     *   IRQ 8  → Vector 40  (RTC)
     *   IRQ 9  → Vector 41  (ACPI/Free)
     *   IRQ 10 → Vector 42  (Free)
     *   IRQ 11 → Vector 43  (Free)
     *   IRQ 12 → Vector 44  (PS/2 Mouse)
     *   IRQ 13 → Vector 45  (FPU - legacy)
     *   IRQ 14 → Vector 46  (Primary IDE)
     *   IRQ 15 → Vector 47  (Secondary IDE)
     */
    idt_set_gate(32, irq32, 0x8E);  /* IRQ0  - Timer (most important!) */
    idt_set_gate(33, irq33, 0x8E);  /* IRQ1  - Keyboard */
    idt_set_gate(34, irq34, 0x8E);  /* IRQ2  - PIC cascade */
    idt_set_gate(35, irq35, 0x8E);  /* IRQ3  - COM2/COM4 */
    idt_set_gate(36, irq36, 0x8E);  /* IRQ4  - COM1/COM3 */
    idt_set_gate(37, irq37, 0x8E);  /* IRQ5  - LPT2 */
    idt_set_gate(38, irq38, 0x8E);  /* IRQ6  - Floppy */
    idt_set_gate(39, irq39, 0x8E);  /* IRQ7  - LPT1 */
    idt_set_gate(40, irq40, 0x8E);  /* IRQ8  - RTC */
    idt_set_gate(41, irq41, 0x8E);  /* IRQ9  - ACPI */
    idt_set_gate(42, irq42, 0x8E);  /* IRQ10 - Free */
    idt_set_gate(43, irq43, 0x8E);  /* IRQ11 - Free */
    idt_set_gate(44, irq44, 0x8E);  /* IRQ12 - Mouse */
    idt_set_gate(45, irq45, 0x8E);  /* IRQ13 - FPU */
    idt_set_gate(46, irq46, 0x8E);  /* IRQ14 - Primary IDE */
    idt_set_gate(47, irq47, 0x8E);  /* IRQ15 - Secondary IDE */

    /*
     * Note: Vectors 48-255 remain zeroed (not used in TinyOS currently).
     * These could be used for:
     * - System calls (INT 0x80 style)
     * - Additional hardware devices
     * - Software interrupts
     * - IPI (Inter-Processor Interrupts) in SMP systems
     */

    /*-------------------------------------------------------------------------
     * STEP 4: POPULATE THE IDTR STRUCTURE
     *-------------------------------------------------------------------------
     * The IDTR (IDT Register) is a special CPU register that holds:
     * 1. Base address of the IDT (32-bit linear address)
     * 2. Limit (size in bytes - 1)
     * 
     * Format (48 bits total):
     *   Bits 0-15:  Limit (16 bits)
     *   Bits 16-47: Base (32 bits)
     * 
     * Calculation:
     *   sizeof(idt) = 256 entries × 8 bytes = 2048 bytes
     *   limit = 2048 - 1 = 2047 = 0x7FF
     */
    idtr.limit = (uint16_t)(sizeof(idt) - 1);  /* 2047 = 0x7FF */
    idtr.base  = (uint32_t)&idt[0];            /* Linear address of idt[0] */

    /*-------------------------------------------------------------------------
     * STEP 5: LOAD THE IDTR INTO THE CPU (LIDT Instruction)
     *-------------------------------------------------------------------------
     * The LIDT instruction loads the IDTR register from memory.
     * 
     * Assembly instruction:
     *   lidt [idtr]
     * 
     * What this does:
     * 1. CPU reads 48 bits from memory address 'idtr'
     * 2. CPU loads bits 0-15 into IDTR.limit
     * 3. CPU loads bits 16-47 into IDTR.base
     * 4. From now on, CPU uses this IDT for all interrupts/exceptions
     * 
     * GCC inline assembly breakdown:
     *   __asm__ volatile (
     *       "lidt %0"              // Assembly instruction template
     *       :                      // No outputs
     *       : "m"(idtr)            // Input: memory operand (idtr variable)
     *   );
     * 
     * The 'volatile' keyword tells GCC:
     * - Don't optimize away this instruction
     * - Don't reorder it with other instructions
     * - This has side effects that matter
     * 
     * CRITICAL MOMENT:
     * After this instruction executes, the IDT is ACTIVE. Any exception or
     * interrupt will use our handlers. No turning back!
     */
    __asm__ volatile("lidt %0" : : "m"(idtr));

    /*
     * SUCCESS! The IDT is now installed and active.
     * 
     * What happens next:
     * 1. kernel_main() continues initialization
     * 2. PMM and paging are set up (can now fault safely!)
     * 3. PIC is remapped (IRQs moved to vectors 32-47)
     * 4. PIT is configured (timer set to 100 Hz)
     * 5. STI instruction enables interrupts
     * 6. Timer starts firing (IRQ0 → Vector 32 → irq32 → isr_common_handler)
     * 7. Kernel enters idle loop (HLT instruction, wakes on interrupts)
     */
}

/*=============================================================================
 * END OF FILE: idt.c
 *=============================================================================
 * 
 * WHAT WE ACCOMPLISHED:
 *   ✅ Created a 256-entry IDT (2048 bytes)
 *   ✅ Installed handlers for all 32 CPU exceptions
 *   ✅ Installed handlers for 16 hardware IRQs (after PIC remap)
 *   ✅ Used correct segment selector (0x10) for GRUB compatibility
 *   ✅ Loaded IDT into CPU with LIDT instruction
 *   ✅ Provided comprehensive documentation for learning
 * 
 * WHAT HAPPENS NEXT:
 *   → See interrupts.c for the C-level interrupt handler (isr_common_handler)
 *   → See isr.S for the assembly interrupt stubs
 *   → See pic.c for PIC remapping code
 *   → See pit.c for timer configuration
 *   → See kernel.c for overall initialization sequence
 * 
 * LEARNING RESOURCES:
 *   - Intel Software Developer Manual Volume 3 (System Programming Guide)
 *     Chapters 6 (Interrupts) and 20 (8259 PIC)
 *   - OSDev Wiki: https://wiki.osdev.org/IDT
 *   - OSDev Wiki: https://wiki.osdev.org/Interrupts
 *   - OSDev Wiki: https://wiki.osdev.org/Exceptions
 * 
 * DEBUGGING TIPS:
 *   - Use QEMU's -d int to log all interrupts
 *   - Use QEMU monitor (Ctrl+Alt+2) to inspect registers
 *   - Print "Checkpoint" messages before/after critical steps
 *   - Test with intentional exceptions (divide by zero, page fault)
 *   - Verify GDT layout matches your selector choices
 * 
 * CONGRATULATIONS!
 *   If you understood this file, you now know:
 *   - How x86 interrupt handling works at a low level
 *   - Why operating systems need exception handlers
 *   - How to avoid triple faults in kernel development
 *   - The importance of matching bootloader GDT layouts
 *   - How CPU exceptions and hardware IRQs differ
 * 
 *   You're well on your way to understanding kernel development! 🎉
 *============================================================================*/
